public class bmc extends bli {
   private static final bib.a[] h;
   private final bli i;
   protected String a = "Controls";
   private final bib s;
   public bhw f;
   public long g;
   private bmb t;
   private biy u;

   public bmc(bli var1, bib var2) {
      this.i = var1;
      this.s = var2;
   }

   public void b() {
      this.t = new bmb(this, this.j);
      this.n.add(new biy(200, this.l / 2 - 155 + 160, this.m - 29, 150, 20, cew.a("gui.done")));
      this.u = this.b(new biy(201, this.l / 2 - 155, this.m - 29, 150, 20, cew.a("controls.resetAll")));
      this.a = cew.a("controls.title");
      int var1 = 0;
      bib.a[] var2 = h;
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         bib.a var5 = var2[var4];
         if (var5.a()) {
            this.n.add(new bjq(var5.c(), this.l / 2 - 155 + var1 % 2 * 160, 18 + 24 * (var1 >> 1), var5));
         } else {
            this.n.add(new bjl(var5.c(), this.l / 2 - 155 + var1 % 2 * 160, 18 + 24 * (var1 >> 1), var5, this.s.c(var5)));
         }

         ++var1;
      }

   }

   public void k() {
      super.k();
      this.t.p();
   }

   protected void a(biy var1) {
      if (var1.k == 200) {
         this.j.a(this.i);
      } else if (var1.k == 201) {
         bhw[] var2 = this.j.t.as;
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            bhw var5 = var2[var4];
            var5.b(var5.i());
         }

         bhw.c();
      } else if (var1.k < 100 && var1 instanceof bjl) {
         this.s.a((bib.a)((bjl)var1).c(), 1);
         var1.j = this.s.c(bib.a.a(var1.k));
      }

   }

   protected void a(int var1, int var2, int var3) {
      if (this.f != null) {
         this.s.a(this.f, -100 + var3);
         this.f = null;
         bhw.c();
      } else if (var3 != 0 || !this.t.a(var1, var2, var3)) {
         super.a(var1, var2, var3);
      }

   }

   protected void b(int var1, int var2, int var3) {
      if (var3 != 0 || !this.t.b(var1, var2, var3)) {
         super.b(var1, var2, var3);
      }

   }

   protected void a(char var1, int var2) {
      if (this.f != null) {
         if (var2 == 1) {
            this.s.a((bhw)this.f, 0);
         } else if (var2 != 0) {
            this.s.a(this.f, var2);
         } else if (var1 > 0) {
            this.s.a(this.f, var1 + 256);
         }

         this.f = null;
         this.g = bhz.I();
         bhw.c();
      } else {
         super.a(var1, var2);
      }

   }

   public void a(int var1, int var2, float var3) {
      this.c();
      this.t.a(var1, var2, var3);
      this.a(this.q, this.a, this.l / 2, 8, 16777215);
      boolean var4 = false;
      bhw[] var5 = this.s.as;
      int var6 = var5.length;

      for(int var7 = 0; var7 < var6; ++var7) {
         bhw var8 = var5[var7];
         if (var8.j() != var8.i()) {
            var4 = true;
            break;
         }
      }

      this.u.l = var4;
      super.a(var1, var2, var3);
   }

   static {
      h = new bib.a[]{bib.a.a, bib.a.b, bib.a.y, bib.a.M};
   }
}
