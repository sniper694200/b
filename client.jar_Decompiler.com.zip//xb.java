import java.util.Iterator;
import java.util.List;

public class xb extends xc {
   zt a;
   zt b;
   double c;
   private int d;

   public xb(zt var1, double var2) {
      this.a = var1;
      this.c = var2;
   }

   public boolean a() {
      if (this.a.l() >= 0) {
         return false;
      } else {
         List<zt> var1 = this.a.l.a(this.a.getClass(), this.a.bw().c(8.0D, 4.0D, 8.0D));
         zt var2 = null;
         double var3 = Double.MAX_VALUE;
         Iterator var5 = var1.iterator();

         while(var5.hasNext()) {
            zt var6 = (zt)var5.next();
            if (var6.l() >= 0) {
               double var7 = this.a.h(var6);
               if (!(var7 > var3)) {
                  var3 = var7;
                  var2 = var6;
               }
            }
         }

         if (var2 == null) {
            return false;
         } else if (var3 < 9.0D) {
            return false;
         } else {
            this.b = var2;
            return true;
         }
      }
   }

   public boolean b() {
      if (this.a.l() >= 0) {
         return false;
      } else if (!this.b.aC()) {
         return false;
      } else {
         double var1 = this.a.h(this.b);
         return !(var1 < 9.0D) && !(var1 > 256.0D);
      }
   }

   public void c() {
      this.d = 0;
   }

   public void d() {
      this.b = null;
   }

   public void e() {
      if (--this.d <= 0) {
         this.d = 10;
         this.a.x().a((ve)this.b, this.c);
      }
   }
}
