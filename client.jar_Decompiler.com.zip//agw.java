import com.google.common.collect.Sets;
import java.util.Set;

public class agw extends aho {
   private static final Set<aou> e;
   private static final float[] f;
   private static final float[] n;

   protected agw(ail.a var1) {
      super(var1, e);
      this.b = f[var1.ordinal()];
      this.c = n[var1.ordinal()];
   }

   public float a(ain var1, awr var2) {
      bcx var3 = var2.a();
      return var3 != bcx.d && var3 != bcx.k && var3 != bcx.l ? super.a(var1, var2) : this.a;
   }

   static {
      e = Sets.newHashSet(new aou[]{aov.f, aov.X, aov.r, aov.s, aov.ae, aov.aU, aov.aZ, aov.bk, aov.au, aov.cd, aov.aB});
      f = new float[]{6.0F, 8.0F, 8.0F, 8.0F, 6.0F};
      n = new float[]{-3.2F, -3.2F, -3.1F, -3.0F, -3.0F};
   }
}
