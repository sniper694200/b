import com.google.common.collect.Lists;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class cdi extends cdd {
   private static final Logger g = LogManager.getLogger();
   public final List<String> f;

   public cdi(String... var1) {
      this.f = Lists.newArrayList(var1);
   }

   public void a(cen var1) throws IOException {
      this.c();
      BufferedImage var2 = null;
      Iterator var3 = this.f.iterator();

      while(var3.hasNext()) {
         String var4 = (String)var3.next();
         cem var5 = null;

         try {
            if (var4 != null) {
               var5 = var1.a(new nd(var4));
               BufferedImage var6 = cdr.a(var5.b());
               if (var2 == null) {
                  var2 = new BufferedImage(var6.getWidth(), var6.getHeight(), 2);
               }

               var2.getGraphics().drawImage(var6, 0, 0, (ImageObserver)null);
            }
            continue;
         } catch (IOException var10) {
            g.error("Couldn't load layered image", var10);
         } finally {
            IOUtils.closeQuietly(var5);
         }

         return;
      }

      cdr.a(this.b(), var2);
   }
}
