import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import javax.annotation.Nullable;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class cdn extends cdd implements cdt {
   private static final Logger h = LogManager.getLogger();
   public static final nd f = new nd("missingno");
   public static final nd g = new nd("textures/atlas/blocks.png");
   private final List<cdo> i;
   private final Map<String, cdo> j;
   private final Map<String, cdo> k;
   private final String l;
   private final cdg m;
   private int n;
   private final cdo o;

   public cdn(String var1) {
      this(var1, (cdg)null);
   }

   public cdn(String var1, @Nullable cdg var2) {
      this.i = Lists.newArrayList();
      this.j = Maps.newHashMap();
      this.k = Maps.newHashMap();
      this.o = new cdo("missingno");
      this.l = var1;
      this.m = var2;
   }

   private void g() {
      int[] var1 = cdr.b;
      this.o.b(16);
      this.o.c(16);
      int[][] var2 = new int[this.n + 1][];
      var2[0] = var1;
      this.o.a((List)Lists.newArrayList(new int[][][]{var2}));
   }

   public void a(cen var1) throws IOException {
      if (this.m != null) {
         this.a(var1, this.m);
      }

   }

   public void a(cen var1, cdg var2) {
      this.j.clear();
      var2.a(this);
      this.g();
      this.c();
      this.b(var1);
   }

   public void b(cen var1) {
      int var2 = bhz.B();
      cdl var3 = new cdl(var2, var2, 0, this.n);
      this.k.clear();
      this.i.clear();
      int var4 = Integer.MAX_VALUE;
      int var5 = 1 << this.n;
      Iterator var6 = this.j.entrySet().iterator();

      while(var6.hasNext()) {
         Entry<String, cdo> var7 = (Entry)var6.next();
         cdo var8 = (cdo)var7.getValue();
         nd var9 = this.a(var8);
         cem var10 = null;

         try {
            cdj var11 = cdj.a(var1.a(var9));
            var10 = var1.a(var9);
            boolean var12 = var10.a("animation") != null;
            var8.a(var11, var12);
         } catch (RuntimeException var22) {
            h.error("Unable to parse metadata from {}", var9, var22);
            continue;
         } catch (IOException var23) {
            h.error("Using missing texture, unable to load {}", var9, var23);
            continue;
         } finally {
            IOUtils.closeQuietly(var10);
         }

         var4 = Math.min(var4, Math.min(var8.c(), var8.d()));
         int var30 = Math.min(Integer.lowestOneBit(var8.c()), Integer.lowestOneBit(var8.d()));
         if (var30 < var5) {
            h.warn("Texture {} with size {}x{} limits mip level from {} to {}", var9, var8.c(), var8.d(), ri.e(var5), ri.e(var30));
            var5 = var30;
         }

         var3.a(var8);
      }

      int var25 = Math.min(var4, var5);
      int var26 = ri.e(var25);
      if (var26 < this.n) {
         h.warn("{}: dropping miplevel from {} to {}, because of minimum power of two: {}", this.l, this.n, var26, var25);
         this.n = var26;
      }

      this.o.d(this.n);
      var3.a(this.o);

      try {
         var3.c();
      } catch (cdm var21) {
         throw var21;
      }

      h.info("Created: {}x{} {}-atlas", var3.a(), var3.b(), this.l);
      cdr.a(this.b(), this.n, var3.a(), var3.b());
      Map<String, cdo> var27 = Maps.newHashMap(this.j);
      Iterator var28 = var3.d().iterator();

      while(true) {
         cdo var29;
         do {
            if (!var28.hasNext()) {
               var28 = var27.values().iterator();

               while(var28.hasNext()) {
                  var29 = (cdo)var28.next();
                  var29.a(this.o);
               }

               return;
            }

            var29 = (cdo)var28.next();
         } while(var29 != this.o && !this.a(var1, var29));

         String var31 = var29.i();
         var27.remove(var31);
         this.k.put(var31, var29);

         try {
            cdr.a(var29.a(0), var29.c(), var29.d(), var29.a(), var29.b(), false, false);
         } catch (Throwable var20) {
            b var13 = b.a(var20, "Stitching texture atlas");
            c var14 = var13.a("Texture being stitched together");
            var14.a((String)"Atlas path", (Object)this.l);
            var14.a((String)"Sprite", (Object)var29);
            throw new f(var13);
         }

         if (var29.m()) {
            this.i.add(var29);
         }
      }
   }

   private boolean a(cen var1, final cdo var2) {
      nd var3 = this.a(var2);
      cem var4 = null;

      label62: {
         boolean var6;
         try {
            var4 = var1.a(var3);
            var2.a(var4, this.n + 1);
            break label62;
         } catch (RuntimeException var13) {
            h.error("Unable to parse metadata from {}", var3, var13);
            var6 = false;
            return var6;
         } catch (IOException var14) {
            h.error("Using missing texture, unable to load {}", var3, var14);
            var6 = false;
         } finally {
            IOUtils.closeQuietly(var4);
         }

         return var6;
      }

      try {
         var2.d(this.n);
         return true;
      } catch (Throwable var12) {
         b var16 = b.a(var12, "Applying mipmap");
         c var7 = var16.a("Sprite being mipmapped");
         var7.a("Sprite name", new d<String>() {
            public String a() throws Exception {
               return var2.i();
            }

            // $FF: synthetic method
            public Object call() throws Exception {
               return this.a();
            }
         });
         var7.a("Sprite size", new d<String>() {
            public String a() throws Exception {
               return var2.c() + " x " + var2.d();
            }

            // $FF: synthetic method
            public Object call() throws Exception {
               return this.a();
            }
         });
         var7.a("Sprite frames", new d<String>() {
            public String a() throws Exception {
               return var2.k() + " frames";
            }

            // $FF: synthetic method
            public Object call() throws Exception {
               return this.a();
            }
         });
         var7.a((String)"Mipmap levels", (Object)this.n);
         throw new f(var16);
      }
   }

   private nd a(cdo var1) {
      nd var2 = new nd(var1.i());
      return new nd(var2.b(), String.format("%s/%s%s", this.l, var2.a(), ".png"));
   }

   public cdo a(String var1) {
      cdo var2 = (cdo)this.k.get(var1);
      if (var2 == null) {
         var2 = this.o;
      }

      return var2;
   }

   public void d() {
      cdr.b(this.b());
      Iterator var1 = this.i.iterator();

      while(var1.hasNext()) {
         cdo var2 = (cdo)var1.next();
         var2.j();
      }

   }

   public cdo a(nd var1) {
      if (var1 == null) {
         throw new IllegalArgumentException("Location cannot be null!");
      } else {
         cdo var2 = (cdo)this.j.get(var1);
         if (var2 == null) {
            var2 = cdo.a(var1);
            this.j.put(var1.toString(), var2);
         }

         return var2;
      }
   }

   public void e() {
      this.d();
   }

   public void a(int var1) {
      this.n = var1;
   }

   public cdo f() {
      return this.o;
   }
}
