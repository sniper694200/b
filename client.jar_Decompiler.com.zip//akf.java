import com.google.common.base.Predicate;
import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;

public class akf {
   private static final List<akf.a<ake>> a = Lists.newArrayList();
   private static final List<akf.a<ail>> b = Lists.newArrayList();
   private static final List<ako> c = Lists.newArrayList();
   private static final Predicate<ain> d = new Predicate<ain>() {
      public boolean a(ain var1) {
         Iterator var2 = akf.c.iterator();

         ako var3;
         do {
            if (!var2.hasNext()) {
               return false;
            }

            var3 = (ako)var2.next();
         } while(!var3.a(var1));

         return true;
      }

      // $FF: synthetic method
      public boolean apply(Object var1) {
         return this.a((ain)var1);
      }
   };

   public static boolean a(ain var0) {
      return b(var0) || c(var0);
   }

   protected static boolean b(ain var0) {
      int var1 = 0;

      for(int var2 = b.size(); var1 < var2; ++var1) {
         if (((akf.a)b.get(var1)).b.a(var0)) {
            return true;
         }
      }

      return false;
   }

   protected static boolean c(ain var0) {
      int var1 = 0;

      for(int var2 = a.size(); var1 < var2; ++var1) {
         if (((akf.a)a.get(var1)).b.a(var0)) {
            return true;
         }
      }

      return false;
   }

   public static boolean a(ain var0, ain var1) {
      if (!d.apply(var0)) {
         return false;
      } else {
         return b(var0, var1) || c(var0, var1);
      }
   }

   protected static boolean b(ain var0, ain var1) {
      ail var2 = var0.c();
      int var3 = 0;

      for(int var4 = b.size(); var3 < var4; ++var3) {
         akf.a<ail> var5 = (akf.a)b.get(var3);
         if (var5.a == var2 && var5.b.a(var1)) {
            return true;
         }
      }

      return false;
   }

   protected static boolean c(ain var0, ain var1) {
      ake var2 = akg.d(var0);
      int var3 = 0;

      for(int var4 = a.size(); var3 < var4; ++var3) {
         akf.a<ake> var5 = (akf.a)a.get(var3);
         if (var5.a == var2 && var5.b.a(var1)) {
            return true;
         }
      }

      return false;
   }

   public static ain d(ain var0, ain var1) {
      if (!var1.b()) {
         ake var2 = akg.d(var1);
         ail var3 = var1.c();
         int var4 = 0;

         int var5;
         akf.a var6;
         for(var5 = b.size(); var4 < var5; ++var4) {
            var6 = (akf.a)b.get(var4);
            if (var6.a == var3 && var6.b.a(var0)) {
               return akg.a(new ain((ail)var6.c), var2);
            }
         }

         var4 = 0;

         for(var5 = a.size(); var4 < var5; ++var4) {
            var6 = (akf.a)a.get(var4);
            if (var6.a == var2 && var6.b.a(var0)) {
               return akg.a(new ain(var3), (ake)var6.c);
            }
         }
      }

      return var1;
   }

   public static void a() {
      a(aip.bH);
      a(aip.bI);
      a(aip.bJ);
      a(aip.bH, aip.K, aip.bI);
      a(aip.bI, aip.bL, aip.bJ);
      a(akh.b, aip.bT, akh.c);
      a(akh.b, aip.bE, akh.c);
      a(akh.b, aip.bz, akh.c);
      a(akh.b, aip.bO, akh.c);
      a(akh.b, aip.bM, akh.c);
      a(akh.b, aip.bg, akh.c);
      a(akh.b, aip.bP, akh.c);
      a(akh.b, aip.bb, akh.d);
      a(akh.b, aip.aF, akh.c);
      a(akh.b, aip.bG, akh.e);
      a(akh.e, aip.ch, akh.f);
      a(akh.f, aip.aF, akh.g);
      a(akh.f, aip.bN, akh.h);
      a(akh.g, aip.bN, akh.i);
      a(akh.h, aip.aF, akh.i);
      a(akh.e, aip.bP, akh.m);
      a(akh.m, aip.aF, akh.n);
      a(akh.e, aip.bz, akh.j);
      a(akh.j, aip.aF, akh.k);
      a(akh.j, aip.bb, akh.l);
      a(akh.j, aip.bN, akh.r);
      a(akh.k, aip.bN, akh.s);
      a(akh.r, aip.aF, akh.s);
      a(akh.o, aip.bN, akh.r);
      a(akh.p, aip.bN, akh.s);
      a(akh.e, aip.bg, akh.o);
      a(akh.o, aip.aF, akh.p);
      a(akh.o, aip.bb, akh.q);
      a(akh.e, ako.a(new ain(aip.bc, 1, aie.a.d.a())), akh.t);
      a(akh.t, aip.aF, akh.u);
      a(akh.e, aip.bT, akh.v);
      a(akh.v, aip.bb, akh.w);
      a(akh.v, aip.bN, akh.x);
      a(akh.w, aip.bN, akh.y);
      a(akh.x, aip.bb, akh.y);
      a(akh.z, aip.bN, akh.x);
      a(akh.A, aip.bN, akh.x);
      a(akh.B, aip.bN, akh.y);
      a(akh.e, aip.bM, akh.z);
      a(akh.z, aip.aF, akh.A);
      a(akh.z, aip.bb, akh.B);
      a(akh.e, aip.bE, akh.C);
      a(akh.C, aip.aF, akh.D);
      a(akh.C, aip.bb, akh.E);
      a(akh.e, aip.bO, akh.F);
      a(akh.F, aip.aF, akh.G);
      a(akh.F, aip.bb, akh.H);
      a(akh.b, aip.bN, akh.I);
      a(akh.I, aip.aF, akh.J);
   }

   private static void a(ajb var0, ail var1, ajb var2) {
      b.add(new akf.a(var0, ako.a(var1), var2));
   }

   private static void a(ajb var0) {
      c.add(ako.a(var0));
   }

   private static void a(ake var0, ail var1, ake var2) {
      a(var0, ako.a(var1), var2);
   }

   private static void a(ake var0, ako var1, ake var2) {
      a.add(new akf.a(var0, var1, var2));
   }

   static class a<T> {
      final T a;
      final ako b;
      final T c;

      public a(T var1, ako var2, T var3) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }
   }
}
