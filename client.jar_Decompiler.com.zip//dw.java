import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public class dw extends bi {
   public String c() {
      return "testforblock";
   }

   public int a() {
      return 2;
   }

   public String b(bn var1) {
      return "commands.testforblock.usage";
   }

   public void a(MinecraftServer var1, bn var2, String[] var3) throws ei {
      if (var3.length < 4) {
         throw new ep("commands.testforblock.usage", new Object[0]);
      } else {
         var2.a(bp.a.b, 0);
         et var4 = a(var2, var3, 0, false);
         aou var5 = b(var2, var3[3]);
         if (var5 == null) {
            throw new el("commands.setblock.notFound", new Object[]{var3[3]});
         } else {
            ams var6 = var2.e();
            if (!var6.e(var4)) {
               throw new ei("commands.testforblock.outOfWorld", new Object[0]);
            } else {
               fy var7 = new fy();
               boolean var8 = false;
               if (var3.length >= 6 && var5.l()) {
                  String var9 = a(var3, 5);

                  try {
                     var7 = gp.a(var9);
                     var8 = true;
                  } catch (go var14) {
                     throw new ei("commands.setblock.tagError", new Object[]{var14.getMessage()});
                  }
               }

               awr var15 = var6.o(var4);
               aou var10 = var15.u();
               if (var10 != var5) {
                  throw new ei("commands.testforblock.failed.tile", new Object[]{var4.p(), var4.q(), var4.r(), var10.c(), var5.c()});
               } else if (var3.length >= 5 && !bi.b(var5, var3[4]).apply(var15)) {
                  try {
                     int var16 = var15.u().e(var15);
                     throw new ei("commands.testforblock.failed.data", new Object[]{var4.p(), var4.q(), var4.r(), var16, Integer.parseInt(var3[4])});
                  } catch (NumberFormatException var13) {
                     throw new ei("commands.testforblock.failed.data", new Object[]{var4.p(), var4.q(), var4.r(), var15.toString(), var3[4]});
                  }
               } else {
                  if (var8) {
                     avh var11 = var6.r(var4);
                     if (var11 == null) {
                        throw new ei("commands.testforblock.failed.tileEntity", new Object[]{var4.p(), var4.q(), var4.r()});
                     }

                     fy var12 = var11.b(new fy());
                     if (!gj.a(var7, var12, true)) {
                        throw new ei("commands.testforblock.failed.nbt", new Object[]{var4.p(), var4.q(), var4.r()});
                     }
                  }

                  var2.a(bp.a.b, 1);
                  a(var2, this, "commands.testforblock.success", new Object[]{var4.p(), var4.q(), var4.r()});
               }
            }
         }
      }
   }

   public List<String> a(MinecraftServer var1, bn var2, String[] var3, @Nullable et var4) {
      if (var3.length > 0 && var3.length <= 3) {
         return a(var3, 0, var4);
      } else {
         return var3.length == 4 ? a(var3, aou.h.c()) : Collections.emptyList();
      }
   }
}
