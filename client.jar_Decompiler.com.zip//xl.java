public class xl extends xc {
   private final adw b;
   private adw c;
   private final ams d;
   private int e;
   zm a;

   public xl(adw var1) {
      this.b = var1;
      this.d = var1.l;
      this.a(3);
   }

   public boolean a() {
      if (this.b.l() != 0) {
         return false;
      } else if (this.b.bR().nextInt(500) != 0) {
         return false;
      } else {
         this.a = this.d.ak().a(new et(this.b), 0);
         if (this.a == null) {
            return false;
         } else if (this.f() && this.b.r(true)) {
            ve var1 = this.d.a((Class)adw.class, (bgz)this.b.bw().c(8.0D, 3.0D, 8.0D), (ve)this.b);
            if (var1 == null) {
               return false;
            } else {
               this.c = (adw)var1;
               return this.c.l() == 0 && this.c.r(true);
            }
         } else {
            return false;
         }
      }
   }

   public void c() {
      this.e = 300;
      this.b.p(true);
   }

   public void d() {
      this.a = null;
      this.c = null;
      this.b.p(false);
   }

   public boolean b() {
      return this.e >= 0 && this.f() && this.b.l() == 0 && this.b.r(false);
   }

   public void e() {
      --this.e;
      this.b.t().a(this.c, 10.0F, 30.0F);
      if (this.b.h(this.c) > 2.25D) {
         this.b.x().a((ve)this.c, 0.25D);
      } else if (this.e == 0 && this.c.dm()) {
         this.i();
      }

      if (this.b.bR().nextInt(35) == 0) {
         this.d.a((ve)this.b, (byte)12);
      }

   }

   private boolean f() {
      if (!this.a.i()) {
         return false;
      } else {
         int var1 = (int)((double)((float)this.a.c()) * 0.35D);
         return this.a.e() < var1;
      }
   }

   private void i() {
      adw var1 = this.b.b((vb)this.c);
      this.c.c(6000);
      this.b.c(6000);
      this.c.s(false);
      this.b.s(false);
      var1.c(-24000);
      var1.b(this.b.p, this.b.q, this.b.r, 0.0F, 0.0F);
      this.d.a((ve)var1);
      this.d.a((ve)var1, (byte)12);
   }
}
