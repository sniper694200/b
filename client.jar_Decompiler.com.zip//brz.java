import com.google.common.collect.Sets;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;
import javax.annotation.Nullable;

public class brz extends ams {
   private final brx b;
   private brv c;
   private final Set<ve> K = Sets.newHashSet();
   private final Set<ve> L = Sets.newHashSet();
   private final bhz M = bhz.z();
   private final Set<aml> N = Sets.newHashSet();
   private int O;
   protected Set<aml> a;

   public brz(brx var1, amv var2, int var3, tx var4, rj var5) {
      super(new bfh(), new bfb(var2, "MpServer"), ayl.a(var3).d(), var5, true);
      this.O = this.r.nextInt(12000);
      this.a = Sets.newHashSet();
      this.b = var1;
      this.V().a(var4);
      this.A(new et(8, 64, 8));
      this.s.a((ams)this);
      this.v = this.n();
      this.z = new bfj();
      this.J();
      this.K();
   }

   public void d() {
      super.d();
      this.a(this.R() + 1L);
      if (this.W().b("doDaylightCycle")) {
         this.b(this.S() + 1L);
      }

      this.E.a("reEntryProcessing");

      for(int var1 = 0; var1 < 10 && !this.L.isEmpty(); ++var1) {
         ve var2 = (ve)this.L.iterator().next();
         this.L.remove(var2);
         if (!this.e.contains(var2)) {
            this.a(var2);
         }
      }

      this.E.c("chunkCache");
      this.c.d();
      this.E.c("blocks");
      this.j();
      this.E.b();
   }

   public void a(int var1, int var2, int var3, int var4, int var5, int var6) {
   }

   protected axp n() {
      this.c = new brv(this);
      return this.c;
   }

   protected boolean a(int var1, int var2, boolean var3) {
      return var3 || !this.f().c(var1, var2).f();
   }

   protected void a() {
      this.a.clear();
      int var1 = this.M.t.e;
      this.E.a("buildList");
      int var2 = ri.c(this.M.h.p / 16.0D);
      int var3 = ri.c(this.M.h.r / 16.0D);

      for(int var4 = -var1; var4 <= var1; ++var4) {
         for(int var5 = -var1; var5 <= var1; ++var5) {
            this.a.add(new aml(var4 + var2, var5 + var3));
         }
      }

      this.E.b();
   }

   protected void j() {
      this.a();
      if (this.O > 0) {
         --this.O;
      }

      this.N.retainAll(this.a);
      if (this.N.size() == this.a.size()) {
         this.N.clear();
      }

      int var1 = 0;
      Iterator var2 = this.a.iterator();

      while(var2.hasNext()) {
         aml var3 = (aml)var2.next();
         if (!this.N.contains(var3)) {
            int var4 = var3.a * 16;
            int var5 = var3.b * 16;
            this.E.a("getChunk");
            axu var6 = this.a(var3.a, var3.b);
            this.a(var4, var5, var6);
            this.E.b();
            this.N.add(var3);
            ++var1;
            if (var1 >= 10) {
               return;
            }
         }
      }

   }

   public void b(int var1, int var2, boolean var3) {
      if (var3) {
         this.c.d(var1, var2);
      } else {
         this.c.b(var1, var2);
         this.b(var1 * 16, 0, var2 * 16, var1 * 16 + 15, 256, var2 * 16 + 15);
      }

   }

   public boolean a(ve var1) {
      boolean var2 = super.a(var1);
      this.K.add(var1);
      if (var2) {
         if (var1 instanceof afc) {
            this.M.U().a((cgr)(new cgl((afc)var1)));
         }
      } else {
         this.L.add(var1);
      }

      return var2;
   }

   public void e(ve var1) {
      super.e(var1);
      this.K.remove(var1);
   }

   protected void b(ve var1) {
      super.b(var1);
      if (this.L.contains(var1)) {
         this.L.remove(var1);
      }

   }

   protected void c(ve var1) {
      super.c(var1);
      if (this.K.contains(var1)) {
         if (var1.aC()) {
            this.L.add(var1);
         } else {
            this.K.remove(var1);
         }
      }

   }

   public void a(int var1, ve var2) {
      ve var3 = this.a(var1);
      if (var3 != null) {
         this.e(var3);
      }

      this.K.add(var2);
      var2.h(var1);
      if (!this.a(var2)) {
         this.L.add(var2);
      }

      this.k.a(var1, var2);
   }

   @Nullable
   public ve a(int var1) {
      return (ve)(var1 == this.M.h.S() ? this.M.h : super.a(var1));
   }

   public ve e(int var1) {
      ve var2 = (ve)this.k.d(var1);
      if (var2 != null) {
         this.K.remove(var2);
         this.e(var2);
      }

      return var2;
   }

   @Deprecated
   public boolean b(et var1, awr var2) {
      int var3 = var1.p();
      int var4 = var1.q();
      int var5 = var1.r();
      this.a(var3, var4, var5, var3, var4, var5);
      return super.a((et)var1, (awr)var2, 3);
   }

   public void O() {
      this.b.a().a((hh)(new ho("Quitting")));
   }

   protected void t() {
   }

   protected void a(int var1, int var2, axu var3) {
      super.a(var1, var2, var3);
      if (this.O == 0) {
         this.l = this.l * 3 + 1013904223;
         int var4 = this.l >> 2;
         int var5 = var4 & 15;
         int var6 = var4 >> 8 & 15;
         int var7 = var4 >> 16 & 255;
         et var8 = new et(var5 + var1, var7, var6 + var2);
         awr var9 = var3.a(var8);
         var5 += var1;
         var6 += var2;
         if (var9.a() == bcx.a && this.j(var8) <= this.r.nextInt(8) && this.b(amy.a, var8) <= 0 && this.M.h != null && this.M.h.d((double)var5 + 0.5D, (double)var7 + 0.5D, (double)var6 + 0.5D) > 4.0D) {
            this.a((double)var5 + 0.5D, (double)var7 + 0.5D, (double)var6 + 0.5D, qd.a, qe.i, 0.7F, 0.8F + this.r.nextFloat() * 0.2F, false);
            this.O = this.r.nextInt(12000) + 6000;
         }
      }

   }

   public void b(int var1, int var2, int var3) {
      int var4 = true;
      Random var5 = new Random();
      ain var6 = this.M.h.co();
      boolean var7 = this.M.c.l() == amq.c && !var6.b() && var6.c() == ail.a(aov.cv);
      et.a var8 = new et.a();

      for(int var9 = 0; var9 < 667; ++var9) {
         this.a(var1, var2, var3, 16, var5, var7, var8);
         this.a(var1, var2, var3, 32, var5, var7, var8);
      }

   }

   public void a(int var1, int var2, int var3, int var4, Random var5, boolean var6, et.a var7) {
      int var8 = var1 + this.r.nextInt(var4) - this.r.nextInt(var4);
      int var9 = var2 + this.r.nextInt(var4) - this.r.nextInt(var4);
      int var10 = var3 + this.r.nextInt(var4) - this.r.nextInt(var4);
      var7.c(var8, var9, var10);
      awr var11 = this.o(var7);
      var11.u().a((awr)var11, (ams)this, (et)var7, (Random)var5);
      if (var6 && var11.u() == aov.cv) {
         this.a(fj.J, (double)((float)var8 + 0.5F), (double)((float)var9 + 0.5F), (double)((float)var10 + 0.5F), 0.0D, 0.0D, 0.0D, new int[0]);
      }

   }

   public void c() {
      this.e.removeAll(this.f);

      int var1;
      ve var2;
      int var4;
      for(var1 = 0; var1 < this.f.size(); ++var1) {
         var2 = (ve)this.f.get(var1);
         int var3 = var2.ab;
         var4 = var2.ad;
         if (var2.aa && this.a(var3, var4, true)) {
            this.a(var3, var4).b(var2);
         }
      }

      for(var1 = 0; var1 < this.f.size(); ++var1) {
         this.c((ve)this.f.get(var1));
      }

      this.f.clear();

      for(var1 = 0; var1 < this.e.size(); ++var1) {
         var2 = (ve)this.e.get(var1);
         ve var6 = var2.bJ();
         if (var6 != null) {
            if (!var6.F && var6.w(var2)) {
               continue;
            }

            var2.o();
         }

         if (var2.F) {
            var4 = var2.ab;
            int var5 = var2.ad;
            if (var2.aa && this.a(var4, var5, true)) {
               this.a(var4, var5).b(var2);
            }

            this.e.remove(var1--);
            this.c(var2);
         }
      }

   }

   public c a(b var1) {
      c var2 = super.a(var1);
      var2.a("Forced entities", new d<String>() {
         public String a() {
            return brz.this.K.size() + " total; " + brz.this.K;
         }

         // $FF: synthetic method
         public Object call() throws Exception {
            return this.a();
         }
      });
      var2.a("Retry entities", new d<String>() {
         public String a() {
            return brz.this.L.size() + " total; " + brz.this.L;
         }

         // $FF: synthetic method
         public Object call() throws Exception {
            return this.a();
         }
      });
      var2.a("Server brand", new d<String>() {
         public String a() throws Exception {
            return brz.this.M.h.C();
         }

         // $FF: synthetic method
         public Object call() throws Exception {
            return this.a();
         }
      });
      var2.a("Server type", new d<String>() {
         public String a() throws Exception {
            return brz.this.M.F() == null ? "Non-integrated multiplayer server" : "Integrated singleplayer server";
         }

         // $FF: synthetic method
         public Object call() throws Exception {
            return this.a();
         }
      });
      return var2;
   }

   public void a(@Nullable aeb var1, double var2, double var4, double var6, qc var8, qe var9, float var10, float var11) {
      if (var1 == this.M.h) {
         this.a(var2, var4, var6, var8, var9, var10, var11, false);
      }

   }

   public void a(et var1, qc var2, qe var3, float var4, float var5, boolean var6) {
      this.a((double)var1.p() + 0.5D, (double)var1.q() + 0.5D, (double)var1.r() + 0.5D, var2, var3, var4, var5, var6);
   }

   public void a(double var1, double var3, double var5, qc var7, qe var8, float var9, float var10, boolean var11) {
      double var12 = this.M.aa().d(var1, var3, var5);
      cgn var14 = new cgn(var7, var8, var9, var10, (float)var1, (float)var3, (float)var5);
      if (var11 && var12 > 100.0D) {
         double var15 = Math.sqrt(var12) / 40.0D;
         this.M.U().a(var14, (int)(var15 * 20.0D));
      } else {
         this.M.U().a((cgr)var14);
      }

   }

   public void a(double var1, double var3, double var5, double var7, double var9, double var11, @Nullable fy var13) {
      this.M.j.a((btd)(new bss.c(this, var1, var3, var5, var7, var9, var11, this.M.j, var13)));
   }

   public void a(ht<?> var1) {
      this.b.a(var1);
   }

   public void a(bhi var1) {
      this.F = var1;
   }

   public void b(long var1) {
      if (var1 < 0L) {
         var1 = -var1;
         this.W().a("doDaylightCycle", "false");
      } else {
         this.W().a("doDaylightCycle", "true");
      }

      super.b(var1);
   }

   public brv f() {
      return (brv)super.B();
   }

   // $FF: synthetic method
   public axp B() {
      return this.f();
   }
}
