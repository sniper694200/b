import java.io.IOException;

public class jj implements ht<hw> {
   protected int a;
   protected int b;
   protected int c;
   protected int d;
   protected byte e;
   protected byte f;
   protected boolean g;
   protected boolean h;

   public jj() {
   }

   public jj(int var1) {
      this.a = var1;
   }

   public void a(gy var1) throws IOException {
      this.a = var1.g();
   }

   public void b(gy var1) throws IOException {
      var1.d(this.a);
   }

   public void a(hw var1) {
      var1.a(this);
   }

   public String toString() {
      return "Entity_" + super.toString();
   }

   public ve a(ams var1) {
      return var1.a(this.a);
   }

   public int a() {
      return this.b;
   }

   public int b() {
      return this.c;
   }

   public int c() {
      return this.d;
   }

   public byte d() {
      return this.e;
   }

   public byte e() {
      return this.f;
   }

   public boolean f() {
      return this.h;
   }

   public boolean g() {
      return this.g;
   }

   public static class c extends jj {
      public c() {
         this.h = true;
      }

      public c(int var1, byte var2, byte var3, boolean var4) {
         super(var1);
         this.e = var2;
         this.f = var3;
         this.h = true;
         this.g = var4;
      }

      public void a(gy var1) throws IOException {
         super.a(var1);
         this.e = var1.readByte();
         this.f = var1.readByte();
         this.g = var1.readBoolean();
      }

      public void b(gy var1) throws IOException {
         super.b(var1);
         var1.writeByte(this.e);
         var1.writeByte(this.f);
         var1.writeBoolean(this.g);
      }
   }

   public static class a extends jj {
      public a() {
      }

      public a(int var1, long var2, long var4, long var6, boolean var8) {
         super(var1);
         this.b = (int)var2;
         this.c = (int)var4;
         this.d = (int)var6;
         this.g = var8;
      }

      public void a(gy var1) throws IOException {
         super.a(var1);
         this.b = var1.readShort();
         this.c = var1.readShort();
         this.d = var1.readShort();
         this.g = var1.readBoolean();
      }

      public void b(gy var1) throws IOException {
         super.b(var1);
         var1.writeShort(this.b);
         var1.writeShort(this.c);
         var1.writeShort(this.d);
         var1.writeBoolean(this.g);
      }
   }

   public static class b extends jj {
      public b() {
         this.h = true;
      }

      public b(int var1, long var2, long var4, long var6, byte var8, byte var9, boolean var10) {
         super(var1);
         this.b = (int)var2;
         this.c = (int)var4;
         this.d = (int)var6;
         this.e = var8;
         this.f = var9;
         this.g = var10;
         this.h = true;
      }

      public void a(gy var1) throws IOException {
         super.a(var1);
         this.b = var1.readShort();
         this.c = var1.readShort();
         this.d = var1.readShort();
         this.e = var1.readByte();
         this.f = var1.readByte();
         this.g = var1.readBoolean();
      }

      public void b(gy var1) throws IOException {
         super.b(var1);
         var1.writeShort(this.b);
         var1.writeShort(this.c);
         var1.writeShort(this.d);
         var1.writeByte(this.e);
         var1.writeByte(this.f);
         var1.writeBoolean(this.g);
      }
   }
}
