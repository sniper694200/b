public class btl extends btd {
   float a;

   protected btl(ams var1, double var2, double var4, double var6, double var8, double var10, double var12) {
      this(var1, var2, var4, var6, var8, var10, var12, 1.0F);
   }

   protected btl(ams var1, double var2, double var4, double var6, double var8, double var10, double var12, float var14) {
      super(var1, var2, var4, var6, var8, var10, var12);
      this.j *= 0.10000000149011612D;
      this.k *= 0.10000000149011612D;
      this.l *= 0.10000000149011612D;
      this.j += var8;
      this.k += var10;
      this.l += var12;
      float var15 = 1.0F - (float)(Math.random() * 0.30000001192092896D);
      this.A = var15;
      this.B = var15;
      this.C = var15;
      this.y *= 0.75F;
      this.y *= var14;
      this.a = this.y;
      this.x = (int)(8.0D / (Math.random() * 0.8D + 0.2D));
      this.x = (int)((float)this.x * var14);
   }

   public void a(bui var1, ve var2, float var3, float var4, float var5, float var6, float var7, float var8) {
      float var9 = ((float)this.w + var3) / (float)this.x * 32.0F;
      var9 = ri.a(var9, 0.0F, 1.0F);
      this.y = this.a * var9;
      super.a(var1, var2, var3, var4, var5, var6, var7, var8);
   }

   public void a() {
      this.d = this.g;
      this.e = this.h;
      this.f = this.i;
      if (this.w++ >= this.x) {
         this.i();
      }

      this.b(7 - this.w * 8 / this.x);
      this.k -= 0.03D;
      this.a(this.j, this.k, this.l);
      this.j *= 0.9900000095367432D;
      this.k *= 0.9900000095367432D;
      this.l *= 0.9900000095367432D;
      if (this.m) {
         this.j *= 0.699999988079071D;
         this.l *= 0.699999988079071D;
      }

   }

   public static class a implements btf {
      public btd a(int var1, ams var2, double var3, double var5, double var7, double var9, double var11, double var13, int... var15) {
         return new btl(var2, var3, var5, var7, var9, var11, var13);
      }
   }
}
