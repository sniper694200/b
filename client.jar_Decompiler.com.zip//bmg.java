import io.netty.buffer.Unpooled;
import java.util.Iterator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class bmg extends bme {
   private static final Logger v = LogManager.getLogger();
   private static final nd w = new nd("textures/gui/container/beacon.png");
   private final tt x;
   private bmg.b y;
   private boolean z;

   public bmg(aea var1, tt var2) {
      super(new afr(var1, var2));
      this.x = var2;
      this.f = 230;
      this.g = 219;
   }

   public void b() {
      super.b();
      this.y = new bmg.b(-1, this.i + 164, this.s + 107);
      this.n.add(this.y);
      this.n.add(new bmg.a(-2, this.i + 190, this.s + 107));
      this.z = true;
      this.y.l = false;
   }

   public void e() {
      super.e();
      int var1 = this.x.c(0);
      ux var2 = ux.a(this.x.c(1));
      ux var3 = ux.a(this.x.c(2));
      if (this.z && var1 >= 0) {
         this.z = false;
         int var4 = 100;

         int var6;
         int var7;
         int var8;
         ux var9;
         bmg.c var10;
         for(int var5 = 0; var5 <= 2; ++var5) {
            var6 = avf.a[var5].length;
            var7 = var6 * 22 + (var6 - 1) * 2;

            for(var8 = 0; var8 < var6; ++var8) {
               var9 = avf.a[var5][var8];
               var10 = new bmg.c(var4++, this.i + 76 + var8 * 24 - var7 / 2, this.s + 22 + var5 * 25, var9, var5);
               this.n.add(var10);
               if (var5 >= var1) {
                  var10.l = false;
               } else if (var9 == var2) {
                  var10.b(true);
               }
            }
         }

         int var11 = true;
         var6 = avf.a[3].length + 1;
         var7 = var6 * 22 + (var6 - 1) * 2;

         for(var8 = 0; var8 < var6 - 1; ++var8) {
            var9 = avf.a[3][var8];
            var10 = new bmg.c(var4++, this.i + 167 + var8 * 24 - var7 / 2, this.s + 47, var9, 3);
            this.n.add(var10);
            if (3 >= var1) {
               var10.l = false;
            } else if (var9 == var3) {
               var10.b(true);
            }
         }

         if (var2 != null) {
            bmg.c var12 = new bmg.c(var4++, this.i + 167 + (var6 - 1) * 24 - var7 / 2, this.s + 47, var2, 3);
            this.n.add(var12);
            if (3 >= var1) {
               var12.l = false;
            } else if (var2 == var3) {
               var12.b(true);
            }
         }
      }

      this.y.l = !this.x.a(0).b() && var2 != null;
   }

   protected void a(biy var1) {
      if (var1.k == -2) {
         this.j.h.d.a((ht)(new lg(this.j.h.by.d)));
         this.j.a((bli)null);
      } else if (var1.k == -1) {
         String var2 = "MC|Beacon";
         gy var3 = new gy(Unpooled.buffer());
         var3.writeInt(this.x.c(1));
         var3.writeInt(this.x.c(2));
         this.j.v().a((ht)(new lh("MC|Beacon", var3)));
         this.j.h.d.a((ht)(new lg(this.j.h.by.d)));
         this.j.a((bli)null);
      } else if (var1 instanceof bmg.c) {
         bmg.c var4 = (bmg.c)var1;
         if (var4.c()) {
            return;
         }

         int var5 = ux.a(var4.p);
         if (var4.q < 3) {
            this.x.b(1, var5);
         } else {
            this.x.b(2, var5);
         }

         this.n.clear();
         this.b();
         this.e();
      }

   }

   public void a(int var1, int var2, float var3) {
      this.c();
      super.a(var1, var2, var3);
      this.b(var1, var2);
   }

   protected void c(int var1, int var2) {
      bhx.a();
      this.a(this.q, cew.a("tile.beacon.primary"), 62, 10, 14737632);
      this.a(this.q, cew.a("tile.beacon.secondary"), 169, 10, 14737632);
      Iterator var3 = this.n.iterator();

      while(var3.hasNext()) {
         biy var4 = (biy)var3.next();
         if (var4.a()) {
            var4.b(var1 - this.i, var2 - this.s);
            break;
         }
      }

      bhx.c();
   }

   protected void a(float var1, int var2, int var3) {
      buq.c(1.0F, 1.0F, 1.0F, 1.0F);
      this.j.N().a(w);
      int var4 = (this.l - this.f) / 2;
      int var5 = (this.m - this.g) / 2;
      this.b(var4, var5, 0, 0, this.f, this.g);
      this.k.a = 100.0F;
      this.k.b(new ain(aip.bZ), var4 + 42, var5 + 109);
      this.k.b(new ain(aip.l), var4 + 42 + 22, var5 + 109);
      this.k.b(new ain(aip.n), var4 + 42 + 44, var5 + 109);
      this.k.b(new ain(aip.m), var4 + 42 + 66, var5 + 109);
      this.k.a = 0.0F;
   }

   class a extends bmg.d {
      public a(int var2, int var3, int var4) {
         super(var2, var3, var4, bmg.w, 112, 220);
      }

      public void b(int var1, int var2) {
         bmg.this.a(cew.a("gui.cancel"), var1, var2);
      }
   }

   class b extends bmg.d {
      public b(int var2, int var3, int var4) {
         super(var2, var3, var4, bmg.w, 90, 220);
      }

      public void b(int var1, int var2) {
         bmg.this.a(cew.a("gui.done"), var1, var2);
      }
   }

   class c extends bmg.d {
      private final ux p;
      private final int q;

      public c(int var2, int var3, int var4, ux var5, int var6) {
         super(var2, var3, var4, bme.a, var5.d() % 8 * 18, 198 + var5.d() / 8 * 18);
         this.p = var5;
         this.q = var6;
      }

      public void b(int var1, int var2) {
         String var3 = cew.a(this.p.a());
         if (this.q >= 3 && this.p != uz.j) {
            var3 = var3 + " II";
         }

         bmg.this.a(var3, var1, var2);
      }
   }

   static class d extends biy {
      private final nd o;
      private final int p;
      private final int q;
      private boolean r;

      protected d(int var1, int var2, int var3, nd var4, int var5, int var6) {
         super(var1, var2, var3, 22, 22, "");
         this.o = var4;
         this.p = var5;
         this.q = var6;
      }

      public void a(bhz var1, int var2, int var3, float var4) {
         if (this.m) {
            var1.N().a(bmg.w);
            buq.c(1.0F, 1.0F, 1.0F, 1.0F);
            this.n = var2 >= this.h && var3 >= this.i && var2 < this.h + this.f && var3 < this.i + this.g;
            int var5 = true;
            int var6 = 0;
            if (!this.l) {
               var6 += this.f * 2;
            } else if (this.r) {
               var6 += this.f * 1;
            } else if (this.n) {
               var6 += this.f * 3;
            }

            this.b(this.h, this.i, var6, 219, this.f, this.g);
            if (!bmg.w.equals(this.o)) {
               var1.N().a(this.o);
            }

            this.b(this.h + 2, this.i + 2, this.p, this.q, 18, 18);
         }
      }

      public boolean c() {
         return this.r;
      }

      public void b(boolean var1) {
         this.r = var1;
      }
   }
}
