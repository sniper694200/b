import java.util.Iterator;

public class agh implements tt {
   private final amd a;
   private final fi<ain> b;
   private final aeb c;
   private ame d;
   private int e;

   public agh(aeb var1, amd var2) {
      this.b = fi.a(3, ain.a);
      this.c = var1;
      this.a = var2;
   }

   public int w_() {
      return this.b.size();
   }

   public boolean x_() {
      Iterator var1 = this.b.iterator();

      ain var2;
      do {
         if (!var1.hasNext()) {
            return true;
         }

         var2 = (ain)var1.next();
      } while(var2.b());

      return false;
   }

   public ain a(int var1) {
      return (ain)this.b.get(var1);
   }

   public ain a(int var1, int var2) {
      ain var3 = (ain)this.b.get(var1);
      if (var1 == 2 && !var3.b()) {
         return tu.a(this.b, var1, var3.E());
      } else {
         ain var4 = tu.a(this.b, var1, var2);
         if (!var4.b() && this.e(var1)) {
            this.i();
         }

         return var4;
      }
   }

   private boolean e(int var1) {
      return var1 == 0 || var1 == 1;
   }

   public ain c_(int var1) {
      return tu.a(this.b, var1);
   }

   public void a(int var1, ain var2) {
      this.b.set(var1, var2);
      if (!var2.b() && var2.E() > this.z_()) {
         var2.e(this.z_());
      }

      if (this.e(var1)) {
         this.i();
      }

   }

   public String h_() {
      return "mob.villager";
   }

   public boolean n_() {
      return false;
   }

   public hh i_() {
      return (hh)(this.n_() ? new ho(this.h_()) : new hp(this.h_(), new Object[0]));
   }

   public int z_() {
      return 64;
   }

   public boolean a(aeb var1) {
      return this.a.t_() == var1;
   }

   public void b(aeb var1) {
   }

   public void c(aeb var1) {
   }

   public boolean b(int var1, ain var2) {
      return true;
   }

   public void y_() {
      this.i();
   }

   public void i() {
      this.d = null;
      ain var1 = (ain)this.b.get(0);
      ain var2 = (ain)this.b.get(1);
      if (var1.b()) {
         var1 = var2;
         var2 = ain.a;
      }

      if (var1.b()) {
         this.a(2, ain.a);
      } else {
         amf var3 = this.a.b_(this.c);
         if (var3 != null) {
            ame var4 = var3.a(var1, var2, this.e);
            if (var4 != null && !var4.h()) {
               this.d = var4;
               this.a(2, var4.d().l());
            } else if (!var2.b()) {
               var4 = var3.a(var2, var1, this.e);
               if (var4 != null && !var4.h()) {
                  this.d = var4;
                  this.a(2, var4.d().l());
               } else {
                  this.a(2, ain.a);
               }
            } else {
               this.a(2, ain.a);
            }
         }

         this.a.a(this.a(2));
      }

   }

   public ame j() {
      return this.d;
   }

   public void d(int var1) {
      this.e = var1;
      this.i();
   }

   public int c(int var1) {
      return 0;
   }

   public void b(int var1, int var2) {
   }

   public int h() {
      return 0;
   }

   public void m() {
      this.b.clear();
   }
}
