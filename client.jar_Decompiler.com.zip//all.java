public class all extends rq.a {
   public final ali b;
   public final int c;

   public all(ali var1, int var2) {
      super(var1.e().a());
      this.b = var1;
      this.c = var2;
   }
}
