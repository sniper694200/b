public class aun extends aou {
   public static final axd a = axd.a("explode");

   public aun() {
      super(bcx.u);
      this.w(this.A.b().a(a, false));
      this.a(ahn.d);
   }

   public void c(ams var1, et var2, awr var3) {
      super.c(var1, var2, var3);
      if (var1.y(var2)) {
         this.d(var1, var2, var3.a(a, true));
         var1.g(var2);
      }

   }

   public void a(awr var1, ams var2, et var3, aou var4, et var5) {
      if (var2.y(var3)) {
         this.d(var2, var3, var1.a(a, true));
         var2.g(var3);
      }

   }

   public void a(ams var1, et var2, amn var3) {
      if (!var1.G) {
         ack var4 = new ack(var1, (double)((float)var2.p() + 0.5F), (double)var2.q(), (double)((float)var2.r() + 0.5F), var3.c());
         var4.a((short)(var1.r.nextInt(var4.l() / 4) + var4.l() / 8));
         var1.a((ve)var4);
      }
   }

   public void d(ams var1, et var2, awr var3) {
      this.a(var1, var2, var3, (vn)null);
   }

   public void a(ams var1, et var2, awr var3, vn var4) {
      if (!var1.G) {
         if ((Boolean)var3.c(a)) {
            ack var5 = new ack(var1, (double)((float)var2.p() + 0.5F), (double)var2.q(), (double)((float)var2.r() + 0.5F), var4);
            var1.a((ve)var5);
            var1.a((aeb)null, var5.p, var5.q, var5.r, qd.hW, qe.e, 1.0F, 1.0F);
         }

      }
   }

   public boolean a(ams var1, et var2, awr var3, aeb var4, tz var5, fa var6, float var7, float var8, float var9) {
      ain var10 = var4.b((tz)var5);
      if (!var10.b() && (var10.c() == aip.e || var10.c() == aip.bW)) {
         this.a(var1, var2, var3.a(a, true), (vn)var4);
         var1.a((et)var2, (awr)aov.a.t(), 11);
         if (var10.c() == aip.e) {
            var10.a(1, var4);
         } else if (!var4.bO.d) {
            var10.g(1);
         }

         return true;
      } else {
         return super.a(var1, var2, var3, var4, var5, var6, var7, var8, var9);
      }
   }

   public void a(ams var1, et var2, awr var3, ve var4) {
      if (!var1.G && var4 instanceof aef) {
         aef var5 = (aef)var4;
         if (var5.aR()) {
            this.a(var1, var2, var1.o(var2).a(a, true), var5.e instanceof vn ? (vn)var5.e : null);
            var1.g(var2);
         }
      }

   }

   public boolean a(amn var1) {
      return false;
   }

   public awr a(int var1) {
      return this.t().a(a, (var1 & 1) > 0);
   }

   public int e(awr var1) {
      return (Boolean)var1.c(a) ? 1 : 0;
   }

   protected aws b() {
      return new aws(this, new axh[]{a});
   }
}
