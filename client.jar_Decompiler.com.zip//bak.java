import java.util.Random;

public class bak extends aze {
   private static final awr a;
   private static final awr b;

   public bak() {
      super(false);
   }

   public boolean b(ams var1, Random var2, et var3) {
      int var4 = var2.nextInt(5) + 7;
      int var5 = var4 - var2.nextInt(2) - 3;
      int var6 = var4 - var5;
      int var7 = 1 + var2.nextInt(var6 + 1);
      if (var3.q() >= 1 && var3.q() + var4 + 1 <= 256) {
         boolean var8 = true;

         int var12;
         int var13;
         int var18;
         for(int var9 = var3.q(); var9 <= var3.q() + 1 + var4 && var8; ++var9) {
            int var10 = true;
            if (var9 - var3.q() < var5) {
               var18 = 0;
            } else {
               var18 = var7;
            }

            et.a var11 = new et.a();

            for(var12 = var3.p() - var18; var12 <= var3.p() + var18 && var8; ++var12) {
               for(var13 = var3.r() - var18; var13 <= var3.r() + var18 && var8; ++var13) {
                  if (var9 >= 0 && var9 < 256) {
                     if (!this.a(var1.o(var11.c(var12, var9, var13)).u())) {
                        var8 = false;
                     }
                  } else {
                     var8 = false;
                  }
               }
            }
         }

         if (!var8) {
            return false;
         } else {
            aou var17 = var1.o(var3.b()).u();
            if ((var17 == aov.c || var17 == aov.d) && var3.q() < 256 - var4 - 1) {
               this.a(var1, var3.b());
               var18 = 0;

               int var19;
               for(var19 = var3.q() + var4; var19 >= var3.q() + var5; --var19) {
                  for(var12 = var3.p() - var18; var12 <= var3.p() + var18; ++var12) {
                     var13 = var12 - var3.p();

                     for(int var14 = var3.r() - var18; var14 <= var3.r() + var18; ++var14) {
                        int var15 = var14 - var3.r();
                        if (Math.abs(var13) != var18 || Math.abs(var15) != var18 || var18 <= 0) {
                           et var16 = new et(var12, var19, var14);
                           if (!var1.o(var16).b()) {
                              this.a(var1, var16, b);
                           }
                        }
                     }
                  }

                  if (var18 >= 1 && var19 == var3.q() + var5 + 1) {
                     --var18;
                  } else if (var18 < var7) {
                     ++var18;
                  }
               }

               for(var19 = 0; var19 < var4 - 1; ++var19) {
                  bcx var20 = var1.o(var3.b(var19)).a();
                  if (var20 == bcx.a || var20 == bcx.j) {
                     this.a(var1, var3.b(var19), a);
                  }
               }

               return true;
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   static {
      a = aov.r.t().a(asm.b, asp.a.b);
      b = aov.t.t().a(asl.e, asp.a.b).a(arp.b, false);
   }
}
