public class ayu {
   private static final awr a;
   private final char[] b = new char[65536];

   public awr a(int var1, int var2, int var3) {
      awr var4 = (awr)aou.i.a(this.b[b(var1, var2, var3)]);
      return var4 == null ? a : var4;
   }

   public void a(int var1, int var2, int var3, awr var4) {
      this.b[b(var1, var2, var3)] = (char)aou.i.a(var4);
   }

   private static int b(int var0, int var1, int var2) {
      return var0 << 12 | var2 << 8 | var1;
   }

   public int a(int var1, int var2) {
      int var3 = (var1 << 12 | var2 << 8) + 256 - 1;

      for(int var4 = 255; var4 >= 0; --var4) {
         awr var5 = (awr)aou.i.a(this.b[var3 + var4]);
         if (var5 != null && var5 != a) {
            return var4;
         }
      }

      return 0;
   }

   static {
      a = aov.a.t();
   }
}
