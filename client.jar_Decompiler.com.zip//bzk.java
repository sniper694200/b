public class bzk extends bze<acd> {
   private static final nd a = new nd("textures/particle/particles.png");

   public bzk(bzd var1) {
      super(var1);
   }

   public void a(acd var1, double var2, double var4, double var6, float var8, float var9) {
      aeb var10 = var1.l();
      if (var10 != null && !this.e) {
         buq.G();
         buq.c((float)var2, (float)var4, (float)var6);
         buq.D();
         buq.b(0.5F, 0.5F, 0.5F);
         this.d(var1);
         bvc var11 = bvc.a();
         bui var12 = var11.c();
         int var13 = true;
         int var14 = true;
         float var15 = 0.0625F;
         float var16 = 0.125F;
         float var17 = 0.125F;
         float var18 = 0.1875F;
         float var19 = 1.0F;
         float var20 = 0.5F;
         float var21 = 0.5F;
         buq.b(180.0F - this.b.e, 0.0F, 1.0F, 0.0F);
         buq.b((float)(this.b.g.aw == 2 ? -1 : 1) * -this.b.f, 1.0F, 0.0F, 0.0F);
         if (this.e) {
            buq.h();
            buq.e(this.c(var1));
         }

         var12.a(7, cdw.j);
         var12.b(-0.5D, -0.5D, 0.0D).a(0.0625D, 0.1875D).c(0.0F, 1.0F, 0.0F).d();
         var12.b(0.5D, -0.5D, 0.0D).a(0.125D, 0.1875D).c(0.0F, 1.0F, 0.0F).d();
         var12.b(0.5D, 0.5D, 0.0D).a(0.125D, 0.125D).c(0.0F, 1.0F, 0.0F).d();
         var12.b(-0.5D, 0.5D, 0.0D).a(0.0625D, 0.125D).c(0.0F, 1.0F, 0.0F).d();
         var11.b();
         if (this.e) {
            buq.n();
            buq.i();
         }

         buq.E();
         buq.H();
         int var22 = var10.cF() == vm.b ? 1 : -1;
         ain var23 = var10.co();
         if (var23.c() != aip.aZ) {
            var22 = -var22;
         }

         float var24 = var10.l(var9);
         float var25 = ri.a(ri.c(var24) * 3.1415927F);
         float var26 = (var10.aO + (var10.aN - var10.aO) * var9) * 0.017453292F;
         double var27 = (double)ri.a(var26);
         double var29 = (double)ri.b(var26);
         double var31 = (double)var22 * 0.35D;
         double var33 = 0.8D;
         double var35;
         double var37;
         double var39;
         double var41;
         if ((this.b.g == null || this.b.g.aw <= 0) && var10 == bhz.z().h) {
            float var43 = this.b.g.aD;
            var43 /= 100.0F;
            bhc var44 = new bhc((double)var22 * -0.36D * (double)var43, -0.045D * (double)var43, 0.4D);
            var44 = var44.a(-(var10.y + (var10.w - var10.y) * var9) * 0.017453292F);
            var44 = var44.b(-(var10.x + (var10.v - var10.x) * var9) * 0.017453292F);
            var44 = var44.b(var25 * 0.5F);
            var44 = var44.a(-var25 * 0.7F);
            var35 = var10.m + (var10.p - var10.m) * (double)var9 + var44.b;
            var37 = var10.n + (var10.q - var10.n) * (double)var9 + var44.c;
            var39 = var10.o + (var10.r - var10.o) * (double)var9 + var44.d;
            var41 = (double)var10.by();
         } else {
            var35 = var10.m + (var10.p - var10.m) * (double)var9 - var29 * var31 - var27 * 0.8D;
            var37 = var10.n + (double)var10.by() + (var10.q - var10.n) * (double)var9 - 0.45D;
            var39 = var10.o + (var10.r - var10.o) * (double)var9 - var27 * var31 + var29 * 0.8D;
            var41 = var10.aU() ? -0.1875D : 0.0D;
         }

         double var58 = var1.m + (var1.p - var1.m) * (double)var9;
         double var45 = var1.n + (var1.q - var1.n) * (double)var9 + 0.25D;
         double var47 = var1.o + (var1.r - var1.o) * (double)var9;
         double var49 = (double)((float)(var35 - var58));
         double var51 = (double)((float)(var37 - var45)) + var41;
         double var53 = (double)((float)(var39 - var47));
         buq.z();
         buq.g();
         var12.a(3, cdw.f);
         int var55 = true;

         for(int var56 = 0; var56 <= 16; ++var56) {
            float var57 = (float)var56 / 16.0F;
            var12.b(var2 + var49 * (double)var57, var4 + var51 * (double)(var57 * var57 + var57) * 0.5D + 0.25D, var6 + var53 * (double)var57).b(0, 0, 0, 255).d();
         }

         var11.b();
         buq.f();
         buq.y();
         super.a(var1, var2, var4, var6, var8, var9);
      }
   }

   protected nd a(acd var1) {
      return a;
   }
}
