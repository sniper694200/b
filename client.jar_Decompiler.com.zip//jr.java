import com.google.common.collect.Lists;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class jr implements ht<hw> {
   private jr.a a;
   private List<akr> b;
   private List<akr> c;
   private boolean d;
   private boolean e;

   public jr() {
   }

   public jr(jr.a var1, List<akr> var2, List<akr> var3, boolean var4, boolean var5) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = var5;
   }

   public void a(hw var1) {
      var1.a(this);
   }

   public void a(gy var1) throws IOException {
      this.a = (jr.a)var1.a(jr.a.class);
      this.d = var1.readBoolean();
      this.e = var1.readBoolean();
      int var2 = var1.g();
      this.b = Lists.newArrayList();

      int var3;
      for(var3 = 0; var3 < var2; ++var3) {
         this.b.add(aks.a(var1.g()));
      }

      if (this.a == jr.a.a) {
         var2 = var1.g();
         this.c = Lists.newArrayList();

         for(var3 = 0; var3 < var2; ++var3) {
            this.c.add(aks.a(var1.g()));
         }
      }

   }

   public void b(gy var1) throws IOException {
      var1.a((Enum)this.a);
      var1.writeBoolean(this.d);
      var1.writeBoolean(this.e);
      var1.d(this.b.size());
      Iterator var2 = this.b.iterator();

      akr var3;
      while(var2.hasNext()) {
         var3 = (akr)var2.next();
         var1.d(aks.a(var3));
      }

      if (this.a == jr.a.a) {
         var1.d(this.c.size());
         var2 = this.c.iterator();

         while(var2.hasNext()) {
            var3 = (akr)var2.next();
            var1.d(aks.a(var3));
         }
      }

   }

   public List<akr> a() {
      return this.b;
   }

   public List<akr> b() {
      return this.c;
   }

   public boolean c() {
      return this.d;
   }

   public boolean d() {
      return this.e;
   }

   public jr.a e() {
      return this.a;
   }

   public static enum a {
      a,
      b,
      c;
   }
}
