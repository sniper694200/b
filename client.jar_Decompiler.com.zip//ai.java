import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ai implements p<ai.b> {
   private static final nd a = new nd("entity_hurt_player");
   private final Map<nn, ai.a> b = Maps.newHashMap();

   public nd a() {
      return a;
   }

   public void a(nn var1, p.a<ai.b> var2) {
      ai.a var3 = (ai.a)this.b.get(var1);
      if (var3 == null) {
         var3 = new ai.a(var1);
         this.b.put(var1, var3);
      }

      var3.a(var2);
   }

   public void b(nn var1, p.a<ai.b> var2) {
      ai.a var3 = (ai.a)this.b.get(var1);
      if (var3 != null) {
         var3.b(var2);
         if (var3.a()) {
            this.b.remove(var1);
         }
      }

   }

   public void a(nn var1) {
      this.b.remove(var1);
   }

   public ai.b b(JsonObject var1, JsonDeserializationContext var2) {
      ab var3 = ab.a(var1.get("damage"));
      return new ai.b(var3);
   }

   public void a(oo var1, up var2, float var3, float var4, boolean var5) {
      ai.a var6 = (ai.a)this.b.get(var1.P());
      if (var6 != null) {
         var6.a(var1, var2, var3, var4, var5);
      }

   }

   // $FF: synthetic method
   public q a(JsonObject var1, JsonDeserializationContext var2) {
      return this.b(var1, var2);
   }

   static class a {
      private final nn a;
      private final Set<p.a<ai.b>> b = Sets.newHashSet();

      public a(nn var1) {
         this.a = var1;
      }

      public boolean a() {
         return this.b.isEmpty();
      }

      public void a(p.a<ai.b> var1) {
         this.b.add(var1);
      }

      public void b(p.a<ai.b> var1) {
         this.b.remove(var1);
      }

      public void a(oo var1, up var2, float var3, float var4, boolean var5) {
         List<p.a<ai.b>> var6 = null;
         Iterator var7 = this.b.iterator();

         p.a var8;
         while(var7.hasNext()) {
            var8 = (p.a)var7.next();
            if (((ai.b)var8.a()).a(var1, var2, var3, var4, var5)) {
               if (var6 == null) {
                  var6 = Lists.newArrayList();
               }

               var6.add(var8);
            }
         }

         if (var6 != null) {
            var7 = var6.iterator();

            while(var7.hasNext()) {
               var8 = (p.a)var7.next();
               var8.a(this.a);
            }
         }

      }
   }

   public static class b extends u {
      private final ab a;

      public b(ab var1) {
         super(ai.a);
         this.a = var1;
      }

      public boolean a(oo var1, up var2, float var3, float var4, boolean var5) {
         return this.a.a(var1, var2, var3, var4, var5);
      }
   }
}
