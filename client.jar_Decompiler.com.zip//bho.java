import com.google.common.collect.Maps;
import java.util.Map;

public interface bho {
   Map<String, bho> a = Maps.newHashMap();
   bho b = new bhm("dummy");
   bho c = new bhm("trigger");
   bho d = new bhm("deathCount");
   bho e = new bhm("playerKillCount");
   bho f = new bhm("totalKillCount");
   bho g = new bhn("health");
   bho h = new bhp("food");
   bho i = new bhp("air");
   bho j = new bhp("armor");
   bho k = new bhp("xp");
   bho l = new bhp("level");
   bho[] m = new bho[]{new bhl("teamkill.", .a.a), new bhl("teamkill.", .a.b), new bhl("teamkill.", .a.c), new bhl("teamkill.", .a.d), new bhl("teamkill.", .a.e), new bhl("teamkill.", .a.f), new bhl("teamkill.", .a.g), new bhl("teamkill.", .a.h), new bhl("teamkill.", .a.i), new bhl("teamkill.", .a.j), new bhl("teamkill.", .a.k), new bhl("teamkill.", .a.l), new bhl("teamkill.", .a.m), new bhl("teamkill.", .a.n), new bhl("teamkill.", .a.o), new bhl("teamkill.", .a.p)};
   bho[] n = new bho[]{new bhl("killedByTeam.", .a.a), new bhl("killedByTeam.", .a.b), new bhl("killedByTeam.", .a.c), new bhl("killedByTeam.", .a.d), new bhl("killedByTeam.", .a.e), new bhl("killedByTeam.", .a.f), new bhl("killedByTeam.", .a.g), new bhl("killedByTeam.", .a.h), new bhl("killedByTeam.", .a.i), new bhl("killedByTeam.", .a.j), new bhl("killedByTeam.", .a.k), new bhl("killedByTeam.", .a.l), new bhl("killedByTeam.", .a.m), new bhl("killedByTeam.", .a.n), new bhl("killedByTeam.", .a.o), new bhl("killedByTeam.", .a.p)};

   String a();

   boolean b();

   bho.a c();

   public static enum a {
      a("integer"),
      b("hearts");

      private static final Map<String, bho.a> c = Maps.newHashMap();
      private final String d;

      private a(String var3) {
         this.d = var3;
      }

      public String a() {
         return this.d;
      }

      public static bho.a a(String var0) {
         bho.a var1 = (bho.a)c.get(var0);
         return var1 == null ? a : var1;
      }

      static {
         bho.a[] var0 = values();
         int var1 = var0.length;

         for(int var2 = 0; var2 < var1; ++var2) {
            bho.a var3 = var0[var2];
            c.put(var3.a(), var3);
         }

      }
   }
}
