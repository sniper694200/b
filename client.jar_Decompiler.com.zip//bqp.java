public class bqp extends bqd {
   public brq a;

   public bqp() {
      this.s = 64;
      this.t = 32;
      this.a = new brq(this);
      this.a.a(0, 0).a(-4.0F, -4.0F, -1.0F, 8, 8, 2, 0.0F);
      this.a.a(0, 10).a(-1.0F, -4.0F, -4.0F, 2, 8, 8, 0.0F);
      this.a.a(20, 0).a(-4.0F, -1.0F, -4.0F, 8, 2, 8, 0.0F);
      this.a.a(0.0F, 0.0F, 0.0F);
   }

   public void a(ve var1, float var2, float var3, float var4, float var5, float var6, float var7) {
      this.a(var2, var3, var4, var5, var6, var7, var1);
      this.a.a(var7);
   }

   public void a(float var1, float var2, float var3, float var4, float var5, float var6, ve var7) {
      super.a(var1, var2, var3, var4, var5, var6, var7);
      this.a.g = var4 * 0.017453292F;
      this.a.f = var5 * 0.017453292F;
   }
}
