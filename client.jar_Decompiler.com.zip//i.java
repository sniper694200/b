import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Sets;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import javax.annotation.Nullable;
import org.apache.commons.lang3.ArrayUtils;

public class i {
   private final i a;
   private final r b;
   private final l c;
   private final nd d;
   private final Map<String, n> e;
   private final String[][] f;
   private final Set<i> g = Sets.newLinkedHashSet();
   private final hh h;

   public i(nd var1, @Nullable i var2, @Nullable r var3, l var4, Map<String, n> var5, String[][] var6) {
      this.d = var1;
      this.b = var3;
      this.e = ImmutableMap.copyOf(var5);
      this.a = var2;
      this.c = var4;
      this.f = var6;
      if (var2 != null) {
         var2.a(this);
      }

      if (var3 == null) {
         this.h = new ho(var1.toString());
      } else {
         this.h = new ho("[");
         this.h.b().a(var3.e().c());
         hh var7 = var3.a().f();
         hh var8 = new ho("");
         hh var9 = var7.f();
         var9.b().a(var3.e().c());
         var8.a(var9);
         var8.a("\n");
         var8.a(var3.b());
         var7.b().a(new hj(hj.a.a, var8));
         this.h.a(var7);
         this.h.a("]");
      }

   }

   public i.a a() {
      return new i.a(this.a == null ? null : this.a.h(), this.b, this.c, this.e, this.f);
   }

   @Nullable
   public i b() {
      return this.a;
   }

   @Nullable
   public r c() {
      return this.b;
   }

   public l d() {
      return this.c;
   }

   public String toString() {
      return "SimpleAdvancement{id=" + this.h() + ", parent=" + (this.a == null ? "null" : this.a.h()) + ", display=" + this.b + ", rewards=" + this.c + ", criteria=" + this.e + ", requirements=" + Arrays.deepToString(this.f) + '}';
   }

   public Iterable<i> e() {
      return this.g;
   }

   public Map<String, n> f() {
      return this.e;
   }

   public int g() {
      return this.f.length;
   }

   public void a(i var1) {
      this.g.add(var1);
   }

   public nd h() {
      return this.d;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof i)) {
         return false;
      } else {
         i var2 = (i)var1;
         return this.d.equals(var2.d);
      }
   }

   public int hashCode() {
      return this.d.hashCode();
   }

   public String[][] i() {
      return this.f;
   }

   public hh j() {
      return this.h;
   }

   public static class a {
      private final nd a;
      private i b;
      private final r c;
      private final l d;
      private final Map<String, n> e;
      private final String[][] f;

      a(@Nullable nd var1, @Nullable r var2, l var3, Map<String, n> var4, String[][] var5) {
         this.a = var1;
         this.c = var2;
         this.d = var3;
         this.e = var4;
         this.f = var5;
      }

      public boolean a(Function<nd, i> var1) {
         if (this.a == null) {
            return true;
         } else {
            this.b = (i)var1.apply(this.a);
            return this.b != null;
         }
      }

      public i a(nd var1) {
         return new i(var1, this.b, this.c, this.d, this.e, this.f);
      }

      public void a(gy var1) {
         if (this.a == null) {
            var1.writeBoolean(false);
         } else {
            var1.writeBoolean(true);
            var1.a(this.a);
         }

         if (this.c == null) {
            var1.writeBoolean(false);
         } else {
            var1.writeBoolean(true);
            this.c.a(var1);
         }

         n.a(this.e, var1);
         var1.d(this.f.length);
         String[][] var2 = this.f;
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            String[] var5 = var2[var4];
            var1.d(var5.length);
            String[] var6 = var5;
            int var7 = var5.length;

            for(int var8 = 0; var8 < var7; ++var8) {
               String var9 = var6[var8];
               var1.a(var9);
            }
         }

      }

      public String toString() {
         return "Task Advancement{parentId=" + this.a + ", display=" + this.c + ", rewards=" + this.d + ", criteria=" + this.e + ", requirements=" + Arrays.deepToString(this.f) + '}';
      }

      public static i.a a(JsonObject var0, JsonDeserializationContext var1) {
         nd var2 = var0.has("parent") ? new nd(ra.h(var0, "parent")) : null;
         r var3 = var0.has("display") ? r.a(ra.t(var0, "display"), var1) : null;
         l var4 = (l)ra.a(var0, "rewards", l.a, var1, l.class);
         Map<String, n> var5 = n.b(ra.t(var0, "criteria"), var1);
         if (var5.isEmpty()) {
            throw new JsonSyntaxException("Advancement criteria cannot be empty");
         } else {
            JsonArray var6 = ra.a(var0, "requirements", new JsonArray());
            String[][] var7 = new String[var6.size()][];

            int var8;
            int var10;
            for(var8 = 0; var8 < var6.size(); ++var8) {
               JsonArray var9 = ra.n(var6.get(var8), "requirements[" + var8 + "]");
               var7[var8] = new String[var9.size()];

               for(var10 = 0; var10 < var9.size(); ++var10) {
                  var7[var8][var10] = ra.a(var9.get(var10), "requirements[" + var8 + "][" + var10 + "]");
               }
            }

            if (var7.length == 0) {
               var7 = new String[var5.size()][];
               var8 = 0;

               String var21;
               for(Iterator var16 = var5.keySet().iterator(); var16.hasNext(); var7[var8++] = new String[]{var21}) {
                  var21 = (String)var16.next();
               }
            }

            String[][] var17 = var7;
            int var18 = var7.length;

            int var13;
            for(var10 = 0; var10 < var18; ++var10) {
               String[] var11 = var17[var10];
               if (var11.length == 0 && var5.isEmpty()) {
                  throw new JsonSyntaxException("Requirement entry cannot be empty");
               }

               String[] var12 = var11;
               var13 = var11.length;

               for(int var14 = 0; var14 < var13; ++var14) {
                  String var15 = var12[var14];
                  if (!var5.containsKey(var15)) {
                     throw new JsonSyntaxException("Unknown required criterion '" + var15 + "'");
                  }
               }
            }

            Iterator var19 = var5.keySet().iterator();

            String var20;
            boolean var23;
            do {
               if (!var19.hasNext()) {
                  return new i.a(var2, var3, var4, var5, var7);
               }

               var20 = (String)var19.next();
               var23 = false;
               String[][] var22 = var7;
               int var24 = var7.length;

               for(var13 = 0; var13 < var24; ++var13) {
                  String[] var25 = var22[var13];
                  if (ArrayUtils.contains(var25, var20)) {
                     var23 = true;
                     break;
                  }
               }
            } while(var23);

            throw new JsonSyntaxException("Criterion '" + var20 + "' isn't a requirement for completion. This isn't supported behaviour, all criteria must be required.");
         }
      }

      public static i.a b(gy var0) {
         nd var1 = var0.readBoolean() ? var0.l() : null;
         r var2 = var0.readBoolean() ? r.b(var0) : null;
         Map<String, n> var3 = n.c(var0);
         String[][] var4 = new String[var0.g()][];

         for(int var5 = 0; var5 < var4.length; ++var5) {
            var4[var5] = new String[var0.g()];

            for(int var6 = 0; var6 < var4[var5].length; ++var6) {
               var4[var5][var6] = var0.e(32767);
            }
         }

         return new i.a(var1, var2, l.a, var3, var4);
      }
   }
}
