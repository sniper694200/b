import javax.annotation.Nullable;

public class ahu extends ail {
   public ahu() {
      this.k = 1;
      this.e(432);
      this.b(ahn.e);
      this.a(new nd("broken"), new aio() {
         public float a(ain var1, @Nullable ams var2, @Nullable vn var3) {
            return ahu.d(var1) ? 0.0F : 1.0F;
         }
      });
      apx.c.a(this, agt.b);
   }

   public static boolean d(ain var0) {
      return var0.i() < var0.k() - 1;
   }

   public boolean a(ain var1, ain var2) {
      return var2.c() == aip.aN;
   }

   public uc<ain> a(ams var1, aeb var2, tz var3) {
      ain var4 = var2.b((tz)var3);
      vj var5 = vo.d(var4);
      ain var6 = var2.b(var5);
      if (var6.b()) {
         var2.a(var5, var4.l());
         var4.e(0);
         return new uc(ub.a, var4);
      } else {
         return new uc(ub.c, var4);
      }
   }
}
