import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.function.Supplier;
import org.lwjgl.input.Keyboard;

public class bhw implements Comparable<bhw> {
   private static final Map<String, bhw> a = Maps.newHashMap();
   private static final re<bhw> b = new re();
   private static final Set<String> c = Sets.newHashSet();
   private static final Map<String, Integer> d = Maps.newHashMap();
   private final String e;
   private final int f;
   private final String g;
   private int h;
   private boolean i;
   private int j;

   public static void a(int var0) {
      if (var0 != 0) {
         bhw var1 = (bhw)b.a(var0);
         if (var1 != null) {
            ++var1.j;
         }

      }
   }

   public static void a(int var0, boolean var1) {
      if (var0 != 0) {
         bhw var2 = (bhw)b.a(var0);
         if (var2 != null) {
            var2.i = var1;
         }

      }
   }

   public static void a() {
      Iterator var0 = a.values().iterator();

      while(var0.hasNext()) {
         bhw var1 = (bhw)var0.next();

         try {
            a(var1.h, var1.h < 256 && Keyboard.isKeyDown(var1.h));
         } catch (IndexOutOfBoundsException var3) {
         }
      }

   }

   public static void b() {
      Iterator var0 = a.values().iterator();

      while(var0.hasNext()) {
         bhw var1 = (bhw)var0.next();
         var1.k();
      }

   }

   public static void c() {
      b.c();
      Iterator var0 = a.values().iterator();

      while(var0.hasNext()) {
         bhw var1 = (bhw)var0.next();
         b.a(var1.h, var1);
      }

   }

   public static Set<String> d() {
      return c;
   }

   public bhw(String var1, int var2, String var3) {
      this.e = var1;
      this.h = var2;
      this.f = var2;
      this.g = var3;
      a.put(var1, this);
      b.a(var2, this);
      c.add(var3);
   }

   public boolean e() {
      return this.i;
   }

   public String f() {
      return this.g;
   }

   public boolean g() {
      if (this.j == 0) {
         return false;
      } else {
         --this.j;
         return true;
      }
   }

   private void k() {
      this.j = 0;
      this.i = false;
   }

   public String h() {
      return this.e;
   }

   public int i() {
      return this.f;
   }

   public int j() {
      return this.h;
   }

   public void b(int var1) {
      this.h = var1;
   }

   public int a(bhw var1) {
      return this.g.equals(var1.g) ? cew.a(this.e).compareTo(cew.a(var1.e)) : ((Integer)d.get(this.g)).compareTo((Integer)d.get(var1.g));
   }

   public static Supplier<String> b(String var0) {
      bhw var1 = (bhw)a.get(var0);
      return var1 == null ? () -> {
         return var0;
      } : () -> {
         return bib.a(var1.j());
      };
   }

   // $FF: synthetic method
   public int compareTo(Object var1) {
      return this.a((bhw)var1);
   }

   static {
      d.put("key.categories.movement", 1);
      d.put("key.categories.gameplay", 2);
      d.put("key.categories.inventory", 3);
      d.put("key.categories.creative", 4);
      d.put("key.categories.multiplayer", 5);
      d.put("key.categories.ui", 6);
      d.put("key.categories.misc", 7);
   }
}
