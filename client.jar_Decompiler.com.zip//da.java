import net.minecraft.server.MinecraftServer;

public class da extends bi {
   public String c() {
      return "reload";
   }

   public int a() {
      return 3;
   }

   public String b(bn var1) {
      return "commands.reload.usage";
   }

   public void a(MinecraftServer var1, bn var2, String[] var3) throws ei {
      if (var3.length > 0) {
         throw new ep("commands.reload.usage", new Object[0]);
      } else {
         var1.aM();
         a(var2, this, "commands.reload.success", new Object[0]);
      }
   }
}
