import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;

public class zn {
   private final ams a;
   private boolean b;
   private int c = -1;
   private int d;
   private int e;
   private zm f;
   private int g;
   private int h;
   private int i;

   public zn(ams var1) {
      this.a = var1;
   }

   public void a() {
      if (this.a.D()) {
         this.c = 0;
      } else if (this.c != 2) {
         if (this.c == 0) {
            float var1 = this.a.c(0.0F);
            if ((double)var1 < 0.5D || (double)var1 > 0.501D) {
               return;
            }

            this.c = this.a.r.nextInt(10) == 0 ? 1 : 2;
            this.b = false;
            if (this.c == 2) {
               return;
            }
         }

         if (this.c != -1) {
            if (!this.b) {
               if (!this.b()) {
                  return;
               }

               this.b = true;
            }

            if (this.e > 0) {
               --this.e;
            } else {
               this.e = 2;
               if (this.d > 0) {
                  this.c();
                  --this.d;
               } else {
                  this.c = 2;
               }

            }
         }
      }
   }

   private boolean b() {
      List<aeb> var1 = this.a.i;
      Iterator var2 = var1.iterator();

      bhc var11;
      do {
         do {
            do {
               do {
                  do {
                     aeb var3;
                     do {
                        if (!var2.hasNext()) {
                           return false;
                        }

                        var3 = (aeb)var2.next();
                     } while(var3.y());

                     this.f = this.a.ak().a(new et(var3), 1);
                  } while(this.f == null);
               } while(this.f.c() < 10);
            } while(this.f.d() < 20);
         } while(this.f.e() < 20);

         et var4 = this.f.a();
         float var5 = (float)this.f.b();
         boolean var6 = false;

         for(int var7 = 0; var7 < 10; ++var7) {
            float var8 = this.a.r.nextFloat() * 6.2831855F;
            this.g = var4.p() + (int)((double)(ri.b(var8) * var5) * 0.9D);
            this.h = var4.q();
            this.i = var4.r() + (int)((double)(ri.a(var8) * var5) * 0.9D);
            var6 = false;
            Iterator var9 = this.a.ak().b().iterator();

            while(var9.hasNext()) {
               zm var10 = (zm)var9.next();
               if (var10 != this.f && var10.a(new et(this.g, this.h, this.i))) {
                  var6 = true;
                  break;
               }
            }

            if (!var6) {
               break;
            }
         }

         if (var6) {
            return false;
         }

         var11 = this.a(new et(this.g, this.h, this.i));
      } while(var11 == null);

      this.e = 0;
      this.d = 20;
      return true;
   }

   private boolean c() {
      bhc var1 = this.a(new et(this.g, this.h, this.i));
      if (var1 == null) {
         return false;
      } else {
         adr var2;
         try {
            var2 = new adr(this.a);
            var2.a((ty)this.a.D(new et(var2)), (vq)null);
         } catch (Exception var4) {
            var4.printStackTrace();
            return false;
         }

         var2.b(var1.b, var1.c, var1.d, this.a.r.nextFloat() * 360.0F, 0.0F);
         this.a.a((ve)var2);
         et var3 = this.f.a();
         var2.a(var3, this.f.b());
         return true;
      }
   }

   @Nullable
   private bhc a(et var1) {
      for(int var2 = 0; var2 < 10; ++var2) {
         et var3 = var1.a(this.a.r.nextInt(16) - 8, this.a.r.nextInt(6) - 3, this.a.r.nextInt(16) - 8);
         if (this.f.a(var3) && amz.a(vo.a.a, this.a, var3)) {
            return new bhc((double)var3.p(), (double)var3.q(), (double)var3.r());
         }
      }

      return null;
   }
}
