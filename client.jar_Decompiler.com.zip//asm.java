import com.google.common.base.Predicate;
import javax.annotation.Nullable;

public class asm extends art {
   public static final axf<asp.a> b = axf.a("variant", asp.a.class, new Predicate<asp.a>() {
      public boolean a(@Nullable asp.a var1) {
         return var1.a() < 4;
      }

      // $FF: synthetic method
      public boolean apply(@Nullable Object var1) {
         return this.a((asp.a)var1);
      }
   });

   public asm() {
      this.w(this.A.b().a(b, asp.a.a).a(a, art.a.b));
   }

   public bcy c(awr var1, amw var2, et var3) {
      asp.a var4 = (asp.a)var1.c(b);
      switch((art.a)var1.c(a)) {
      case a:
      case c:
      case d:
      default:
         switch(var4) {
         case a:
         default:
            return asp.a.b.c();
         case b:
            return asp.a.f.c();
         case c:
            return bcy.q;
         case d:
            return asp.a.b.c();
         }
      case b:
         return var4.c();
      }
   }

   public void a(ahn var1, fi<ain> var2) {
      var2.add(new ain(this, 1, asp.a.a.a()));
      var2.add(new ain(this, 1, asp.a.b.a()));
      var2.add(new ain(this, 1, asp.a.c.a()));
      var2.add(new ain(this, 1, asp.a.d.a()));
   }

   public awr a(int var1) {
      awr var2 = this.t().a(b, asp.a.a((var1 & 3) % 4));
      switch(var1 & 12) {
      case 0:
         var2 = var2.a(a, art.a.b);
         break;
      case 4:
         var2 = var2.a(a, art.a.a);
         break;
      case 8:
         var2 = var2.a(a, art.a.c);
         break;
      default:
         var2 = var2.a(a, art.a.d);
      }

      return var2;
   }

   public int e(awr var1) {
      int var2 = 0;
      int var3 = var2 | ((asp.a)var1.c(b)).a();
      switch((art.a)var1.c(a)) {
      case a:
         var3 |= 4;
         break;
      case c:
         var3 |= 8;
         break;
      case d:
         var3 |= 12;
      }

      return var3;
   }

   protected aws b() {
      return new aws(this, new axh[]{b, a});
   }

   protected ain u(awr var1) {
      return new ain(ail.a((aou)this), 1, ((asp.a)var1.c(b)).a());
   }

   public int d(awr var1) {
      return ((asp.a)var1.c(b)).a();
   }
}
