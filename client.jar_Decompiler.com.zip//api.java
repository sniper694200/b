import java.util.Iterator;
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;

public class api extends aou {
   public static final axd a = axd.a("north");
   public static final axd b = axd.a("east");
   public static final axd c = axd.a("south");
   public static final axd d = axd.a("west");
   public static final axd e = axd.a("up");
   public static final axd f = axd.a("down");

   protected api() {
      super(bcx.k, bcy.A);
      this.a(ahn.c);
      this.w(this.A.b().a(a, false).a(b, false).a(c, false).a(d, false).a(e, false).a(f, false));
   }

   public awr d(awr var1, amw var2, et var3) {
      aou var4 = var2.o(var3.b()).u();
      aou var5 = var2.o(var3.a()).u();
      aou var6 = var2.o(var3.c()).u();
      aou var7 = var2.o(var3.f()).u();
      aou var8 = var2.o(var3.d()).u();
      aou var9 = var2.o(var3.e()).u();
      return var1.a(f, var4 == this || var4 == aov.cS || var4 == aov.bH).a(e, var5 == this || var5 == aov.cS).a(a, var6 == this || var6 == aov.cS).a(b, var7 == this || var7 == aov.cS).a(c, var8 == this || var8 == aov.cS).a(d, var9 == this || var9 == aov.cS);
   }

   public bgz b(awr var1, amw var2, et var3) {
      var1 = var1.c(var2, var3);
      float var4 = 0.1875F;
      float var5 = (Boolean)var1.c(d) ? 0.0F : 0.1875F;
      float var6 = (Boolean)var1.c(f) ? 0.0F : 0.1875F;
      float var7 = (Boolean)var1.c(a) ? 0.0F : 0.1875F;
      float var8 = (Boolean)var1.c(b) ? 1.0F : 0.8125F;
      float var9 = (Boolean)var1.c(e) ? 1.0F : 0.8125F;
      float var10 = (Boolean)var1.c(c) ? 1.0F : 0.8125F;
      return new bgz((double)var5, (double)var6, (double)var7, (double)var8, (double)var9, (double)var10);
   }

   public void a(awr var1, ams var2, et var3, bgz var4, List<bgz> var5, @Nullable ve var6, boolean var7) {
      if (!var7) {
         var1 = var1.c(var2, var3);
      }

      float var8 = 0.1875F;
      float var9 = 0.8125F;
      a((et)var3, (bgz)var4, (List)var5, (bgz)(new bgz(0.1875D, 0.1875D, 0.1875D, 0.8125D, 0.8125D, 0.8125D)));
      if ((Boolean)var1.c(d)) {
         a((et)var3, (bgz)var4, (List)var5, (bgz)(new bgz(0.0D, 0.1875D, 0.1875D, 0.1875D, 0.8125D, 0.8125D)));
      }

      if ((Boolean)var1.c(b)) {
         a((et)var3, (bgz)var4, (List)var5, (bgz)(new bgz(0.8125D, 0.1875D, 0.1875D, 1.0D, 0.8125D, 0.8125D)));
      }

      if ((Boolean)var1.c(e)) {
         a((et)var3, (bgz)var4, (List)var5, (bgz)(new bgz(0.1875D, 0.8125D, 0.1875D, 0.8125D, 1.0D, 0.8125D)));
      }

      if ((Boolean)var1.c(f)) {
         a((et)var3, (bgz)var4, (List)var5, (bgz)(new bgz(0.1875D, 0.0D, 0.1875D, 0.8125D, 0.1875D, 0.8125D)));
      }

      if ((Boolean)var1.c(a)) {
         a((et)var3, (bgz)var4, (List)var5, (bgz)(new bgz(0.1875D, 0.1875D, 0.0D, 0.8125D, 0.8125D, 0.1875D)));
      }

      if ((Boolean)var1.c(c)) {
         a((et)var3, (bgz)var4, (List)var5, (bgz)(new bgz(0.1875D, 0.1875D, 0.8125D, 0.8125D, 0.8125D, 1.0D)));
      }

   }

   public int e(awr var1) {
      return 0;
   }

   public void b(ams var1, et var2, awr var3, Random var4) {
      if (!this.b(var1, var2)) {
         var1.b(var2, true);
      }

   }

   public ail a(awr var1, Random var2, int var3) {
      return aip.cT;
   }

   public int a(Random var1) {
      return var1.nextInt(2);
   }

   public boolean c(awr var1) {
      return false;
   }

   public boolean b(awr var1) {
      return false;
   }

   public boolean a(ams var1, et var2) {
      return super.a(var1, var2) ? this.b(var1, var2) : false;
   }

   public void a(awr var1, ams var2, et var3, aou var4, et var5) {
      if (!this.b(var2, var3)) {
         var2.a((et)var3, (aou)this, 1);
      }

   }

   public boolean b(ams var1, et var2) {
      boolean var3 = var1.d(var2.a());
      boolean var4 = var1.d(var2.b());
      Iterator var5 = fa.c.a.iterator();

      aou var9;
      do {
         et var7;
         aou var8;
         do {
            if (!var5.hasNext()) {
               aou var10 = var1.o(var2.b()).u();
               return var10 == this || var10 == aov.bH;
            }

            fa var6 = (fa)var5.next();
            var7 = var2.a(var6);
            var8 = var1.o(var7).u();
         } while(var8 != this);

         if (!var3 && !var4) {
            return false;
         }

         var9 = var1.o(var7.b()).u();
      } while(var9 != this && var9 != aov.bH);

      return true;
   }

   public amk f() {
      return amk.c;
   }

   public boolean a(awr var1, amw var2, et var3, fa var4) {
      aou var5 = var2.o(var3.a(var4)).u();
      return var5 != this && var5 != aov.cS && (var4 != fa.a || var5 != aov.bH);
   }

   protected aws b() {
      return new aws(this, new axh[]{a, b, c, d, e, f});
   }

   public boolean b(amw var1, et var2) {
      return false;
   }

   public awp a(amw var1, awr var2, et var3, fa var4) {
      return awp.i;
   }
}
