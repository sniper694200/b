import com.google.common.collect.Maps;
import java.util.Map;

public class hg {
   private final hg.a a;
   private final String b;

   public hg(hg.a var1, String var2) {
      this.a = var1;
      this.b = var2;
   }

   public hg.a a() {
      return this.a;
   }

   public String b() {
      return this.b;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         hg var2 = (hg)var1;
         if (this.a != var2.a) {
            return false;
         } else {
            if (this.b != null) {
               if (!this.b.equals(var2.b)) {
                  return false;
               }
            } else if (var2.b != null) {
               return false;
            }

            return true;
         }
      } else {
         return false;
      }
   }

   public String toString() {
      return "ClickEvent{action=" + this.a + ", value='" + this.b + '\'' + '}';
   }

   public int hashCode() {
      int var1 = this.a.hashCode();
      var1 = 31 * var1 + (this.b != null ? this.b.hashCode() : 0);
      return var1;
   }

   public static enum a {
      a("open_url", true),
      b("open_file", false),
      c("run_command", true),
      d("suggest_command", true),
      e("change_page", true);

      private static final Map<String, hg.a> f = Maps.newHashMap();
      private final boolean g;
      private final String h;

      private a(String var3, boolean var4) {
         this.h = var3;
         this.g = var4;
      }

      public boolean a() {
         return this.g;
      }

      public String b() {
         return this.h;
      }

      public static hg.a a(String var0) {
         return (hg.a)f.get(var0);
      }

      static {
         hg.a[] var0 = values();
         int var1 = var0.length;

         for(int var2 = 0; var2 < var1; ++var2) {
            hg.a var3 = var0[var2];
            f.put(var3.b(), var3);
         }

      }
   }
}
