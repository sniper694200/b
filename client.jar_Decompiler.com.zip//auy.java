public class auy extends aop {
   public static final axg d = axg.a("power", 0, 15);
   private final int e;

   protected auy(bcx var1, int var2) {
      this(var1, var2, var1.r());
   }

   protected auy(bcx var1, int var2, bcy var3) {
      super(var1, var3);
      this.w(this.A.b().a(d, 0));
      this.e = var2;
   }

   protected int e(ams var1, et var2) {
      int var3 = Math.min(var1.a(ve.class, c.a(var2)).size(), this.e);
      if (var3 > 0) {
         float var4 = (float)Math.min(this.e, var3) / (float)this.e;
         return ri.f(var4 * 15.0F);
      } else {
         return 0;
      }
   }

   protected void b(ams var1, et var2) {
      var1.a((aeb)null, var2, qd.ee, qe.e, 0.3F, 0.90000004F);
   }

   protected void c(ams var1, et var2) {
      var1.a((aeb)null, var2, qd.ed, qe.e, 0.3F, 0.75F);
   }

   protected int i(awr var1) {
      return (Integer)var1.c(d);
   }

   protected awr a(awr var1, int var2) {
      return var1.a(d, var2);
   }

   public int a(ams var1) {
      return 10;
   }

   public awr a(int var1) {
      return this.t().a(d, var1);
   }

   public int e(awr var1) {
      return (Integer)var1.c(d);
   }

   protected aws b() {
      return new aws(this, new axh[]{d});
   }
}
