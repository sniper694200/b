public class xt extends xp {
   private final zz c;

   public xt(zz var1, double var2) {
      super(var1, var2, 8);
      this.c = var1;
   }

   public boolean a() {
      return this.c.dl() && !this.c.dn() && super.a();
   }

   public void c() {
      super.c();
      this.c.dp().a(false);
   }

   public void d() {
      super.d();
      this.c.r(false);
   }

   public void e() {
      super.e();
      this.c.dp().a(false);
      if (!this.f()) {
         this.c.r(false);
      } else if (!this.c.dn()) {
         this.c.r(true);
      }

   }

   protected boolean a(ams var1, et var2) {
      if (!var1.d(var2.a())) {
         return false;
      } else {
         awr var3 = var1.o(var2);
         aou var4 = var3.u();
         if (var4 == aov.ae) {
            avh var5 = var1.r(var2);
            if (var5 instanceof avj && ((avj)var5).l < 1) {
               return true;
            }
         } else {
            if (var4 == aov.am) {
               return true;
            }

            if (var4 == aov.C && var3.c(aos.a) != aos.a.a) {
               return true;
            }
         }

         return false;
      }
   }
}
