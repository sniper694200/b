import javax.annotation.Nullable;

public interface abl {
   boolean a();

   void b();

   void c();

   void a(aba var1, et var2, up var3, @Nullable aeb var4);

   void d();

   void e();

   float f();

   float h();

   abr<? extends abl> i();

   @Nullable
   bhc g();

   float a(aaz var1, up var2, float var3);
}
