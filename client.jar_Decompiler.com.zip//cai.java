public class cai extends cad<aab> {
   private static final nd a = new nd("textures/entity/pig/pig.png");

   public cai(bzd var1) {
      super(var1, new bqg(), 0.7F);
      this.a((cce)(new ccd(this)));
   }

   protected nd a(aab var1) {
      return a;
   }
}
