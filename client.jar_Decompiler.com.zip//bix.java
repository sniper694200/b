import com.google.common.collect.Maps;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

public class bix extends bip {
   private static final nd a = new nd("textures/gui/bars.png");
   private final bhz f;
   private final Map<UUID, bjh> g = Maps.newLinkedHashMap();

   public bix(bhz var1) {
      this.f = var1;
   }

   public void a() {
      if (!this.g.isEmpty()) {
         bir var1 = new bir(this.f);
         int var2 = var1.a();
         int var3 = 12;
         Iterator var4 = this.g.values().iterator();

         while(var4.hasNext()) {
            bjh var5 = (bjh)var4.next();
            int var6 = var2 / 2 - 91;
            buq.c(1.0F, 1.0F, 1.0F, 1.0F);
            this.f.N().a(a);
            this.a(var6, var3, var5);
            String var8 = var5.e().d();
            this.f.k.a(var8, (float)(var2 / 2 - this.f.k.a(var8) / 2), (float)(var3 - 9), 16777215);
            var3 += 10 + this.f.k.a;
            if (var3 >= var1.b() / 3) {
               break;
            }
         }

      }
   }

   private void a(int var1, int var2, tr var3) {
      this.b(var1, var2, 0, var3.g().ordinal() * 5 * 2, 182, 5);
      if (var3.h() != tr.b.a) {
         this.b(var1, var2, 0, 80 + (var3.h().ordinal() - 1) * 5 * 2, 182, 5);
      }

      int var4 = (int)(var3.f() * 183.0F);
      if (var4 > 0) {
         this.b(var1, var2, 0, var3.g().ordinal() * 5 * 2 + 5, var4, 5);
         if (var3.h() != tr.b.a) {
            this.b(var1, var2, 0, 80 + (var3.h().ordinal() - 1) * 5 * 2 + 5, var4, 5);
         }
      }

   }

   public void a(ik var1) {
      if (var1.b() == ik.a.a) {
         this.g.put(var1.a(), new bjh(var1));
      } else if (var1.b() == ik.a.b) {
         this.g.remove(var1.a());
      } else {
         ((bjh)this.g.get(var1.a())).a(var1);
      }

   }

   public void b() {
      this.g.clear();
   }

   public boolean d() {
      if (!this.g.isEmpty()) {
         Iterator var1 = this.g.values().iterator();

         while(var1.hasNext()) {
            tr var2 = (tr)var1.next();
            if (var2.j()) {
               return true;
            }
         }
      }

      return false;
   }

   public boolean e() {
      if (!this.g.isEmpty()) {
         Iterator var1 = this.g.values().iterator();

         while(var1.hasNext()) {
            tr var2 = (tr)var1.next();
            if (var2.i()) {
               return true;
            }
         }
      }

      return false;
   }

   public boolean f() {
      if (!this.g.isEmpty()) {
         Iterator var1 = this.g.values().iterator();

         while(var1.hasNext()) {
            tr var2 = (tr)var1.next();
            if (var2.k()) {
               return true;
            }
         }
      }

      return false;
   }
}
