import com.google.common.base.MoreObjects;
import java.util.Iterator;
import java.util.Random;
import javax.annotation.Nullable;

public class aur extends aou {
   public static final axe a;
   public static final axd b;
   public static final axd c;
   protected static final bgz d;
   protected static final bgz e;
   protected static final bgz f;
   protected static final bgz g;

   public aur() {
      super(bcx.q);
      this.w(this.A.b().a(a, fa.c).a(b, false).a(c, false));
      this.a(ahn.d);
      this.a(true);
   }

   public bgz b(awr var1, amw var2, et var3) {
      switch((fa)var1.c(a)) {
      case f:
      default:
         return g;
      case e:
         return f;
      case d:
         return e;
      case c:
         return d;
      }
   }

   @Nullable
   public bgz a(awr var1, amw var2, et var3) {
      return k;
   }

   public boolean b(awr var1) {
      return false;
   }

   public boolean c(awr var1) {
      return false;
   }

   public boolean b(ams var1, et var2, fa var3) {
      fa var4 = var3.d();
      et var5 = var2.a(var4);
      awr var6 = var1.o(var5);
      boolean var7 = c(var6.u());
      return !var7 && var3.k().c() && var6.d(var1, var5, var3) == awp.a && !var6.m();
   }

   public boolean a(ams var1, et var2) {
      Iterator var3 = fa.c.a.iterator();

      fa var4;
      do {
         if (!var3.hasNext()) {
            return false;
         }

         var4 = (fa)var3.next();
      } while(!this.b(var1, var2, var4));

      return true;
   }

   public awr a(ams var1, et var2, fa var3, float var4, float var5, float var6, int var7, vn var8) {
      awr var9 = this.t().a(b, false).a(c, false);
      if (var3.k().c()) {
         var9 = var9.a(a, var3);
      }

      return var9;
   }

   public void a(ams var1, et var2, awr var3, vn var4, ain var5) {
      this.a(var1, var2, var3, false, false, -1, (awr)null);
   }

   public void a(awr var1, ams var2, et var3, aou var4, et var5) {
      if (var4 != this) {
         if (this.e(var2, var3, var1)) {
            fa var6 = (fa)var1.c(a);
            if (!this.b(var2, var3, var6)) {
               this.b(var2, var3, var1, 0);
               var2.g(var3);
            }
         }

      }
   }

   public void a(ams var1, et var2, awr var3, boolean var4, boolean var5, int var6, @Nullable awr var7) {
      fa var8 = (fa)var3.c(a);
      boolean var9 = (Boolean)var3.c(c);
      boolean var10 = (Boolean)var3.c(b);
      boolean var11 = !var4;
      boolean var12 = false;
      int var13 = 0;
      awr[] var14 = new awr[42];

      et var16;
      for(int var15 = 1; var15 < 42; ++var15) {
         var16 = var2.a(var8, var15);
         awr var17 = var1.o(var16);
         if (var17.u() == aov.bR) {
            if (var17.c(a) == var8.d()) {
               var13 = var15;
            }
            break;
         }

         if (var17.u() != aov.bS && var15 != var6) {
            var14[var15] = null;
            var11 = false;
         } else {
            if (var15 == var6) {
               var17 = (awr)MoreObjects.firstNonNull(var7, var17);
            }

            boolean var18 = !(Boolean)var17.c(auq.c);
            boolean var19 = (Boolean)var17.c(auq.a);
            var12 |= var18 && var19;
            var14[var15] = var17;
            if (var15 == var6) {
               var1.a((et)var2, (aou)this, this.a(var1));
               var11 &= var18;
            }
         }
      }

      var11 &= var13 > 1;
      var12 &= var11;
      awr var20 = this.t().a(c, var11).a(b, var12);
      if (var13 > 0) {
         var16 = var2.a(var8, var13);
         fa var22 = var8.d();
         var1.a((et)var16, (awr)var20.a(a, var22), 3);
         this.a(var1, var16, var22);
         this.a(var1, var16, var11, var12, var9, var10);
      }

      this.a(var1, var2, var11, var12, var9, var10);
      if (!var4) {
         var1.a((et)var2, (awr)var20.a(a, var8), 3);
         if (var5) {
            this.a(var1, var2, var8);
         }
      }

      if (var9 != var11) {
         for(int var21 = 1; var21 < var13; ++var21) {
            et var23 = var2.a(var8, var21);
            awr var24 = var14[var21];
            if (var24 != null && var1.o(var23).a() != bcx.a) {
               var1.a((et)var23, (awr)var24.a(c, var11), 3);
            }
         }
      }

   }

   public void a(ams var1, et var2, awr var3, Random var4) {
   }

   public void b(ams var1, et var2, awr var3, Random var4) {
      this.a(var1, var2, var3, false, true, -1, (awr)null);
   }

   private void a(ams var1, et var2, boolean var3, boolean var4, boolean var5, boolean var6) {
      if (var4 && !var6) {
         var1.a((aeb)null, var2, qd.ia, qe.e, 0.4F, 0.6F);
      } else if (!var4 && var6) {
         var1.a((aeb)null, var2, qd.hZ, qe.e, 0.4F, 0.5F);
      } else if (var3 && !var5) {
         var1.a((aeb)null, var2, qd.hY, qe.e, 0.4F, 0.7F);
      } else if (!var3 && var5) {
         var1.a((aeb)null, var2, qd.ib, qe.e, 0.4F, 1.2F / (var1.r.nextFloat() * 0.2F + 0.9F));
      }

   }

   private void a(ams var1, et var2, fa var3) {
      var1.b(var2, this, false);
      var1.b(var2.a(var3.d()), this, false);
   }

   private boolean e(ams var1, et var2, awr var3) {
      if (!this.a(var1, var2)) {
         this.b(var1, var2, var3, 0);
         var1.g(var2);
         return false;
      } else {
         return true;
      }
   }

   public void b(ams var1, et var2, awr var3) {
      boolean var4 = (Boolean)var3.c(c);
      boolean var5 = (Boolean)var3.c(b);
      if (var4 || var5) {
         this.a(var1, var2, var3, true, false, -1, (awr)null);
      }

      if (var5) {
         var1.b(var2, this, false);
         var1.b(var2.a(((fa)var3.c(a)).d()), this, false);
      }

      super.b(var1, var2, var3);
   }

   public int b(awr var1, amw var2, et var3, fa var4) {
      return (Boolean)var1.c(b) ? 15 : 0;
   }

   public int c(awr var1, amw var2, et var3, fa var4) {
      if (!(Boolean)var1.c(b)) {
         return 0;
      } else {
         return var1.c(a) == var4 ? 15 : 0;
      }
   }

   public boolean g(awr var1) {
      return true;
   }

   public amk f() {
      return amk.b;
   }

   public awr a(int var1) {
      return this.t().a(a, fa.b(var1 & 3)).a(b, (var1 & 8) > 0).a(c, (var1 & 4) > 0);
   }

   public int e(awr var1) {
      int var2 = 0;
      int var3 = var2 | ((fa)var1.c(a)).b();
      if ((Boolean)var1.c(b)) {
         var3 |= 8;
      }

      if ((Boolean)var1.c(c)) {
         var3 |= 4;
      }

      return var3;
   }

   public awr a(awr var1, atk var2) {
      return var1.a(a, var2.a((fa)var1.c(a)));
   }

   public awr a(awr var1, arw var2) {
      return var1.a(var2.a((fa)var1.c(a)));
   }

   protected aws b() {
      return new aws(this, new axh[]{a, b, c});
   }

   public awp a(amw var1, awr var2, et var3, fa var4) {
      return awp.i;
   }

   static {
      a = ark.D;
      b = axd.a("powered");
      c = axd.a("attached");
      d = new bgz(0.3125D, 0.0D, 0.625D, 0.6875D, 0.625D, 1.0D);
      e = new bgz(0.3125D, 0.0D, 0.0D, 0.6875D, 0.625D, 0.375D);
      f = new bgz(0.625D, 0.0D, 0.3125D, 1.0D, 0.625D, 0.6875D);
      g = new bgz(0.0D, 0.0D, 0.3125D, 0.375D, 0.625D, 0.6875D);
   }
}
