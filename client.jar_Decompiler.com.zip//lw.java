import java.io.IOException;

public class lw implements ht<kw> {
   private et a;
   private String[] b;

   public lw() {
   }

   public lw(et var1, hh[] var2) {
      this.a = var1;
      this.b = new String[]{var2[0].c(), var2[1].c(), var2[2].c(), var2[3].c()};
   }

   public void a(gy var1) throws IOException {
      this.a = var1.e();
      this.b = new String[4];

      for(int var2 = 0; var2 < 4; ++var2) {
         this.b[var2] = var1.e(384);
      }

   }

   public void b(gy var1) throws IOException {
      var1.a(this.a);

      for(int var2 = 0; var2 < 4; ++var2) {
         var1.a(this.b[var2]);
      }

   }

   public void a(kw var1) {
      var1.a(this);
   }

   public et a() {
      return this.a;
   }

   public String[] b() {
      return this.b;
   }
}
