import com.mojang.authlib.GameProfile;
import com.mojang.authlib.minecraft.MinecraftProfileTexture;
import com.mojang.authlib.minecraft.MinecraftProfileTexture.Type;
import java.util.Map;
import java.util.UUID;
import javax.annotation.Nullable;

public class bxe extends bww<awb> {
   private static final nd d = new nd("textures/entity/skeleton/skeleton.png");
   private static final nd e = new nd("textures/entity/skeleton/wither_skeleton.png");
   private static final nd f = new nd("textures/entity/zombie/zombie.png");
   private static final nd g = new nd("textures/entity/creeper/creeper.png");
   private static final nd h = new nd("textures/entity/enderdragon/dragon.png");
   private final brk i = new brk(0.0F);
   public static bxe a;
   private final bqt j = new bqt(0, 0, 64, 32);
   private final bqt k = new bpu();

   public void a(awb var1, double var2, double var4, double var6, float var8, int var9, float var10) {
      fa var11 = fa.a(var1.v() & 7);
      float var12 = var1.a(var8);
      this.a((float)var2, (float)var4, (float)var6, var11, (float)(var1.h() * 360) / 16.0F, var1.f(), var1.a(), var9, var12);
   }

   public void a(bwv var1) {
      super.a(var1);
      a = this;
   }

   public void a(float var1, float var2, float var3, fa var4, float var5, int var6, @Nullable GameProfile var7, int var8, float var9) {
      bqd var10 = this.j;
      if (var8 >= 0) {
         this.a(b[var8]);
         buq.n(5890);
         buq.G();
         buq.b(4.0F, 2.0F, 1.0F);
         buq.c(0.0625F, 0.0625F, 0.0625F);
         buq.n(5888);
      } else {
         switch(var6) {
         case 0:
         default:
            this.a(d);
            break;
         case 1:
            this.a(e);
            break;
         case 2:
            this.a(f);
            var10 = this.k;
            break;
         case 3:
            var10 = this.k;
            nd var11 = ced.a();
            if (var7 != null) {
               bhz var12 = bhz.z();
               Map<Type, MinecraftProfileTexture> var13 = var12.Y().a(var7);
               if (var13.containsKey(Type.SKIN)) {
                  var11 = var12.Y().a((MinecraftProfileTexture)var13.get(Type.SKIN), Type.SKIN);
               } else {
                  UUID var14 = aeb.a(var7);
                  var11 = ced.a(var14);
               }
            }

            this.a(var11);
            break;
         case 4:
            this.a(g);
            break;
         case 5:
            this.a(h);
            var10 = this.i;
         }
      }

      buq.G();
      buq.r();
      if (var4 == fa.b) {
         buq.c(var1 + 0.5F, var2, var3 + 0.5F);
      } else {
         switch(var4) {
         case c:
            buq.c(var1 + 0.5F, var2 + 0.25F, var3 + 0.74F);
            break;
         case d:
            buq.c(var1 + 0.5F, var2 + 0.25F, var3 + 0.26F);
            var5 = 180.0F;
            break;
         case e:
            buq.c(var1 + 0.74F, var2 + 0.25F, var3 + 0.5F);
            var5 = 270.0F;
            break;
         case f:
         default:
            buq.c(var1 + 0.26F, var2 + 0.25F, var3 + 0.5F);
            var5 = 90.0F;
         }
      }

      float var15 = 0.0625F;
      buq.D();
      buq.b(-1.0F, -1.0F, 1.0F);
      buq.e();
      if (var6 == 3) {
         buq.a(buq.q.b);
      }

      ((bqd)var10).a((ve)null, var9, 0.0F, 0.0F, var5, 0.0F, 0.0625F);
      buq.H();
      if (var8 >= 0) {
         buq.n(5890);
         buq.H();
         buq.n(5888);
      }

   }
}
