import com.google.common.collect.Maps;
import com.google.common.io.Files;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class nr implements nv {
   private static final Logger a = LogManager.getLogger();
   private final File b;
   private final MinecraftServer c;
   private final Map<nd, bm> d = Maps.newHashMap();
   private String e = "-";
   private bm f;
   private final ArrayDeque<nr.a> g = new ArrayDeque();
   private boolean h = false;
   private final bn i = new bn() {
      public String h_() {
         return nr.this.e;
      }

      public boolean a(int var1, String var2) {
         return var1 <= 2;
      }

      public ams e() {
         return nr.this.c.d[0];
      }

      public MinecraftServer C_() {
         return nr.this.c;
      }
   };

   public nr(@Nullable File var1, MinecraftServer var2) {
      this.b = var1;
      this.c = var2;
      this.f();
   }

   @Nullable
   public bm a(nd var1) {
      return (bm)this.d.get(var1);
   }

   public bl a() {
      return this.c.N();
   }

   public int c() {
      return this.c.d[0].W().c("maxCommandChainLength");
   }

   public Map<nd, bm> d() {
      return this.d;
   }

   public void e() {
      String var1 = this.c.d[0].W().a("gameLoopFunction");
      if (!var1.equals(this.e)) {
         this.e = var1;
         this.f = this.a(new nd(var1));
      }

      if (this.f != null) {
         this.a(this.f, this.i);
      }

   }

   public int a(bm var1, bn var2) {
      int var3 = this.c();
      if (this.h) {
         if (this.g.size() < var3) {
            this.g.addFirst(new nr.a(this, var2, new bm.d(var1)));
         }

         return 0;
      } else {
         int var6;
         try {
            this.h = true;
            int var4 = 0;
            bm.c[] var5 = var1.a();

            for(var6 = var5.length - 1; var6 >= 0; --var6) {
               this.g.push(new nr.a(this, var2, var5[var6]));
            }

            while(!this.g.isEmpty()) {
               ((nr.a)this.g.removeFirst()).a(this.g, var3);
               ++var4;
               if (var4 >= var3) {
                  var6 = var4;
                  return var6;
               }
            }

            var6 = var4;
         } finally {
            this.g.clear();
            this.h = false;
         }

         return var6;
      }
   }

   public void f() {
      this.d.clear();
      this.f = null;
      this.e = "-";
      this.h();
   }

   private void h() {
      if (this.b != null) {
         this.b.mkdirs();
         Iterator var1 = FileUtils.listFiles(this.b, new String[]{"mcfunction"}, true).iterator();

         while(var1.hasNext()) {
            File var2 = (File)var1.next();
            String var3 = FilenameUtils.removeExtension(this.b.toURI().relativize(var2.toURI()).toString());
            String[] var4 = var3.split("/", 2);
            if (var4.length == 2) {
               nd var5 = new nd(var4[0], var4[1]);

               try {
                  this.d.put(var5, bm.a(this, Files.readLines(var2, StandardCharsets.UTF_8)));
               } catch (Throwable var7) {
                  a.error("Couldn't read custom function " + var5 + " from " + var2, var7);
               }
            }
         }

         if (!this.d.isEmpty()) {
            a.info("Loaded " + this.d.size() + " custom command functions");
         }

      }
   }

   public static class a {
      private final nr a;
      private final bn b;
      private final bm.c c;

      public a(nr var1, bn var2, bm.c var3) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }

      public void a(ArrayDeque<nr.a> var1, int var2) {
         this.c.a(this.a, this.b, var1, var2);
      }

      public String toString() {
         return this.c.toString();
      }
   }
}
