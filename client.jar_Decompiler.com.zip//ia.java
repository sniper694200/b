import java.io.IOException;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;

public class ia implements ht<hw> {
   private int a;
   private UUID b;
   private int c;
   private double d;
   private double e;
   private double f;
   private int g;
   private int h;
   private int i;
   private byte j;
   private byte k;
   private byte l;
   private na m;
   private List<na.a<?>> n;

   public ia() {
   }

   public ia(vn var1) {
      this.a = var1.S();
      this.b = var1.bm();
      this.c = vg.b.a(var1.getClass());
      this.d = var1.p;
      this.e = var1.q;
      this.f = var1.r;
      this.j = (byte)((int)(var1.v * 256.0F / 360.0F));
      this.k = (byte)((int)(var1.w * 256.0F / 360.0F));
      this.l = (byte)((int)(var1.aP * 256.0F / 360.0F));
      double var2 = 3.9D;
      double var4 = var1.s;
      double var6 = var1.t;
      double var8 = var1.u;
      if (var4 < -3.9D) {
         var4 = -3.9D;
      }

      if (var6 < -3.9D) {
         var6 = -3.9D;
      }

      if (var8 < -3.9D) {
         var8 = -3.9D;
      }

      if (var4 > 3.9D) {
         var4 = 3.9D;
      }

      if (var6 > 3.9D) {
         var6 = 3.9D;
      }

      if (var8 > 3.9D) {
         var8 = 3.9D;
      }

      this.g = (int)(var4 * 8000.0D);
      this.h = (int)(var6 * 8000.0D);
      this.i = (int)(var8 * 8000.0D);
      this.m = var1.V();
   }

   public void a(gy var1) throws IOException {
      this.a = var1.g();
      this.b = var1.i();
      this.c = var1.g();
      this.d = var1.readDouble();
      this.e = var1.readDouble();
      this.f = var1.readDouble();
      this.j = var1.readByte();
      this.k = var1.readByte();
      this.l = var1.readByte();
      this.g = var1.readShort();
      this.h = var1.readShort();
      this.i = var1.readShort();
      this.n = na.b(var1);
   }

   public void b(gy var1) throws IOException {
      var1.d(this.a);
      var1.a(this.b);
      var1.d(this.c);
      var1.writeDouble(this.d);
      var1.writeDouble(this.e);
      var1.writeDouble(this.f);
      var1.writeByte(this.j);
      var1.writeByte(this.k);
      var1.writeByte(this.l);
      var1.writeShort(this.g);
      var1.writeShort(this.h);
      var1.writeShort(this.i);
      this.m.a(var1);
   }

   public void a(hw var1) {
      var1.a(this);
   }

   @Nullable
   public List<na.a<?>> a() {
      return this.n;
   }

   public int b() {
      return this.a;
   }

   public UUID c() {
      return this.b;
   }

   public int d() {
      return this.c;
   }

   public double e() {
      return this.d;
   }

   public double f() {
      return this.e;
   }

   public double g() {
      return this.f;
   }

   public int h() {
      return this.g;
   }

   public int i() {
      return this.h;
   }

   public int j() {
      return this.i;
   }

   public byte k() {
      return this.j;
   }

   public byte l() {
      return this.k;
   }

   public byte m() {
      return this.l;
   }
}
