public class abn extends abe {
   private int b;
   private int c;
   private vc d;

   public abn(abb var1) {
      super(var1);
   }

   public void b() {
      ++this.b;
      if (this.b % 2 == 0 && this.b < 10) {
         bhc var1 = this.a.a(1.0F).a();
         var1.b(-0.7853982F);
         double var2 = this.a.bw.p;
         double var4 = this.a.bw.q + (double)(this.a.bw.H / 2.0F);
         double var6 = this.a.bw.r;

         for(int var8 = 0; var8 < 8; ++var8) {
            double var9 = var2 + this.a.bR().nextGaussian() / 2.0D;
            double var11 = var4 + this.a.bR().nextGaussian() / 2.0D;
            double var13 = var6 + this.a.bR().nextGaussian() / 2.0D;

            for(int var15 = 0; var15 < 6; ++var15) {
               this.a.l.a(fj.Q, var9, var11, var13, -var1.b * 0.07999999821186066D * (double)var15, -var1.c * 0.6000000238418579D, -var1.d * 0.07999999821186066D * (double)var15);
            }

            var1.b(0.19634955F);
         }
      }

   }

   public void c() {
      ++this.b;
      if (this.b >= 200) {
         if (this.c >= 4) {
            this.a.de().a(abr.e);
         } else {
            this.a.de().a(abr.g);
         }
      } else if (this.b == 10) {
         bhc var1 = (new bhc(this.a.bw.p - this.a.p, 0.0D, this.a.bw.r - this.a.r)).a();
         float var2 = 5.0F;
         double var3 = this.a.bw.p + var1.b * 5.0D / 2.0D;
         double var5 = this.a.bw.r + var1.d * 5.0D / 2.0D;
         double var7 = this.a.bw.q + (double)(this.a.bw.H / 2.0F);
         et.a var9 = new et.a(ri.c(var3), ri.c(var7), ri.c(var5));

         while(this.a.l.d((et)var9)) {
            --var7;
            var9.c(ri.c(var3), ri.c(var7), ri.c(var5));
         }

         var7 = (double)(ri.c(var7) + 1);
         this.d = new vc(this.a.l, var3, var7, var5);
         this.d.a((vn)this.a);
         this.d.a(5.0F);
         this.d.e(200);
         this.d.a(fj.Q);
         this.d.a(new uy(uz.g));
         this.a.l.a((ve)this.d);
      }

   }

   public void d() {
      this.b = 0;
      ++this.c;
   }

   public void e() {
      if (this.d != null) {
         this.d.X();
         this.d = null;
      }

   }

   public abr<abn> i() {
      return abr.f;
   }

   public void j() {
      this.c = 0;
   }
}
