public class app extends aou {
   protected app() {
      super(bcx.d);
      this.a(ahn.c);
   }

   public boolean a(ams var1, et var2, awr var3, aeb var4, tz var5, fa var6, float var7, float var8, float var9) {
      if (var1.G) {
         return true;
      } else {
         var4.a((ua)(new app.a(var1, var2)));
         var4.b(qq.Z);
         return true;
      }
   }

   public static class a implements ua {
      private final ams a;
      private final et b;

      public a(ams var1, et var2) {
         this.a = var1;
         this.b = var2;
      }

      public String h_() {
         return "crafting_table";
      }

      public boolean n_() {
         return false;
      }

      public hh i_() {
         return new hp(aov.ai.a() + ".name", new Object[0]);
      }

      public afp a(aea var1, aeb var2) {
         return new afx(var1, this.a, this.b);
      }

      public String l() {
         return "minecraft:crafting_table";
      }
   }
}
