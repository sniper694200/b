import com.google.common.collect.Maps;
import java.util.Map;

public class bgq {
   private static final Map<nd, bgr.a<?>> a = Maps.newHashMap();
   private static final Map<Class<? extends bgr>, bgr.a<?>> b = Maps.newHashMap();

   public static <T extends bgr> void a(bgr.a<? extends T> var0) {
      nd var1 = var0.a();
      Class<T> var2 = var0.b();
      if (a.containsKey(var1)) {
         throw new IllegalArgumentException("Can't re-register entity property name " + var1);
      } else if (b.containsKey(var2)) {
         throw new IllegalArgumentException("Can't re-register entity property class " + var2.getName());
      } else {
         a.put(var1, var0);
         b.put(var2, var0);
      }
   }

   public static bgr.a<?> a(nd var0) {
      bgr.a<?> var1 = (bgr.a)a.get(var0);
      if (var1 == null) {
         throw new IllegalArgumentException("Unknown loot entity property '" + var0 + "'");
      } else {
         return var1;
      }
   }

   public static <T extends bgr> bgr.a<T> a(T var0) {
      bgr.a<?> var1 = (bgr.a)b.get(var0.getClass());
      if (var1 == null) {
         throw new IllegalArgumentException("Unknown loot entity property " + var0);
      } else {
         return var1;
      }
   }

   static {
      a((bgr.a)(new bgs.a()));
   }
}
