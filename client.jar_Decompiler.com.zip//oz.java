import net.minecraft.server.MinecraftServer;

public class oz implements md {
   private final MinecraftServer a;
   private final gw b;

   public oz(MinecraftServer var1, gw var2) {
      this.a = var1;
      this.b = var2;
   }

   public void a(mc var1) {
      switch(var1.a()) {
      case d:
         this.b.a(gx.d);
         hp var2;
         if (var1.b() > 335) {
            var2 = new hp("multiplayer.disconnect.outdated_server", new Object[]{"1.12"});
            this.b.a((ht)(new mj(var2)));
            this.b.a((hh)var2);
         } else if (var1.b() < 335) {
            var2 = new hp("multiplayer.disconnect.outdated_client", new Object[]{"1.12"});
            this.b.a((ht)(new mj(var2)));
            this.b.a((hh)var2);
         } else {
            this.b.a((hb)(new pa(this.a, this.b)));
         }
         break;
      case c:
         this.b.a(gx.c);
         this.b.a((hb)(new pb(this.a, this.b)));
         break;
      default:
         throw new UnsupportedOperationException("Invalid intention " + var1.a());
      }

   }

   public void a(hh var1) {
   }
}
