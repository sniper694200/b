public class caq extends bzp<acn> {
   private static final nd a = new nd("textures/entity/skeleton/skeleton.png");

   public caq(bzd var1) {
      super(var1, new bqu(), 0.5F);
      this.a((cce)(new cca(this)));
      this.a((cce)(new cbz(this) {
         protected void M_() {
            this.c = new bqu(0.5F, true);
            this.d = new bqu(1.0F, true);
         }
      }));
   }

   public void N_() {
      buq.c(0.09375F, 0.1875F, 0.0F);
   }

   protected nd a(acn var1) {
      return a;
   }
}
