public class aqx extends ark {
   public aqx(ahq var1) {
      super(bcx.e, bcy.a(var1));
      this.c(1.4F);
      this.a(atw.d);
      String var2 = var1.d();
      if (var2.length() > 1) {
         String var3 = var2.substring(0, 1).toUpperCase() + var2.substring(1, var2.length());
         this.c("glazedTerracotta" + var3);
      }

      this.a(ahn.c);
   }

   protected aws b() {
      return new aws(this, new axh[]{D});
   }

   public awr a(awr var1, atk var2) {
      return var1.a(D, var2.a((fa)var1.c(D)));
   }

   public awr a(awr var1, arw var2) {
      return var1.a(var2.a((fa)var1.c(D)));
   }

   public awr a(ams var1, et var2, fa var3, float var4, float var5, float var6, int var7, vn var8) {
      return this.t().a(D, var8.bt().d());
   }

   public int e(awr var1) {
      int var2 = 0;
      int var3 = var2 | ((fa)var1.c(D)).b();
      return var3;
   }

   public awr a(int var1) {
      return this.t().a(D, fa.b(var1));
   }

   public bda h(awr var1) {
      return bda.e;
   }
}
