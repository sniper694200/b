import javax.annotation.Nullable;

public class axn implements axz {
   private static final axy d = new axs();
   protected static final awr a;
   protected qu b;
   protected axy c;
   private int e;

   public axn() {
      this.b(4);
   }

   private static int b(int var0, int var1, int var2) {
      return var1 << 8 | var2 << 4 | var0;
   }

   private void b(int var1) {
      if (var1 != this.e) {
         this.e = var1;
         if (this.e <= 4) {
            this.e = 4;
            this.c = new axw(this.e, this);
         } else if (this.e <= 8) {
            this.c = new axt(this.e, this);
         } else {
            this.c = d;
            this.e = ri.d(aou.i.a());
         }

         this.c.a(a);
         this.b = new qu(this.e, 4096);
      }
   }

   public int a(int var1, awr var2) {
      qu var3 = this.b;
      axy var4 = this.c;
      this.b(var1);

      for(int var5 = 0; var5 < var3.b(); ++var5) {
         awr var6 = var4.a(var3.a(var5));
         if (var6 != null) {
            this.b(var5, var6);
         }
      }

      return this.c.a(var2);
   }

   public void a(int var1, int var2, int var3, awr var4) {
      this.b(b(var1, var2, var3), var4);
   }

   protected void b(int var1, awr var2) {
      int var3 = this.c.a(var2);
      this.b.a(var1, var3);
   }

   public awr a(int var1, int var2, int var3) {
      return this.a(b(var1, var2, var3));
   }

   protected awr a(int var1) {
      awr var2 = this.c.a(this.b.a(var1));
      return var2 == null ? a : var2;
   }

   public void a(gy var1) {
      int var2 = var1.readByte();
      if (this.e != var2) {
         this.b(var2);
      }

      this.c.a(var1);
      var1.b(this.b.a());
   }

   public void b(gy var1) {
      var1.writeByte(this.e);
      this.c.b(var1);
      var1.a(this.b.a());
   }

   @Nullable
   public axq a(byte[] var1, axq var2) {
      axq var3 = null;

      for(int var4 = 0; var4 < 4096; ++var4) {
         int var5 = aou.i.a(this.a(var4));
         int var6 = var4 & 15;
         int var7 = var4 >> 8 & 15;
         int var8 = var4 >> 4 & 15;
         if ((var5 >> 12 & 15) != 0) {
            if (var3 == null) {
               var3 = new axq();
            }

            var3.a(var6, var7, var8, var5 >> 12 & 15);
         }

         var1[var4] = (byte)(var5 >> 4 & 255);
         var2.a(var6, var7, var8, var5 & 15);
      }

      return var3;
   }

   public void a(byte[] var1, axq var2, @Nullable axq var3) {
      for(int var4 = 0; var4 < 4096; ++var4) {
         int var5 = var4 & 15;
         int var6 = var4 >> 8 & 15;
         int var7 = var4 >> 4 & 15;
         int var8 = var3 == null ? 0 : var3.a(var5, var6, var7);
         int var9 = var8 << 12 | (var1[var4] & 255) << 4 | var2.a(var5, var6, var7);
         this.b(var4, (awr)aou.i.a(var9));
      }

   }

   public int a() {
      return 1 + this.c.a() + gy.a(this.b.b()) + this.b.a().length * 8;
   }

   static {
      a = aov.a.t();
   }
}
