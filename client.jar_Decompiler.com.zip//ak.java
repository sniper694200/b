import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;

public class ak implements p<ak.a> {
   private static final nd a = new nd("impossible");

   public nd a() {
      return a;
   }

   public void a(nn var1, p.a<ak.a> var2) {
   }

   public void b(nn var1, p.a<ak.a> var2) {
   }

   public void a(nn var1) {
   }

   public ak.a b(JsonObject var1, JsonDeserializationContext var2) {
      return new ak.a();
   }

   // $FF: synthetic method
   public q a(JsonObject var1, JsonDeserializationContext var2) {
      return this.b(var1, var2);
   }

   public static class a extends u {
      public a() {
         super(ak.a);
      }
   }
}
