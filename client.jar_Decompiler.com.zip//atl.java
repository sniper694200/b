public class atl extends aqk {
   public static final axf<atl.a> a = axf.a("variant", atl.a.class);

   public atl() {
      this.w(this.A.b().a(a, atl.a.a));
   }

   public int d(awr var1) {
      return ((atl.a)var1.c(a)).b();
   }

   public void a(ahn var1, fi<ain> var2) {
      atl.a[] var3 = atl.a.values();
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         atl.a var6 = var3[var5];
         var2.add(new ain(this, 1, var6.b()));
      }

   }

   public bcy c(awr var1, amw var2, et var3) {
      return ((atl.a)var1.c(a)).d();
   }

   public awr a(int var1) {
      return this.t().a(a, atl.a.a(var1));
   }

   public int e(awr var1) {
      return ((atl.a)var1.c(a)).b();
   }

   protected aws b() {
      return new aws(this, new axh[]{a});
   }

   public int y(awr var1) {
      atl.a var2 = (atl.a)var1.c(a);
      return var2.a();
   }

   public static enum a implements rm {
      a(0, "sand", "default", bcy.e, -2370656),
      b(1, "red_sand", "red", bcy.r, -5679071);

      private static final atl.a[] c = new atl.a[values().length];
      private final int d;
      private final String e;
      private final bcy f;
      private final String g;
      private final int h;

      private a(int var3, String var4, String var5, bcy var6, int var7) {
         this.d = var3;
         this.e = var4;
         this.f = var6;
         this.g = var5;
         this.h = var7;
      }

      public int a() {
         return this.h;
      }

      public int b() {
         return this.d;
      }

      public String toString() {
         return this.e;
      }

      public bcy d() {
         return this.f;
      }

      public static atl.a a(int var0) {
         if (var0 < 0 || var0 >= c.length) {
            var0 = 0;
         }

         return c[var0];
      }

      public String m() {
         return this.e;
      }

      public String e() {
         return this.g;
      }

      static {
         atl.a[] var0 = values();
         int var1 = var0.length;

         for(int var2 = 0; var2 < var1; ++var2) {
            atl.a var3 = var0[var2];
            c[var3.b()] = var3;
         }

      }
   }
}
