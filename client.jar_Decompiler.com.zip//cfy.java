import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;

public class cfy implements cfw {
   private final bwa a;
   private final bvy b;

   public cfy(bwa var1, bvy var2) {
      this.a = var1;
      this.b = var2;
   }

   public List<bvn> a(@Nullable awr var1, @Nullable fa var2, long var3) {
      return Collections.emptyList();
   }

   public boolean a() {
      return false;
   }

   public boolean b() {
      return true;
   }

   public boolean c() {
      return true;
   }

   public cdo d() {
      return null;
   }

   public bwa e() {
      return this.a;
   }

   public bvy f() {
      return this.b;
   }
}
