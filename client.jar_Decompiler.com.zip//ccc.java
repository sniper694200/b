public class ccc implements cce<zy> {
   private final cae a;

   public ccc(cae var1) {
      this.a = var1;
   }

   public void a(zy var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8) {
      if (!var1.l_() && !var1.aX()) {
         bvk var9 = bhz.z().ab();
         this.a.a((nd)cdn.g);
         buq.q();
         buq.a(buq.i.a);
         buq.G();
         buq.b(1.0F, -1.0F, 1.0F);
         buq.c(0.2F, 0.35F, 0.5F);
         buq.b(42.0F, 0.0F, 1.0F, 0.0F);
         buq.G();
         buq.c(-0.5F, -0.5F, 0.5F);
         var9.a(aov.Q.t(), 1.0F);
         buq.H();
         buq.G();
         buq.c(0.1F, 0.0F, -0.6F);
         buq.b(42.0F, 0.0F, 1.0F, 0.0F);
         buq.c(-0.5F, -0.5F, 0.5F);
         var9.a(aov.Q.t(), 1.0F);
         buq.H();
         buq.H();
         buq.G();
         this.a.h().a.c(0.0625F);
         buq.b(1.0F, -1.0F, 1.0F);
         buq.c(0.0F, 0.7F, -0.2F);
         buq.b(12.0F, 0.0F, 1.0F, 0.0F);
         buq.c(-0.5F, -0.5F, 0.5F);
         var9.a(aov.Q.t(), 1.0F);
         buq.H();
         buq.a(buq.i.b);
         buq.r();
      }
   }

   public boolean a() {
      return true;
   }
}
