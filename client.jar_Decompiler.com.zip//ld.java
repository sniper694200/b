import java.io.IOException;

public class ld implements ht<kw> {
   private int a;
   private short b;
   private boolean c;

   public ld() {
   }

   public ld(int var1, short var2, boolean var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }

   public void a(kw var1) {
      var1.a(this);
   }

   public void a(gy var1) throws IOException {
      this.a = var1.readByte();
      this.b = var1.readShort();
      this.c = var1.readByte() != 0;
   }

   public void b(gy var1) throws IOException {
      var1.writeByte(this.a);
      var1.writeShort(this.b);
      var1.writeByte(this.c ? 1 : 0);
   }

   public int a() {
      return this.a;
   }

   public short b() {
      return this.b;
   }
}
