public class ahz extends ail {
   public ahz() {
      this.k = 16;
      this.b(ahn.f);
   }

   public uc<ain> a(ams var1, aeb var2, tz var3) {
      ain var4 = var2.b((tz)var3);
      if (!var2.bO.d) {
         var4.g(1);
      }

      var1.a((aeb)null, var2.p, var2.q, var2.r, qd.bn, qe.g, 0.5F, 0.4F / (j.nextFloat() * 0.4F + 0.8F));
      var2.dt().a(this, 20);
      if (!var1.G) {
         aev var5 = new aev(var1, var2);
         var5.a(var2, var2.w, var2.v, 0.0F, 1.5F, 1.0F);
         var1.a((ve)var5);
      }

      var2.b(qq.b((ail)this));
      return new uc(ub.a, var4);
   }
}
