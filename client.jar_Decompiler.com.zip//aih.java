public class aih extends ail {
   public final int a;
   private final int b;
   private final float c;
   private final boolean d;
   private boolean e;
   private uy f;
   private float n;

   public aih(int var1, float var2, boolean var3) {
      this.a = 32;
      this.b = var1;
      this.d = var3;
      this.c = var2;
      this.b(ahn.h);
   }

   public aih(int var1, boolean var2) {
      this(var1, 0.6F, var2);
   }

   public ain a(ain var1, ams var2, vn var3) {
      if (var3 instanceof aeb) {
         aeb var4 = (aeb)var3;
         var4.di().a(this, var1);
         var2.a((aeb)null, var4.p, var4.q, var4.r, qd.fD, qe.h, 0.5F, var2.r.nextFloat() * 0.1F + 0.9F);
         this.a(var1, var2, var4);
         var4.b(qq.b((ail)this));
         if (var4 instanceof oo) {
            m.y.a((oo)var4, var1);
         }
      }

      var1.g(1);
      return var1;
   }

   protected void a(ain var1, ams var2, aeb var3) {
      if (!var2.G && this.f != null && var2.r.nextFloat() < this.n) {
         var3.c((uy)(new uy(this.f)));
      }

   }

   public int e(ain var1) {
      return 32;
   }

   public aka f(ain var1) {
      return aka.b;
   }

   public uc<ain> a(ams var1, aeb var2, tz var3) {
      ain var4 = var2.b((tz)var3);
      if (var2.n(this.e)) {
         var2.c((tz)var3);
         return new uc(ub.a, var4);
      } else {
         return new uc(ub.c, var4);
      }
   }

   public int h(ain var1) {
      return this.b;
   }

   public float i(ain var1) {
      return this.c;
   }

   public boolean g() {
      return this.d;
   }

   public aih a(uy var1, float var2) {
      this.f = var1;
      this.n = var2;
      return this;
   }

   public aih h() {
      this.e = true;
      return this;
   }
}
