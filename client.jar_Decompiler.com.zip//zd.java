import com.google.common.collect.Lists;
import java.util.List;
import javax.annotation.Nullable;

public class zd implements amu {
   private final List<zc> a = Lists.newArrayList();

   public void a(ams var1, et var2, awr var3, awr var4, int var5) {
      if (this.a(var1, var2, var3, var4)) {
         int var6 = 0;

         for(int var7 = this.a.size(); var6 < var7; ++var6) {
            zc var8 = (zc)this.a.get(var6);
            if (var8 != null && !var8.j()) {
               bej var9 = var8.l();
               if (var9 != null && !var9.b() && var9.d() != 0) {
                  beh var10 = var8.c.c();
                  double var11 = var2.f(((double)var10.a + var8.a.p) / 2.0D, ((double)var10.b + var8.a.q) / 2.0D, ((double)var10.c + var8.a.r) / 2.0D);
                  int var13 = (var9.d() - var9.e()) * (var9.d() - var9.e());
                  if (var11 < (double)var13) {
                     var8.k();
                  }
               }
            }
         }

      }
   }

   protected boolean a(ams var1, et var2, awr var3, awr var4) {
      bgz var5 = var3.d(var1, var2);
      bgz var6 = var4.d(var1, var2);
      return var5 != var6 && (var5 == null || !var5.equals(var6));
   }

   public void a(et var1) {
   }

   public void a(int var1, int var2, int var3, int var4, int var5, int var6) {
   }

   public void a(@Nullable aeb var1, qc var2, qe var3, double var4, double var6, double var8, float var10, float var11) {
   }

   public void a(int var1, boolean var2, double var3, double var5, double var7, double var9, double var11, double var13, int... var15) {
   }

   public void a(int var1, boolean var2, boolean var3, double var4, double var6, double var8, double var10, double var12, double var14, int... var16) {
   }

   public void a(ve var1) {
      if (var1 instanceof vo) {
         this.a.add(((vo)var1).x());
      }

   }

   public void b(ve var1) {
      if (var1 instanceof vo) {
         this.a.remove(((vo)var1).x());
      }

   }

   public void a(qc var1, et var2) {
   }

   public void a(int var1, et var2, int var3) {
   }

   public void a(aeb var1, int var2, et var3, int var4) {
   }

   public void b(int var1, et var2, int var3) {
   }
}
