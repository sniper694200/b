import com.google.common.collect.Maps;
import java.util.Map;

public class chn extends fo<nd, cho> {
   private Map<nd, cho> a;

   protected Map<nd, cho> b() {
      this.a = Maps.newHashMap();
      return this.a;
   }

   public void a(cho var1) {
      this.a(var1.b(), var1);
   }

   public void a() {
      this.a.clear();
   }
}
