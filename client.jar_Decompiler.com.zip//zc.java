import javax.annotation.Nullable;

public abstract class zc {
   protected vo a;
   protected ams b;
   @Nullable
   protected bej c;
   protected double d;
   private final wb i;
   protected int e;
   private int j;
   private bhc k;
   private bhc l;
   private long m;
   private long n;
   private double o;
   protected float f;
   protected boolean g;
   private long p;
   protected bei h;
   private et q;
   private final bek r;

   public zc(vo var1, ams var2) {
      this.k = bhc.a;
      this.l = bhc.a;
      this.f = 0.5F;
      this.a = var1;
      this.b = var2;
      this.i = var1.a((wa)adf.b);
      this.r = this.a();
   }

   protected abstract bek a();

   public void a(double var1) {
      this.d = var1;
   }

   public float i() {
      return (float)this.i.e();
   }

   public boolean j() {
      return this.g;
   }

   public void k() {
      if (this.b.R() - this.p > 20L) {
         if (this.q != null) {
            this.c = null;
            this.c = this.b(this.q);
            this.p = this.b.R();
            this.g = false;
         }
      } else {
         this.g = true;
      }

   }

   @Nullable
   public final bej a(double var1, double var3, double var5) {
      return this.b(new et(var1, var3, var5));
   }

   @Nullable
   public bej b(et var1) {
      if (!this.b()) {
         return null;
      } else if (this.c != null && !this.c.b() && var1.equals(this.q)) {
         return this.c;
      } else {
         this.q = var1;
         float var2 = this.i();
         this.b.E.a("pathfind");
         et var3 = new et(this.a);
         int var4 = (int)(var2 + 8.0F);
         anb var5 = new anb(this.b, var3.a(-var4, -var4, -var4), var3.a(var4, var4, var4), 0);
         bej var6 = this.r.a(var5, this.a, (et)this.q, var2);
         this.b.E.b();
         return var6;
      }
   }

   @Nullable
   public bej a(ve var1) {
      if (!this.b()) {
         return null;
      } else {
         et var2 = new et(var1);
         if (this.c != null && !this.c.b() && var2.equals(this.q)) {
            return this.c;
         } else {
            this.q = var2;
            float var3 = this.i();
            this.b.E.a("pathfind");
            et var4 = (new et(this.a)).a();
            int var5 = (int)(var3 + 16.0F);
            anb var6 = new anb(this.b, var4.a(-var5, -var5, -var5), var4.a(var5, var5, var5), 0);
            bej var7 = this.r.a(var6, this.a, (ve)var1, var3);
            this.b.E.b();
            return var7;
         }
      }
   }

   public boolean a(double var1, double var3, double var5, double var7) {
      return this.a(this.a(var1, var3, var5), var7);
   }

   public boolean a(ve var1, double var2) {
      bej var4 = this.a(var1);
      return var4 != null && this.a(var4, var2);
   }

   public boolean a(@Nullable bej var1, double var2) {
      if (var1 == null) {
         this.c = null;
         return false;
      } else {
         if (!var1.a(this.c)) {
            this.c = var1;
         }

         this.q_();
         if (this.c.d() <= 0) {
            return false;
         } else {
            this.d = var2;
            bhc var4 = this.c();
            this.j = this.e;
            this.k = var4;
            return true;
         }
      }
   }

   @Nullable
   public bej l() {
      return this.c;
   }

   public void d() {
      ++this.e;
      if (this.g) {
         this.k();
      }

      if (!this.o()) {
         bhc var1;
         if (this.b()) {
            this.n();
         } else if (this.c != null && this.c.e() < this.c.d()) {
            var1 = this.c();
            bhc var2 = this.c.a(this.a, this.c.e());
            if (var1.c > var2.c && !this.a.z && ri.c(var1.b) == ri.c(var2.b) && ri.c(var1.d) == ri.c(var2.d)) {
               this.c.c(this.c.e() + 1);
            }
         }

         this.m();
         if (!this.o()) {
            var1 = this.c.a((ve)this.a);
            et var4 = (new et(var1)).b();
            bgz var3 = this.b.o(var4).e(this.b, var4);
            var1 = var1.a(0.0D, 1.0D - var3.e, 0.0D);
            this.a.u().a(var1.b, var1.c, var1.d, this.d);
         }
      }
   }

   protected void m() {
   }

   protected void n() {
      bhc var1 = this.c();
      int var2 = this.c.d();

      for(int var3 = this.c.e(); var3 < this.c.d(); ++var3) {
         if ((double)this.c.a(var3).b != Math.floor(var1.c)) {
            var2 = var3;
            break;
         }
      }

      this.f = this.a.G > 0.75F ? this.a.G / 2.0F : 0.75F - this.a.G / 2.0F;
      bhc var8 = this.c.f();
      if (ri.e((float)(this.a.p - (var8.b + 0.5D))) < this.f && ri.e((float)(this.a.r - (var8.d + 0.5D))) < this.f && Math.abs(this.a.q - var8.c) < 1.0D) {
         this.c.c(this.c.e() + 1);
      }

      int var4 = ri.f(this.a.G);
      int var5 = ri.f(this.a.H);
      int var6 = var4;

      for(int var7 = var2 - 1; var7 >= this.c.e(); --var7) {
         if (this.a(var1, this.c.a(this.a, var7), var4, var5, var6)) {
            this.c.c(var7);
            break;
         }
      }

      this.a(var1);
   }

   protected void a(bhc var1) {
      if (this.e - this.j > 100) {
         if (var1.g(this.k) < 2.25D) {
            this.p();
         }

         this.j = this.e;
         this.k = var1;
      }

      if (this.c != null && !this.c.b()) {
         bhc var2 = this.c.f();
         if (var2.equals(this.l)) {
            this.m += System.currentTimeMillis() - this.n;
         } else {
            this.l = var2;
            double var3 = var1.f(this.l);
            this.o = this.a.cy() > 0.0F ? var3 / (double)this.a.cy() * 1000.0D : 0.0D;
         }

         if (this.o > 0.0D && (double)this.m > this.o * 3.0D) {
            this.l = bhc.a;
            this.m = 0L;
            this.o = 0.0D;
            this.p();
         }

         this.n = System.currentTimeMillis();
      }

   }

   public boolean o() {
      return this.c == null || this.c.b();
   }

   public void p() {
      this.c = null;
   }

   protected abstract bhc c();

   protected abstract boolean b();

   protected boolean q() {
      return this.a.ao() || this.a.au();
   }

   protected void q_() {
      if (this.c != null) {
         for(int var1 = 0; var1 < this.c.d(); ++var1) {
            beh var2 = this.c.a(var1);
            beh var3 = var1 + 1 < this.c.d() ? this.c.a(var1 + 1) : null;
            awr var4 = this.b.o(new et(var2.a, var2.b, var2.c));
            aou var5 = var4.u();
            if (var5 == aov.bE) {
               this.c.a(var1, var2.a(var2.a, var2.b + 1, var2.c));
               if (var3 != null && var2.b >= var3.b) {
                  this.c.a(var1 + 1, var3.a(var3.a, var2.b + 1, var3.c));
               }
            }
         }

      }
   }

   protected abstract boolean a(bhc var1, bhc var2, int var3, int var4, int var5);

   public boolean a(et var1) {
      return this.b.o(var1.b()).b();
   }

   public bei r() {
      return this.h;
   }
}
