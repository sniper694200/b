public class arc extends asg {
   public boolean e() {
      return false;
   }
}
