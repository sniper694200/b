import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.lang.reflect.Type;
import javax.annotation.Nullable;

public class bvp {
   public static final fa a = null;
   public final fa b;
   public final int c;
   public final String d;
   public final bvr e;

   public bvp(@Nullable fa var1, int var2, String var3, bvr var4) {
      this.b = var1;
      this.c = var2;
      this.d = var3;
      this.e = var4;
   }

   static class a implements JsonDeserializer<bvp> {
      public bvp a(JsonElement var1, Type var2, JsonDeserializationContext var3) throws JsonParseException {
         JsonObject var4 = var1.getAsJsonObject();
         fa var5 = this.c(var4);
         int var6 = this.a(var4);
         String var7 = this.b(var4);
         bvr var8 = (bvr)var3.deserialize(var4, bvr.class);
         return new bvp(var5, var6, var7, var8);
      }

      protected int a(JsonObject var1) {
         return ra.a(var1, "tintindex", -1);
      }

      private String b(JsonObject var1) {
         return ra.h(var1, "texture");
      }

      @Nullable
      private fa c(JsonObject var1) {
         String var2 = ra.a(var1, "cullface", "");
         return fa.a(var2);
      }

      // $FF: synthetic method
      public Object deserialize(JsonElement var1, Type var2, JsonDeserializationContext var3) throws JsonParseException {
         return this.a(var1, var2, var3);
      }
   }
}
