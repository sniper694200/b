import com.google.common.base.MoreObjects;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class bwn {
   private final Map<aou, bwq> a = Maps.newIdentityHashMap();
   private final Set<aou> b = Sets.newIdentityHashSet();

   public void a(aou var1, bwq var2) {
      this.a.put(var1, var2);
   }

   public void a(aou... var1) {
      Collections.addAll(this.b, var1);
   }

   public Map<awr, cgb> a() {
      Map<awr, cgb> var1 = Maps.newIdentityHashMap();
      Iterator var2 = aou.h.iterator();

      while(var2.hasNext()) {
         aou var3 = (aou)var2.next();
         var1.putAll(this.b(var3));
      }

      return var1;
   }

   public Set<nd> a(aou var1) {
      if (this.b.contains(var1)) {
         return Collections.emptySet();
      } else {
         bwq var2 = (bwq)this.a.get(var1);
         if (var2 == null) {
            return Collections.singleton(aou.h.b(var1));
         } else {
            Set<nd> var3 = Sets.newHashSet();
            Iterator var4 = var2.a(var1).values().iterator();

            while(var4.hasNext()) {
               cgb var5 = (cgb)var4.next();
               var3.add(new nd(var5.b(), var5.a()));
            }

            return var3;
         }
      }
   }

   public Map<awr, cgb> b(aou var1) {
      return this.b.contains(var1) ? Collections.emptyMap() : ((bwq)MoreObjects.firstNonNull(this.a.get(var1), new bwo())).a(var1);
   }
}
