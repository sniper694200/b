import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.nio.IntBuffer;
import javax.imageio.ImageIO;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class cdr {
   private static final Logger c = LogManager.getLogger();
   private static final IntBuffer d = bhy.f(4194304);
   public static final cde a = new cde(16, 16);
   public static final int[] b;
   private static final float[] e;
   private static final int[] f;

   private static float d(int var0) {
      return e[var0 & 255];
   }

   public static int a() {
      return buq.A();
   }

   public static void a(int var0) {
      buq.h(var0);
   }

   public static int a(int var0, BufferedImage var1) {
      return a(var0, var1, false, false);
   }

   public static void a(int var0, int[] var1, int var2, int var3) {
      b(var0);
      a(0, var1, var2, var3, 0, 0, false, false, false);
   }

   public static int[][] a(int var0, int var1, int[][] var2) {
      int[][] var3 = new int[var0 + 1][];
      var3[0] = var2[0];
      if (var0 > 0) {
         boolean var4 = false;

         int var5;
         for(var5 = 0; var5 < var2.length; ++var5) {
            if (var2[0][var5] >> 24 == 0) {
               var4 = true;
               break;
            }
         }

         for(var5 = 1; var5 <= var0; ++var5) {
            if (var2[var5] != null) {
               var3[var5] = var2[var5];
            } else {
               int[] var6 = var3[var5 - 1];
               int[] var7 = new int[var6.length >> 2];
               int var8 = var1 >> var5;
               int var9 = var7.length / var8;
               int var10 = var8 << 1;

               for(int var11 = 0; var11 < var8; ++var11) {
                  for(int var12 = 0; var12 < var9; ++var12) {
                     int var13 = 2 * (var11 + var12 * var10);
                     var7[var11 + var12 * var8] = a(var6[var13 + 0], var6[var13 + 1], var6[var13 + 0 + var10], var6[var13 + 1 + var10], var4);
                  }
               }

               var3[var5] = var7;
            }
         }
      }

      return var3;
   }

   private static int a(int var0, int var1, int var2, int var3, boolean var4) {
      if (var4) {
         f[0] = var0;
         f[1] = var1;
         f[2] = var2;
         f[3] = var3;
         float var13 = 0.0F;
         float var14 = 0.0F;
         float var15 = 0.0F;
         float var16 = 0.0F;

         int var9;
         for(var9 = 0; var9 < 4; ++var9) {
            if (f[var9] >> 24 != 0) {
               var13 += d(f[var9] >> 24);
               var14 += d(f[var9] >> 16);
               var15 += d(f[var9] >> 8);
               var16 += d(f[var9] >> 0);
            }
         }

         var13 /= 4.0F;
         var14 /= 4.0F;
         var15 /= 4.0F;
         var16 /= 4.0F;
         var9 = (int)(Math.pow((double)var13, 0.45454545454545453D) * 255.0D);
         int var10 = (int)(Math.pow((double)var14, 0.45454545454545453D) * 255.0D);
         int var11 = (int)(Math.pow((double)var15, 0.45454545454545453D) * 255.0D);
         int var12 = (int)(Math.pow((double)var16, 0.45454545454545453D) * 255.0D);
         if (var9 < 96) {
            var9 = 0;
         }

         return var9 << 24 | var10 << 16 | var11 << 8 | var12;
      } else {
         int var5 = a(var0, var1, var2, var3, 24);
         int var6 = a(var0, var1, var2, var3, 16);
         int var7 = a(var0, var1, var2, var3, 8);
         int var8 = a(var0, var1, var2, var3, 0);
         return var5 << 24 | var6 << 16 | var7 << 8 | var8;
      }
   }

   private static int a(int var0, int var1, int var2, int var3, int var4) {
      float var5 = d(var0 >> var4);
      float var6 = d(var1 >> var4);
      float var7 = d(var2 >> var4);
      float var8 = d(var3 >> var4);
      float var9 = (float)((double)((float)Math.pow((double)(var5 + var6 + var7 + var8) * 0.25D, 0.45454545454545453D)));
      return (int)((double)var9 * 255.0D);
   }

   public static void a(int[][] var0, int var1, int var2, int var3, int var4, boolean var5, boolean var6) {
      for(int var7 = 0; var7 < var0.length; ++var7) {
         int[] var8 = var0[var7];
         a(var7, var8, var1 >> var7, var2 >> var7, var3 >> var7, var4 >> var7, var5, var6, var0.length > 1);
      }

   }

   private static void a(int var0, int[] var1, int var2, int var3, int var4, int var5, boolean var6, boolean var7, boolean var8) {
      int var9 = 4194304 / var2;
      a(var6, var8);
      a(var7);

      int var12;
      for(int var10 = 0; var10 < var2 * var3; var10 += var2 * var12) {
         int var11 = var10 / var2;
         var12 = Math.min(var9, var3 - var11);
         int var13 = var2 * var12;
         b(var1, var10, var13);
         buq.b(3553, var0, var4, var5 + var11, var2, var12, 32993, 33639, d);
      }

   }

   public static int a(int var0, BufferedImage var1, boolean var2, boolean var3) {
      a(var0, var1.getWidth(), var1.getHeight());
      return a(var0, var1, 0, 0, var2, var3);
   }

   public static void a(int var0, int var1, int var2) {
      a(var0, 0, var1, var2);
   }

   public static void a(int var0, int var1, int var2, int var3) {
      a(var0);
      b(var0);
      if (var1 >= 0) {
         buq.b(3553, 33085, var1);
         buq.b(3553, 33082, 0);
         buq.b(3553, 33083, var1);
         buq.b(3553, 34049, 0.0F);
      }

      for(int var4 = 0; var4 <= var1; ++var4) {
         buq.a(3553, var4, 6408, var2 >> var4, var3 >> var4, 0, 32993, 33639, (IntBuffer)null);
      }

   }

   public static int a(int var0, BufferedImage var1, int var2, int var3, boolean var4, boolean var5) {
      b(var0);
      a(var1, var2, var3, var4, var5);
      return var0;
   }

   private static void a(BufferedImage var0, int var1, int var2, boolean var3, boolean var4) {
      int var5 = var0.getWidth();
      int var6 = var0.getHeight();
      int var7 = 4194304 / var5;
      int[] var8 = new int[var7 * var5];
      b(var3);
      a(var4);

      for(int var9 = 0; var9 < var5 * var6; var9 += var5 * var7) {
         int var10 = var9 / var5;
         int var11 = Math.min(var7, var6 - var10);
         int var12 = var5 * var11;
         var0.getRGB(0, var10, var5, var11, var8, 0, var5);
         a(var8, var12);
         buq.b(3553, 0, var1, var2 + var10, var5, var11, 32993, 33639, d);
      }

   }

   private static void a(boolean var0) {
      if (var0) {
         buq.b(3553, 10242, 10496);
         buq.b(3553, 10243, 10496);
      } else {
         buq.b(3553, 10242, 10497);
         buq.b(3553, 10243, 10497);
      }

   }

   private static void b(boolean var0) {
      a(var0, false);
   }

   private static void a(boolean var0, boolean var1) {
      if (var0) {
         buq.b(3553, 10241, var1 ? 9987 : 9729);
         buq.b(3553, 10240, 9729);
      } else {
         buq.b(3553, 10241, var1 ? 9986 : 9728);
         buq.b(3553, 10240, 9728);
      }

   }

   private static void a(int[] var0, int var1) {
      b(var0, 0, var1);
   }

   private static void b(int[] var0, int var1, int var2) {
      int[] var3 = var0;
      if (bhz.z().t.g) {
         var3 = a(var0);
      }

      d.clear();
      d.put(var3, var1, var2);
      d.position(0).limit(var2);
   }

   static void b(int var0) {
      buq.i(var0);
   }

   public static int[] a(cen var0, nd var1) throws IOException {
      cem var2 = null;

      int[] var7;
      try {
         var2 = var0.a(var1);
         BufferedImage var3 = a(var2.b());
         int var4 = var3.getWidth();
         int var5 = var3.getHeight();
         int[] var6 = new int[var4 * var5];
         var3.getRGB(0, 0, var4, var5, var6, 0, var4);
         var7 = var6;
      } finally {
         IOUtils.closeQuietly(var2);
      }

      return var7;
   }

   public static BufferedImage a(InputStream var0) throws IOException {
      BufferedImage var1;
      try {
         var1 = ImageIO.read(var0);
      } finally {
         IOUtils.closeQuietly(var0);
      }

      return var1;
   }

   public static int[] a(int[] var0) {
      int[] var1 = new int[var0.length];

      for(int var2 = 0; var2 < var0.length; ++var2) {
         var1[var2] = c(var0[var2]);
      }

      return var1;
   }

   public static int c(int var0) {
      int var1 = var0 >> 24 & 255;
      int var2 = var0 >> 16 & 255;
      int var3 = var0 >> 8 & 255;
      int var4 = var0 & 255;
      int var5 = (var2 * 30 + var3 * 59 + var4 * 11) / 100;
      int var6 = (var2 * 30 + var3 * 70) / 100;
      int var7 = (var2 * 30 + var4 * 70) / 100;
      return var1 << 24 | var5 << 16 | var6 << 8 | var7;
   }

   public static void a(int[] var0, int var1, int var2) {
      int[] var3 = new int[var1];
      int var4 = var2 / 2;

      for(int var5 = 0; var5 < var4; ++var5) {
         System.arraycopy(var0, var5 * var1, var3, 0, var1);
         System.arraycopy(var0, (var2 - 1 - var5) * var1, var0, var5 * var1, var1);
         System.arraycopy(var3, 0, var0, (var2 - 1 - var5) * var1, var1);
      }

   }

   static {
      b = a.e();
      int var0 = -16777216;
      int var1 = -524040;
      int[] var2 = new int[]{-524040, -524040, -524040, -524040, -524040, -524040, -524040, -524040};
      int[] var3 = new int[]{-16777216, -16777216, -16777216, -16777216, -16777216, -16777216, -16777216, -16777216};
      int var4 = var2.length;

      for(int var5 = 0; var5 < 16; ++var5) {
         System.arraycopy(var5 < var4 ? var2 : var3, 0, b, 16 * var5, var4);
         System.arraycopy(var5 < var4 ? var3 : var2, 0, b, 16 * var5 + var4, var4);
      }

      a.d();
      e = new float[256];

      for(var0 = 0; var0 < e.length; ++var0) {
         e[var0] = (float)Math.pow((double)((float)var0 / 255.0F), 2.2D);
      }

      f = new int[4];
   }
}
