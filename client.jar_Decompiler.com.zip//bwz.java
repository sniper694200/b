public class bwz extends bww<avq> {
   private static final nd a = new nd("textures/entity/chest/ender.png");
   private final bpj d = new bpj();

   public void a(avq var1, double var2, double var4, double var6, float var8, int var9, float var10) {
      int var11 = 0;
      if (var1.u()) {
         var11 = var1.v();
      }

      if (var9 >= 0) {
         this.a(b[var9]);
         buq.n(5890);
         buq.G();
         buq.b(4.0F, 4.0F, 1.0F);
         buq.c(0.0625F, 0.0625F, 0.0625F);
         buq.n(5888);
      } else {
         this.a(a);
      }

      buq.G();
      buq.D();
      buq.c(1.0F, 1.0F, 1.0F, var10);
      buq.c((float)var2, (float)var4 + 1.0F, (float)var6 + 1.0F);
      buq.b(1.0F, -1.0F, -1.0F);
      buq.c(0.5F, 0.5F, 0.5F);
      int var12 = 0;
      if (var11 == 2) {
         var12 = 180;
      }

      if (var11 == 3) {
         var12 = 0;
      }

      if (var11 == 4) {
         var12 = 90;
      }

      if (var11 == 5) {
         var12 = -90;
      }

      buq.b((float)var12, 0.0F, 1.0F, 0.0F);
      buq.c(-0.5F, -0.5F, -0.5F);
      float var13 = var1.f + (var1.a - var1.f) * var8;
      var13 = 1.0F - var13;
      var13 = 1.0F - var13 * var13 * var13;
      this.d.a.f = -(var13 * 1.5707964F);
      this.d.a();
      buq.E();
      buq.H();
      buq.c(1.0F, 1.0F, 1.0F, 1.0F);
      if (var9 >= 0) {
         buq.n(5890);
         buq.H();
         buq.n(5888);
      }

   }
}
