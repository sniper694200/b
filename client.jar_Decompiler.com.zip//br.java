import com.google.common.collect.Lists;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public class br extends bi {
   public String c() {
      return "advancement";
   }

   public int a() {
      return 2;
   }

   public String b(bn var1) {
      return "commands.advancement.usage";
   }

   public void a(MinecraftServer var1, bn var2, String[] var3) throws ei {
      if (var3.length < 1) {
         throw new ep("commands.advancement.usage", new Object[0]);
      } else {
         br.a var4 = br.a.a(var3[0]);
         if (var4 != null) {
            if (var3.length < 3) {
               throw var4.a();
            }

            oo var5 = b(var1, var2, var3[1]);
            br.b var6 = br.b.a(var3[2]);
            if (var6 == null) {
               throw var4.a();
            }

            this.a(var1, var2, var3, var5, var4, var6);
         } else {
            if (!"test".equals(var3[0])) {
               throw new ep("commands.advancement.usage", new Object[0]);
            }

            if (var3.length == 3) {
               this.a(var2, b(var1, var2, var3[1]), a(var1, var3[2]));
            } else {
               if (var3.length != 4) {
                  throw new ep("commands.advancement.test.usage", new Object[0]);
               }

               this.a(var2, b(var1, var2, var3[1]), a(var1, var3[2]), var3[3]);
            }
         }

      }
   }

   private void a(MinecraftServer var1, bn var2, String[] var3, oo var4, br.a var5, br.b var6) throws ei {
      if (var6 == br.b.e) {
         if (var3.length == 3) {
            int var10 = var5.a(var4, var1.aK().c());
            if (var10 == 0) {
               throw var6.a(var5, var4.h_());
            } else {
               var6.a(var2, this, var5, var4.h_(), var10);
            }
         } else {
            throw var6.a(var5);
         }
      } else if (var3.length < 4) {
         throw var6.a(var5);
      } else {
         i var7 = a(var1, var3[3]);
         if (var6 == br.b.a && var3.length == 5) {
            String var11 = var3[4];
            if (!var7.f().keySet().contains(var11)) {
               throw new ei("commands.advancement.criterionNotFound", new Object[]{var7.h(), var3[4]});
            }

            if (!var5.a(var4, var7, var11)) {
               throw new ei(var5.d + ".criterion.failed", new Object[]{var7.h(), var4.h_(), var11});
            }

            a((bn)var2, (bk)this, (String)(var5.d + ".criterion.success"), (Object[])(new Object[]{var7.h(), var4.h_(), var11}));
         } else {
            if (var3.length != 4) {
               throw var6.a(var5);
            }

            List<i> var8 = this.a(var7, var6);
            int var9 = var5.a(var4, (Iterable)var8);
            if (var9 == 0) {
               throw var6.a(var5, var7.h(), var4.h_());
            }

            var6.a(var2, this, var5, var7.h(), var4.h_(), var9);
         }

      }
   }

   private void a(i var1, List<i> var2) {
      Iterator var3 = var1.e().iterator();

      while(var3.hasNext()) {
         i var4 = (i)var3.next();
         var2.add(var4);
         this.a(var4, var2);
      }

   }

   private List<i> a(i var1, br.b var2) {
      List<i> var3 = Lists.newArrayList();
      if (var2.h) {
         for(i var4 = var1.b(); var4 != null; var4 = var4.b()) {
            var3.add(var4);
         }
      }

      var3.add(var1);
      if (var2.i) {
         this.a((i)var1, (List)var3);
      }

      return var3;
   }

   private void a(bn var1, oo var2, i var3, String var4) throws ei {
      nn var5 = var2.P();
      o var6 = var5.b(var3).c(var4);
      if (var6 == null) {
         throw new ei("commands.advancement.criterionNotFound", new Object[]{var3.h(), var4});
      } else if (!var6.a()) {
         throw new ei("commands.advancement.test.criterion.notDone", new Object[]{var2.h_(), var3.h(), var4});
      } else {
         a((bn)var1, (bk)this, (String)"commands.advancement.test.criterion.success", (Object[])(new Object[]{var2.h_(), var3.h(), var4}));
      }
   }

   private void a(bn var1, oo var2, i var3) throws ei {
      k var4 = var2.P().b(var3);
      if (!var4.a()) {
         throw new ei("commands.advancement.test.advancement.notDone", new Object[]{var2.h_(), var3.h()});
      } else {
         a((bn)var1, (bk)this, (String)"commands.advancement.test.advancement.success", (Object[])(new Object[]{var2.h_(), var3.h()}));
      }
   }

   public List<String> a(MinecraftServer var1, bn var2, String[] var3, @Nullable et var4) {
      if (var3.length == 1) {
         return a((String[])var3, (String[])(new String[]{"grant", "revoke", "test"}));
      } else {
         br.a var5 = br.a.a(var3[0]);
         if (var5 != null) {
            if (var3.length == 2) {
               return a((String[])var3, (String[])var1.J());
            }

            if (var3.length == 3) {
               return a((String[])var3, (String[])br.b.f);
            }

            br.b var6 = br.b.a(var3[2]);
            if (var6 != null && var6 != br.b.e) {
               if (var3.length == 4) {
                  return a((String[])var3, (Collection)this.a(var1));
               }

               if (var3.length == 5 && var6 == br.b.a) {
                  i var7 = var1.aK().a(new nd(var3[3]));
                  if (var7 != null) {
                     return a((String[])var3, (Collection)var7.f().keySet());
                  }
               }
            }
         }

         if ("test".equals(var3[0])) {
            if (var3.length == 2) {
               return a((String[])var3, (String[])var1.J());
            }

            if (var3.length == 3) {
               return a((String[])var3, (Collection)this.a(var1));
            }

            if (var3.length == 4) {
               i var8 = var1.aK().a(new nd(var3[2]));
               if (var8 != null) {
                  return a((String[])var3, (Collection)var8.f().keySet());
               }
            }
         }

         return Collections.emptyList();
      }
   }

   private List<nd> a(MinecraftServer var1) {
      List<nd> var2 = Lists.newArrayList();
      Iterator var3 = var1.aK().c().iterator();

      while(var3.hasNext()) {
         i var4 = (i)var3.next();
         var2.add(var4.h());
      }

      return var2;
   }

   public boolean b(String[] var1, int var2) {
      return var1.length > 1 && ("grant".equals(var1[0]) || "revoke".equals(var1[0]) || "test".equals(var1[0])) && var2 == 1;
   }

   public static i a(MinecraftServer var0, String var1) throws ei {
      i var2 = var0.aK().a(new nd(var1));
      if (var2 == null) {
         throw new ei("commands.advancement.advancementNotFound", new Object[]{var1});
      } else {
         return var2;
      }
   }

   static enum b {
      a("only", false, false),
      b("through", true, true),
      c("from", false, true),
      d("until", true, false),
      e("everything", true, true);

      static final String[] f = new String[values().length];
      final String g;
      final boolean h;
      final boolean i;

      private b(String var3, boolean var4, boolean var5) {
         this.g = var3;
         this.h = var4;
         this.i = var5;
      }

      ei a(br.a var1, Object... var2) {
         return new ei(var1.d + "." + this.g + ".failed", var2);
      }

      ei a(br.a var1) {
         return new ei(var1.d + "." + this.g + ".usage", new Object[0]);
      }

      void a(bn var1, br var2, br.a var3, Object... var4) {
         bi.a((bn)var1, (bk)var2, (String)(var3.d + "." + this.g + ".success"), (Object[])var4);
      }

      @Nullable
      static br.b a(String var0) {
         br.b[] var1 = values();
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            br.b var4 = var1[var3];
            if (var4.g.equals(var0)) {
               return var4;
            }
         }

         return null;
      }

      static {
         for(int var0 = 0; var0 < values().length; ++var0) {
            f[var0] = values()[var0].g;
         }

      }
   }

   static enum a {
      a("grant") {
         protected boolean a(oo var1, i var2) {
            k var3 = var1.P().b(var2);
            if (var3.a()) {
               return false;
            } else {
               Iterator var4 = var3.e().iterator();

               while(var4.hasNext()) {
                  String var5 = (String)var4.next();
                  var1.P().a(var2, var5);
               }

               return true;
            }
         }

         protected boolean a(oo var1, i var2, String var3) {
            return var1.P().a(var2, var3);
         }
      },
      b("revoke") {
         protected boolean a(oo var1, i var2) {
            k var3 = var1.P().b(var2);
            if (!var3.b()) {
               return false;
            } else {
               Iterator var4 = var3.f().iterator();

               while(var4.hasNext()) {
                  String var5 = (String)var4.next();
                  var1.P().b(var2, var5);
               }

               return true;
            }
         }

         protected boolean a(oo var1, i var2, String var3) {
            return var1.P().b(var2, var3);
         }
      };

      final String c;
      final String d;

      private a(String var3) {
         this.c = var3;
         this.d = "commands.advancement." + var3;
      }

      @Nullable
      static br.a a(String var0) {
         br.a[] var1 = values();
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            br.a var4 = var1[var3];
            if (var4.c.equals(var0)) {
               return var4;
            }
         }

         return null;
      }

      ei a() {
         return new ei(this.d + ".usage", new Object[0]);
      }

      public int a(oo var1, Iterable<i> var2) {
         int var3 = 0;
         Iterator var4 = var2.iterator();

         while(var4.hasNext()) {
            i var5 = (i)var4.next();
            if (this.a(var1, var5)) {
               ++var3;
            }
         }

         return var3;
      }

      protected abstract boolean a(oo var1, i var2);

      protected abstract boolean a(oo var1, i var2, String var3);

      // $FF: synthetic method
      a(String var3, Object var4) {
         this(var3);
      }
   }
}
