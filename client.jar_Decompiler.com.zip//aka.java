public enum aka {
   a,
   b,
   c,
   d,
   e;
}
