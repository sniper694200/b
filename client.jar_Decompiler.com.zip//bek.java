import com.google.common.collect.Sets;
import java.util.Set;
import javax.annotation.Nullable;

public class bek {
   private final bee a = new bee();
   private final Set<beh> b = Sets.newHashSet();
   private final beh[] c = new beh[32];
   private final bei d;

   public bek(bei var1) {
      this.d = var1;
   }

   @Nullable
   public bej a(amw var1, vo var2, ve var3, float var4) {
      return this.a(var1, var2, var3.p, var3.bw().b, var3.r, var4);
   }

   @Nullable
   public bej a(amw var1, vo var2, et var3, float var4) {
      return this.a(var1, var2, (double)((float)var3.p() + 0.5F), (double)((float)var3.q() + 0.5F), (double)((float)var3.r() + 0.5F), var4);
   }

   @Nullable
   private bej a(amw var1, vo var2, double var3, double var5, double var7, float var9) {
      this.a.a();
      this.d.a(var1, var2);
      beh var10 = this.d.b();
      beh var11 = this.d.a(var3, var5, var7);
      bej var12 = this.a(var10, var11, var9);
      this.d.a();
      return var12;
   }

   @Nullable
   private bej a(beh var1, beh var2, float var3) {
      var1.e = 0.0F;
      var1.f = var1.c(var2);
      var1.g = var1.f;
      this.a.a();
      this.b.clear();
      this.a.a(var1);
      beh var4 = var1;
      int var5 = 0;

      while(!this.a.e()) {
         ++var5;
         if (var5 >= 200) {
            break;
         }

         beh var6 = this.a.c();
         if (var6.equals(var2)) {
            var4 = var2;
            break;
         }

         if (var6.c(var2) < var4.c(var2)) {
            var4 = var6;
         }

         var6.i = true;
         int var7 = this.d.a(this.c, var6, var2, var3);

         for(int var8 = 0; var8 < var7; ++var8) {
            beh var9 = this.c[var8];
            float var10 = var6.c(var9);
            var9.j = var6.j + var10;
            var9.k = var10 + var9.l;
            float var11 = var6.e + var9.k;
            if (var9.j < var3 && (!var9.a() || var11 < var9.e)) {
               var9.h = var6;
               var9.e = var11;
               var9.f = var9.c(var2) + var9.l;
               if (var9.a()) {
                  this.a.a(var9, var9.e + var9.f);
               } else {
                  var9.g = var9.e + var9.f;
                  this.a.a(var9);
               }
            }
         }
      }

      if (var4 == var1) {
         return null;
      } else {
         bej var12 = this.a(var1, var4);
         return var12;
      }
   }

   private bej a(beh var1, beh var2) {
      int var3 = 1;

      beh var4;
      for(var4 = var2; var4.h != null; var4 = var4.h) {
         ++var3;
      }

      beh[] var5 = new beh[var3];
      var4 = var2;
      --var3;

      for(var5[var3] = var2; var4.h != null; var5[var3] = var4) {
         var4 = var4.h;
         --var3;
      }

      return new bej(var5);
   }
}
