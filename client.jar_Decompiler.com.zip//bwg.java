import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class bwg {
   private final List<bwi> a;
   private aws b;

   public bwg(List<bwi> var1) {
      this.a = var1;
   }

   public List<bwi> a() {
      return this.a;
   }

   public Set<bwb> b() {
      Set<bwb> var1 = Sets.newHashSet();
      Iterator var2 = this.a.iterator();

      while(var2.hasNext()) {
         bwi var3 = (bwi)var2.next();
         var1.add(var3.a());
      }

      return var1;
   }

   public void a(aws var1) {
      this.b = var1;
   }

   public aws c() {
      return this.b;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else {
         if (var1 instanceof bwg) {
            bwg var2 = (bwg)var1;
            if (this.a.equals(var2.a)) {
               if (this.b == null) {
                  return var2.b == null;
               }

               return this.b.equals(var2.b);
            }
         }

         return false;
      }
   }

   public int hashCode() {
      return 31 * this.a.hashCode() + (this.b == null ? 0 : this.b.hashCode());
   }

   public static class a implements JsonDeserializer<bwg> {
      public bwg a(JsonElement var1, Type var2, JsonDeserializationContext var3) throws JsonParseException {
         return new bwg(this.a(var3, var1.getAsJsonArray()));
      }

      private List<bwi> a(JsonDeserializationContext var1, JsonArray var2) {
         List<bwi> var3 = Lists.newArrayList();
         Iterator var4 = var2.iterator();

         while(var4.hasNext()) {
            JsonElement var5 = (JsonElement)var4.next();
            var3.add((bwi)var1.deserialize(var5, bwi.class));
         }

         return var3;
      }

      // $FF: synthetic method
      public Object deserialize(JsonElement var1, Type var2, JsonDeserializationContext var3) throws JsonParseException {
         return this.a(var1, var2, var3);
      }
   }
}
