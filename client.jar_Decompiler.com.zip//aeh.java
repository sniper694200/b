import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;

public class aeh extends ve {
   private int a;
   private boolean b;
   private int c;
   private boolean d;
   private vn e;
   private UUID f;

   public aeh(ams var1) {
      super(var1);
      this.c = 22;
      this.a(0.5F, 0.8F);
   }

   public aeh(ams var1, double var2, double var4, double var6, float var8, int var9, vn var10) {
      this(var1);
      this.a = var9;
      this.a(var10);
      this.v = var8 * 57.295776F;
      this.b(var2, var4, var6);
   }

   protected void i() {
   }

   public void a(@Nullable vn var1) {
      this.e = var1;
      this.f = var1 == null ? null : var1.bm();
   }

   @Nullable
   public vn j() {
      if (this.e == null && this.f != null && this.l instanceof om) {
         ve var1 = ((om)this.l).a(this.f);
         if (var1 instanceof vn) {
            this.e = (vn)var1;
         }
      }

      return this.e;
   }

   protected void a(fy var1) {
      this.a = var1.h("Warmup");
      this.f = var1.a("OwnerUUID");
   }

   protected void b(fy var1) {
      var1.a("Warmup", this.a);
      if (this.f != null) {
         var1.a("OwnerUUID", this.f);
      }

   }

   public void B_() {
      super.B_();
      if (this.l.G) {
         if (this.d) {
            --this.c;
            if (this.c == 14) {
               for(int var1 = 0; var1 < 12; ++var1) {
                  double var2 = this.p + (this.S.nextDouble() * 2.0D - 1.0D) * (double)this.G * 0.5D;
                  double var4 = this.q + 0.05D + this.S.nextDouble() * 1.0D;
                  double var6 = this.r + (this.S.nextDouble() * 2.0D - 1.0D) * (double)this.G * 0.5D;
                  double var8 = (this.S.nextDouble() * 2.0D - 1.0D) * 0.3D;
                  double var10 = 0.3D + this.S.nextDouble() * 0.3D;
                  double var12 = (this.S.nextDouble() * 2.0D - 1.0D) * 0.3D;
                  this.l.a(fj.j, var2, var4 + 1.0D, var6, var8, var10, var12);
               }
            }
         }
      } else if (--this.a < 0) {
         if (this.a == -8) {
            List<vn> var14 = this.l.a(vn.class, this.bw().c(0.2D, 0.0D, 0.2D));
            Iterator var15 = var14.iterator();

            while(var15.hasNext()) {
               vn var3 = (vn)var15.next();
               this.c(var3);
            }
         }

         if (!this.b) {
            this.l.a((ve)this, (byte)4);
            this.b = true;
         }

         if (--this.c < 0) {
            this.X();
         }
      }

   }

   private void c(vn var1) {
      vn var2 = this.j();
      if (var1.aC() && !var1.be() && var1 != var2) {
         if (var2 == null) {
            var1.a(up.o, 6.0F);
         } else {
            if (var2.r(var1)) {
               return;
            }

            var1.a(up.b(this, var2), 6.0F);
         }

      }
   }

   public void a(byte var1) {
      super.a(var1);
      if (var1 == 4) {
         this.d = true;
         if (!this.ai()) {
            this.l.a(this.p, this.q, this.r, qd.br, this.bK(), 1.0F, this.S.nextFloat() * 0.2F + 0.85F, false);
         }
      }

   }

   public float a(float var1) {
      if (!this.d) {
         return 0.0F;
      } else {
         int var2 = this.c - 2;
         return var2 <= 0 ? 1.0F : 1.0F - ((float)var2 - var1) / 20.0F;
      }
   }
}
