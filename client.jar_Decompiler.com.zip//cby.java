import java.util.UUID;
import javax.annotation.Nullable;

public class cby implements cce<aeb> {
   private final bzd c;
   protected bzy<? extends vn> a;
   private bqd d;
   private nd e;
   private UUID f;
   private Class<?> g;
   protected bzy<? extends vn> b;
   private bqd h;
   private nd i;
   private UUID j;
   private Class<?> k;

   public cby(bzd var1) {
      this.c = var1;
   }

   public void a(aeb var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8) {
      if (var1.dp() != null || var1.dq() != null) {
         buq.D();
         buq.c(1.0F, 1.0F, 1.0F, 1.0F);
         fy var9 = var1.dp();
         if (!var9.b_()) {
            cby.a var10 = this.a(var1, this.f, var9, this.a, this.d, this.e, this.g, var2, var3, var4, var5, var6, var7, var8, true);
            this.f = var10.a;
            this.a = var10.b;
            this.e = var10.d;
            this.d = var10.c;
            this.g = var10.e;
         }

         fy var12 = var1.dq();
         if (!var12.b_()) {
            cby.a var11 = this.a(var1, this.j, var12, this.b, this.h, this.i, this.k, var2, var3, var4, var5, var6, var7, var8, false);
            this.j = var11.a;
            this.b = var11.b;
            this.i = var11.d;
            this.h = var11.c;
            this.k = var11.e;
         }

         buq.E();
      }
   }

   private cby.a a(aeb var1, @Nullable UUID var2, fy var3, bzy<? extends vn> var4, bqd var5, nd var6, Class<?> var7, float var8, float var9, float var10, float var11, float var12, float var13, float var14, boolean var15) {
      if (var2 == null || !var2.equals(var3.a("UUID"))) {
         var2 = var3.a("UUID");
         var7 = vg.a(var3.l("id"));
         if (var7 == aaa.class) {
            var4 = new cah(this.c);
            var5 = new bqf();
            var6 = cah.a[var3.h("Variant")];
         }
      }

      ((bzy)var4).a((nd)var6);
      buq.G();
      float var16 = var1.aU() ? -1.3F : -1.5F;
      float var17 = var15 ? 0.4F : -0.4F;
      buq.c(var17, var16, 0.0F);
      if (var7 == aaa.class) {
         var11 = 0.0F;
      }

      ((bqd)var5).a(var1, var8, var9, var10);
      ((bqd)var5).a(var8, var9, var11, var12, var13, var14, var1);
      ((bqd)var5).a(var1, var8, var9, var11, var12, var13, var14);
      buq.H();
      return new cby.a(var2, (bzy)var4, (bqd)var5, var6, var7);
   }

   public boolean a() {
      return false;
   }

   class a {
      public UUID a;
      public bzy<? extends vn> b;
      public bqd c;
      public nd d;
      public Class<?> e;

      public a(UUID var2, bzy<? extends vn> var3, bqd var4, nd var5, Class<?> var6) {
         this.a = var2;
         this.b = var3;
         this.c = var4;
         this.d = var5;
         this.e = var6;
      }
   }
}
