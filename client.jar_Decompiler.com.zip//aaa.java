import com.google.common.base.Predicate;
import com.google.common.collect.Sets;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Set;
import javax.annotation.Nullable;

public class aaa extends aaf implements zw {
   private static final mx<Integer> bG;
   private static final Predicate<vo> bH;
   private static final ail bI;
   private static final Set<ail> bJ;
   private static final Int2ObjectMap<qc> bK;
   public float bB;
   public float bC;
   public float bD;
   public float bE;
   public float bF = 1.0F;
   private boolean bL;
   private et bM;

   public aaa(ams var1) {
      super(var1);
      this.a(0.5F, 0.9F);
      this.f = new wl(this);
   }

   @Nullable
   public vq a(ty var1, @Nullable vq var2) {
      this.m(this.S.nextInt(5));
      return super.a(var1, var2);
   }

   protected void r() {
      this.bz = new yg(this);
      this.br.a(0, new xw(this, 1.25D));
      this.br.a(0, new wx(this));
      this.br.a(1, new xj(this, aeb.class, 8.0F));
      this.br.a(2, this.bz);
      this.br.a(2, new wz(this, 1.0D, 5.0F, 1.0F));
      this.br.a(2, new ym(this, 1.0D));
      this.br.a(3, new xg(this));
      this.br.a(3, new wy(this, 1.0D, 3.0F, 7.0F));
   }

   protected void bM() {
      super.bM();
      this.cm().b(adf.e);
      this.a((wa)adf.a).a(6.0D);
      this.a((wa)adf.e).a(0.4000000059604645D);
      this.a((wa)adf.d).a(0.20000000298023224D);
   }

   protected zc b(ams var1) {
      za var2 = new za(this, var1);
      var2.a(false);
      var2.c(true);
      var2.b(true);
      return var2;
   }

   public float by() {
      return this.H * 0.6F;
   }

   public void n() {
      b(this.l, this);
      if (this.bM == null || this.bM.f(this.p, this.q, this.r) > 12.0D || this.l.o(this.bM).u() != aov.aN) {
         this.bL = false;
         this.bM = null;
      }

      super.n();
      this.dx();
   }

   public void a(et var1, boolean var2) {
      this.bM = var1;
      this.bL = var2;
   }

   public boolean dt() {
      return this.bL;
   }

   private void dx() {
      this.bE = this.bB;
      this.bD = this.bC;
      this.bC = (float)((double)this.bC + (double)(this.z ? -1 : 4) * 0.3D);
      this.bC = ri.a(this.bC, 0.0F, 1.0F);
      if (!this.z && this.bF < 1.0F) {
         this.bF = 1.0F;
      }

      this.bF = (float)((double)this.bF * 0.9D);
      if (!this.z && this.t < 0.0D) {
         this.t *= 0.6D;
      }

      this.bB += this.bF * 2.0F;
   }

   private static boolean b(ams var0, ve var1) {
      if (!var1.ai() && var0.r.nextInt(50) == 0) {
         List<vo> var2 = var0.a(vo.class, var1.bw().g(20.0D), bH);
         if (!var2.isEmpty()) {
            vo var3 = (vo)var2.get(var0.r.nextInt(var2.size()));
            if (!var3.ai()) {
               qc var4 = g(vg.b.a(var3.getClass()));
               var0.a((aeb)null, var1.p, var1.q, var1.r, var4, var1.bK(), 0.7F, b(var0.r));
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public boolean a(aeb var1, tz var2) {
      ain var3 = var1.b((tz)var2);
      if (!this.dl() && bJ.contains(var3.c())) {
         if (!var1.bO.d) {
            var3.g(1);
         }

         if (!this.ai()) {
            this.l.a((aeb)null, this.p, this.q, this.r, qd.eJ, this.bK(), 1.0F, 1.0F + (this.S.nextFloat() - this.S.nextFloat()) * 0.2F);
         }

         if (!this.l.G) {
            if (this.S.nextInt(10) == 0) {
               this.c(var1);
               this.p(true);
               this.l.a((ve)this, (byte)7);
            } else {
               this.p(false);
               this.l.a((ve)this, (byte)6);
            }
         }

         return true;
      } else if (var3.c() == bI) {
         if (!var1.bO.d) {
            var3.g(1);
         }

         this.c(new uy(uz.s, 900));
         if (var1.z() || !this.be()) {
            this.a(up.a(var1), Float.MAX_VALUE);
         }

         return true;
      } else {
         if (!this.l.G && !this.a() && this.dl() && this.e(var1)) {
            this.bz.a(!this.dn());
         }

         return super.a(var1, var2);
      }
   }

   public boolean e(ain var1) {
      return false;
   }

   public boolean P() {
      int var1 = ri.c(this.p);
      int var2 = ri.c(this.bw().b);
      int var3 = ri.c(this.r);
      et var4 = new et(var1, var2, var3);
      aou var5 = this.l.o(var4.b()).u();
      return var5 instanceof arp || var5 == aov.c || var5 instanceof art || var5 == aov.a && this.l.j(var4) > 8 && super.P();
   }

   public void e(float var1, float var2) {
   }

   protected void a(double var1, boolean var3, awr var4, et var5) {
   }

   public boolean a(zt var1) {
      return false;
   }

   @Nullable
   public vb a(vb var1) {
      return null;
   }

   public static void a(ams var0, ve var1) {
      if (!var1.ai() && !b(var0, var1) && var0.r.nextInt(200) == 0) {
         var0.a((aeb)null, var1.p, var1.q, var1.r, a(var0.r), var1.bK(), 1.0F, b(var0.r));
      }

   }

   public boolean B(ve var1) {
      return var1.a(up.a((vn)this), 3.0F);
   }

   @Nullable
   public qc F() {
      return a(this.S);
   }

   private static qc a(Random var0) {
      if (var0.nextInt(1000) == 0) {
         List<Integer> var1 = new ArrayList(bK.keySet());
         return g((Integer)var1.get(var0.nextInt(var1.size())));
      } else {
         return qd.eH;
      }
   }

   public static qc g(int var0) {
      return bK.containsKey(var0) ? (qc)bK.get(var0) : qd.eH;
   }

   protected qc d(up var1) {
      return qd.eL;
   }

   protected qc cf() {
      return qd.eI;
   }

   protected void a(et var1, aou var2) {
      this.a(qd.fn, 0.15F, 1.0F);
   }

   protected float d(float var1) {
      this.a(qd.eK, 0.15F, 1.0F);
      return var1 + this.bC / 2.0F;
   }

   protected boolean ah() {
      return true;
   }

   protected float cr() {
      return b(this.S);
   }

   private static float b(Random var0) {
      return (var0.nextFloat() - var0.nextFloat()) * 0.2F + 1.0F;
   }

   public qe bK() {
      return qe.g;
   }

   public boolean az() {
      return true;
   }

   protected void C(ve var1) {
      if (!(var1 instanceof aeb)) {
         super.C(var1);
      }
   }

   public boolean a(up var1, float var2) {
      if (this.b((up)var1)) {
         return false;
      } else {
         if (this.bz != null) {
            this.bz.a(false);
         }

         return super.a(var1, var2);
      }
   }

   public int du() {
      return ri.a((Integer)this.Y.a(bG), 0, 4);
   }

   public void m(int var1) {
      this.Y.b(bG, var1);
   }

   protected void i() {
      super.i();
      this.Y.a((mx)bG, (int)0);
   }

   public void b(fy var1) {
      super.b(var1);
      var1.a("Variant", this.du());
   }

   public void a(fy var1) {
      super.a(var1);
      this.m(var1.h("Variant"));
   }

   @Nullable
   protected nd J() {
      return bfl.ax;
   }

   public boolean a() {
      return !this.z;
   }

   static {
      bG = na.a(aaa.class, mz.b);
      bH = new Predicate<vo>() {
         public boolean a(@Nullable vo var1) {
            return var1 != null && aaa.bK.containsKey(vg.b.a(var1.getClass()));
         }

         // $FF: synthetic method
         public boolean apply(@Nullable Object var1) {
            return this.a((vo)var1);
         }
      };
      bI = aip.bk;
      bJ = Sets.newHashSet(new ail[]{aip.Q, aip.bp, aip.bo, aip.cV});
      bK = new Int2ObjectOpenHashMap(32);
      bK.put(vg.b.a(aco.class), qd.eM);
      bK.put(vg.b.a(acp.class), qd.fc);
      bK.put(vg.b.a(acq.class), qd.eN);
      bK.put(vg.b.a(acr.class), qd.eO);
      bK.put(vg.b.a(abb.class), qd.eP);
      bK.put(vg.b.a(acs.class), qd.eQ);
      bK.put(vg.b.a(act.class), qd.eR);
      bK.put(vg.b.a(acv.class), qd.eS);
      bK.put(vg.b.a(acw.class), qd.eT);
      bK.put(vg.b.a(acz.class), qd.eU);
      bK.put(vg.b.a(ada.class), qd.eV);
      bK.put(vg.b.a(adb.class), qd.eW);
      bK.put(vg.b.a(add.class), qd.fl);
      bK.put(vg.b.a(aac.class), qd.eX);
      bK.put(vg.b.a(adg.class), qd.eY);
      bK.put(vg.b.a(adh.class), qd.eZ);
      bK.put(vg.b.a(adi.class), qd.fa);
      bK.put(vg.b.a(adj.class), qd.fb);
      bK.put(vg.b.a(adl.class), qd.fc);
      bK.put(vg.b.a(adm.class), qd.fd);
      bK.put(vg.b.a(adn.class), qd.fe);
      bK.put(vg.b.a(ado.class), qd.ff);
      bK.put(vg.b.a(adp.class), qd.fg);
      bK.put(vg.b.a(abv.class), qd.fh);
      bK.put(vg.b.a(adq.class), qd.fi);
      bK.put(vg.b.a(aak.class), qd.fj);
      bK.put(vg.b.a(adr.class), qd.fk);
      bK.put(vg.b.a(ads.class), qd.fm);
   }
}
