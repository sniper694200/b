import java.io.File;
import javax.annotation.Nullable;

public interface bfc {
   @Nullable
   bfb d();

   void c() throws amt;

   ayd a(ayk var1);

   void a(bfb var1, fy var2);

   void a(bfb var1);

   bfi e();

   void a();

   File b();

   File a(String var1);

   bce h();
}
