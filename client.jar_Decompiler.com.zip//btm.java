import java.util.Random;

public class btm extends btd {
   private static final Random a = new Random();
   private int b = 128;

   protected btm(ams var1, double var2, double var4, double var6, double var8, double var10, double var12) {
      super(var1, var2, var4, var6, 0.5D - a.nextDouble(), var10, 0.5D - a.nextDouble());
      this.k *= 0.20000000298023224D;
      if (var8 == 0.0D && var12 == 0.0D) {
         this.j *= 0.10000000149011612D;
         this.l *= 0.10000000149011612D;
      }

      this.y *= 0.75F;
      this.x = (int)(8.0D / (Math.random() * 0.8D + 0.2D));
   }

   public boolean c() {
      return true;
   }

   public void a() {
      this.d = this.g;
      this.e = this.h;
      this.f = this.i;
      if (this.w++ >= this.x) {
         this.i();
      }

      this.b(this.b + (7 - this.w * 8 / this.x));
      this.k += 0.004D;
      this.a(this.j, this.k, this.l);
      if (this.h == this.e) {
         this.j *= 1.1D;
         this.l *= 1.1D;
      }

      this.j *= 0.9599999785423279D;
      this.k *= 0.9599999785423279D;
      this.l *= 0.9599999785423279D;
      if (this.m) {
         this.j *= 0.699999988079071D;
         this.l *= 0.699999988079071D;
      }

   }

   public void c(int var1) {
      this.b = var1;
   }

   public static class b implements btf {
      public btd a(int var1, ams var2, double var3, double var5, double var7, double var9, double var11, double var13, int... var15) {
         btd var16 = new btm(var2, var3, var5, var7, var9, var11, var13);
         ((btm)var16).c(144);
         return var16;
      }
   }

   public static class e implements btf {
      public btd a(int var1, ams var2, double var3, double var5, double var7, double var9, double var11, double var13, int... var15) {
         btd var16 = new btm(var2, var3, var5, var7, var9, var11, var13);
         ((btm)var16).c(144);
         float var17 = var2.r.nextFloat() * 0.5F + 0.35F;
         var16.a(1.0F * var17, 0.0F * var17, 1.0F * var17);
         return var16;
      }
   }

   public static class a implements btf {
      public btd a(int var1, ams var2, double var3, double var5, double var7, double var9, double var11, double var13, int... var15) {
         btd var16 = new btm(var2, var3, var5, var7, var9, var11, var13);
         var16.e(0.15F);
         var16.a((float)var9, (float)var11, (float)var13);
         return var16;
      }
   }

   public static class c implements btf {
      public btd a(int var1, ams var2, double var3, double var5, double var7, double var9, double var11, double var13, int... var15) {
         btd var16 = new btm(var2, var3, var5, var7, var9, var11, var13);
         var16.a((float)var9, (float)var11, (float)var13);
         return var16;
      }
   }

   public static class d implements btf {
      public btd a(int var1, ams var2, double var3, double var5, double var7, double var9, double var11, double var13, int... var15) {
         return new btm(var2, var3, var5, var7, var9, var11, var13);
      }
   }
}
