public class arh extends aou {
   public arh() {
      super(bcx.e);
      this.a(ahn.b);
   }

   public bcy c(awr var1, amw var2, et var3) {
      return bcy.r;
   }
}
