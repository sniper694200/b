public class cal extends cad<aad> {
   private static final nd a = new nd("textures/entity/rabbit/brown.png");
   private static final nd j = new nd("textures/entity/rabbit/white.png");
   private static final nd k = new nd("textures/entity/rabbit/black.png");
   private static final nd l = new nd("textures/entity/rabbit/gold.png");
   private static final nd m = new nd("textures/entity/rabbit/salt.png");
   private static final nd n = new nd("textures/entity/rabbit/white_splotched.png");
   private static final nd o = new nd("textures/entity/rabbit/toast.png");
   private static final nd p = new nd("textures/entity/rabbit/caerbannog.png");

   public cal(bzd var1) {
      super(var1, new bql(), 0.3F);
   }

   protected nd a(aad var1) {
      String var2 = a.a(var1.h_());
      if (var2 != null && "Toast".equals(var2)) {
         return o;
      } else {
         switch(var1.dn()) {
         case 0:
         default:
            return a;
         case 1:
            return j;
         case 2:
            return k;
         case 3:
            return n;
         case 4:
            return l;
         case 5:
            return m;
         case 99:
            return p;
         }
      }
   }
}
