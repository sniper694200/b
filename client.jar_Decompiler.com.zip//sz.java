public class sz implements rs {
   public static final String[] a = new String[]{"minecraft:white_shulker_box", "minecraft:orange_shulker_box", "minecraft:magenta_shulker_box", "minecraft:light_blue_shulker_box", "minecraft:yellow_shulker_box", "minecraft:lime_shulker_box", "minecraft:pink_shulker_box", "minecraft:gray_shulker_box", "minecraft:silver_shulker_box", "minecraft:cyan_shulker_box", "minecraft:purple_shulker_box", "minecraft:blue_shulker_box", "minecraft:brown_shulker_box", "minecraft:green_shulker_box", "minecraft:red_shulker_box", "minecraft:black_shulker_box"};

   public int a() {
      return 813;
   }

   public fy a(fy var1) {
      if ("minecraft:shulker_box".equals(var1.l("id")) && var1.b("tag", 10)) {
         fy var2 = var1.p("tag");
         if (var2.b("BlockEntityTag", 10)) {
            fy var3 = var2.p("BlockEntityTag");
            if (var3.c("Items", 10).b_()) {
               var3.r("Items");
            }

            int var4 = var3.h("Color");
            var3.r("Color");
            if (var3.b_()) {
               var2.r("BlockEntityTag");
            }

            if (var2.b_()) {
               var1.r("tag");
            }

            var1.a("id", a[var4 % 16]);
         }
      }

      return var1;
   }
}
