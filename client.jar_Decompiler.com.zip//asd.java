public class asd extends aou {
   public asd() {
      super(bcx.e);
      this.a(ahn.b);
   }

   public bcy c(awr var1, amw var2, et var3) {
      return bcy.L;
   }
}
