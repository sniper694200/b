import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;
import java.io.IOException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.MarkerManager;

public class ha extends MessageToByteEncoder<ht<?>> {
   private static final Logger a = LogManager.getLogger();
   private static final Marker b;
   private final hu c;

   public ha(hu var1) {
      this.c = var1;
   }

   protected void a(ChannelHandlerContext var1, ht<?> var2, ByteBuf var3) throws Exception {
      gx var4 = (gx)var1.channel().attr(gw.c).get();
      if (var4 == null) {
         throw new RuntimeException("ConnectionProtocol unknown: " + var2.toString());
      } else {
         Integer var5 = var4.a(this.c, var2);
         if (a.isDebugEnabled()) {
            a.debug(b, "OUT: [{}:{}] {}", var1.channel().attr(gw.c).get(), var5, var2.getClass().getName());
         }

         if (var5 == null) {
            throw new IOException("Can't serialize unregistered packet");
         } else {
            gy var6 = new gy(var3);
            var6.d(var5);

            try {
               var2.b(var6);
            } catch (Throwable var8) {
               a.error(var8);
            }

         }
      }
   }

   // $FF: synthetic method
   protected void encode(ChannelHandlerContext var1, Object var2, ByteBuf var3) throws Exception {
      this.a(var1, (ht)var2, var3);
   }

   static {
      b = MarkerManager.getMarker("PACKET_SENT", gw.b);
   }
}
