import net.minecraft.server.MinecraftServer;

public class cy extends bi {
   public String c() {
      return "publish";
   }

   public String b(bn var1) {
      return "commands.publish.usage";
   }

   public void a(MinecraftServer var1, bn var2, String[] var3) throws ei {
      String var4 = var1.a(amq.b, false);
      if (var4 != null) {
         a(var2, this, "commands.publish.started", new Object[]{var4});
      } else {
         a(var2, this, "commands.publish.failed", new Object[0]);
      }

   }
}
