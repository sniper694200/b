import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.lang.reflect.Type;
import org.lwjgl.util.vector.Quaternion;

public class bwa {
   public static final bwa a = new bwa();
   public static float b;
   public static float c;
   public static float d;
   public static float e;
   public static float f;
   public static float g;
   public static float h;
   public static float i;
   public static float j;
   public final bvz k;
   public final bvz l;
   public final bvz m;
   public final bvz n;
   public final bvz o;
   public final bvz p;
   public final bvz q;
   public final bvz r;

   private bwa() {
      this(bvz.a, bvz.a, bvz.a, bvz.a, bvz.a, bvz.a, bvz.a, bvz.a);
   }

   public bwa(bwa var1) {
      this.k = var1.k;
      this.l = var1.l;
      this.m = var1.m;
      this.n = var1.n;
      this.o = var1.o;
      this.p = var1.p;
      this.q = var1.q;
      this.r = var1.r;
   }

   public bwa(bvz var1, bvz var2, bvz var3, bvz var4, bvz var5, bvz var6, bvz var7, bvz var8) {
      this.k = var1;
      this.l = var2;
      this.m = var3;
      this.n = var4;
      this.o = var5;
      this.p = var6;
      this.q = var7;
      this.r = var8;
   }

   public void a(bwa.b var1) {
      a(this.b(var1), false);
   }

   public static void a(bvz var0, boolean var1) {
      if (var0 != bvz.a) {
         int var2 = var1 ? -1 : 1;
         buq.c((float)var2 * (b + var0.c.x), c + var0.c.y, d + var0.c.z);
         float var3 = e + var0.b.x;
         float var4 = f + var0.b.y;
         float var5 = g + var0.b.z;
         if (var1) {
            var4 = -var4;
            var5 = -var5;
         }

         buq.a(a(var3, var4, var5));
         buq.b(h + var0.d.x, i + var0.d.y, j + var0.d.z);
      }
   }

   private static Quaternion a(float var0, float var1, float var2) {
      float var3 = var0 * 0.017453292F;
      float var4 = var1 * 0.017453292F;
      float var5 = var2 * 0.017453292F;
      float var6 = ri.a(0.5F * var3);
      float var7 = ri.b(0.5F * var3);
      float var8 = ri.a(0.5F * var4);
      float var9 = ri.b(0.5F * var4);
      float var10 = ri.a(0.5F * var5);
      float var11 = ri.b(0.5F * var5);
      return new Quaternion(var6 * var9 * var11 + var7 * var8 * var10, var7 * var8 * var11 - var6 * var9 * var10, var6 * var8 * var11 + var7 * var9 * var10, var7 * var9 * var11 - var6 * var8 * var10);
   }

   public bvz b(bwa.b var1) {
      switch(var1) {
      case b:
         return this.k;
      case c:
         return this.l;
      case d:
         return this.m;
      case e:
         return this.n;
      case f:
         return this.o;
      case g:
         return this.p;
      case h:
         return this.q;
      case i:
         return this.r;
      default:
         return bvz.a;
      }
   }

   public boolean c(bwa.b var1) {
      return this.b(var1) != bvz.a;
   }

   static class a implements JsonDeserializer<bwa> {
      public bwa a(JsonElement var1, Type var2, JsonDeserializationContext var3) throws JsonParseException {
         JsonObject var4 = var1.getAsJsonObject();
         bvz var5 = this.a(var3, var4, "thirdperson_righthand");
         bvz var6 = this.a(var3, var4, "thirdperson_lefthand");
         if (var6 == bvz.a) {
            var6 = var5;
         }

         bvz var7 = this.a(var3, var4, "firstperson_righthand");
         bvz var8 = this.a(var3, var4, "firstperson_lefthand");
         if (var8 == bvz.a) {
            var8 = var7;
         }

         bvz var9 = this.a(var3, var4, "head");
         bvz var10 = this.a(var3, var4, "gui");
         bvz var11 = this.a(var3, var4, "ground");
         bvz var12 = this.a(var3, var4, "fixed");
         return new bwa(var6, var5, var8, var7, var9, var10, var11, var12);
      }

      private bvz a(JsonDeserializationContext var1, JsonObject var2, String var3) {
         return var2.has(var3) ? (bvz)var1.deserialize(var2.get(var3), bvz.class) : bvz.a;
      }

      // $FF: synthetic method
      public Object deserialize(JsonElement var1, Type var2, JsonDeserializationContext var3) throws JsonParseException {
         return this.a(var1, var2, var3);
      }
   }

   public static enum b {
      a,
      b,
      c,
      d,
      e,
      f,
      g,
      h,
      i;
   }
}
