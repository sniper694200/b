import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public class cf extends bi {
   public String c() {
      return "execute";
   }

   public int a() {
      return 2;
   }

   public String b(bn var1) {
      return "commands.execute.usage";
   }

   public void a(MinecraftServer var1, bn var2, String[] var3) throws ei {
      if (var3.length < 5) {
         throw new ep("commands.execute.usage", new Object[0]);
      } else {
         ve var4 = a(var1, var2, var3[0], ve.class);
         double var5 = b(var4.p, var3[1], false);
         double var7 = b(var4.q, var3[2], false);
         double var9 = b(var4.r, var3[3], false);
         new et(var5, var7, var9);
         int var12 = 4;
         if ("detect".equals(var3[4]) && var3.length > 10) {
            ams var13 = var4.e();
            double var14 = b(var5, var3[5], false);
            double var16 = b(var7, var3[6], false);
            double var18 = b(var9, var3[7], false);
            aou var20 = b(var2, var3[8]);
            et var21 = new et(var14, var16, var18);
            if (!var13.e(var21)) {
               throw new ei("commands.execute.failed", new Object[]{"detect", var4.h_()});
            }

            awr var22 = var13.o(var21);
            if (var22.u() != var20) {
               throw new ei("commands.execute.failed", new Object[]{"detect", var4.h_()});
            }

            if (!bi.b(var20, var3[9]).apply(var22)) {
               throw new ei("commands.execute.failed", new Object[]{"detect", var4.h_()});
            }

            var12 = 10;
         }

         String var24 = a(var3, var12);
         bn var25 = bo.a(var2).a(var4, new bhc(var5, var7, var9)).a(var1.d[0].W().b("commandBlockOutput"));
         bl var15 = var1.N();

         try {
            int var26 = var15.a(var25, var24);
            if (var26 < 1) {
               throw new ei("commands.execute.allInvocationsFailed", new Object[]{var24});
            }
         } catch (Throwable var23) {
            throw new ei("commands.execute.failed", new Object[]{var24, var4.h_()});
         }
      }
   }

   public List<String> a(MinecraftServer var1, bn var2, String[] var3, @Nullable et var4) {
      if (var3.length == 1) {
         return a(var3, var1.J());
      } else if (var3.length > 1 && var3.length <= 4) {
         return a(var3, 1, var4);
      } else if (var3.length > 5 && var3.length <= 8 && "detect".equals(var3[4])) {
         return a(var3, 5, var4);
      } else {
         return var3.length == 9 && "detect".equals(var3[4]) ? a(var3, aou.h.c()) : Collections.emptyList();
      }
   }

   public boolean b(String[] var1, int var2) {
      return var2 == 0;
   }
}
