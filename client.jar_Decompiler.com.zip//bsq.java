public class bsq extends btd {
   protected bsq(ams var1, double var2, double var4, double var6, double var8, double var10, double var12) {
      super(var1, var2, var4, var6, var8, var10, var12);
      this.j = var8 + (Math.random() * 2.0D - 1.0D) * 0.05000000074505806D;
      this.k = var10 + (Math.random() * 2.0D - 1.0D) * 0.05000000074505806D;
      this.l = var12 + (Math.random() * 2.0D - 1.0D) * 0.05000000074505806D;
      float var14 = this.r.nextFloat() * 0.3F + 0.7F;
      this.A = var14;
      this.B = var14;
      this.C = var14;
      this.y = this.r.nextFloat() * this.r.nextFloat() * 6.0F + 1.0F;
      this.x = (int)(16.0D / ((double)this.r.nextFloat() * 0.8D + 0.2D)) + 2;
   }

   public void a() {
      this.d = this.g;
      this.e = this.h;
      this.f = this.i;
      if (this.w++ >= this.x) {
         this.i();
      }

      this.b(7 - this.w * 8 / this.x);
      this.k += 0.004D;
      this.a(this.j, this.k, this.l);
      this.j *= 0.8999999761581421D;
      this.k *= 0.8999999761581421D;
      this.l *= 0.8999999761581421D;
      if (this.m) {
         this.j *= 0.699999988079071D;
         this.l *= 0.699999988079071D;
      }

   }

   public static class a implements btf {
      public btd a(int var1, ams var2, double var3, double var5, double var7, double var9, double var11, double var13, int... var15) {
         return new bsq(var2, var3, var5, var7, var9, var11, var13);
      }
   }
}
