import javax.annotation.Nullable;

public class abi extends abd {
   private bhc b;

   public abi(abb var1) {
      super(var1);
   }

   public void c() {
      if (this.b == null) {
         this.b = new bhc(this.a.p, this.a.q, this.a.r);
      }

   }

   public boolean a() {
      return true;
   }

   public void d() {
      this.b = null;
   }

   public float f() {
      return 1.0F;
   }

   @Nullable
   public bhc g() {
      return this.b;
   }

   public abr<abi> i() {
      return abr.k;
   }
}
