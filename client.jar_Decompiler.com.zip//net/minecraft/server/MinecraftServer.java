package net.minecraft.server;

import com.google.common.collect.Lists;
import com.google.common.collect.Queues;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.ListenableFutureTask;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.GameProfileRepository;
import com.mojang.authlib.minecraft.MinecraftSessionService;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufOutputStream;
import io.netty.buffer.Unpooled;
import io.netty.handler.codec.base64.Base64;
import java.awt.GraphicsEnvironment;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.Proxy;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Queue;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import javax.annotation.Nullable;
import javax.imageio.ImageIO;
import org.apache.commons.lang3.Validate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public abstract class MinecraftServer implements .bn, Runnable, .tp, .uk {
   private static final Logger k = LogManager.getLogger();
   public static final File a = new File("usercache.json");
   private final .bfe l;
   private final .uj m = new .uj("server", this, aw());
   private final File n;
   private final List<.nv> o = Lists.newArrayList();
   public final .bl b;
   public final .rj c = new .rj();
   private final .ox p;
   private final .ms q = new .ms();
   private final Random r = new Random();
   private final .rw s;
   private int u = -1;
   public .om[] d;
   private .pj v;
   private boolean w = true;
   private boolean x;
   private int y;
   protected final Proxy e;
   public String f;
   public int g;
   private boolean z;
   private boolean A;
   private boolean B;
   private boolean C;
   private boolean D;
   private boolean E;
   private String F;
   private int G;
   private int H;
   public final long[] h = new long[100];
   public long[][] i;
   private KeyPair I;
   private String J;
   private String K;
   private String L;
   private boolean M;
   private boolean N;
   private String O = "";
   private String P = "";
   private boolean Q;
   private long R;
   private String S;
   private boolean T;
   private boolean U;
   private final YggdrasilAuthenticationService V;
   private final MinecraftSessionService W;
   private final GameProfileRepository X;
   private final .pf Y;
   private long Z;
   public final Queue<FutureTask<?>> j = Queues.newArrayDeque();
   private Thread aa;
   private long ab = aw();
   private boolean ac;

   public MinecraftServer(File var1, Proxy var2, .rw var3, YggdrasilAuthenticationService var4, MinecraftSessionService var5, GameProfileRepository var6, .pf var7) {
      this.e = var2;
      this.V = var4;
      this.W = var5;
      this.X = var6;
      this.Y = var7;
      this.n = var1;
      this.p = new .ox(this);
      this.b = this.i();
      this.l = new .bex(var1, var3);
      this.s = var3;
   }

   public .dh i() {
      return new .dh(this);
   }

   public abstract boolean j() throws IOException;

   public void a(String var1) {
      if (this.W().b(var1)) {
         k.info("Converting map!");
         this.b("menu.convertingLevel");
         this.W().a(var1, new .rk() {
            private long b = MinecraftServer.aw();

            public void a(String var1) {
            }

            public void b(String var1) {
            }

            public void a(int var1) {
               if (MinecraftServer.aw() - this.b >= 1000L) {
                  this.b = MinecraftServer.aw();
                  MinecraftServer.k.info("Converting... {}%", var1);
               }

            }

            public void a() {
            }

            public void c(String var1) {
            }
         });
      }

   }

   protected synchronized void b(String var1) {
      this.S = var1;
   }

   @Nullable
   public synchronized String k() {
      return this.S;
   }

   public void a(String var1, String var2, long var3, .amx var5, String var6) {
      this.a(var1);
      this.b("menu.loadingLevel");
      this.d = new .om[3];
      this.i = new long[this.d.length][100];
      .bfc var7 = this.l.a(var1, true);
      this.a(this.S(), var7);
      .bfb var9 = var7.d();
      .amv var8;
      if (var9 == null) {
         if (this.V()) {
            var8 = .og.a;
         } else {
            var8 = new .amv(var3, this.n(), this.m(), this.p(), var5);
            var8.a(var6);
            if (this.N) {
               var8.a();
            }
         }

         var9 = new .bfb(var8, var2);
      } else {
         var9.a(var2);
         var8 = new .amv(var9);
      }

      for(int var10 = 0; var10 < this.d.length; ++var10) {
         int var11 = 0;
         if (var10 == 1) {
            var11 = -1;
         }

         if (var10 == 2) {
            var11 = 1;
         }

         if (var10 == 0) {
            if (this.V()) {
               this.d[var10] = (.om)(new .og(this, var7, var9, var11, this.c)).b();
            } else {
               this.d[var10] = (.om)(new .om(this, var7, var9, var11, this.c)).b();
            }

            this.d[var10].a(var8);
         } else {
            this.d[var10] = (.om)(new .oi(this, var7, var11, this.d[0], this.c)).b();
         }

         this.d[var10].a((.amu)(new .on(this, this.d[var10])));
         if (!this.R()) {
            this.d[var10].V().a(this.n());
         }
      }

      this.v.a(this.d);
      this.a(this.o());
      this.l();
   }

   public void l() {
      int var1 = true;
      int var2 = true;
      int var3 = true;
      int var4 = true;
      int var5 = 0;
      this.b("menu.generatingTerrain");
      int var6 = false;
      k.info("Preparing start region for level 0");
      .om var7 = this.d[0];
      .et var8 = var7.T();
      long var9 = aw();

      for(int var11 = -192; var11 <= 192 && this.w(); var11 += 16) {
         for(int var12 = -192; var12 <= 192 && this.w(); var12 += 16) {
            long var13 = aw();
            if (var13 - var9 > 1000L) {
               this.a_("Preparing spawn area", var5 * 100 / 625);
               var9 = var13;
            }

            ++var5;
            var7.r().c(var8.p() + var11 >> 4, var8.r() + var12 >> 4);
         }
      }

      this.t();
   }

   public void a(String var1, .bfc var2) {
      File var3 = new File(var2.b(), "resources.zip");
      if (var3.isFile()) {
         try {
            this.a_("level://" + URLEncoder.encode(var1, StandardCharsets.UTF_8.toString()) + "/" + "resources.zip", "");
         } catch (UnsupportedEncodingException var5) {
            k.warn("Something went wrong url encoding {}", var1);
         }
      }

   }

   public abstract boolean m();

   public abstract .amq n();

   public abstract .tx o();

   public abstract boolean p();

   public abstract int q();

   public abstract boolean r();

   public abstract boolean s();

   protected void a_(String var1, int var2) {
      this.f = var1;
      this.g = var2;
      k.info("{}: {}%", var1, var2);
   }

   protected void t() {
      this.f = null;
      this.g = 0;
   }

   public void a(boolean var1) {
      .om[] var2 = this.d;
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         .om var5 = var2[var4];
         if (var5 != null) {
            if (!var1) {
               k.info("Saving chunks for level '{}'/{}", var5.V().j(), var5.s.q().b());
            }

            try {
               var5.a(true, (.rk)null);
            } catch (.amt var7) {
               k.warn(var7.getMessage());
            }
         }
      }

   }

   public void u() {
      k.info("Stopping server");
      if (this.an() != null) {
         this.an().b();
      }

      if (this.v != null) {
         k.info("Saving players");
         this.v.j();
         this.v.u();
      }

      if (this.d != null) {
         k.info("Saving worlds");
         .om[] var1 = this.d;
         int var2 = var1.length;

         int var3;
         .om var4;
         for(var3 = 0; var3 < var2; ++var3) {
            var4 = var1[var3];
            if (var4 != null) {
               var4.b = false;
            }
         }

         this.a(false);
         var1 = this.d;
         var2 = var1.length;

         for(var3 = 0; var3 < var2; ++var3) {
            var4 = var1[var3];
            if (var4 != null) {
               var4.s();
            }
         }
      }

      if (this.m.d()) {
         this.m.e();
      }

   }

   public boolean w() {
      return this.w;
   }

   public void x() {
      this.w = false;
   }

   public void run() {
      try {
         if (this.j()) {
            this.ab = aw();
            long var1 = 0L;
            this.q.a((.hh)(new .ho(this.F)));
            this.q.a(new .ms.c("1.12", 335));
            this.a(this.q);

            while(this.w) {
               long var48 = aw();
               long var5 = var48 - this.ab;
               if (var5 > 2000L && this.ab - this.R >= 15000L) {
                  k.warn("Can't keep up! Did the system time change, or is the server overloaded? Running {}ms behind, skipping {} tick(s)", var5, var5 / 50L);
                  var5 = 2000L;
                  this.R = this.ab;
               }

               if (var5 < 0L) {
                  k.warn("Time ran backwards! Did the system time change?");
                  var5 = 0L;
               }

               var1 += var5;
               this.ab = var48;
               if (this.d[0].g()) {
                  this.C();
                  var1 = 0L;
               } else {
                  while(var1 > 50L) {
                     var1 -= 50L;
                     this.C();
                  }
               }

               Thread.sleep(Math.max(1L, 50L - var1));
               this.Q = true;
            }
         } else {
            this.a((.b)null);
         }
      } catch (Throwable var46) {
         k.error("Encountered an unexpected exception", var46);
         .b var2 = null;
         if (var46 instanceof .f) {
            var2 = this.b(((.f)var46).a());
         } else {
            var2 = this.b(new .b("Exception in server tick loop", var46));
         }

         File var3 = new File(new File(this.A(), "crash-reports"), "crash-" + (new SimpleDateFormat("yyyy-MM-dd_HH.mm.ss")).format(new Date()) + "-server.txt");
         if (var2.a(var3)) {
            k.error("This crash report has been saved to: {}", var3.getAbsolutePath());
         } else {
            k.error("We were unable to save this crash report to disk.");
         }

         this.a(var2);
      } finally {
         try {
            this.x = true;
            this.u();
         } catch (Throwable var44) {
            k.error("Exception stopping the server", var44);
         } finally {
            this.B();
         }

      }

   }

   public void a(.ms var1) {
      File var2 = this.d("server-icon.png");
      if (!var2.exists()) {
         var2 = this.W().b(this.S(), "icon.png");
      }

      if (var2.isFile()) {
         ByteBuf var3 = Unpooled.buffer();

         try {
            BufferedImage var4 = ImageIO.read(var2);
            Validate.validState(var4.getWidth() == 64, "Must be 64 pixels wide", new Object[0]);
            Validate.validState(var4.getHeight() == 64, "Must be 64 pixels high", new Object[0]);
            ImageIO.write(var4, "PNG", new ByteBufOutputStream(var3));
            ByteBuf var5 = Base64.encode(var3);
            var1.a("data:image/png;base64," + var5.toString(StandardCharsets.UTF_8));
         } catch (Exception var9) {
            k.error("Couldn't load server icon", var9);
         } finally {
            var3.release();
         }
      }

   }

   public boolean y() {
      this.ac = this.ac || this.z().isFile();
      return this.ac;
   }

   public File z() {
      return this.W().b(this.S(), "icon.png");
   }

   public File A() {
      return new File(".");
   }

   public void a(.b var1) {
   }

   public void B() {
   }

   public void C() {
      long var1 = System.nanoTime();
      ++this.y;
      if (this.T) {
         this.T = false;
         this.c.a = true;
         this.c.a();
      }

      this.c.a("root");
      this.D();
      if (var1 - this.Z >= 5000000000L) {
         this.Z = var1;
         this.q.a(new .ms.a(this.I(), this.H()));
         GameProfile[] var3 = new GameProfile[Math.min(this.H(), 12)];
         int var4 = .ri.a((Random)this.r, 0, this.H() - var3.length);

         for(int var5 = 0; var5 < var3.length; ++var5) {
            var3[var5] = ((.oo)this.v.v().get(var4 + var5)).da();
         }

         Collections.shuffle(Arrays.asList(var3));
         this.q.b().a(var3);
      }

      if (this.y % 900 == 0) {
         this.c.a("save");
         this.v.j();
         this.a(true);
         this.c.b();
      }

      this.c.a("tallying");
      this.h[this.y % 100] = System.nanoTime() - var1;
      this.c.b();
      this.c.a("snooper");
      if (!this.m.d() && this.y > 100) {
         this.m.a();
      }

      if (this.y % 6000 == 0) {
         this.m.b();
      }

      this.c.b();
      this.c.b();
   }

   public void D() {
      this.c.a("jobs");
      synchronized(this.j) {
         while(!this.j.isEmpty()) {
            .h.a((FutureTask)this.j.poll(), k);
         }
      }

      this.c.c("levels");

      int var1;
      for(var1 = 0; var1 < this.d.length; ++var1) {
         long var2 = System.nanoTime();
         if (var1 == 0 || this.E()) {
            .om var4 = this.d[var1];
            this.c.a(var4.V().j());
            if (this.y % 20 == 0) {
               this.c.a("timeSync");
               this.v.a((.ht)(new .kn(var4.R(), var4.S(), var4.W().b("doDaylightCycle"))), var4.s.q().a());
               this.c.b();
            }

            this.c.a("tick");

            .b var6;
            try {
               var4.d();
            } catch (Throwable var8) {
               var6 = .b.a(var8, "Exception ticking world");
               var4.a((.b)var6);
               throw new .f(var6);
            }

            try {
               var4.k();
            } catch (Throwable var7) {
               var6 = .b.a(var7, "Exception ticking world entities");
               var4.a((.b)var6);
               throw new .f(var6);
            }

            this.c.b();
            this.c.a("tracker");
            var4.v().a();
            this.c.b();
            this.c.b();
         }

         this.i[var1][this.y % 100] = System.nanoTime() - var2;
      }

      this.c.c("connection");
      this.an().c();
      this.c.c("players");
      this.v.e();
      this.c.c("commandFunctions");
      this.aL().e();
      this.c.c("tickables");

      for(var1 = 0; var1 < this.o.size(); ++var1) {
         ((.nv)this.o.get(var1)).e();
      }

      this.c.b();
   }

   public boolean E() {
      return true;
   }

   public void F() {
      this.aa = new Thread(this, "Server thread");
      this.aa.start();
   }

   public File d(String var1) {
      return new File(this.A(), var1);
   }

   public void f(String var1) {
      k.warn(var1);
   }

   public .om a(int var1) {
      if (var1 == -1) {
         return this.d[1];
      } else {
         return var1 == 1 ? this.d[2] : this.d[0];
      }
   }

   public String G() {
      return "1.12";
   }

   public int H() {
      return this.v.o();
   }

   public int I() {
      return this.v.p();
   }

   public String[] J() {
      return this.v.f();
   }

   public GameProfile[] K() {
      return this.v.g();
   }

   public String getServerModName() {
      return "vanilla";
   }

   public .b b(.b var1) {
      var1.g().a("Profiler Position", new .d<String>() {
         public String a() throws Exception {
            return MinecraftServer.this.c.a ? MinecraftServer.this.c.c() : "N/A (disabled)";
         }

         // $FF: synthetic method
         public Object call() throws Exception {
            return this.a();
         }
      });
      if (this.v != null) {
         var1.g().a("Player Count", new .d<String>() {
            public String a() {
               return MinecraftServer.this.v.o() + " / " + MinecraftServer.this.v.p() + "; " + MinecraftServer.this.v.v();
            }

            // $FF: synthetic method
            public Object call() throws Exception {
               return this.a();
            }
         });
      }

      return var1;
   }

   public List<String> a(.bn var1, String var2, @Nullable .et var3, boolean var4) {
      List<String> var5 = Lists.newArrayList();
      boolean var6 = var2.startsWith("/");
      if (var6) {
         var2 = var2.substring(1);
      }

      if (!var6 && !var4) {
         String[] var13 = var2.split(" ", -1);
         String var14 = var13[var13.length - 1];
         String[] var15 = this.v.f();
         int var16 = var15.length;

         for(int var11 = 0; var11 < var16; ++var11) {
            String var12 = var15[var11];
            if (.bi.a(var14, var12)) {
               var5.add(var12);
            }
         }

         return var5;
      } else {
         boolean var7 = !var2.contains(" ");
         List<String> var8 = this.b.a(var1, var2, var3);
         if (!var8.isEmpty()) {
            Iterator var9 = var8.iterator();

            while(true) {
               while(var9.hasNext()) {
                  String var10 = (String)var9.next();
                  if (var7 && !var4) {
                     var5.add("/" + var10);
                  } else {
                     var5.add(var10);
                  }
               }

               return var5;
            }
         } else {
            return var5;
         }
      }
   }

   public boolean M() {
      return this.n != null;
   }

   public String h_() {
      return "Server";
   }

   public void a(.hh var1) {
      k.info(var1.c());
   }

   public boolean a(int var1, String var2) {
      return true;
   }

   public .bl N() {
      return this.b;
   }

   public KeyPair O() {
      return this.I;
   }

   public String Q() {
      return this.J;
   }

   public void i(String var1) {
      this.J = var1;
   }

   public boolean R() {
      return this.J != null;
   }

   public String S() {
      return this.K;
   }

   public void j(String var1) {
      this.K = var1;
   }

   public void k(String var1) {
      this.L = var1;
   }

   public String T() {
      return this.L;
   }

   public void a(KeyPair var1) {
      this.I = var1;
   }

   public void a(.tx var1) {
      .om[] var2 = this.d;
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         .om var5 = var2[var4];
         if (var5 != null) {
            if (var5.V().s()) {
               var5.V().a(.tx.d);
               var5.a(true, true);
            } else if (this.R()) {
               var5.V().a(var1);
               var5.a(var5.ag() != .tx.a, true);
            } else {
               var5.V().a(var1);
               var5.a(this.U(), this.B);
            }
         }
      }

   }

   public boolean U() {
      return true;
   }

   public boolean V() {
      return this.M;
   }

   public void b(boolean var1) {
      this.M = var1;
   }

   public void c(boolean var1) {
      this.N = var1;
   }

   public .bfe W() {
      return this.l;
   }

   public String X() {
      return this.O;
   }

   public String Y() {
      return this.P;
   }

   public void a_(String var1, String var2) {
      this.O = var1;
      this.P = var2;
   }

   public void a(.uj var1) {
      var1.a("whitelist_enabled", false);
      var1.a("whitelist_count", 0);
      if (this.v != null) {
         var1.a("players_current", this.H());
         var1.a("players_max", this.I());
         var1.a("players_seen", this.v.q().length);
      }

      var1.a("uses_auth", this.z);
      var1.a("gui_state", this.ap() ? "enabled" : "disabled");
      var1.a("run_time", (aw() - var1.g()) / 60L * 1000L);
      var1.a("avg_tick_ms", (int)(.ri.a(this.h) * 1.0E-6D));
      int var2 = 0;
      if (this.d != null) {
         .om[] var3 = this.d;
         int var4 = var3.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            .om var6 = var3[var5];
            if (var6 != null) {
               .bfb var7 = var6.V();
               var1.a("world[" + var2 + "][dimension]", var6.s.q().a());
               var1.a("world[" + var2 + "][mode]", var7.q());
               var1.a("world[" + var2 + "][difficulty]", var6.ag());
               var1.a("world[" + var2 + "][hardcore]", var7.s());
               var1.a("world[" + var2 + "][generator_name]", var7.t().a());
               var1.a("world[" + var2 + "][generator_version]", var7.t().d());
               var1.a("world[" + var2 + "][height]", this.G);
               var1.a("world[" + var2 + "][chunks_loaded]", var6.r().g());
               ++var2;
            }
         }
      }

      var1.a("worlds", var2);
   }

   public void b(.uj var1) {
      var1.b("singleplayer", this.R());
      var1.b("server_brand", this.getServerModName());
      var1.b("gui_supported", GraphicsEnvironment.isHeadless() ? "headless" : "supported");
      var1.b("dedicated", this.aa());
   }

   public boolean Z() {
      return true;
   }

   public abstract boolean aa();

   public boolean ab() {
      return this.z;
   }

   public void d(boolean var1) {
      this.z = var1;
   }

   public boolean ac() {
      return this.A;
   }

   public boolean ad() {
      return this.B;
   }

   public void f(boolean var1) {
      this.B = var1;
   }

   public boolean ae() {
      return this.C;
   }

   public abstract boolean af();

   public void g(boolean var1) {
      this.C = var1;
   }

   public boolean ag() {
      return this.D;
   }

   public void h(boolean var1) {
      this.D = var1;
   }

   public boolean ah() {
      return this.E;
   }

   public void i(boolean var1) {
      this.E = var1;
   }

   public abstract boolean ai();

   public String aj() {
      return this.F;
   }

   public void l(String var1) {
      this.F = var1;
   }

   public int ak() {
      return this.G;
   }

   public void c(int var1) {
      this.G = var1;
   }

   public boolean al() {
      return this.x;
   }

   public .pj am() {
      return this.v;
   }

   public void a(.pj var1) {
      this.v = var1;
   }

   public void a(.amq var1) {
      .om[] var2 = this.d;
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         .om var5 = var2[var4];
         var5.V().a(var1);
      }

   }

   public .ox an() {
      return this.p;
   }

   public boolean ao() {
      return this.Q;
   }

   public boolean ap() {
      return false;
   }

   public abstract String a(.amq var1, boolean var2);

   public int aq() {
      return this.y;
   }

   public void ar() {
      this.T = true;
   }

   public .uj as() {
      return this.m;
   }

   public .ams e() {
      return this.d[0];
   }

   public boolean a(.ams var1, .et var2, .aeb var3) {
      return false;
   }

   public boolean au() {
      return this.U;
   }

   public Proxy av() {
      return this.e;
   }

   public static long aw() {
      return System.currentTimeMillis();
   }

   public int ax() {
      return this.H;
   }

   public void d(int var1) {
      this.H = var1;
   }

   public MinecraftSessionService az() {
      return this.W;
   }

   public GameProfileRepository aA() {
      return this.X;
   }

   public .pf aB() {
      return this.Y;
   }

   public .ms aC() {
      return this.q;
   }

   public void aD() {
      this.Z = 0L;
   }

   @Nullable
   public .ve a(UUID var1) {
      .om[] var2 = this.d;
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         .om var5 = var2[var4];
         if (var5 != null) {
            .ve var6 = var5.a(var1);
            if (var6 != null) {
               return var6;
            }
         }
      }

      return null;
   }

   public boolean g() {
      return this.d[0].W().b("sendCommandFeedback");
   }

   public MinecraftServer C_() {
      return this;
   }

   public int aE() {
      return 29999984;
   }

   public <V> ListenableFuture<V> a(Callable<V> var1) {
      Validate.notNull(var1);
      if (!this.aF() && !this.al()) {
         ListenableFutureTask<V> var2 = ListenableFutureTask.create(var1);
         synchronized(this.j) {
            this.j.add(var2);
            return var2;
         }
      } else {
         try {
            return Futures.immediateFuture(var1.call());
         } catch (Exception var6) {
            return Futures.immediateFailedCheckedFuture(var6);
         }
      }
   }

   public ListenableFuture<Object> a(Runnable var1) {
      Validate.notNull(var1);
      return this.a(Executors.callable(var1));
   }

   public boolean aF() {
      return Thread.currentThread() == this.aa;
   }

   public int aG() {
      return 256;
   }

   public int a(@Nullable .om var1) {
      return var1 != null ? var1.W().c("spawnRadius") : 10;
   }

   public .nq aK() {
      return this.d[0].z();
   }

   public .nr aL() {
      return this.d[0].A();
   }

   public void aM() {
      if (this.aF()) {
         this.am().j();
         this.d[0].am().a();
         this.aK().a();
         this.aL().f();
         this.am().w();
      } else {
         this.a(this::aM);
      }

   }
}
