package net.minecraft.realms;

import java.net.InetAddress;
import java.net.UnknownHostException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class RealmsConnect {
   private static final Logger LOGGER = LogManager.getLogger();
   private final RealmsScreen onlineScreen;
   private volatile boolean aborted;
   private .gw connection;

   public RealmsConnect(RealmsScreen var1) {
      this.onlineScreen = var1;
   }

   public void connect(final String var1, final int var2) {
      Realms.setConnectedToRealms(true);
      (new Thread("Realms-connect-task") {
         public void run() {
            InetAddress var1x = null;

            try {
               var1x = InetAddress.getByName(var1);
               if (RealmsConnect.this.aborted) {
                  return;
               }

               RealmsConnect.this.connection = .gw.a(var1x, var2, .bhz.z().t.f());
               if (RealmsConnect.this.aborted) {
                  return;
               }

               RealmsConnect.this.connection.a((.hb)(new .brw(RealmsConnect.this.connection, .bhz.z(), RealmsConnect.this.onlineScreen.getProxy())));
               if (RealmsConnect.this.aborted) {
                  return;
               }

               RealmsConnect.this.connection.a((.ht)(new .mc(335, var1, var2, .gx.d)));
               if (RealmsConnect.this.aborted) {
                  return;
               }

               RealmsConnect.this.connection.a((.ht)(new .ml(.bhz.z().K().e())));
            } catch (UnknownHostException var5) {
               Realms.clearResourcePack();
               if (RealmsConnect.this.aborted) {
                  return;
               }

               RealmsConnect.LOGGER.error("Couldn't connect to world", var5);
               Realms.setScreen(new DisconnectedRealmsScreen(RealmsConnect.this.onlineScreen, "connect.failed", new .hp("disconnect.genericReason", new Object[]{"Unknown host '" + var1 + "'"})));
            } catch (Exception var6) {
               Realms.clearResourcePack();
               if (RealmsConnect.this.aborted) {
                  return;
               }

               RealmsConnect.LOGGER.error("Couldn't connect to world", var6);
               String var3 = var6.toString();
               if (var1x != null) {
                  String var4 = var1x + ":" + var2;
                  var3 = var3.replaceAll(var4, "");
               }

               Realms.setScreen(new DisconnectedRealmsScreen(RealmsConnect.this.onlineScreen, "connect.failed", new .hp("disconnect.genericReason", new Object[]{var3})));
            }

         }
      }).start();
   }

   public void abort() {
      this.aborted = true;
      if (this.connection != null && this.connection.g()) {
         this.connection.a((.hh)(new .hp("disconnect.genericReason", new Object[0])));
         this.connection.l();
      }

   }

   public void tick() {
      if (this.connection != null) {
         if (this.connection.g()) {
            this.connection.a();
         } else {
            this.connection.l();
         }
      }

   }
}
