package net.minecraft.realms;

public class RealmsVertexFormatElement {
   private final .cdz v;

   public RealmsVertexFormatElement(.cdz var1) {
      this.v = var1;
   }

   public .cdz getVertexFormatElement() {
      return this.v;
   }

   public boolean isPosition() {
      return this.v.f();
   }

   public int getIndex() {
      return this.v.d();
   }

   public int getByteSize() {
      return this.v.e();
   }

   public int getCount() {
      return this.v.c();
   }

   public int hashCode() {
      return this.v.hashCode();
   }

   public boolean equals(Object var1) {
      return this.v.equals(var1);
   }

   public String toString() {
      return this.v.toString();
   }
}
