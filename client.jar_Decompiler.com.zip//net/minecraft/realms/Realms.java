package net.minecraft.realms;

import com.google.common.util.concurrent.ListenableFuture;
import com.mojang.authlib.GameProfile;
import com.mojang.util.UUIDTypeAdapter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Proxy;

public class Realms {
   public static boolean isTouchScreen() {
      return .bhz.z().t.B;
   }

   public static Proxy getProxy() {
      return .bhz.z().M();
   }

   public static String sessionId() {
      .big var0 = .bhz.z().K();
      return var0 == null ? null : var0.a();
   }

   public static String userName() {
      .big var0 = .bhz.z().K();
      return var0 == null ? null : var0.c();
   }

   public static long currentTimeMillis() {
      return .bhz.I();
   }

   public static String getSessionId() {
      return .bhz.z().K().a();
   }

   public static String getUUID() {
      return .bhz.z().K().b();
   }

   public static String getName() {
      return .bhz.z().K().c();
   }

   public static String uuidToName(String var0) {
      return .bhz.z().X().fillProfileProperties(new GameProfile(UUIDTypeAdapter.fromString(var0), (String)null), false).getName();
   }

   public static void setScreen(RealmsScreen var0) {
      .bhz.z().a((.bli)var0.getProxy());
   }

   public static String getGameDirectoryPath() {
      return .bhz.z().w.getAbsolutePath();
   }

   public static int survivalId() {
      return .amq.b.a();
   }

   public static int creativeId() {
      return .amq.c.a();
   }

   public static int adventureId() {
      return .amq.d.a();
   }

   public static int spectatorId() {
      return .amq.e.a();
   }

   public static void setConnectedToRealms(boolean var0) {
      .bhz.z().a(var0);
   }

   public static ListenableFuture<Object> downloadResourcePack(String var0, String var1) {
      return .bhz.z().P().a(var0, var1);
   }

   public static void clearResourcePack() {
      .bhz.z().P().h();
   }

   public static boolean getRealmsNotificationsEnabled() {
      return .bhz.z().t.b(.bib.a.L);
   }

   public static boolean inTitleScreen() {
      return .bhz.z().m != null && .bhz.z().m instanceof .blp;
   }

   public static void deletePlayerTag(File var0) {
      if (var0.exists()) {
         try {
            .fy var1 = .gi.a((InputStream)(new FileInputStream(var0)));
            .fy var2 = var1.p("Data");
            var2.r("Player");
            .gi.a((.fy)var1, (OutputStream)(new FileOutputStream(var0)));
         } catch (Exception var3) {
            var3.printStackTrace();
         }
      }

   }
}
