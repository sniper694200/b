public interface ua extends ug {
   afp a(aea var1, aeb var2);

   String l();
}
