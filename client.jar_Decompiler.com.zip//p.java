import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;

public interface p<T extends q> {
   nd a();

   void a(nn var1, p.a<T> var2);

   void b(nn var1, p.a<T> var2);

   void a(nn var1);

   T a(JsonObject var1, JsonDeserializationContext var2);

   public static class a<T extends q> {
      private final T a;
      private final i b;
      private final String c;

      public a(T var1, i var2, String var3) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }

      public T a() {
         return this.a;
      }

      public void a(nn var1) {
         var1.a(this.b, this.c);
      }

      public boolean equals(Object var1) {
         if (this == var1) {
            return true;
         } else if (var1 != null && this.getClass() == var1.getClass()) {
            p.a<?> var2 = (p.a)var1;
            if (!this.a.equals(var2.a)) {
               return false;
            } else {
               return !this.b.equals(var2.b) ? false : this.c.equals(var2.c);
            }
         } else {
            return false;
         }
      }

      public int hashCode() {
         int var1 = this.a.hashCode();
         var1 = 31 * var1 + this.b.hashCode();
         var1 = 31 * var1 + this.c.hashCode();
         return var1;
      }
   }
}
