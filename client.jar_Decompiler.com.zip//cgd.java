import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;

public class cgd implements cfw {
   protected final List<bvn> a;
   protected final Map<fa, List<bvn>> b;
   protected final boolean c;
   protected final boolean d;
   protected final cdo e;
   protected final bwa f;
   protected final bvy g;

   public cgd(List<bvn> var1, Map<fa, List<bvn>> var2, boolean var3, boolean var4, cdo var5, bwa var6, bvy var7) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = var5;
      this.f = var6;
      this.g = var7;
   }

   public List<bvn> a(@Nullable awr var1, @Nullable fa var2, long var3) {
      return var2 == null ? this.a : (List)this.b.get(var2);
   }

   public boolean a() {
      return this.c;
   }

   public boolean b() {
      return this.d;
   }

   public boolean c() {
      return false;
   }

   public cdo d() {
      return this.e;
   }

   public bwa e() {
      return this.f;
   }

   public bvy f() {
      return this.g;
   }

   public static class a {
      private final List<bvn> a;
      private final Map<fa, List<bvn>> b;
      private final bvy c;
      private final boolean d;
      private cdo e;
      private final boolean f;
      private final bwa g;

      public a(bvs var1, bvy var2) {
         this(var1.b(), var1.c(), var1.j(), var2);
      }

      public a(awr var1, cfw var2, cdo var3, et var4) {
         this(var2.a(), var2.b(), var2.e(), var2.f());
         this.e = var2.d();
         long var5 = ri.a((fq)var4);
         fa[] var7 = fa.values();
         int var8 = var7.length;

         for(int var9 = 0; var9 < var8; ++var9) {
            fa var10 = var7[var9];
            this.a(var1, var2, var3, var10, var5);
         }

         this.a(var1, var2, var3, var5);
      }

      private a(boolean var1, boolean var2, bwa var3, bvy var4) {
         this.a = Lists.newArrayList();
         this.b = Maps.newEnumMap(fa.class);
         fa[] var5 = fa.values();
         int var6 = var5.length;

         for(int var7 = 0; var7 < var6; ++var7) {
            fa var8 = var5[var7];
            this.b.put(var8, Lists.newArrayList());
         }

         this.c = var4;
         this.d = var1;
         this.f = var2;
         this.g = var3;
      }

      private void a(awr var1, cfw var2, cdo var3, fa var4, long var5) {
         Iterator var7 = var2.a(var1, var4, var5).iterator();

         while(var7.hasNext()) {
            bvn var8 = (bvn)var7.next();
            this.a(var4, new bvu(var8, var3));
         }

      }

      private void a(awr var1, cfw var2, cdo var3, long var4) {
         Iterator var6 = var2.a(var1, (fa)null, var4).iterator();

         while(var6.hasNext()) {
            bvn var7 = (bvn)var6.next();
            this.a((bvn)(new bvu(var7, var3)));
         }

      }

      public cgd.a a(fa var1, bvn var2) {
         ((List)this.b.get(var1)).add(var2);
         return this;
      }

      public cgd.a a(bvn var1) {
         this.a.add(var1);
         return this;
      }

      public cgd.a a(cdo var1) {
         this.e = var1;
         return this;
      }

      public cfw b() {
         if (this.e == null) {
            throw new RuntimeException("Missing particle!");
         } else {
            return new cgd(this.a, this.b, this.d, this.f, this.e, this.g, this.c);
         }
      }
   }
}
