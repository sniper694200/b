import com.google.common.collect.Maps;
import java.util.Collection;
import java.util.Map;
import javax.annotation.Nullable;

public abstract class bhk {
   public boolean a(@Nullable bhk var1) {
      if (var1 == null) {
         return false;
      } else {
         return this == var1;
      }
   }

   public abstract String b();

   public abstract String d(String var1);

   public abstract boolean h();

   public abstract boolean g();

   public abstract bhk.b i();

   public abstract .a m();

   public abstract Collection<String> d();

   public abstract bhk.b j();

   public abstract bhk.a k();

   public static enum a {
      a("always", 0),
      b("never", 1),
      c("pushOtherTeams", 2),
      d("pushOwnTeam", 3);

      private static final Map<String, bhk.a> g = Maps.newHashMap();
      public final String e;
      public final int f;

      public static String[] a() {
         return (String[])g.keySet().toArray(new String[g.size()]);
      }

      @Nullable
      public static bhk.a a(String var0) {
         return (bhk.a)g.get(var0);
      }

      private a(String var3, int var4) {
         this.e = var3;
         this.f = var4;
      }

      static {
         bhk.a[] var0 = values();
         int var1 = var0.length;

         for(int var2 = 0; var2 < var1; ++var2) {
            bhk.a var3 = var0[var2];
            g.put(var3.e, var3);
         }

      }
   }

   public static enum b {
      a("always", 0),
      b("never", 1),
      c("hideForOtherTeams", 2),
      d("hideForOwnTeam", 3);

      private static final Map<String, bhk.b> g = Maps.newHashMap();
      public final String e;
      public final int f;

      public static String[] a() {
         return (String[])g.keySet().toArray(new String[g.size()]);
      }

      @Nullable
      public static bhk.b a(String var0) {
         return (bhk.b)g.get(var0);
      }

      private b(String var3, int var4) {
         this.e = var3;
         this.f = var4;
      }

      static {
         bhk.b[] var0 = values();
         int var1 = var0.length;

         for(int var2 = 0; var2 < var1; ++var2) {
            bhk.b var3 = var0[var2];
            g.put(var3.e, var3);
         }

      }
   }
}
