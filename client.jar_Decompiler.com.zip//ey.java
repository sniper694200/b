import java.util.Random;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import org.apache.commons.lang3.Validate;

public class ey<K, V> extends fh<K, V> {
   private final K d;
   private V e;

   public ey(K var1) {
      this.d = var1;
   }

   public void a(int var1, K var2, V var3) {
      if (this.d.equals(var2)) {
         this.e = var3;
      }

      super.a(var1, var2, var3);
   }

   public void a() {
      Validate.notNull(this.e, "Missing default of DefaultedMappedRegistry: " + this.d, new Object[0]);
   }

   public int a(V var1) {
      int var2 = super.a(var1);
      return var2 == -1 ? super.a(this.e) : var2;
   }

   @Nonnull
   public K b(V var1) {
      K var2 = super.b(var1);
      return var2 == null ? this.d : var2;
   }

   @Nonnull
   public V c(@Nullable K var1) {
      V var2 = super.c(var1);
      return var2 == null ? this.e : var2;
   }

   @Nonnull
   public V a(int var1) {
      V var2 = super.a(var1);
      return var2 == null ? this.e : var2;
   }

   @Nonnull
   public V a(Random var1) {
      V var2 = super.a(var1);
      return var2 == null ? this.e : var2;
   }
}
