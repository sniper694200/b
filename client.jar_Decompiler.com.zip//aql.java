import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class aql extends aou {
   public static final axg a = axg.a("moisture", 0, 7);
   protected static final bgz b = new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.9375D, 1.0D);

   protected aql() {
      super(bcx.c);
      this.w(this.A.b().a(a, 0));
      this.a(true);
      this.e(255);
   }

   public bgz b(awr var1, amw var2, et var3) {
      return b;
   }

   public boolean b(awr var1) {
      return false;
   }

   public boolean c(awr var1) {
      return false;
   }

   public void b(ams var1, et var2, awr var3, Random var4) {
      int var5 = (Integer)var3.c(a);
      if (!this.d(var1, var2) && !var1.B(var2.a())) {
         if (var5 > 0) {
            var1.a((et)var2, (awr)var3.a(a, var5 - 1), 2);
         } else if (!this.c(var1, var2)) {
            this.b(var1, var2);
         }
      } else if (var5 < 7) {
         var1.a((et)var2, (awr)var3.a(a, 7), 2);
      }

   }

   public void a(ams var1, et var2, ve var3, float var4) {
      if (!var1.G && var1.r.nextFloat() < var4 - 0.5F && var3 instanceof vn && (var3 instanceof aeb || var1.W().b("mobGriefing")) && var3.G * var3.G * var3.H > 0.512F) {
         this.b(var1, var2);
      }

      super.a(var1, var2, var3, var4);
   }

   private void b(ams var1, et var2) {
      awr var3 = aov.d.t();
      var1.a(var2, var3);
      bgz var4 = var3.d(var1, var2).a(var2);
      List<ve> var5 = var1.b((ve)null, (bgz)var4);
      Iterator var6 = var5.iterator();

      while(var6.hasNext()) {
         ve var7 = (ve)var6.next();
         var7.b(var7.p, var4.e, var7.r);
      }

   }

   private boolean c(ams var1, et var2) {
      aou var3 = var1.o(var2.a()).u();
      return var3 instanceof apq || var3 instanceof aue;
   }

   private boolean d(ams var1, et var2) {
      Iterator var3 = et.b(var2.a(-4, 0, -4), var2.a(4, 1, 4)).iterator();

      et.a var4;
      do {
         if (!var3.hasNext()) {
            return false;
         }

         var4 = (et.a)var3.next();
      } while(var1.o(var4).a() != bcx.h);

      return true;
   }

   public void a(awr var1, ams var2, et var3, aou var4, et var5) {
      super.a(var1, var2, var3, var4, var5);
      if (var2.o(var3.a()).a().a()) {
         this.b(var2, var3);
      }

   }

   public void c(ams var1, et var2, awr var3) {
      super.c(var1, var2, var3);
      if (var1.o(var2.a()).a().a()) {
         this.b(var1, var2);
      }

   }

   public boolean a(awr var1, amw var2, et var3, fa var4) {
      switch(var4) {
      case b:
         return true;
      case c:
      case d:
      case e:
      case f:
         awr var5 = var2.o(var3.a(var4));
         aou var6 = var5.u();
         return !var5.p() && var6 != aov.ak && var6 != aov.da;
      default:
         return super.a(var1, var2, var3, var4);
      }
   }

   public ail a(awr var1, Random var2, int var3) {
      return aov.d.a(aov.d.t().a(apw.a, apw.a.a), var2, var3);
   }

   public awr a(int var1) {
      return this.t().a(a, var1 & 7);
   }

   public int e(awr var1) {
      return (Integer)var1.c(a);
   }

   protected aws b() {
      return new aws(this, new axh[]{a});
   }

   public awp a(amw var1, awr var2, et var3, fa var4) {
      return var4 == fa.a ? awp.a : awp.i;
   }
}
