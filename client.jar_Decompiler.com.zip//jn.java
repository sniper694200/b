import java.io.IOException;

public class jn implements ht<hw> {
   public jn.a a;
   public int b;
   public int c;
   public int d;
   public hh e;

   public jn() {
   }

   public jn(uo var1, jn.a var2) {
      this(var1, var2, true);
   }

   public jn(uo var1, jn.a var2, boolean var3) {
      this.a = var2;
      vn var4 = var1.c();
      switch(var2) {
      case b:
         this.d = var1.f();
         this.c = var4 == null ? -1 : var4.S();
         break;
      case c:
         this.b = var1.h().S();
         this.c = var4 == null ? -1 : var4.S();
         if (var3) {
            this.e = var1.b();
         } else {
            this.e = new ho("");
         }
      }

   }

   public void a(gy var1) throws IOException {
      this.a = (jn.a)var1.a(jn.a.class);
      if (this.a == jn.a.b) {
         this.d = var1.g();
         this.c = var1.readInt();
      } else if (this.a == jn.a.c) {
         this.b = var1.g();
         this.c = var1.readInt();
         this.e = var1.f();
      }

   }

   public void b(gy var1) throws IOException {
      var1.a((Enum)this.a);
      if (this.a == jn.a.b) {
         var1.d(this.d);
         var1.writeInt(this.c);
      } else if (this.a == jn.a.c) {
         var1.d(this.b);
         var1.writeInt(this.c);
         var1.a(this.e);
      }

   }

   public void a(hw var1) {
      var1.a(this);
   }

   public static enum a {
      a,
      b,
      c;
   }
}
