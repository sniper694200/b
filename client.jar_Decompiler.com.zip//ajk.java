import java.util.List;
import javax.annotation.Nullable;

public class ajk extends ail {
   public ajk() {
      this.k = 1;
      this.b(ahn.j);
      this.e(336);
      this.a(new nd("blocking"), new aio() {
         public float a(ain var1, @Nullable ams var2, @Nullable vn var3) {
            return var3 != null && var3.cG() && var3.cJ() == var1 ? 1.0F : 0.0F;
         }
      });
      apx.c.a(this, agt.b);
   }

   public String b(ain var1) {
      if (var1.d("BlockEntityTag") != null) {
         ahq var2 = avd.d(var1);
         return ft.a("item.shield." + var2.d() + ".name");
      } else {
         return ft.a("item.shield.name");
      }
   }

   public void a(ain var1, @Nullable ams var2, List<String> var3, ajz var4) {
      agx.a(var1, var3);
   }

   public aka f(ain var1) {
      return aka.d;
   }

   public int e(ain var1) {
      return 72000;
   }

   public uc<ain> a(ams var1, aeb var2, tz var3) {
      ain var4 = var2.b((tz)var3);
      var2.c((tz)var3);
      return new uc(ub.a, var4);
   }

   public boolean a(ain var1, ain var2) {
      return var2.c() == ail.a(aov.f) ? true : super.a(var1, var2);
   }
}
