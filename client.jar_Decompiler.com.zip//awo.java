public interface awo {
   boolean a(ams var1, et var2, int var3, int var4);

   void a(ams var1, et var2, aou var3, et var4);
}
