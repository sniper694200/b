import javax.annotation.Nullable;

public interface axp {
   @Nullable
   axu a(int var1, int var2);

   axu c(int var1, int var2);

   boolean d();

   String f();

   boolean e(int var1, int var2);
}
