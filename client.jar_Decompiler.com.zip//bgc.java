import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import java.util.Random;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class bgc extends bfx {
   private static final Logger a = LogManager.getLogger();
   private final bfu b;

   public bgc(bgj[] var1, bfu var2) {
      super(var1);
      this.b = var2;
   }

   public ain a(ain var1, Random var2, bfr var3) {
      if (var1.f()) {
         float var4 = 1.0F - this.b.b(var2);
         var1.b(ri.d(var4 * (float)var1.k()));
      } else {
         a.warn("Couldn't set damage of loot item {}", var1);
      }

      return var1;
   }

   public static class a extends bfx.a<bgc> {
      protected a() {
         super(new nd("set_damage"), bgc.class);
      }

      public void a(JsonObject var1, bgc var2, JsonSerializationContext var3) {
         var1.add("damage", var3.serialize(var2.b));
      }

      public bgc a(JsonObject var1, JsonDeserializationContext var2, bgj[] var3) {
         return new bgc(var3, (bfu)ra.a(var1, "damage", var2, bfu.class));
      }

      // $FF: synthetic method
      public bfx b(JsonObject var1, JsonDeserializationContext var2, bgj[] var3) {
         return this.a(var1, var2, var3);
      }
   }
}
