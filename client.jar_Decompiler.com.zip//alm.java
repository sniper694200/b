import javax.annotation.Nullable;

public class alm {
   public static final ali a = a("protection");
   public static final ali b = a("fire_protection");
   public static final ali c = a("feather_falling");
   public static final ali d = a("blast_protection");
   public static final ali e = a("projectile_protection");
   public static final ali f = a("respiration");
   public static final ali g = a("aqua_affinity");
   public static final ali h = a("thorns");
   public static final ali i = a("depth_strider");
   public static final ali j = a("frost_walker");
   public static final ali k = a("binding_curse");
   public static final ali l = a("sharpness");
   public static final ali m = a("smite");
   public static final ali n = a("bane_of_arthropods");
   public static final ali o = a("knockback");
   public static final ali p = a("fire_aspect");
   public static final ali q = a("looting");
   public static final ali r = a("sweeping");
   public static final ali s = a("efficiency");
   public static final ali t = a("silk_touch");
   public static final ali u = a("unbreaking");
   public static final ali v = a("fortune");
   public static final ali w = a("power");
   public static final ali x = a("punch");
   public static final ali y = a("flame");
   public static final ali z = a("infinity");
   public static final ali A = a("luck_of_the_sea");
   public static final ali B = a("lure");
   public static final ali C = a("mending");
   public static final ali D = a("vanishing_curse");

   @Nullable
   private static ali a(String var0) {
      ali var1 = (ali)ali.b.c(new nd(var0));
      if (var1 == null) {
         throw new IllegalStateException("Invalid Enchantment requested: " + var0);
      } else {
         return var1;
      }
   }

   static {
      if (!ng.a()) {
         throw new RuntimeException("Accessed Enchantments before Bootstrap!");
      }
   }
}
