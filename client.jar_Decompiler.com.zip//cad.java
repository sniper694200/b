public abstract class cad<T extends vo> extends bzy<T> {
   public cad(bzd var1, bqd var2, float var3) {
      super(var1, var2, var3);
   }

   protected boolean b(T var1) {
      return super.a((vn)var1) && (var1.bs() || var1.n_() && var1 == this.b.d);
   }

   public boolean a(T var1, bxw var2, double var3, double var5, double var7) {
      if (super.a(var1, var2, var3, var5, var7)) {
         return true;
      } else if (var1.da() && var1.db() != null) {
         ve var9 = var1.db();
         return var2.a(var9.bx());
      } else {
         return false;
      }
   }

   public void a(T var1, double var2, double var4, double var6, float var8, float var9) {
      super.a((vn)var1, var2, var4, var6, var8, var9);
      if (!this.e) {
         this.b(var1, var2, var4, var6, var8, var9);
      }

   }

   public void c(T var1) {
      int var2 = var1.av();
      int var3 = var2 % 65536;
      int var4 = var2 / 65536;
      cig.a(cig.r, (float)var3, (float)var4);
   }

   private double a(double var1, double var3, double var5) {
      return var1 + (var3 - var1) * var5;
   }

   protected void b(T var1, double var2, double var4, double var6, float var8, float var9) {
      ve var10 = var1.db();
      if (var10 != null) {
         var4 -= (1.6D - (double)var1.H) * 0.5D;
         bvc var11 = bvc.a();
         bui var12 = var11.c();
         double var13 = this.a((double)var10.x, (double)var10.v, (double)(var9 * 0.5F)) * 0.01745329238474369D;
         double var15 = this.a((double)var10.y, (double)var10.w, (double)(var9 * 0.5F)) * 0.01745329238474369D;
         double var17 = Math.cos(var13);
         double var19 = Math.sin(var13);
         double var21 = Math.sin(var15);
         if (var10 instanceof aby) {
            var17 = 0.0D;
            var19 = 0.0D;
            var21 = -1.0D;
         }

         double var23 = Math.cos(var15);
         double var25 = this.a(var10.m, var10.p, (double)var9) - var17 * 0.7D - var19 * 0.5D * var23;
         double var27 = this.a(var10.n + (double)var10.by() * 0.7D, var10.q + (double)var10.by() * 0.7D, (double)var9) - var21 * 0.5D - 0.25D;
         double var29 = this.a(var10.o, var10.r, (double)var9) - var19 * 0.7D + var17 * 0.5D * var23;
         double var31 = this.a((double)var1.aO, (double)var1.aN, (double)var9) * 0.01745329238474369D + 1.5707963267948966D;
         var17 = Math.cos(var31) * (double)var1.G * 0.4D;
         var19 = Math.sin(var31) * (double)var1.G * 0.4D;
         double var33 = this.a(var1.m, var1.p, (double)var9) + var17;
         double var35 = this.a(var1.n, var1.q, (double)var9);
         double var37 = this.a(var1.o, var1.r, (double)var9) + var19;
         var2 += var17;
         var6 += var19;
         double var39 = (double)((float)(var25 - var33));
         double var41 = (double)((float)(var27 - var35));
         double var43 = (double)((float)(var29 - var37));
         buq.z();
         buq.g();
         buq.r();
         int var45 = true;
         double var46 = 0.025D;
         var12.a(5, cdw.f);

         int var48;
         float var49;
         float var50;
         float var51;
         float var52;
         for(var48 = 0; var48 <= 24; ++var48) {
            var49 = 0.5F;
            var50 = 0.4F;
            var51 = 0.3F;
            if (var48 % 2 == 0) {
               var49 *= 0.7F;
               var50 *= 0.7F;
               var51 *= 0.7F;
            }

            var52 = (float)var48 / 24.0F;
            var12.b(var2 + var39 * (double)var52 + 0.0D, var4 + var41 * (double)(var52 * var52 + var52) * 0.5D + (double)((24.0F - (float)var48) / 18.0F + 0.125F), var6 + var43 * (double)var52).a(var49, var50, var51, 1.0F).d();
            var12.b(var2 + var39 * (double)var52 + 0.025D, var4 + var41 * (double)(var52 * var52 + var52) * 0.5D + (double)((24.0F - (float)var48) / 18.0F + 0.125F) + 0.025D, var6 + var43 * (double)var52).a(var49, var50, var51, 1.0F).d();
         }

         var11.b();
         var12.a(5, cdw.f);

         for(var48 = 0; var48 <= 24; ++var48) {
            var49 = 0.5F;
            var50 = 0.4F;
            var51 = 0.3F;
            if (var48 % 2 == 0) {
               var49 *= 0.7F;
               var50 *= 0.7F;
               var51 *= 0.7F;
            }

            var52 = (float)var48 / 24.0F;
            var12.b(var2 + var39 * (double)var52 + 0.0D, var4 + var41 * (double)(var52 * var52 + var52) * 0.5D + (double)((24.0F - (float)var48) / 18.0F + 0.125F) + 0.025D, var6 + var43 * (double)var52).a(var49, var50, var51, 1.0F).d();
            var12.b(var2 + var39 * (double)var52 + 0.025D, var4 + var41 * (double)(var52 * var52 + var52) * 0.5D + (double)((24.0F - (float)var48) / 18.0F + 0.125F), var6 + var43 * (double)var52 + 0.025D).a(var49, var50, var51, 1.0F).d();
         }

         var11.b();
         buq.f();
         buq.y();
         buq.q();
      }
   }

   // $FF: synthetic method
   protected boolean a(vn var1) {
      return this.b((vo)var1);
   }
}
