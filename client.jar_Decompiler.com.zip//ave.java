import javax.annotation.Nullable;

public enum ave {
   a("base", "b"),
   b("square_bottom_left", "bl", "   ", "   ", "#  "),
   c("square_bottom_right", "br", "   ", "   ", "  #"),
   d("square_top_left", "tl", "#  ", "   ", "   "),
   e("square_top_right", "tr", "  #", "   ", "   "),
   f("stripe_bottom", "bs", "   ", "   ", "###"),
   g("stripe_top", "ts", "###", "   ", "   "),
   h("stripe_left", "ls", "#  ", "#  ", "#  "),
   i("stripe_right", "rs", "  #", "  #", "  #"),
   j("stripe_center", "cs", " # ", " # ", " # "),
   k("stripe_middle", "ms", "   ", "###", "   "),
   l("stripe_downright", "drs", "#  ", " # ", "  #"),
   m("stripe_downleft", "dls", "  #", " # ", "#  "),
   n("small_stripes", "ss", "# #", "# #", "   "),
   o("cross", "cr", "# #", " # ", "# #"),
   p("straight_cross", "sc", " # ", "###", " # "),
   q("triangle_bottom", "bt", "   ", " # ", "# #"),
   r("triangle_top", "tt", "# #", " # ", "   "),
   s("triangles_bottom", "bts", "   ", "# #", " # "),
   t("triangles_top", "tts", " # ", "# #", "   "),
   u("diagonal_left", "ld", "## ", "#  ", "   "),
   v("diagonal_up_right", "rd", "   ", "  #", " ##"),
   w("diagonal_up_left", "lud", "   ", "#  ", "## "),
   x("diagonal_right", "rud", " ##", "  #", "   "),
   y("circle", "mc", "   ", " # ", "   "),
   z("rhombus", "mr", " # ", "# #", " # "),
   A("half_vertical", "vh", "## ", "## ", "## "),
   B("half_horizontal", "hh", "###", "###", "   "),
   C("half_vertical_right", "vhr", " ##", " ##", " ##"),
   D("half_horizontal_bottom", "hhb", "   ", "###", "###"),
   E("border", "bo", "###", "# #", "###"),
   F("curly_border", "cbo", new ain(aov.bn)),
   G("creeper", "cre", new ain(aip.ci, 1, 4)),
   H("gradient", "gra", "# #", " # ", " # "),
   I("gradient_up", "gru", " # ", " # ", "# #"),
   J("bricks", "bri", new ain(aov.V)),
   K("skull", "sku", new ain(aip.ci, 1, 1)),
   L("flower", "flo", new ain(aov.O, 1, aqp.a.j.b())),
   M("mojang", "moj", new ain(aip.ar, 1, 1));

   private final String N;
   private final String O;
   private final String[] P;
   private ain Q;

   private ave(String var3, String var4) {
      this.P = new String[3];
      this.Q = ain.a;
      this.N = var3;
      this.O = var4;
   }

   private ave(String var3, String var4, ain var5) {
      this(var3, var4);
      this.Q = var5;
   }

   private ave(String var3, String var4, String var5, String var6, String var7) {
      this(var3, var4);
      this.P[0] = var5;
      this.P[1] = var6;
      this.P[2] = var7;
   }

   public String a() {
      return this.N;
   }

   public String b() {
      return this.O;
   }

   public String[] c() {
      return this.P;
   }

   public boolean d() {
      return !this.Q.b() || this.P[0] != null;
   }

   public boolean e() {
      return !this.Q.b();
   }

   public ain f() {
      return this.Q;
   }

   @Nullable
   public static ave a(String var0) {
      ave[] var1 = values();
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         ave var4 = var1[var3];
         if (var4.O.equals(var0)) {
            return var4;
         }
      }

      return null;
   }
}
