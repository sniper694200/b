import java.io.IOException;

public class lg implements ht<kw> {
   private int a;

   public lg() {
   }

   public lg(int var1) {
      this.a = var1;
   }

   public void a(kw var1) {
      var1.a(this);
   }

   public void a(gy var1) throws IOException {
      this.a = var1.readByte();
   }

   public void b(gy var1) throws IOException {
      var1.writeByte(this.a);
   }
}
