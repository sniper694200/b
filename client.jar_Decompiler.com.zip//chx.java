import javax.annotation.Nullable;

public class chx {
   private final bhz a;
   @Nullable
   private chy b;

   public chx(bhz var1) {
      this.a = var1;
   }

   public void a(btz var1) {
      if (this.b != null) {
         this.b.a(var1);
      }

   }

   public void a(bia var1) {
      if (this.b != null) {
         this.b.a(var1);
      }

   }

   public void a(@Nullable brz var1, @Nullable bha var2) {
      if (this.b != null && var2 != null && var1 != null) {
         this.b.a(var1, var2);
      }

   }

   public void a(brz var1, et var2, awr var3, float var4) {
      if (this.b != null) {
         this.b.a(var1, var2, var3, var4);
      }

   }

   public void a() {
      if (this.b != null) {
         this.b.c();
      }

   }

   public void a(ain var1) {
      if (this.b != null) {
         this.b.a(var1);
      }

   }

   public void b() {
      if (this.b != null) {
         this.b.b();
         this.b = null;
      }
   }

   public void c() {
      if (this.b != null) {
         this.b();
      }

      this.b = this.a.t.S.a(this);
   }

   public void d() {
      if (this.b != null) {
         if (this.a.f != null) {
            this.b.a();
         } else {
            this.b();
         }
      } else if (this.a.f != null) {
         this.c();
      }

   }

   public void a(chz var1) {
      this.a.t.S = var1;
      this.a.t.b();
      if (this.b != null) {
         this.b.b();
         this.b = var1.a(this);
      }

   }

   public bhz e() {
      return this.a;
   }

   public amq f() {
      return this.a.c == null ? amq.a : this.a.c.l();
   }

   public static hh a(String var0) {
      hk var1 = new hk("key." + var0);
      var1.b().a(true);
      return var1;
   }
}
