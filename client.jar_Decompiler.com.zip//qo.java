public class qo {
   private int a;
   private qp b;

   public int a() {
      return this.a;
   }

   public void a(int var1) {
      this.a = var1;
   }

   public <T extends qp> T b() {
      return this.b;
   }

   public void a(qp var1) {
      this.b = var1;
   }
}
