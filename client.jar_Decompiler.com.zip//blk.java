public class blk extends bli {
   private final bli a;
   private String f;

   public blk(bli var1) {
      this.a = var1;
   }

   public void b() {
      int var1 = 0;
      this.f = cew.a("options.skinCustomisation.title");
      aec[] var2 = aec.values();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         aec var5 = var2[var4];
         this.n.add(new blk.a(var5.b(), this.l / 2 - 155 + var1 % 2 * 160, this.m / 6 + 24 * (var1 >> 1), 150, 20, var5));
         ++var1;
      }

      this.n.add(new bjl(199, this.l / 2 - 155 + var1 % 2 * 160, this.m / 6 + 24 * (var1 >> 1), bib.a.H, this.j.t.c(bib.a.H)));
      ++var1;
      if (var1 % 2 == 1) {
         ++var1;
      }

      this.n.add(new biy(200, this.l / 2 - 100, this.m / 6 + 24 * (var1 >> 1), cew.a("gui.done")));
   }

   protected void a(char var1, int var2) {
      if (var2 == 1) {
         this.j.t.b();
      }

      super.a(var1, var2);
   }

   protected void a(biy var1) {
      if (var1.l) {
         if (var1.k == 200) {
            this.j.t.b();
            this.j.a(this.a);
         } else if (var1.k == 199) {
            this.j.t.a((bib.a)bib.a.H, 1);
            var1.j = this.j.t.c(bib.a.H);
            this.j.t.c();
         } else if (var1 instanceof blk.a) {
            aec var2 = ((blk.a)var1).p;
            this.j.t.a(var2);
            var1.j = this.a(var2);
         }

      }
   }

   public void a(int var1, int var2, float var3) {
      this.c();
      this.a(this.q, this.f, this.l / 2, 20, 16777215);
      super.a(var1, var2, var3);
   }

   private String a(aec var1) {
      String var2;
      if (this.j.t.d().contains(var1)) {
         var2 = cew.a("options.on");
      } else {
         var2 = cew.a("options.off");
      }

      return var1.d().d() + ": " + var2;
   }

   class a extends biy {
      private final aec p;

      private a(int var2, int var3, int var4, int var5, int var6, aec var7) {
         super(var2, var3, var4, var5, var6, blk.this.a(var7));
         this.p = var7;
      }

      // $FF: synthetic method
      a(int var2, int var3, int var4, int var5, int var6, aec var7, Object var8) {
         this(var2, var3, var4, var5, var6, var7);
      }
   }
}
