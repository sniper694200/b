public class bsi extends btd {
   protected bsi(ams var1, double var2, double var4, double var6, ail var8) {
      super(var1, var2, var4, var6, 0.0D, 0.0D, 0.0D);
      this.a(bhz.z().ad().a().a(var8));
      this.A = 1.0F;
      this.B = 1.0F;
      this.C = 1.0F;
      this.j = 0.0D;
      this.k = 0.0D;
      this.l = 0.0D;
      this.z = 0.0F;
      this.x = 80;
   }

   public int b() {
      return 1;
   }

   public void a(bui var1, ve var2, float var3, float var4, float var5, float var6, float var7, float var8) {
      float var9 = this.E.e();
      float var10 = this.E.f();
      float var11 = this.E.g();
      float var12 = this.E.h();
      float var13 = 0.5F;
      float var14 = (float)(this.d + (this.g - this.d) * (double)var3 - H);
      float var15 = (float)(this.e + (this.h - this.e) * (double)var3 - I);
      float var16 = (float)(this.f + (this.i - this.f) * (double)var3 - J);
      int var17 = this.a(var3);
      int var18 = var17 >> 16 & '\uffff';
      int var19 = var17 & '\uffff';
      var1.b((double)(var14 - var4 * 0.5F - var7 * 0.5F), (double)(var15 - var5 * 0.5F), (double)(var16 - var6 * 0.5F - var8 * 0.5F)).a((double)var10, (double)var12).a(this.A, this.B, this.C, 1.0F).a(var18, var19).d();
      var1.b((double)(var14 - var4 * 0.5F + var7 * 0.5F), (double)(var15 + var5 * 0.5F), (double)(var16 - var6 * 0.5F + var8 * 0.5F)).a((double)var10, (double)var11).a(this.A, this.B, this.C, 1.0F).a(var18, var19).d();
      var1.b((double)(var14 + var4 * 0.5F + var7 * 0.5F), (double)(var15 + var5 * 0.5F), (double)(var16 + var6 * 0.5F + var8 * 0.5F)).a((double)var9, (double)var11).a(this.A, this.B, this.C, 1.0F).a(var18, var19).d();
      var1.b((double)(var14 + var4 * 0.5F - var7 * 0.5F), (double)(var15 - var5 * 0.5F), (double)(var16 + var6 * 0.5F - var8 * 0.5F)).a((double)var9, (double)var12).a(this.A, this.B, this.C, 1.0F).a(var18, var19).d();
   }

   public static class a implements btf {
      public btd a(int var1, ams var2, double var3, double var5, double var7, double var9, double var11, double var13, int... var15) {
         return new bsi(var2, var3, var5, var7, ail.a(aov.cv));
      }
   }
}
