import java.util.Random;
import javax.annotation.Nullable;

public abstract class aop extends aou {
   protected static final bgz a = new bgz(0.0625D, 0.0D, 0.0625D, 0.9375D, 0.03125D, 0.9375D);
   protected static final bgz b = new bgz(0.0625D, 0.0D, 0.0625D, 0.9375D, 0.0625D, 0.9375D);
   protected static final bgz c = new bgz(0.125D, 0.0D, 0.125D, 0.875D, 0.25D, 0.875D);

   protected aop(bcx var1) {
      this(var1, var1.r());
   }

   protected aop(bcx var1, bcy var2) {
      super(var1, var2);
      this.a(ahn.d);
      this.a(true);
   }

   public bgz b(awr var1, amw var2, et var3) {
      boolean var4 = this.i(var1) > 0;
      return var4 ? a : b;
   }

   public int a(ams var1) {
      return 20;
   }

   @Nullable
   public bgz a(awr var1, amw var2, et var3) {
      return k;
   }

   public boolean b(awr var1) {
      return false;
   }

   public boolean c(awr var1) {
      return false;
   }

   public boolean b(amw var1, et var2) {
      return true;
   }

   public boolean d() {
      return true;
   }

   public boolean a(ams var1, et var2) {
      return this.i(var1, var2.b());
   }

   public void a(awr var1, ams var2, et var3, aou var4, et var5) {
      if (!this.i(var2, var3.b())) {
         this.b(var2, var3, var1, 0);
         var2.g(var3);
      }

   }

   private boolean i(ams var1, et var2) {
      return var1.o(var2).q() || var1.o(var2).u() instanceof aqm;
   }

   public void a(ams var1, et var2, awr var3, Random var4) {
   }

   public void b(ams var1, et var2, awr var3, Random var4) {
      if (!var1.G) {
         int var5 = this.i(var3);
         if (var5 > 0) {
            this.a(var1, var2, var3, var5);
         }

      }
   }

   public void a(ams var1, et var2, awr var3, ve var4) {
      if (!var1.G) {
         int var5 = this.i(var3);
         if (var5 == 0) {
            this.a(var1, var2, var3, var5);
         }

      }
   }

   protected void a(ams var1, et var2, awr var3, int var4) {
      int var5 = this.e(var1, var2);
      boolean var6 = var4 > 0;
      boolean var7 = var5 > 0;
      if (var4 != var5) {
         var3 = this.a(var3, var5);
         var1.a((et)var2, (awr)var3, 2);
         this.d(var1, var2);
         var1.b(var2, var2);
      }

      if (!var7 && var6) {
         this.c(var1, var2);
      } else if (var7 && !var6) {
         this.b(var1, var2);
      }

      if (var7) {
         var1.a((et)(new et(var2)), (aou)this, this.a(var1));
      }

   }

   protected abstract void b(ams var1, et var2);

   protected abstract void c(ams var1, et var2);

   public void b(ams var1, et var2, awr var3) {
      if (this.i(var3) > 0) {
         this.d(var1, var2);
      }

      super.b(var1, var2, var3);
   }

   protected void d(ams var1, et var2) {
      var1.b(var2, this, false);
      var1.b(var2.b(), this, false);
   }

   public int b(awr var1, amw var2, et var3, fa var4) {
      return this.i(var1);
   }

   public int c(awr var1, amw var2, et var3, fa var4) {
      return var4 == fa.b ? this.i(var1) : 0;
   }

   public boolean g(awr var1) {
      return true;
   }

   public bda h(awr var1) {
      return bda.b;
   }

   protected abstract int e(ams var1, et var2);

   protected abstract int i(awr var1);

   protected abstract awr a(awr var1, int var2);

   public awp a(amw var1, awr var2, et var3, fa var4) {
      return awp.i;
   }
}
