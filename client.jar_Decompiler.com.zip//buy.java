import java.util.Iterator;

public class buy extends bul {
   public void a(amk var1) {
      if (this.b) {
         Iterator var2 = this.a.iterator();

         while(var2.hasNext()) {
            bxp var3 = (bxp)var2.next();
            bxo var4 = (bxo)var3;
            buq.G();
            this.a(var3);
            buq.s(var4.a(var1, var4.h()));
            buq.H();
         }

         buq.I();
         this.a.clear();
      }
   }
}
