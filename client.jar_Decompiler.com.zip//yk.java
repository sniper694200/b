public class yk extends xc {
   private final adw a;

   public yk(adw var1) {
      this.a = var1;
      this.a(5);
   }

   public boolean a() {
      if (!this.a.aC()) {
         return false;
      } else if (this.a.ao()) {
         return false;
      } else if (!this.a.z) {
         return false;
      } else if (this.a.D) {
         return false;
      } else {
         aeb var1 = this.a.t_();
         if (var1 == null) {
            return false;
         } else if (this.a.h(var1) > 16.0D) {
            return false;
         } else {
            return var1.by != null;
         }
      }
   }

   public void c() {
      this.a.x().p();
   }

   public void d() {
      this.a.a_((aeb)null);
   }
}
