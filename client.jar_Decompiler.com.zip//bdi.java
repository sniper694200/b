public class bdi extends bdo {
   private anf[] c;
   private final anf[] d;
   private final anf[] e;
   private final anf[] f;
   private final ayv g;

   public bdi(long var1, bdo var3, amx var4, ayv var5) {
      super(var1);
      this.c = new anf[]{ank.d, ank.d, ank.d, ank.K, ank.K, ank.c};
      this.d = new anf[]{ank.f, ank.E, ank.e, ank.c, ank.C, ank.h};
      this.e = new anf[]{ank.f, ank.e, ank.g, ank.c};
      this.f = new anf[]{ank.n, ank.n, ank.n, ank.F};
      this.a = var3;
      if (var4 == amx.h) {
         this.c = new anf[]{ank.d, ank.f, ank.e, ank.h, ank.c, ank.g};
         this.g = null;
      } else {
         this.g = var5;
      }

   }

   public int[] a(int var1, int var2, int var3, int var4) {
      int[] var5 = this.a.a(var1, var2, var3, var4);
      int[] var6 = bdm.a(var3 * var4);

      for(int var7 = 0; var7 < var4; ++var7) {
         for(int var8 = 0; var8 < var3; ++var8) {
            this.a((long)(var8 + var1), (long)(var7 + var2));
            int var9 = var5[var8 + var7 * var3];
            int var10 = (var9 & 3840) >> 8;
            var9 &= -3841;
            if (this.g != null && this.g.G >= 0) {
               var6[var8 + var7 * var3] = this.g.G;
            } else if (b(var9)) {
               var6[var8 + var7 * var3] = var9;
            } else if (var9 == anf.a(ank.p)) {
               var6[var8 + var7 * var3] = var9;
            } else if (var9 == 1) {
               if (var10 > 0) {
                  if (this.a(3) == 0) {
                     var6[var8 + var7 * var3] = anf.a(ank.O);
                  } else {
                     var6[var8 + var7 * var3] = anf.a(ank.N);
                  }
               } else {
                  var6[var8 + var7 * var3] = anf.a(this.c[this.a(this.c.length)]);
               }
            } else if (var9 == 2) {
               if (var10 > 0) {
                  var6[var8 + var7 * var3] = anf.a(ank.w);
               } else {
                  var6[var8 + var7 * var3] = anf.a(this.d[this.a(this.d.length)]);
               }
            } else if (var9 == 3) {
               if (var10 > 0) {
                  var6[var8 + var7 * var3] = anf.a(ank.H);
               } else {
                  var6[var8 + var7 * var3] = anf.a(this.e[this.a(this.e.length)]);
               }
            } else if (var9 == 4) {
               var6[var8 + var7 * var3] = anf.a(this.f[this.a(this.f.length)]);
            } else {
               var6[var8 + var7 * var3] = anf.a(ank.p);
            }
         }
      }

      return var6;
   }
}
