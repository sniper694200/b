import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class boi extends bli {
   private static final Logger g = LogManager.getLogger();
   protected bli a;
   protected String f = "Select world";
   private String h;
   private biy i;
   private biy s;
   private biy t;
   private biy u;
   private bok v;

   public boi(bli var1) {
      this.a = var1;
   }

   public void b() {
      this.f = cew.a("selectWorld.title");
      this.v = new bok(this, this.j, this.l, this.m, 32, this.m - 64, 36);
      this.a();
   }

   public void k() {
      super.k();
      this.v.p();
   }

   public void a() {
      this.s = this.b(new biy(1, this.l / 2 - 154, this.m - 52, 150, 20, cew.a("selectWorld.select")));
      this.b(new biy(3, this.l / 2 + 4, this.m - 52, 150, 20, cew.a("selectWorld.create")));
      this.t = this.b(new biy(4, this.l / 2 - 154, this.m - 28, 72, 20, cew.a("selectWorld.edit")));
      this.i = this.b(new biy(2, this.l / 2 - 76, this.m - 28, 72, 20, cew.a("selectWorld.delete")));
      this.u = this.b(new biy(5, this.l / 2 + 4, this.m - 28, 72, 20, cew.a("selectWorld.recreate")));
      this.b(new biy(0, this.l / 2 + 82, this.m - 28, 72, 20, cew.a("gui.cancel")));
      this.s.l = false;
      this.i.l = false;
      this.t.l = false;
      this.u.l = false;
   }

   protected void a(biy var1) {
      if (var1.l) {
         boj var2 = this.v.f();
         if (var1.k == 2) {
            if (var2 != null) {
               var2.b();
            }
         } else if (var1.k == 1) {
            if (var2 != null) {
               var2.a();
            }
         } else if (var1.k == 3) {
            this.j.a((bli)(new bog(this)));
         } else if (var1.k == 4) {
            if (var2 != null) {
               var2.c();
            }
         } else if (var1.k == 0) {
            this.j.a(this.a);
         } else if (var1.k == 5 && var2 != null) {
            var2.d();
         }

      }
   }

   public void a(int var1, int var2, float var3) {
      this.h = null;
      this.v.a(var1, var2, var3);
      this.a(this.q, this.f, this.l / 2, 20, 16777215);
      super.a(var1, var2, var3);
      if (this.h != null) {
         this.a(Lists.newArrayList(Splitter.on("\n").split(this.h)), var1, var2);
      }

   }

   protected void a(int var1, int var2, int var3) {
      super.a(var1, var2, var3);
      this.v.a(var1, var2, var3);
   }

   protected void b(int var1, int var2, int var3) {
      super.b(var1, var2, var3);
      this.v.b(var1, var2, var3);
   }

   public void a(String var1) {
      this.h = var1;
   }

   public void a(@Nullable boj var1) {
      boolean var2 = var1 != null;
      this.s.l = var2;
      this.i.l = var2;
      this.t.l = var2;
      this.u.l = var2;
   }
}
