import javax.annotation.Nullable;

public interface bfi {
   void a(aeb var1);

   @Nullable
   fy b(aeb var1);

   String[] f();
}
