public class aju extends agv {
   public aef a(ams var1, ain var2, vn var3) {
      return new aes(var1, var3);
   }
}
