import com.mojang.authlib.GameProfile;
import java.io.IOException;
import java.util.UUID;

public class mg implements ht<mf> {
   private GameProfile a;

   public mg() {
   }

   public mg(GameProfile var1) {
      this.a = var1;
   }

   public void a(gy var1) throws IOException {
      String var2 = var1.e(36);
      String var3 = var1.e(16);
      UUID var4 = UUID.fromString(var2);
      this.a = new GameProfile(var4, var3);
   }

   public void b(gy var1) throws IOException {
      UUID var2 = this.a.getId();
      var1.a(var2 == null ? "" : var2.toString());
      var1.a(this.a.getName());
   }

   public void a(mf var1) {
      var1.a(this);
   }

   public GameProfile a() {
      return this.a;
   }
}
