import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.mojang.authlib.GameProfile;
import io.netty.buffer.Unpooled;
import java.io.File;
import java.net.SocketAddress;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public abstract class pj {
   public static final File a = new File("banned-players.json");
   public static final File b = new File("banned-ips.json");
   public static final File c = new File("ops.json");
   public static final File d = new File("whitelist.json");
   private static final Logger f = LogManager.getLogger();
   private static final SimpleDateFormat g = new SimpleDateFormat("yyyy-MM-dd 'at' HH:mm:ss z");
   private final MinecraftServer h;
   private final List<oo> i = Lists.newArrayList();
   private final Map<UUID, oo> j = Maps.newHashMap();
   private final po k;
   private final pg l;
   private final pk m;
   private final pq n;
   private final Map<UUID, ql> o;
   private final Map<UUID, nn> p;
   private bfi q;
   private boolean r;
   protected int e;
   private int s;
   private amq t;
   private boolean u;
   private int v;

   public pj(MinecraftServer var1) {
      this.k = new po(a);
      this.l = new pg(b);
      this.m = new pk(c);
      this.n = new pq(d);
      this.o = Maps.newHashMap();
      this.p = Maps.newHashMap();
      this.h = var1;
      this.k.a(false);
      this.l.a(false);
      this.e = 8;
   }

   public void a(gw var1, oo var2) {
      GameProfile var3 = var2.da();
      pf var4 = this.h.aB();
      GameProfile var5 = var4.a(var3.getId());
      String var6 = var5 == null ? var3.getName() : var5.getName();
      var4.a(var3);
      fy var7 = this.a(var2);
      var2.a((ams)this.h.a(var2.am));
      var2.c.a((om)var2.l);
      String var8 = "local";
      if (var1.b() != null) {
         var8 = var1.b().toString();
      }

      f.info("{}[{}] logged in with entity id {} at ({}, {}, {})", var2.h_(), var8, var2.S(), var2.p, var2.q, var2.r);
      om var9 = this.h.a(var2.am);
      bfb var10 = var9.V();
      this.a(var2, (oo)null, var9);
      oy var11 = new oy(this.h, var1, var2);
      var11.a((ht)(new jh(var2.S(), var2.c.b(), var10.s(), var9.s.q().a(), var9.ag(), this.p(), var10.t(), var9.W().b("reducedDebugInfo"))));
      var11.a((ht)(new iw("MC|Brand", (new gy(Unpooled.buffer())).a(this.c().getServerModName()))));
      var11.a((ht)(new il(var10.x(), var10.y())));
      var11.a((ht)(new jm(var2.bO)));
      var11.a((ht)(new ka(var2.bv.d)));
      this.f(var2);
      var2.E().c();
      var2.F().a(var2);
      this.a((nt)var9.af(), var2);
      this.h.aD();
      hp var12;
      if (var2.h_().equalsIgnoreCase(var6)) {
         var12 = new hp("multiplayer.player.joined", new Object[]{var2.i_()});
      } else {
         var12 = new hp("multiplayer.player.joined.renamed", new Object[]{var2.i_(), var6});
      }

      var12.b().a(a.o);
      this.a((hh)var12);
      this.c(var2);
      var11.a(var2.p, var2.q, var2.r, var2.v, var2.w);
      this.b(var2, var9);
      if (!this.h.X().isEmpty()) {
         var2.a(this.h.X(), this.h.Y());
      }

      Iterator var13 = var2.ca().iterator();

      while(var13.hasNext()) {
         uy var14 = (uy)var13.next();
         var11.a((ht)(new kv(var2.S(), var14)));
      }

      if (var7 != null && var7.b("RootVehicle", 10)) {
         fy var18 = var7.p("RootVehicle");
         ve var19 = ayc.a(var18.p("Entity"), var9, true);
         if (var19 != null) {
            UUID var15 = var18.a("Attach");
            Iterator var16;
            ve var17;
            if (var19.bm().equals(var15)) {
               var2.a(var19, true);
            } else {
               var16 = var19.bG().iterator();

               while(var16.hasNext()) {
                  var17 = (ve)var16.next();
                  if (var17.bm().equals(var15)) {
                     var2.a(var17, true);
                     break;
                  }
               }
            }

            if (!var2.aS()) {
               f.warn("Couldn't reattach entity to player");
               var9.f(var19);
               var16 = var19.bG().iterator();

               while(var16.hasNext()) {
                  var17 = (ve)var16.next();
                  var9.f(var17);
               }
            }
         }
      }

      var2.j_();
   }

   protected void a(nt var1, oo var2) {
      Set<bhe> var3 = Sets.newHashSet();
      Iterator var4 = var1.g().iterator();

      while(var4.hasNext()) {
         bhf var5 = (bhf)var4.next();
         var2.a.a((ht)(new kk(var5, 0)));
      }

      for(int var9 = 0; var9 < 19; ++var9) {
         bhe var10 = var1.a(var9);
         if (var10 != null && !var3.contains(var10)) {
            List<ht<?>> var6 = var1.d(var10);
            Iterator var7 = var6.iterator();

            while(var7.hasNext()) {
               ht<?> var8 = (ht)var7.next();
               var2.a.a(var8);
            }

            var3.add(var10);
         }
      }

   }

   public void a(om[] var1) {
      this.q = var1[0].U().e();
      var1[0].al().a(new axj() {
         public void a(axl var1, double var2) {
            pj.this.a((ht)(new jy(var1, jy.a.a)));
         }

         public void a(axl var1, double var2, double var4, long var6) {
            pj.this.a((ht)(new jy(var1, jy.a.b)));
         }

         public void a(axl var1, double var2, double var4) {
            pj.this.a((ht)(new jy(var1, jy.a.c)));
         }

         public void a(axl var1, int var2) {
            pj.this.a((ht)(new jy(var1, jy.a.e)));
         }

         public void b(axl var1, int var2) {
            pj.this.a((ht)(new jy(var1, jy.a.f)));
         }

         public void b(axl var1, double var2) {
         }

         public void c(axl var1, double var2) {
         }
      });
   }

   public void a(oo var1, @Nullable om var2) {
      om var3 = var1.x();
      if (var2 != null) {
         var2.w().b(var1);
      }

      var3.w().a(var1);
      var3.r().c((int)var1.p >> 4, (int)var1.r >> 4);
      if (var2 != null) {
         m.u.a(var1, var2.s.q(), var3.s.q());
         if (var2.s.q() == ayl.b && var1.l.s.q() == ayl.a && var1.Q() != null) {
            m.B.a(var1, var1.Q());
         }
      }

   }

   public int d() {
      return os.b(this.s());
   }

   @Nullable
   public fy a(oo var1) {
      fy var2 = this.h.d[0].V().h();
      fy var3;
      if (var1.h_().equals(this.h.Q()) && var2 != null) {
         var3 = var2;
         var1.f(var2);
         f.debug("loading single player");
      } else {
         var3 = this.q.b(var1);
      }

      return var3;
   }

   protected void b(oo var1) {
      this.q.a(var1);
      ql var2 = (ql)this.o.get(var1.bm());
      if (var2 != null) {
         var2.b();
      }

      nn var3 = (nn)this.p.get(var1.bm());
      if (var3 != null) {
         var3.c();
      }

   }

   public void c(oo var1) {
      this.i.add(var1);
      this.j.put(var1.bm(), var1);
      this.a((ht)(new jo(jo.a.a, new oo[]{var1})));
      om var2 = this.h.a(var1.am);

      for(int var3 = 0; var3 < this.i.size(); ++var3) {
         var1.a.a((ht)(new jo(jo.a.a, new oo[]{(oo)this.i.get(var3)})));
      }

      var2.a((ve)var1);
      this.a((oo)var1, (om)null);
   }

   public void d(oo var1) {
      var1.x().w().c(var1);
   }

   public void e(oo var1) {
      om var2 = var1.x();
      var1.b((qm)qq.f);
      this.b(var1);
      if (var1.aS()) {
         ve var3 = var1.bH();
         if (var3.b(oo.class).size() == 1) {
            f.debug("Removing player mount");
            var1.o();
            var2.f(var3);
            Iterator var4 = var3.bG().iterator();

            while(var4.hasNext()) {
               ve var5 = (ve)var4.next();
               var2.f(var5);
            }

            var2.a(var1.ab, var1.ad).e();
         }
      }

      var2.e(var1);
      var2.w().b(var1);
      var1.P().a();
      this.i.remove(var1);
      UUID var6 = var1.bm();
      oo var7 = (oo)this.j.get(var6);
      if (var7 == var1) {
         this.j.remove(var6);
         this.o.remove(var6);
         this.p.remove(var6);
      }

      this.a((ht)(new jo(jo.a.e, new oo[]{var1})));
   }

   public String a(SocketAddress var1, GameProfile var2) {
      String var4;
      if (this.k.a(var2)) {
         pp var5 = (pp)this.k.b(var2);
         var4 = "You are banned from this server!\nReason: " + var5.d();
         if (var5.c() != null) {
            var4 = var4 + "\nYour ban will be removed on " + g.format(var5.c());
         }

         return var4;
      } else if (!this.e(var2)) {
         return "You are not white-listed on this server!";
      } else if (this.l.a(var1)) {
         ph var3 = this.l.b(var1);
         var4 = "Your IP address is banned from this server!\nReason: " + var3.d();
         if (var3.c() != null) {
            var4 = var4 + "\nYour ban will be removed on " + g.format(var3.c());
         }

         return var4;
      } else {
         return this.i.size() >= this.e && !this.f(var2) ? "The server is full!" : null;
      }
   }

   public oo g(GameProfile var1) {
      UUID var2 = aeb.a(var1);
      List<oo> var3 = Lists.newArrayList();

      for(int var4 = 0; var4 < this.i.size(); ++var4) {
         oo var5 = (oo)this.i.get(var4);
         if (var5.bm().equals(var2)) {
            var3.add(var5);
         }
      }

      oo var7 = (oo)this.j.get(var1.getId());
      if (var7 != null && !var3.contains(var7)) {
         var3.add(var7);
      }

      Iterator var8 = var3.iterator();

      while(var8.hasNext()) {
         oo var6 = (oo)var8.next();
         var6.a.b((hh)(new hp("multiplayer.disconnect.duplicate_login", new Object[0])));
      }

      Object var9;
      if (this.h.V()) {
         var9 = new oh(this.h.a(0));
      } else {
         var9 = new op(this.h.a(0));
      }

      return new oo(this.h, this.h.a(0), var1, (op)var9);
   }

   public oo a(oo var1, int var2, boolean var3) {
      var1.x().v().b(var1);
      var1.x().v().b((ve)var1);
      var1.x().w().b(var1);
      this.i.remove(var1);
      this.h.a(var1.am).f(var1);
      et var4 = var1.de();
      boolean var5 = var1.df();
      var1.am = var2;
      Object var6;
      if (this.h.V()) {
         var6 = new oh(this.h.a(var1.am));
      } else {
         var6 = new op(this.h.a(var1.am));
      }

      oo var7 = new oo(this.h, this.h.a(var1.am), var1.da(), (op)var6);
      var7.a = var1.a;
      var7.a(var1, var3);
      var7.h(var1.S());
      var7.v(var1);
      var7.a((vm)var1.cF());
      Iterator var8 = var1.T().iterator();

      while(var8.hasNext()) {
         String var9 = (String)var8.next();
         var7.a((String)var9);
      }

      om var10 = this.h.a(var1.am);
      this.a(var7, var1, var10);
      et var11;
      if (var4 != null) {
         var11 = aeb.a(this.h.a(var1.am), var4, var5);
         if (var11 != null) {
            var7.b((double)((float)var11.p() + 0.5F), (double)((float)var11.q() + 0.1F), (double)((float)var11.r() + 0.5F), 0.0F, 0.0F);
            var7.b(var4, var5);
         } else {
            var7.a.a((ht)(new jc(0, 0.0F)));
         }
      }

      var10.r().c((int)var7.p >> 4, (int)var7.r >> 4);

      while(!var10.a((ve)var7, (bgz)var7.bw()).isEmpty() && var7.q < 256.0D) {
         var7.b(var7.p, var7.q + 1.0D, var7.r);
      }

      var7.a.a((ht)(new jv(var7.am, var7.l.ag(), var7.l.V().t(), var7.c.b())));
      var11 = var10.T();
      var7.a.a(var7.p, var7.q, var7.r, var7.v, var7.w);
      var7.a.a((ht)(new km(var11)));
      var7.a.a((ht)(new kg(var7.bR, var7.bQ, var7.bP)));
      this.b(var7, var10);
      this.f(var7);
      var10.w().a(var7);
      var10.a((ve)var7);
      this.i.add(var7);
      this.j.put(var7.bm(), var7);
      var7.j_();
      var7.c(var7.cd());
      return var7;
   }

   public void f(oo var1) {
      GameProfile var2 = var1.da();
      int var3 = this.h(var2) ? this.m.a(var2) : 0;
      var3 = this.h.R() && this.h.d[0].V().u() ? 4 : var3;
      var3 = this.u ? 4 : var3;
      this.b(var1, var3);
   }

   public void a(oo var1, int var2) {
      int var3 = var1.am;
      om var4 = this.h.a(var1.am);
      var1.am = var2;
      om var5 = this.h.a(var1.am);
      var1.a.a((ht)(new jv(var1.am, var1.l.ag(), var1.l.V().t(), var1.c.b())));
      this.f(var1);
      var4.f(var1);
      var1.F = false;
      this.a(var1, var3, var4, var5);
      this.a(var1, var4);
      var1.a.a(var1.p, var1.q, var1.r, var1.v, var1.w);
      var1.c.a(var5);
      var1.a.a((ht)(new jm(var1.bO)));
      this.b(var1, var5);
      this.g(var1);
      Iterator var6 = var1.ca().iterator();

      while(var6.hasNext()) {
         uy var7 = (uy)var6.next();
         var1.a.a((ht)(new kv(var1.S(), var7)));
      }

   }

   public void a(ve var1, int var2, om var3, om var4) {
      double var5 = var1.p;
      double var7 = var1.r;
      double var9 = 8.0D;
      float var11 = var1.v;
      var3.E.a("moving");
      if (var1.am == -1) {
         var5 = ri.a(var5 / 8.0D, var4.al().b() + 16.0D, var4.al().d() - 16.0D);
         var7 = ri.a(var7 / 8.0D, var4.al().c() + 16.0D, var4.al().e() - 16.0D);
         var1.b(var5, var1.q, var7, var1.v, var1.w);
         if (var1.aC()) {
            var3.a(var1, false);
         }
      } else if (var1.am == 0) {
         var5 = ri.a(var5 * 8.0D, var4.al().b() + 16.0D, var4.al().d() - 16.0D);
         var7 = ri.a(var7 * 8.0D, var4.al().c() + 16.0D, var4.al().e() - 16.0D);
         var1.b(var5, var1.q, var7, var1.v, var1.w);
         if (var1.aC()) {
            var3.a(var1, false);
         }
      } else {
         et var12;
         if (var2 == 1) {
            var12 = var4.T();
         } else {
            var12 = var4.p();
         }

         var5 = (double)var12.p();
         var1.q = (double)var12.q();
         var7 = (double)var12.r();
         var1.b(var5, var1.q, var7, 90.0F, 0.0F);
         if (var1.aC()) {
            var3.a(var1, false);
         }
      }

      var3.E.b();
      if (var2 != 1) {
         var3.E.a("placing");
         var5 = (double)ri.a((int)var5, -29999872, 29999872);
         var7 = (double)ri.a((int)var7, -29999872, 29999872);
         if (var1.aC()) {
            var1.b(var5, var1.q, var7, var1.v, var1.w);
            var4.x().a(var1, var11);
            var4.a(var1);
            var4.a(var1, false);
         }

         var3.E.b();
      }

      var1.a((ams)var4);
   }

   public void e() {
      if (++this.v > 600) {
         this.a((ht)(new jo(jo.a.c, this.i)));
         this.v = 0;
      }

   }

   public void a(ht<?> var1) {
      for(int var2 = 0; var2 < this.i.size(); ++var2) {
         ((oo)this.i.get(var2)).a.a(var1);
      }

   }

   public void a(ht<?> var1, int var2) {
      for(int var3 = 0; var3 < this.i.size(); ++var3) {
         oo var4 = (oo)this.i.get(var3);
         if (var4.am == var2) {
            var4.a.a(var1);
         }
      }

   }

   public void a(aeb var1, hh var2) {
      bhk var3 = var1.aY();
      if (var3 != null) {
         Collection<String> var4 = var3.d();
         Iterator var5 = var4.iterator();

         while(var5.hasNext()) {
            String var6 = (String)var5.next();
            oo var7 = this.a(var6);
            if (var7 != null && var7 != var1) {
               var7.a(var2);
            }
         }

      }
   }

   public void b(aeb var1, hh var2) {
      bhk var3 = var1.aY();
      if (var3 == null) {
         this.a(var2);
      } else {
         for(int var4 = 0; var4 < this.i.size(); ++var4) {
            oo var5 = (oo)this.i.get(var4);
            if (var5.aY() != var3) {
               var5.a(var2);
            }
         }

      }
   }

   public String b(boolean var1) {
      String var2 = "";
      List<oo> var3 = Lists.newArrayList(this.i);

      for(int var4 = 0; var4 < var3.size(); ++var4) {
         if (var4 > 0) {
            var2 = var2 + ", ";
         }

         var2 = var2 + ((oo)var3.get(var4)).h_();
         if (var1) {
            var2 = var2 + " (" + ((oo)var3.get(var4)).bn() + ")";
         }
      }

      return var2;
   }

   public String[] f() {
      String[] var1 = new String[this.i.size()];

      for(int var2 = 0; var2 < this.i.size(); ++var2) {
         var1[var2] = ((oo)this.i.get(var2)).h_();
      }

      return var1;
   }

   public GameProfile[] g() {
      GameProfile[] var1 = new GameProfile[this.i.size()];

      for(int var2 = 0; var2 < this.i.size(); ++var2) {
         var1[var2] = ((oo)this.i.get(var2)).da();
      }

      return var1;
   }

   public po h() {
      return this.k;
   }

   public pg i() {
      return this.l;
   }

   public void a(GameProfile var1) {
      int var2 = this.h.q();
      this.m.a((pm)(new pl(var1, this.h.q(), this.m.b(var1))));
      this.b(this.a(var1.getId()), var2);
   }

   public void b(GameProfile var1) {
      this.m.c(var1);
      this.b(this.a(var1.getId()), 0);
   }

   private void b(oo var1, int var2) {
      if (var1 != null && var1.a != null) {
         byte var3;
         if (var2 <= 0) {
            var3 = 24;
         } else if (var2 >= 4) {
            var3 = 28;
         } else {
            var3 = (byte)(24 + var2);
         }

         var1.a.a((ht)(new iz(var1, var3)));
      }

   }

   public boolean e(GameProfile var1) {
      return !this.r || this.m.d(var1) || this.n.d(var1);
   }

   public boolean h(GameProfile var1) {
      return this.m.d(var1) || this.h.R() && this.h.d[0].V().u() && this.h.Q().equalsIgnoreCase(var1.getName()) || this.u;
   }

   @Nullable
   public oo a(String var1) {
      Iterator var2 = this.i.iterator();

      oo var3;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         var3 = (oo)var2.next();
      } while(!var3.h_().equalsIgnoreCase(var1));

      return var3;
   }

   public void a(@Nullable aeb var1, double var2, double var4, double var6, double var8, int var10, ht<?> var11) {
      for(int var12 = 0; var12 < this.i.size(); ++var12) {
         oo var13 = (oo)this.i.get(var12);
         if (var13 != var1 && var13.am == var10) {
            double var14 = var2 - var13.p;
            double var16 = var4 - var13.q;
            double var18 = var6 - var13.r;
            if (var14 * var14 + var16 * var16 + var18 * var18 < var8 * var8) {
               var13.a.a(var11);
            }
         }
      }

   }

   public void j() {
      for(int var1 = 0; var1 < this.i.size(); ++var1) {
         this.b((oo)this.i.get(var1));
      }

   }

   public void d(GameProfile var1) {
      this.n.a((pm)(new pr(var1)));
   }

   public void c(GameProfile var1) {
      this.n.c(var1);
   }

   public pq k() {
      return this.n;
   }

   public String[] l() {
      return this.n.a();
   }

   public pk m() {
      return this.m;
   }

   public String[] n() {
      return this.m.a();
   }

   public void a() {
   }

   public void b(oo var1, om var2) {
      axl var3 = this.h.d[0].al();
      var1.a.a((ht)(new jy(var3, jy.a.d)));
      var1.a.a((ht)(new kn(var2.R(), var2.S(), var2.W().b("doDaylightCycle"))));
      et var4 = var2.T();
      var1.a.a((ht)(new km(var4)));
      if (var2.Y()) {
         var1.a.a((ht)(new jc(1, 0.0F)));
         var1.a.a((ht)(new jc(7, var2.j(1.0F))));
         var1.a.a((ht)(new jc(8, var2.h(1.0F))));
      }

   }

   public void g(oo var1) {
      var1.a(var1.bx);
      var1.u();
      var1.a.a((ht)(new ka(var1.bv.d)));
   }

   public int o() {
      return this.i.size();
   }

   public int p() {
      return this.e;
   }

   public String[] q() {
      return this.h.d[0].U().e().f();
   }

   public void a(boolean var1) {
      this.r = var1;
   }

   public List<oo> b(String var1) {
      List<oo> var2 = Lists.newArrayList();
      Iterator var3 = this.i.iterator();

      while(var3.hasNext()) {
         oo var4 = (oo)var3.next();
         if (var4.A().equals(var1)) {
            var2.add(var4);
         }
      }

      return var2;
   }

   public int s() {
      return this.s;
   }

   public MinecraftServer c() {
      return this.h;
   }

   public fy t() {
      return null;
   }

   public void a(amq var1) {
      this.t = var1;
   }

   private void a(oo var1, oo var2, ams var3) {
      if (var2 != null) {
         var1.c.a(var2.c.b());
      } else if (this.t != null) {
         var1.c.a(this.t);
      }

      var1.c.b(var3.V().q());
   }

   public void c(boolean var1) {
      this.u = var1;
   }

   public void u() {
      for(int var1 = 0; var1 < this.i.size(); ++var1) {
         ((oo)this.i.get(var1)).a.b((hh)(new hp("multiplayer.disconnect.server_shutdown", new Object[0])));
      }

   }

   public void a(hh var1, boolean var2) {
      this.h.a(var1);
      hf var3 = var2 ? hf.b : hf.a;
      this.a((ht)(new in(var1, var3)));
   }

   public void a(hh var1) {
      this.a(var1, true);
   }

   public ql a(aeb var1) {
      UUID var2 = var1.bm();
      ql var3 = var2 == null ? null : (ql)this.o.get(var2);
      if (var3 == null) {
         File var4 = new File(this.h.a(0).U().b(), "stats");
         File var5 = new File(var4, var2 + ".json");
         if (!var5.exists()) {
            File var6 = new File(var4, var1.h_() + ".json");
            if (var6.exists() && var6.isFile()) {
               var6.renameTo(var5);
            }
         }

         var3 = new ql(this.h, var5);
         var3.a();
         this.o.put(var2, var3);
      }

      return var3;
   }

   public nn h(oo var1) {
      UUID var2 = var1.bm();
      nn var3 = (nn)this.p.get(var2);
      if (var3 == null) {
         File var4 = new File(this.h.a(0).U().b(), "advancements");
         File var5 = new File(var4, var2 + ".json");
         var3 = new nn(this.h, var5, var1);
         this.p.put(var2, var3);
      }

      var3.a(var1);
      return var3;
   }

   public void a(int var1) {
      this.s = var1;
      if (this.h.d != null) {
         om[] var2 = this.h.d;
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            om var5 = var2[var4];
            if (var5 != null) {
               var5.w().a(var1);
               var5.v().a(var1);
            }
         }

      }
   }

   public List<oo> v() {
      return this.i;
   }

   public oo a(UUID var1) {
      return (oo)this.j.get(var1);
   }

   public boolean f(GameProfile var1) {
      return false;
   }

   public void w() {
      Iterator var1 = this.p.values().iterator();

      while(var1.hasNext()) {
         nn var2 = (nn)var1.next();
         var2.b();
      }

   }
}
