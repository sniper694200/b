import java.util.Random;

public class aqa extends aou {
   protected static final bgz a = new bgz(0.0625D, 0.0D, 0.0625D, 0.9375D, 1.0D, 0.9375D);

   public aqa() {
      super(bcx.D, bcy.F);
   }

   public bgz b(awr var1, amw var2, et var3) {
      return a;
   }

   public void c(ams var1, et var2, awr var3) {
      var1.a((et)var2, (aou)this, this.a(var1));
   }

   public void a(awr var1, ams var2, et var3, aou var4, et var5) {
      var2.a((et)var3, (aou)this, this.a(var2));
   }

   public void b(ams var1, et var2, awr var3, Random var4) {
      this.b(var1, var2);
   }

   private void b(ams var1, et var2) {
      if (aqk.x(var1.o(var2.b())) && var2.q() >= 0) {
         int var3 = true;
         if (!aqk.f && var1.a(var2.a(-32, -32, -32), var2.a(32, 32, 32))) {
            var1.a((ve)(new aci(var1, (double)((float)var2.p() + 0.5F), (double)var2.q(), (double)((float)var2.r() + 0.5F), this.t())));
         } else {
            var1.g(var2);

            et var4;
            for(var4 = var2; aqk.x(var1.o(var4)) && var4.q() > 0; var4 = var4.b()) {
            }

            if (var4.q() > 0) {
               var1.a((et)var4, (awr)this.t(), 2);
            }
         }

      }
   }

   public boolean a(ams var1, et var2, awr var3, aeb var4, tz var5, fa var6, float var7, float var8, float var9) {
      this.c(var1, var2);
      return true;
   }

   public void a(ams var1, et var2, aeb var3) {
      this.c(var1, var2);
   }

   private void c(ams var1, et var2) {
      awr var3 = var1.o(var2);
      if (var3.u() == this) {
         for(int var4 = 0; var4 < 1000; ++var4) {
            et var5 = var2.a(var1.r.nextInt(16) - var1.r.nextInt(16), var1.r.nextInt(8) - var1.r.nextInt(8), var1.r.nextInt(16) - var1.r.nextInt(16));
            if (var1.o(var5).u().x == bcx.a) {
               if (var1.G) {
                  for(int var6 = 0; var6 < 128; ++var6) {
                     double var7 = var1.r.nextDouble();
                     float var9 = (var1.r.nextFloat() - 0.5F) * 0.2F;
                     float var10 = (var1.r.nextFloat() - 0.5F) * 0.2F;
                     float var11 = (var1.r.nextFloat() - 0.5F) * 0.2F;
                     double var12 = (double)var5.p() + (double)(var2.p() - var5.p()) * var7 + (var1.r.nextDouble() - 0.5D) + 0.5D;
                     double var14 = (double)var5.q() + (double)(var2.q() - var5.q()) * var7 + var1.r.nextDouble() - 0.5D;
                     double var16 = (double)var5.r() + (double)(var2.r() - var5.r()) * var7 + (var1.r.nextDouble() - 0.5D) + 0.5D;
                     var1.a(fj.y, var12, var14, var16, (double)var9, (double)var10, (double)var11);
                  }
               } else {
                  var1.a((et)var5, (awr)var3, 2);
                  var1.g(var2);
               }

               return;
            }
         }

      }
   }

   public int a(ams var1) {
      return 5;
   }

   public boolean b(awr var1) {
      return false;
   }

   public boolean c(awr var1) {
      return false;
   }

   public boolean a(awr var1, amw var2, et var3, fa var4) {
      return true;
   }

   public awp a(amw var1, awr var2, et var3, fa var4) {
      return awp.i;
   }
}
