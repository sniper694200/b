public class aew extends aet {
   public aew(ams var1) {
      super(var1);
   }

   public aew(ams var1, vn var2) {
      super(var1, var2);
   }

   public aew(ams var1, double var2, double var4, double var6) {
      super(var1, var2, var4, var6);
   }

   public static void a(rw var0) {
      aet.a(var0, "ThrowableExpBottle");
   }

   protected float j() {
      return 0.07F;
   }

   protected void a(bha var1) {
      if (!this.l.G) {
         this.l.b(2002, new et(this), akg.a(akh.b));
         int var2 = 3 + this.l.r.nextInt(5) + this.l.r.nextInt(5);

         while(var2 > 0) {
            int var3 = vk.a(var2);
            var2 -= var3;
            this.l.a((ve)(new vk(this.l, this.p, this.q, this.r, var3)));
         }

         this.X();
      }

   }
}
