import java.util.Random;

public class aru extends aou {
   public aru() {
      super(bcx.e);
      this.a(ahn.b);
      this.a(0.2F);
      this.a(true);
   }

   public bcy c(awr var1, amw var2, et var3) {
      return bcy.L;
   }

   public void a(ams var1, et var2, ve var3) {
      if (!var3.am() && var3 instanceof vn && !alk.i((vn)var3)) {
         var3.a(up.e, 1.0F);
      }

      super.a(var1, var2, var3);
   }

   public int e(awr var1, amw var2, et var3) {
      return 15728880;
   }

   public void b(ams var1, et var2, awr var3, Random var4) {
      et var5 = var2.a();
      awr var6 = var1.o(var5);
      if (var6.u() == aov.j || var6.u() == aov.i) {
         var1.g(var5);
         var1.a((aeb)null, var2, qd.bN, qe.e, 0.5F, 2.6F + (var1.r.nextFloat() - var1.r.nextFloat()) * 0.8F);
         if (var1 instanceof om) {
            ((om)var1).a(fj.m, (double)var5.p() + 0.5D, (double)var5.q() + 0.25D, (double)var5.r() + 0.5D, 8, 0.5D, 0.25D, 0.5D, 0.0D);
         }
      }

   }

   public boolean a(awr var1, ve var2) {
      return var2.am();
   }
}
