import java.util.Collection;
import java.util.Iterator;
import java.util.UUID;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class adf {
   private static final Logger k = LogManager.getLogger();
   public static final wa a = (new wh((wa)null, "generic.maxHealth", 20.0D, 0.0D, 1024.0D)).a("Max Health").a(true);
   public static final wa b = (new wh((wa)null, "generic.followRange", 32.0D, 0.0D, 2048.0D)).a("Follow Range");
   public static final wa c = (new wh((wa)null, "generic.knockbackResistance", 0.0D, 0.0D, 1.0D)).a("Knockback Resistance");
   public static final wa d = (new wh((wa)null, "generic.movementSpeed", 0.699999988079071D, 0.0D, 1024.0D)).a("Movement Speed").a(true);
   public static final wa e = (new wh((wa)null, "generic.flyingSpeed", 0.4000000059604645D, 0.0D, 1024.0D)).a("Flying Speed").a(true);
   public static final wa f = new wh((wa)null, "generic.attackDamage", 2.0D, 0.0D, 2048.0D);
   public static final wa g = (new wh((wa)null, "generic.attackSpeed", 4.0D, 0.0D, 1024.0D)).a(true);
   public static final wa h = (new wh((wa)null, "generic.armor", 0.0D, 0.0D, 30.0D)).a(true);
   public static final wa i = (new wh((wa)null, "generic.armorToughness", 0.0D, 0.0D, 20.0D)).a(true);
   public static final wa j = (new wh((wa)null, "generic.luck", 0.0D, -1024.0D, 1024.0D)).a(true);

   public static ge a(we var0) {
      ge var1 = new ge();
      Iterator var2 = var0.a().iterator();

      while(var2.hasNext()) {
         wb var3 = (wb)var2.next();
         var1.a((gn)a(var3));
      }

      return var1;
   }

   private static fy a(wb var0) {
      fy var1 = new fy();
      wa var2 = var0.a();
      var1.a("Name", var2.a());
      var1.a("Base", var0.b());
      Collection<wc> var3 = var0.c();
      if (var3 != null && !var3.isEmpty()) {
         ge var4 = new ge();
         Iterator var5 = var3.iterator();

         while(var5.hasNext()) {
            wc var6 = (wc)var5.next();
            if (var6.e()) {
               var4.a((gn)a(var6));
            }
         }

         var1.a((String)"Modifiers", (gn)var4);
      }

      return var1;
   }

   public static fy a(wc var0) {
      fy var1 = new fy();
      var1.a("Name", var0.b());
      var1.a("Amount", var0.d());
      var1.a("Operation", var0.c());
      var1.a("UUID", var0.a());
      return var1;
   }

   public static void a(we var0, ge var1) {
      for(int var2 = 0; var2 < var1.c(); ++var2) {
         fy var3 = var1.b(var2);
         wb var4 = var0.a(var3.l("Name"));
         if (var4 == null) {
            k.warn("Ignoring unknown attribute '{}'", var3.l("Name"));
         } else {
            a(var4, var3);
         }
      }

   }

   private static void a(wb var0, fy var1) {
      var0.a(var1.k("Base"));
      if (var1.b("Modifiers", 9)) {
         ge var2 = var1.c("Modifiers", 10);

         for(int var3 = 0; var3 < var2.c(); ++var3) {
            wc var4 = a(var2.b(var3));
            if (var4 != null) {
               wc var5 = var0.a(var4.a());
               if (var5 != null) {
                  var0.c(var5);
               }

               var0.b(var4);
            }
         }
      }

   }

   @Nullable
   public static wc a(fy var0) {
      UUID var1 = var0.a("UUID");

      try {
         return new wc(var1, var0.l("Name"), var0.k("Amount"), var0.h("Operation"));
      } catch (Exception var3) {
         k.warn("Unable to create attribute: {}", var3.getMessage());
         return null;
      }
   }
}
