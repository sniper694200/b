import java.util.Random;

public class ask extends aou {
   public ask() {
      super(bcx.e);
      this.a(ahn.b);
   }

   public ail a(awr var1, Random var2, int var3) {
      return ail.a(aov.Z);
   }

   public bcy c(awr var1, amw var2, et var3) {
      return bcy.F;
   }
}
