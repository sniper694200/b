import com.google.common.collect.Lists;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import java.lang.reflect.Type;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class bfq {
   private static final Logger b = LogManager.getLogger();
   public static final bfq a = new bfq(new bfo[0]);
   private final bfo[] c;

   public bfq(bfo[] var1) {
      this.c = var1;
   }

   public List<ain> a(Random var1, bfr var2) {
      List<ain> var3 = Lists.newArrayList();
      if (var2.a(this)) {
         bfo[] var4 = this.c;
         int var5 = var4.length;

         for(int var6 = 0; var6 < var5; ++var6) {
            bfo var7 = var4[var6];
            var7.b(var3, var1, var2);
         }

         var2.b(this);
      } else {
         b.warn("Detected infinite loop in loot tables");
      }

      return var3;
   }

   public void a(tt var1, Random var2, bfr var3) {
      List<ain> var4 = this.a(var2, var3);
      List<Integer> var5 = this.a(var1, var2);
      this.a(var4, var5.size(), var2);
      Iterator var6 = var4.iterator();

      while(var6.hasNext()) {
         ain var7 = (ain)var6.next();
         if (var5.isEmpty()) {
            b.warn("Tried to over-fill a container");
            return;
         }

         if (var7.b()) {
            var1.a((Integer)var5.remove(var5.size() - 1), ain.a);
         } else {
            var1.a((Integer)var5.remove(var5.size() - 1), var7);
         }
      }

   }

   private void a(List<ain> var1, int var2, Random var3) {
      List<ain> var4 = Lists.newArrayList();
      Iterator var5 = var1.iterator();

      while(var5.hasNext()) {
         ain var6 = (ain)var5.next();
         if (var6.b()) {
            var5.remove();
         } else if (var6.E() > 1) {
            var4.add(var6);
            var5.remove();
         }
      }

      var2 -= var1.size();

      while(var2 > 0 && !var4.isEmpty()) {
         ain var8 = (ain)var4.remove(ri.a((Random)var3, 0, var4.size() - 1));
         int var9 = ri.a((Random)var3, 1, var8.E() / 2);
         ain var7 = var8.a(var9);
         if (var8.E() > 1 && var3.nextBoolean()) {
            var4.add(var8);
         } else {
            var1.add(var8);
         }

         if (var7.E() > 1 && var3.nextBoolean()) {
            var4.add(var7);
         } else {
            var1.add(var7);
         }
      }

      var1.addAll(var4);
      Collections.shuffle(var1, var3);
   }

   private List<Integer> a(tt var1, Random var2) {
      List<Integer> var3 = Lists.newArrayList();

      for(int var4 = 0; var4 < var1.w_(); ++var4) {
         if (var1.a(var4).b()) {
            var3.add(var4);
         }
      }

      Collections.shuffle(var3, var2);
      return var3;
   }

   public static class a implements JsonDeserializer<bfq>, JsonSerializer<bfq> {
      public bfq a(JsonElement var1, Type var2, JsonDeserializationContext var3) throws JsonParseException {
         JsonObject var4 = ra.m(var1, "loot table");
         bfo[] var5 = (bfo[])ra.a(var4, "pools", new bfo[0], var3, bfo[].class);
         return new bfq(var5);
      }

      public JsonElement a(bfq var1, Type var2, JsonSerializationContext var3) {
         JsonObject var4 = new JsonObject();
         var4.add("pools", var3.serialize(var1.c));
         return var4;
      }

      // $FF: synthetic method
      public JsonElement serialize(Object var1, Type var2, JsonSerializationContext var3) {
         return this.a((bfq)var1, var2, var3);
      }

      // $FF: synthetic method
      public Object deserialize(JsonElement var1, Type var2, JsonDeserializationContext var3) throws JsonParseException {
         return this.a(var1, var2, var3);
      }
   }
}
