import java.util.Iterator;

public class byf implements bye.a {
   private final bhz a;

   public byf(bhz var1) {
      this.a = var1;
   }

   public void a(float var1, long var2) {
      aeb var4 = this.a.h;
      ams var5 = this.a.f;
      double var6 = var4.M + (var4.p - var4.M) * (double)var1;
      double var8 = var4.N + (var4.q - var4.N) * (double)var1;
      double var10 = var4.O + (var4.r - var4.O) * (double)var1;
      buq.G();
      buq.m();
      buq.a(buq.r.l, buq.l.j, buq.r.e, buq.l.n);
      buq.z();
      et var12 = new et(var4.p, 0.0D, var4.r);
      Iterable<et> var13 = et.a(var12.a(-40, 0, -40), var12.a(40, 0, 40));
      bvc var14 = bvc.a();
      bui var15 = var14.c();
      var15.a(5, cdw.f);
      Iterator var16 = var13.iterator();

      while(var16.hasNext()) {
         et var17 = (et)var16.next();
         int var18 = var5.c(var17.p(), var17.r());
         if (var5.o(var17.a(0, var18, 0).b()) == aov.a.t()) {
            buw.b(var15, (double)((float)var17.p() + 0.25F) - var6, (double)var18 - var8, (double)((float)var17.r() + 0.25F) - var10, (double)((float)var17.p() + 0.75F) - var6, (double)var18 + 0.09375D - var8, (double)((float)var17.r() + 0.75F) - var10, 0.0F, 0.0F, 1.0F, 0.5F);
         } else {
            buw.b(var15, (double)((float)var17.p() + 0.25F) - var6, (double)var18 - var8, (double)((float)var17.r() + 0.25F) - var10, (double)((float)var17.p() + 0.75F) - var6, (double)var18 + 0.09375D - var8, (double)((float)var17.r() + 0.75F) - var10, 0.0F, 1.0F, 0.0F, 0.5F);
         }
      }

      var14.b();
      buq.y();
      buq.H();
   }
}
