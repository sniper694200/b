public class akp implements akr {
   public boolean a(afw var1, ams var2) {
      int var3 = 0;
      ain var4 = ain.a;

      for(int var5 = 0; var5 < var1.w_(); ++var5) {
         ain var6 = var1.a(var5);
         if (!var6.b()) {
            if (var6.c() == aip.bl) {
               if (!var4.b()) {
                  return false;
               }

               var4 = var6;
            } else {
               if (var6.c() != aip.cg) {
                  return false;
               }

               ++var3;
            }
         }
      }

      return !var4.b() && var3 > 0;
   }

   public ain a(afw var1) {
      int var2 = 0;
      ain var3 = ain.a;

      for(int var4 = 0; var4 < var1.w_(); ++var4) {
         ain var5 = var1.a(var4);
         if (!var5.b()) {
            if (var5.c() == aip.bl) {
               if (!var3.b()) {
                  return ain.a;
               }

               var3 = var5;
            } else {
               if (var5.c() != aip.cg) {
                  return ain.a;
               }

               ++var2;
            }
         }
      }

      if (!var3.b() && var2 >= 1) {
         ain var6 = new ain(aip.bl, var2 + 1, var3.j());
         if (var3.t()) {
            var6.g(var3.r());
         }

         if (var3.o()) {
            var6.b(var3.p());
         }

         return var6;
      } else {
         return ain.a;
      }
   }

   public ain b() {
      return ain.a;
   }

   public fi<ain> b(afw var1) {
      fi<ain> var2 = fi.a(var1.w_(), ain.a);

      for(int var3 = 0; var3 < var2.size(); ++var3) {
         ain var4 = var1.a(var3);
         if (var4.c().r()) {
            var2.set(var3, new ain(var4.c().q()));
         }
      }

      return var2;
   }

   public boolean c() {
      return true;
   }

   public boolean a(int var1, int var2) {
      return var1 >= 3 && var2 >= 3;
   }
}
