import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public abstract class ve implements bn {
   private static final Logger a = LogManager.getLogger();
   private static final List<ain> b = Collections.emptyList();
   private static final bgz c = new bgz(0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D);
   private static double f = 1.0D;
   private static int g;
   private int h;
   public boolean i;
   private final List<ve> at;
   protected int j;
   private ve au;
   public boolean k;
   public ams l;
   public double m;
   public double n;
   public double o;
   public double p;
   public double q;
   public double r;
   public double s;
   public double t;
   public double u;
   public float v;
   public float w;
   public float x;
   public float y;
   private bgz av;
   public boolean z;
   public boolean A;
   public boolean B;
   public boolean C;
   public boolean D;
   protected boolean E;
   private boolean aw;
   public boolean F;
   public float G;
   public float H;
   public float I;
   public float J;
   public float K;
   public float L;
   private int ax;
   private float ay;
   public double M;
   public double N;
   public double O;
   public float P;
   public boolean Q;
   public float R;
   protected Random S;
   public int T;
   private int az;
   protected boolean U;
   public int V;
   protected boolean W;
   protected boolean X;
   protected na Y;
   protected static final mx<Byte> Z;
   private static final mx<Integer> aA;
   private static final mx<String> aB;
   private static final mx<Boolean> aC;
   private static final mx<Boolean> aD;
   private static final mx<Boolean> aE;
   public boolean aa;
   public int ab;
   public int ac;
   public int ad;
   public long ae;
   public long af;
   public long ag;
   public boolean ah;
   public boolean ai;
   public int aj;
   protected boolean ak;
   protected int al;
   public int am;
   protected et an;
   protected bhc ao;
   protected fa ap;
   private boolean aF;
   protected UUID aq;
   protected String ar;
   private final bp aG;
   protected boolean as;
   private final Set<String> aH;
   private boolean aI;
   private final double[] aJ;
   private long aK;

   public ve(ams var1) {
      this.h = g++;
      this.at = Lists.newArrayList();
      this.av = c;
      this.G = 0.6F;
      this.H = 1.8F;
      this.ax = 1;
      this.ay = 1.0F;
      this.S = new Random();
      this.az = -this.bL();
      this.W = true;
      this.aq = ri.a(this.S);
      this.ar = this.aq.toString();
      this.aG = new bp();
      this.aH = Sets.newHashSet();
      this.aJ = new double[]{0.0D, 0.0D, 0.0D};
      this.l = var1;
      this.b(0.0D, 0.0D, 0.0D);
      if (var1 != null) {
         this.am = var1.s.q().a();
      }

      this.Y = new na(this);
      this.Y.a((mx)Z, (byte)0);
      this.Y.a((mx)aA, (int)300);
      this.Y.a((mx)aC, (Object)false);
      this.Y.a((mx)aB, (Object)"");
      this.Y.a((mx)aD, (Object)false);
      this.Y.a((mx)aE, (Object)false);
      this.i();
   }

   public int S() {
      return this.h;
   }

   public void h(int var1) {
      this.h = var1;
   }

   public Set<String> T() {
      return this.aH;
   }

   public boolean a(String var1) {
      if (this.aH.size() >= 1024) {
         return false;
      } else {
         this.aH.add(var1);
         return true;
      }
   }

   public boolean b(String var1) {
      return this.aH.remove(var1);
   }

   public void U() {
      this.X();
   }

   protected abstract void i();

   public na V() {
      return this.Y;
   }

   public boolean equals(Object var1) {
      if (var1 instanceof ve) {
         return ((ve)var1).h == this.h;
      } else {
         return false;
      }
   }

   public int hashCode() {
      return this.h;
   }

   protected void W() {
      if (this.l != null) {
         while(this.q > 0.0D && this.q < 256.0D) {
            this.b(this.p, this.q, this.r);
            if (this.l.a(this, this.bw()).isEmpty()) {
               break;
            }

            ++this.q;
         }

         this.s = 0.0D;
         this.t = 0.0D;
         this.u = 0.0D;
         this.w = 0.0F;
      }
   }

   public void X() {
      this.F = true;
   }

   public void b(boolean var1) {
   }

   protected void a(float var1, float var2) {
      if (var1 != this.G || var2 != this.H) {
         float var3 = this.G;
         this.G = var1;
         this.H = var2;
         if (this.G < var3) {
            double var6 = (double)var1 / 2.0D;
            this.a(new bgz(this.p - var6, this.q, this.r - var6, this.p + var6, this.q + (double)this.H, this.r + var6));
            return;
         }

         bgz var4 = this.bw();
         this.a(new bgz(var4.a, var4.b, var4.c, var4.a + (double)this.G, var4.b + (double)this.H, var4.c + (double)this.G));
         if (this.G > var3 && !this.W && !this.l.G) {
            this.a(vt.a, (double)(var3 - this.G), 0.0D, (double)(var3 - this.G));
         }
      }

   }

   protected void b(float var1, float var2) {
      this.v = var1 % 360.0F;
      this.w = var2 % 360.0F;
   }

   public void b(double var1, double var3, double var5) {
      this.p = var1;
      this.q = var3;
      this.r = var5;
      float var7 = this.G / 2.0F;
      float var8 = this.H;
      this.a(new bgz(var1 - (double)var7, var3, var5 - (double)var7, var1 + (double)var7, var3 + (double)var8, var5 + (double)var7));
   }

   public void c(float var1, float var2) {
      float var3 = this.w;
      float var4 = this.v;
      this.v = (float)((double)this.v + (double)var1 * 0.15D);
      this.w = (float)((double)this.w - (double)var2 * 0.15D);
      this.w = ri.a(this.w, -90.0F, 90.0F);
      this.y += this.w - var3;
      this.x += this.v - var4;
      if (this.au != null) {
         this.au.l(this);
      }

   }

   public void B_() {
      if (!this.l.G) {
         this.b(6, this.aW());
      }

      this.Y();
   }

   public void Y() {
      this.l.E.a("entityBaseTick");
      if (this.aS() && this.bJ().F) {
         this.o();
      }

      if (this.j > 0) {
         --this.j;
      }

      this.I = this.J;
      this.m = this.p;
      this.n = this.q;
      this.o = this.r;
      this.y = this.w;
      this.x = this.v;
      if (!this.l.G && this.l instanceof om) {
         this.l.E.a("portal");
         if (this.ak) {
            MinecraftServer var1 = this.l.u();
            if (var1.E()) {
               if (!this.aS()) {
                  int var2 = this.Z();
                  if (this.al++ >= var2) {
                     this.al = var2;
                     this.aj = this.aM();
                     byte var3;
                     if (this.l.s.q().a() == -1) {
                        var3 = 0;
                     } else {
                        var3 = -1;
                     }

                     this.b(var3);
                  }
               }

               this.ak = false;
            }
         } else {
            if (this.al > 0) {
               this.al -= 4;
            }

            if (this.al < 0) {
               this.al = 0;
            }
         }

         this.I();
         this.l.E.b();
      }

      this.as();
      this.aq();
      if (this.l.G) {
         this.ab();
      } else if (this.az > 0) {
         if (this.X) {
            this.az -= 4;
            if (this.az < 0) {
               this.ab();
            }
         } else {
            if (this.az % 20 == 0) {
               this.a(up.c, 1.0F);
            }

            --this.az;
         }
      }

      if (this.au()) {
         this.aa();
         this.L *= 0.5F;
      }

      if (this.q < -64.0D) {
         this.ac();
      }

      if (!this.l.G) {
         this.b(0, this.az > 0);
      }

      this.W = false;
      this.l.E.b();
   }

   protected void I() {
      if (this.aj > 0) {
         --this.aj;
      }

   }

   public int Z() {
      return 1;
   }

   protected void aa() {
      if (!this.X) {
         this.a(up.d, 4.0F);
         this.i(15);
      }
   }

   public void i(int var1) {
      int var2 = var1 * 20;
      if (this instanceof vn) {
         var2 = alu.a((vn)this, var2);
      }

      if (this.az < var2) {
         this.az = var2;
      }

   }

   public void ab() {
      this.az = 0;
   }

   protected void ac() {
      this.X();
   }

   public boolean c(double var1, double var3, double var5) {
      bgz var7 = this.bw().d(var1, var3, var5);
      return this.b(var7);
   }

   private boolean b(bgz var1) {
      return this.l.a(this, var1).isEmpty() && !this.l.d(var1);
   }

   public void a(vt var1, double var2, double var4, double var6) {
      if (this.Q) {
         this.a(this.bw().d(var2, var4, var6));
         this.ad();
      } else {
         if (var1 == vt.c) {
            long var8 = this.l.R();
            if (var8 != this.aK) {
               Arrays.fill(this.aJ, 0.0D);
               this.aK = var8;
            }

            int var10;
            double var11;
            if (var2 != 0.0D) {
               var10 = fa.a.a.ordinal();
               var11 = ri.a(var2 + this.aJ[var10], -0.51D, 0.51D);
               var2 = var11 - this.aJ[var10];
               this.aJ[var10] = var11;
               if (Math.abs(var2) <= 9.999999747378752E-6D) {
                  return;
               }
            } else if (var4 != 0.0D) {
               var10 = fa.a.b.ordinal();
               var11 = ri.a(var4 + this.aJ[var10], -0.51D, 0.51D);
               var4 = var11 - this.aJ[var10];
               this.aJ[var10] = var11;
               if (Math.abs(var4) <= 9.999999747378752E-6D) {
                  return;
               }
            } else {
               if (var6 == 0.0D) {
                  return;
               }

               var10 = fa.a.c.ordinal();
               var11 = ri.a(var6 + this.aJ[var10], -0.51D, 0.51D);
               var6 = var11 - this.aJ[var10];
               this.aJ[var10] = var11;
               if (Math.abs(var6) <= 9.999999747378752E-6D) {
                  return;
               }
            }
         }

         this.l.E.a("move");
         double var53 = this.p;
         double var54 = this.q;
         double var12 = this.r;
         if (this.E) {
            this.E = false;
            var2 *= 0.25D;
            var4 *= 0.05000000074505806D;
            var6 *= 0.25D;
            this.s = 0.0D;
            this.t = 0.0D;
            this.u = 0.0D;
         }

         double var14 = var2;
         double var16 = var4;
         double var18 = var6;
         if ((var1 == vt.a || var1 == vt.b) && this.z && this.aU() && this instanceof aeb) {
            for(double var20 = 0.05D; var2 != 0.0D && this.l.a(this, this.bw().d(var2, (double)(-this.P), 0.0D)).isEmpty(); var14 = var2) {
               if (var2 < 0.05D && var2 >= -0.05D) {
                  var2 = 0.0D;
               } else if (var2 > 0.0D) {
                  var2 -= 0.05D;
               } else {
                  var2 += 0.05D;
               }
            }

            for(; var6 != 0.0D && this.l.a(this, this.bw().d(0.0D, (double)(-this.P), var6)).isEmpty(); var18 = var6) {
               if (var6 < 0.05D && var6 >= -0.05D) {
                  var6 = 0.0D;
               } else if (var6 > 0.0D) {
                  var6 -= 0.05D;
               } else {
                  var6 += 0.05D;
               }
            }

            for(; var2 != 0.0D && var6 != 0.0D && this.l.a(this, this.bw().d(var2, (double)(-this.P), var6)).isEmpty(); var18 = var6) {
               if (var2 < 0.05D && var2 >= -0.05D) {
                  var2 = 0.0D;
               } else if (var2 > 0.0D) {
                  var2 -= 0.05D;
               } else {
                  var2 += 0.05D;
               }

               var14 = var2;
               if (var6 < 0.05D && var6 >= -0.05D) {
                  var6 = 0.0D;
               } else if (var6 > 0.0D) {
                  var6 -= 0.05D;
               } else {
                  var6 += 0.05D;
               }
            }
         }

         List<bgz> var55 = this.l.a(this, this.bw().b(var2, var4, var6));
         bgz var21 = this.bw();
         int var22;
         int var23;
         if (var4 != 0.0D) {
            var22 = 0;

            for(var23 = var55.size(); var22 < var23; ++var22) {
               var4 = ((bgz)var55.get(var22)).b(this.bw(), var4);
            }

            this.a(this.bw().d(0.0D, var4, 0.0D));
         }

         if (var2 != 0.0D) {
            var22 = 0;

            for(var23 = var55.size(); var22 < var23; ++var22) {
               var2 = ((bgz)var55.get(var22)).a(this.bw(), var2);
            }

            if (var2 != 0.0D) {
               this.a(this.bw().d(var2, 0.0D, 0.0D));
            }
         }

         if (var6 != 0.0D) {
            var22 = 0;

            for(var23 = var55.size(); var22 < var23; ++var22) {
               var6 = ((bgz)var55.get(var22)).c(this.bw(), var6);
            }

            if (var6 != 0.0D) {
               this.a(this.bw().d(0.0D, 0.0D, var6));
            }
         }

         boolean var56 = this.z || var4 != var4 && var4 < 0.0D;
         double var33;
         if (this.P > 0.0F && var56 && (var14 != var2 || var18 != var6)) {
            double var57 = var2;
            double var25 = var4;
            double var27 = var6;
            bgz var29 = this.bw();
            this.a(var21);
            var4 = (double)this.P;
            List<bgz> var30 = this.l.a(this, this.bw().b(var14, var4, var18));
            bgz var31 = this.bw();
            bgz var32 = var31.b(var14, 0.0D, var18);
            var33 = var4;
            int var35 = 0;

            for(int var36 = var30.size(); var35 < var36; ++var35) {
               var33 = ((bgz)var30.get(var35)).b(var32, var33);
            }

            var31 = var31.d(0.0D, var33, 0.0D);
            double var68 = var14;
            int var37 = 0;

            for(int var38 = var30.size(); var37 < var38; ++var37) {
               var68 = ((bgz)var30.get(var37)).a(var31, var68);
            }

            var31 = var31.d(var68, 0.0D, 0.0D);
            double var71 = var18;
            int var39 = 0;

            for(int var40 = var30.size(); var39 < var40; ++var39) {
               var71 = ((bgz)var30.get(var39)).c(var31, var71);
            }

            var31 = var31.d(0.0D, 0.0D, var71);
            bgz var73 = this.bw();
            double var74 = var4;
            int var42 = 0;

            for(int var43 = var30.size(); var42 < var43; ++var42) {
               var74 = ((bgz)var30.get(var42)).b(var73, var74);
            }

            var73 = var73.d(0.0D, var74, 0.0D);
            double var75 = var14;
            int var44 = 0;

            for(int var45 = var30.size(); var44 < var45; ++var44) {
               var75 = ((bgz)var30.get(var44)).a(var73, var75);
            }

            var73 = var73.d(var75, 0.0D, 0.0D);
            double var76 = var18;
            int var46 = 0;

            for(int var47 = var30.size(); var46 < var47; ++var46) {
               var76 = ((bgz)var30.get(var46)).c(var73, var76);
            }

            var73 = var73.d(0.0D, 0.0D, var76);
            double var77 = var68 * var68 + var71 * var71;
            double var48 = var75 * var75 + var76 * var76;
            if (var77 > var48) {
               var2 = var68;
               var6 = var71;
               var4 = -var33;
               this.a(var31);
            } else {
               var2 = var75;
               var6 = var76;
               var4 = -var74;
               this.a(var73);
            }

            int var50 = 0;

            for(int var51 = var30.size(); var50 < var51; ++var50) {
               var4 = ((bgz)var30.get(var50)).b(this.bw(), var4);
            }

            this.a(this.bw().d(0.0D, var4, 0.0D));
            if (var57 * var57 + var27 * var27 >= var2 * var2 + var6 * var6) {
               var2 = var57;
               var4 = var25;
               var6 = var27;
               this.a(var29);
            }
         }

         this.l.E.b();
         this.l.E.a("rest");
         this.ad();
         this.A = var14 != var2 || var18 != var6;
         this.B = var4 != var4;
         this.z = this.B && var16 < 0.0D;
         this.C = this.A || this.B;
         var23 = ri.c(this.p);
         int var24 = ri.c(this.q - 0.20000000298023224D);
         int var58 = ri.c(this.r);
         et var26 = new et(var23, var24, var58);
         awr var59 = this.l.o(var26);
         if (var59.a() == bcx.a) {
            et var28 = var26.b();
            awr var61 = this.l.o(var28);
            aou var64 = var61.u();
            if (var64 instanceof aqm || var64 instanceof aut || var64 instanceof aqn) {
               var59 = var61;
               var26 = var28;
            }
         }

         this.a(var4, this.z, var59, var26);
         if (var14 != var2) {
            this.s = 0.0D;
         }

         if (var18 != var6) {
            this.u = 0.0D;
         }

         aou var60 = var59.u();
         if (var16 != var4) {
            var60.a(this.l, this);
         }

         if (this.ak() && (!this.z || !this.aU() || !(this instanceof aeb)) && !this.aS()) {
            double var62 = this.p - var53;
            double var66 = this.q - var54;
            var33 = this.r - var12;
            if (var60 != aov.au) {
               var66 = 0.0D;
            }

            if (var60 != null && this.z) {
               var60.a(this.l, var26, this);
            }

            this.J = (float)((double)this.J + (double)ri.a(var62 * var62 + var33 * var33) * 0.6D);
            this.K = (float)((double)this.K + (double)ri.a(var62 * var62 + var66 * var66 + var33 * var33) * 0.6D);
            if (this.K > (float)this.ax && var59.a() != bcx.a) {
               this.ax = (int)this.K + 1;
               if (this.ao()) {
                  ve var69 = this.aT() && this.bE() != null ? this.bE() : this;
                  float var70 = var69 == this ? 0.35F : 0.4F;
                  float var72 = ri.a(var69.s * var69.s * 0.20000000298023224D + var69.t * var69.t + var69.u * var69.u * 0.20000000298023224D) * var70;
                  if (var72 > 1.0F) {
                     var72 = 1.0F;
                  }

                  this.a(this.ae(), var72, 1.0F + (this.S.nextFloat() - this.S.nextFloat()) * 0.4F);
               } else {
                  this.a(var26, var60);
               }
            } else if (this.K > this.ay && this.ah() && var59.a() == bcx.a) {
               this.ay = this.d(this.K);
            }
         }

         try {
            this.ag();
         } catch (Throwable var52) {
            b var65 = b.a(var52, "Checking entity block collision");
            c var67 = var65.a("Entity being checked for collision");
            this.a(var67);
            throw new f(var65);
         }

         boolean var63 = this.an();
         if (this.l.e(this.bw().h(0.001D))) {
            this.j(1);
            if (!var63) {
               ++this.az;
               if (this.az == 0) {
                  this.i(8);
               }
            }
         } else if (this.az <= 0) {
            this.az = -this.bL();
         }

         if (var63 && this.aR()) {
            this.a(qd.bW, 0.7F, 1.6F + (this.S.nextFloat() - this.S.nextFloat()) * 0.4F);
            this.az = -this.bL();
         }

         this.l.E.b();
      }
   }

   public void ad() {
      bgz var1 = this.bw();
      this.p = (var1.a + var1.d) / 2.0D;
      this.q = var1.b;
      this.r = (var1.c + var1.f) / 2.0D;
   }

   protected qc ae() {
      return qd.ca;
   }

   protected qc af() {
      return qd.bZ;
   }

   protected void ag() {
      bgz var1 = this.bw();
      et.b var2 = et.b.d(var1.a + 0.001D, var1.b + 0.001D, var1.c + 0.001D);
      et.b var3 = et.b.d(var1.d - 0.001D, var1.e - 0.001D, var1.f - 0.001D);
      et.b var4 = et.b.s();
      if (this.l.a((et)var2, (et)var3)) {
         for(int var5 = var2.p(); var5 <= var3.p(); ++var5) {
            for(int var6 = var2.q(); var6 <= var3.q(); ++var6) {
               for(int var7 = var2.r(); var7 <= var3.r(); ++var7) {
                  var4.f(var5, var6, var7);
                  awr var8 = this.l.o(var4);

                  try {
                     var8.u().a((ams)this.l, (et)var4, (awr)var8, (ve)this);
                     this.a(var8);
                  } catch (Throwable var12) {
                     b var10 = b.a(var12, "Colliding entity with block");
                     c var11 = var10.a("Block being collided with");
                     c.a(var11, var4, var8);
                     throw new f(var10);
                  }
               }
            }
         }
      }

      var2.t();
      var3.t();
      var4.t();
   }

   protected void a(awr var1) {
   }

   protected void a(et var1, aou var2) {
      atw var3 = var2.v();
      if (this.l.o(var1.a()).u() == aov.aH) {
         var3 = aov.aH.v();
         this.a(var3.d(), var3.a() * 0.15F, var3.b());
      } else if (!var2.t().a().d()) {
         this.a(var3.d(), var3.a() * 0.15F, var3.b());
      }

   }

   protected float d(float var1) {
      return 0.0F;
   }

   protected boolean ah() {
      return false;
   }

   public void a(qc var1, float var2, float var3) {
      if (!this.ai()) {
         this.l.a((aeb)null, this.p, this.q, this.r, var1, this.bK(), var2, var3);
      }

   }

   public boolean ai() {
      return (Boolean)this.Y.a(aD);
   }

   public void c(boolean var1) {
      this.Y.b(aD, var1);
   }

   public boolean aj() {
      return (Boolean)this.Y.a(aE);
   }

   public void d(boolean var1) {
      this.Y.b(aE, var1);
   }

   protected boolean ak() {
      return true;
   }

   protected void a(double var1, boolean var3, awr var4, et var5) {
      if (var3) {
         if (this.L > 0.0F) {
            var4.u().a(this.l, var5, this, this.L);
         }

         this.L = 0.0F;
      } else if (var1 < 0.0D) {
         this.L = (float)((double)this.L - var1);
      }

   }

   @Nullable
   public bgz al() {
      return null;
   }

   protected void j(int var1) {
      if (!this.X) {
         this.a(up.a, (float)var1);
      }

   }

   public final boolean am() {
      return this.X;
   }

   public void e(float var1, float var2) {
      if (this.aT()) {
         Iterator var3 = this.bF().iterator();

         while(var3.hasNext()) {
            ve var4 = (ve)var3.next();
            var4.e(var1, var2);
         }
      }

   }

   public boolean an() {
      if (this.U) {
         return true;
      } else {
         et.b var1 = et.b.d(this.p, this.q, this.r);
         if (!this.l.B(var1) && !this.l.B(var1.e(this.p, this.q + (double)this.H, this.r))) {
            var1.t();
            return false;
         } else {
            var1.t();
            return true;
         }
      }
   }

   public boolean ao() {
      return this.U;
   }

   public boolean ap() {
      return this.l.a(this.bw().c(0.0D, -20.0D, 0.0D).h(0.001D), bcx.h, this);
   }

   public boolean aq() {
      if (this.bJ() instanceof afb) {
         this.U = false;
      } else if (this.l.a(this.bw().c(0.0D, -0.4000000059604645D, 0.0D).h(0.001D), bcx.h, this)) {
         if (!this.U && !this.W) {
            this.ar();
         }

         this.L = 0.0F;
         this.U = true;
         this.ab();
      } else {
         this.U = false;
      }

      return this.U;
   }

   protected void ar() {
      ve var1 = this.aT() && this.bE() != null ? this.bE() : this;
      float var2 = var1 == this ? 0.2F : 0.9F;
      float var3 = ri.a(var1.s * var1.s * 0.20000000298023224D + var1.t * var1.t + var1.u * var1.u * 0.20000000298023224D) * var2;
      if (var3 > 1.0F) {
         var3 = 1.0F;
      }

      this.a(this.af(), var3, 1.0F + (this.S.nextFloat() - this.S.nextFloat()) * 0.4F);
      float var4 = (float)ri.c(this.bw().b);

      int var5;
      float var6;
      float var7;
      for(var5 = 0; (float)var5 < 1.0F + this.G * 20.0F; ++var5) {
         var6 = (this.S.nextFloat() * 2.0F - 1.0F) * this.G;
         var7 = (this.S.nextFloat() * 2.0F - 1.0F) * this.G;
         this.l.a(fj.e, this.p + (double)var6, (double)(var4 + 1.0F), this.r + (double)var7, this.s, this.t - (double)(this.S.nextFloat() * 0.2F), this.u);
      }

      for(var5 = 0; (float)var5 < 1.0F + this.G * 20.0F; ++var5) {
         var6 = (this.S.nextFloat() * 2.0F - 1.0F) * this.G;
         var7 = (this.S.nextFloat() * 2.0F - 1.0F) * this.G;
         this.l.a(fj.f, this.p + (double)var6, (double)(var4 + 1.0F), this.r + (double)var7, this.s, this.t, this.u);
      }

   }

   public void as() {
      if (this.aV() && !this.ao()) {
         this.at();
      }

   }

   protected void at() {
      int var1 = ri.c(this.p);
      int var2 = ri.c(this.q - 0.20000000298023224D);
      int var3 = ri.c(this.r);
      et var4 = new et(var1, var2, var3);
      awr var5 = this.l.o(var4);
      if (var5.i() != ath.a) {
         this.l.a(fj.L, this.p + ((double)this.S.nextFloat() - 0.5D) * (double)this.G, this.bw().b + 0.1D, this.r + ((double)this.S.nextFloat() - 0.5D) * (double)this.G, -this.s * 4.0D, 1.5D, -this.u * 4.0D, aou.j(var5));
      }

   }

   public boolean a(bcx var1) {
      if (this.bJ() instanceof afb) {
         return false;
      } else {
         double var2 = this.q + (double)this.by();
         et var4 = new et(this.p, var2, this.r);
         awr var5 = this.l.o(var4);
         if (var5.a() == var1) {
            float var6 = ars.b(var5.u().e(var5)) - 0.11111111F;
            float var7 = (float)(var4.q() + 1) - var6;
            boolean var8 = var2 < (double)var7;
            return !var8 && this instanceof aeb ? false : var8;
         } else {
            return false;
         }
      }
   }

   public boolean au() {
      return this.l.a(this.bw().c(-0.10000000149011612D, -0.4000000059604645D, -0.10000000149011612D), bcx.i);
   }

   public void b(float var1, float var2, float var3, float var4) {
      float var5 = var1 * var1 + var2 * var2 + var3 * var3;
      if (!(var5 < 1.0E-4F)) {
         var5 = ri.c(var5);
         if (var5 < 1.0F) {
            var5 = 1.0F;
         }

         var5 = var4 / var5;
         var1 *= var5;
         var2 *= var5;
         var3 *= var5;
         float var6 = ri.a(this.v * 0.017453292F);
         float var7 = ri.b(this.v * 0.017453292F);
         this.s += (double)(var1 * var7 - var3 * var6);
         this.t += (double)var2;
         this.u += (double)(var3 * var7 + var1 * var6);
      }
   }

   public int av() {
      et.a var1 = new et.a(ri.c(this.p), 0, ri.c(this.r));
      if (this.l.e((et)var1)) {
         var1.p(ri.c(this.q + (double)this.by()));
         return this.l.b(var1, 0);
      } else {
         return 0;
      }
   }

   public float aw() {
      et.a var1 = new et.a(ri.c(this.p), 0, ri.c(this.r));
      if (this.l.e((et)var1)) {
         var1.p(ri.c(this.q + (double)this.by()));
         return this.l.n(var1);
      } else {
         return 0.0F;
      }
   }

   public void a(ams var1) {
      this.l = var1;
   }

   public void a(double var1, double var3, double var5, float var7, float var8) {
      this.p = ri.a(var1, -3.0E7D, 3.0E7D);
      this.q = var3;
      this.r = ri.a(var5, -3.0E7D, 3.0E7D);
      this.m = this.p;
      this.n = this.q;
      this.o = this.r;
      var8 = ri.a(var8, -90.0F, 90.0F);
      this.v = var7;
      this.w = var8;
      this.x = this.v;
      this.y = this.w;
      double var9 = (double)(this.x - var7);
      if (var9 < -180.0D) {
         this.x += 360.0F;
      }

      if (var9 >= 180.0D) {
         this.x -= 360.0F;
      }

      this.b(this.p, this.q, this.r);
      this.b(var7, var8);
   }

   public void a(et var1, float var2, float var3) {
      this.b((double)var1.p() + 0.5D, (double)var1.q(), (double)var1.r() + 0.5D, var2, var3);
   }

   public void b(double var1, double var3, double var5, float var7, float var8) {
      this.p = var1;
      this.q = var3;
      this.r = var5;
      this.m = this.p;
      this.n = this.q;
      this.o = this.r;
      this.M = this.p;
      this.N = this.q;
      this.O = this.r;
      this.v = var7;
      this.w = var8;
      this.b(this.p, this.q, this.r);
   }

   public float g(ve var1) {
      float var2 = (float)(this.p - var1.p);
      float var3 = (float)(this.q - var1.q);
      float var4 = (float)(this.r - var1.r);
      return ri.c(var2 * var2 + var3 * var3 + var4 * var4);
   }

   public double d(double var1, double var3, double var5) {
      double var7 = this.p - var1;
      double var9 = this.q - var3;
      double var11 = this.r - var5;
      return var7 * var7 + var9 * var9 + var11 * var11;
   }

   public double c(et var1) {
      return var1.f(this.p, this.q, this.r);
   }

   public double d(et var1) {
      return var1.g(this.p, this.q, this.r);
   }

   public double e(double var1, double var3, double var5) {
      double var7 = this.p - var1;
      double var9 = this.q - var3;
      double var11 = this.r - var5;
      return (double)ri.a(var7 * var7 + var9 * var9 + var11 * var11);
   }

   public double h(ve var1) {
      double var2 = this.p - var1.p;
      double var4 = this.q - var1.q;
      double var6 = this.r - var1.r;
      return var2 * var2 + var4 * var4 + var6 * var6;
   }

   public void d(aeb var1) {
   }

   public void i(ve var1) {
      if (!this.x(var1)) {
         if (!var1.Q && !this.Q) {
            double var2 = var1.p - this.p;
            double var4 = var1.r - this.r;
            double var6 = ri.a(var2, var4);
            if (var6 >= 0.009999999776482582D) {
               var6 = (double)ri.a(var6);
               var2 /= var6;
               var4 /= var6;
               double var8 = 1.0D / var6;
               if (var8 > 1.0D) {
                  var8 = 1.0D;
               }

               var2 *= var8;
               var4 *= var8;
               var2 *= 0.05000000074505806D;
               var4 *= 0.05000000074505806D;
               var2 *= (double)(1.0F - this.R);
               var4 *= (double)(1.0F - this.R);
               if (!this.aT()) {
                  this.f(-var2, 0.0D, -var4);
               }

               if (!var1.aT()) {
                  var1.f(var2, 0.0D, var4);
               }
            }

         }
      }
   }

   public void f(double var1, double var3, double var5) {
      this.s += var1;
      this.t += var3;
      this.u += var5;
      this.ai = true;
   }

   protected void ax() {
      this.D = true;
   }

   public boolean a(up var1, float var2) {
      if (this.b(var1)) {
         return false;
      } else {
         this.ax();
         return false;
      }
   }

   public bhc e(float var1) {
      if (var1 == 1.0F) {
         return this.f(this.w, this.v);
      } else {
         float var2 = this.y + (this.w - this.y) * var1;
         float var3 = this.x + (this.v - this.x) * var1;
         return this.f(var2, var3);
      }
   }

   protected final bhc f(float var1, float var2) {
      float var3 = ri.b(-var2 * 0.017453292F - 3.1415927F);
      float var4 = ri.a(-var2 * 0.017453292F - 3.1415927F);
      float var5 = -ri.b(-var1 * 0.017453292F);
      float var6 = ri.a(-var1 * 0.017453292F);
      return new bhc((double)(var4 * var5), (double)var6, (double)(var3 * var5));
   }

   public bhc f(float var1) {
      if (var1 == 1.0F) {
         return new bhc(this.p, this.q + (double)this.by(), this.r);
      } else {
         double var2 = this.m + (this.p - this.m) * (double)var1;
         double var4 = this.n + (this.q - this.n) * (double)var1 + (double)this.by();
         double var6 = this.o + (this.r - this.o) * (double)var1;
         return new bhc(var2, var4, var6);
      }
   }

   @Nullable
   public bha a(double var1, float var3) {
      bhc var4 = this.f(var3);
      bhc var5 = this.e(var3);
      bhc var6 = var4.b(var5.b * var1, var5.c * var1, var5.d * var1);
      return this.l.a(var4, var6, false, false, true);
   }

   public boolean ay() {
      return false;
   }

   public boolean az() {
      return false;
   }

   public void a(ve var1, int var2, up var3) {
      if (var1 instanceof oo) {
         m.c.a((oo)var1, this, var3);
      }

   }

   public boolean g(double var1, double var3, double var5) {
      double var7 = this.p - var1;
      double var9 = this.q - var3;
      double var11 = this.r - var5;
      double var13 = var7 * var7 + var9 * var9 + var11 * var11;
      return this.a(var13);
   }

   public boolean a(double var1) {
      double var3 = this.bw().a();
      if (Double.isNaN(var3)) {
         var3 = 1.0D;
      }

      var3 *= 64.0D * f;
      return var1 < var3 * var3;
   }

   public boolean c(fy var1) {
      String var2 = this.aB();
      if (!this.F && var2 != null) {
         var1.a("id", var2);
         this.e(var1);
         return true;
      } else {
         return false;
      }
   }

   public boolean d(fy var1) {
      String var2 = this.aB();
      if (!this.F && var2 != null && !this.aS()) {
         var1.a("id", var2);
         this.e(var1);
         return true;
      } else {
         return false;
      }
   }

   public static void b(rw var0) {
      var0.a(ru.e, new ry() {
         public fy a(rv var1, fy var2, int var3) {
            if (var2.b("Passengers", 9)) {
               ge var4 = var2.c("Passengers", 10);

               for(int var5 = 0; var5 < var4.c(); ++var5) {
                  var4.a(var5, var1.a(ru.e, var4.b(var5), var3));
               }
            }

            return var2;
         }
      });
   }

   public fy e(fy var1) {
      try {
         var1.a((String)"Pos", (gn)this.a(this.p, this.q, this.r));
         var1.a((String)"Motion", (gn)this.a(this.s, this.t, this.u));
         var1.a((String)"Rotation", (gn)this.a(this.v, this.w));
         var1.a("FallDistance", this.L);
         var1.a("Fire", (short)this.az);
         var1.a("Air", (short)this.aZ());
         var1.a("OnGround", this.z);
         var1.a("Dimension", this.am);
         var1.a("Invulnerable", this.aF);
         var1.a("PortalCooldown", this.aj);
         var1.a("UUID", this.bm());
         if (this.n_()) {
            var1.a("CustomName", this.bq());
         }

         if (this.br()) {
            var1.a("CustomNameVisible", this.br());
         }

         this.aG.b(var1);
         if (this.ai()) {
            var1.a("Silent", this.ai());
         }

         if (this.aj()) {
            var1.a("NoGravity", this.aj());
         }

         if (this.as) {
            var1.a("Glowing", this.as);
         }

         ge var2;
         Iterator var7;
         if (!this.aH.isEmpty()) {
            var2 = new ge();
            var7 = this.aH.iterator();

            while(var7.hasNext()) {
               String var8 = (String)var7.next();
               var2.a((gn)(new gm(var8)));
            }

            var1.a((String)"Tags", (gn)var2);
         }

         this.b(var1);
         if (this.aT()) {
            var2 = new ge();
            var7 = this.bF().iterator();

            while(var7.hasNext()) {
               ve var9 = (ve)var7.next();
               fy var5 = new fy();
               if (var9.c(var5)) {
                  var2.a((gn)var5);
               }
            }

            if (!var2.b_()) {
               var1.a((String)"Passengers", (gn)var2);
            }
         }

         return var1;
      } catch (Throwable var6) {
         b var3 = b.a(var6, "Saving entity NBT");
         c var4 = var3.a("Entity being saved");
         this.a(var4);
         throw new f(var3);
      }
   }

   public void f(fy var1) {
      try {
         ge var2 = var1.c("Pos", 6);
         ge var9 = var1.c("Motion", 6);
         ge var10 = var1.c("Rotation", 5);
         this.s = var9.f(0);
         this.t = var9.f(1);
         this.u = var9.f(2);
         if (Math.abs(this.s) > 10.0D) {
            this.s = 0.0D;
         }

         if (Math.abs(this.t) > 10.0D) {
            this.t = 0.0D;
         }

         if (Math.abs(this.u) > 10.0D) {
            this.u = 0.0D;
         }

         this.p = var2.f(0);
         this.q = var2.f(1);
         this.r = var2.f(2);
         this.M = this.p;
         this.N = this.q;
         this.O = this.r;
         this.m = this.p;
         this.n = this.q;
         this.o = this.r;
         this.v = var10.g(0);
         this.w = var10.g(1);
         this.x = this.v;
         this.y = this.w;
         this.g(this.v);
         this.h(this.v);
         this.L = var1.j("FallDistance");
         this.az = var1.g("Fire");
         this.l(var1.g("Air"));
         this.z = var1.q("OnGround");
         if (var1.e("Dimension")) {
            this.am = var1.h("Dimension");
         }

         this.aF = var1.q("Invulnerable");
         this.aj = var1.h("PortalCooldown");
         if (var1.b("UUID")) {
            this.aq = var1.a("UUID");
            this.ar = this.aq.toString();
         }

         this.b(this.p, this.q, this.r);
         this.b(this.v, this.w);
         if (var1.b("CustomName", 8)) {
            this.c(var1.l("CustomName"));
         }

         this.j(var1.q("CustomNameVisible"));
         this.aG.a(var1);
         this.c(var1.q("Silent"));
         this.d(var1.q("NoGravity"));
         this.g(var1.q("Glowing"));
         if (var1.b("Tags", 9)) {
            this.aH.clear();
            ge var5 = var1.c("Tags", 8);
            int var6 = Math.min(var5.c(), 1024);

            for(int var7 = 0; var7 < var6; ++var7) {
               this.aH.add(var5.h(var7));
            }
         }

         this.a(var1);
         if (this.aA()) {
            this.b(this.p, this.q, this.r);
         }

      } catch (Throwable var8) {
         b var3 = b.a(var8, "Loading entity NBT");
         c var4 = var3.a("Entity being loaded");
         this.a(var4);
         throw new f(var3);
      }
   }

   protected boolean aA() {
      return true;
   }

   @Nullable
   protected final String aB() {
      nd var1 = vg.a(this);
      return var1 == null ? null : var1.toString();
   }

   protected abstract void a(fy var1);

   protected abstract void b(fy var1);

   protected ge a(double... var1) {
      ge var2 = new ge();
      double[] var3 = var1;
      int var4 = var1.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         double var6 = var3[var5];
         var2.a((gn)(new fz(var6)));
      }

      return var2;
   }

   protected ge a(float... var1) {
      ge var2 = new ge();
      float[] var3 = var1;
      int var4 = var1.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         float var6 = var3[var5];
         var2.a((gn)(new gb(var6)));
      }

      return var2;
   }

   @Nullable
   public acj a(ail var1, int var2) {
      return this.a(var1, var2, 0.0F);
   }

   @Nullable
   public acj a(ail var1, int var2, float var3) {
      return this.a(new ain(var1, var2, 0), var3);
   }

   @Nullable
   public acj a(ain var1, float var2) {
      if (var1.b()) {
         return null;
      } else {
         acj var3 = new acj(this.l, this.p, this.q + (double)var2, this.r, var1);
         var3.q();
         this.l.a((ve)var3);
         return var3;
      }
   }

   public boolean aC() {
      return !this.F;
   }

   public boolean aD() {
      if (this.Q) {
         return false;
      } else {
         et.b var1 = et.b.s();

         for(int var2 = 0; var2 < 8; ++var2) {
            int var3 = ri.c(this.q + (double)(((float)((var2 >> 0) % 2) - 0.5F) * 0.1F) + (double)this.by());
            int var4 = ri.c(this.p + (double)(((float)((var2 >> 1) % 2) - 0.5F) * this.G * 0.8F));
            int var5 = ri.c(this.r + (double)(((float)((var2 >> 2) % 2) - 0.5F) * this.G * 0.8F));
            if (var1.p() != var4 || var1.q() != var3 || var1.r() != var5) {
               var1.f(var4, var3, var5);
               if (this.l.o(var1).r()) {
                  var1.t();
                  return true;
               }
            }
         }

         var1.t();
         return false;
      }
   }

   public boolean b(aeb var1, tz var2) {
      return false;
   }

   @Nullable
   public bgz j(ve var1) {
      return null;
   }

   public void aE() {
      ve var1 = this.bJ();
      if (this.aS() && var1.F) {
         this.o();
      } else {
         this.s = 0.0D;
         this.t = 0.0D;
         this.u = 0.0D;
         this.B_();
         if (this.aS()) {
            var1.k(this);
         }
      }
   }

   public void k(ve var1) {
      if (this.w(var1)) {
         var1.b(this.p, this.q + this.aG() + var1.aF(), this.r);
      }
   }

   public void l(ve var1) {
   }

   public double aF() {
      return 0.0D;
   }

   public double aG() {
      return (double)this.H * 0.75D;
   }

   public boolean m(ve var1) {
      return this.a(var1, false);
   }

   public boolean a(ve var1, boolean var2) {
      for(ve var3 = var1; var3.au != null; var3 = var3.au) {
         if (var3.au == this) {
            return false;
         }
      }

      if (!var2 && (!this.n(var1) || !var1.q(this))) {
         return false;
      } else {
         if (this.aS()) {
            this.o();
         }

         this.au = var1;
         this.au.o(this);
         return true;
      }
   }

   protected boolean n(ve var1) {
      return this.j <= 0;
   }

   public void aH() {
      for(int var1 = this.at.size() - 1; var1 >= 0; --var1) {
         ((ve)this.at.get(var1)).o();
      }

   }

   public void o() {
      if (this.au != null) {
         ve var1 = this.au;
         this.au = null;
         var1.p(this);
      }

   }

   protected void o(ve var1) {
      if (var1.bJ() != this) {
         throw new IllegalStateException("Use x.startRiding(y), not y.addPassenger(x)");
      } else {
         if (!this.l.G && var1 instanceof aeb && !(this.bE() instanceof aeb)) {
            this.at.add(0, var1);
         } else {
            this.at.add(var1);
         }

      }
   }

   protected void p(ve var1) {
      if (var1.bJ() == this) {
         throw new IllegalStateException("Use x.stopRiding(y), not y.removePassenger(x)");
      } else {
         this.at.remove(var1);
         var1.j = 60;
      }
   }

   protected boolean q(ve var1) {
      return this.bF().size() < 1;
   }

   public void a(double var1, double var3, double var5, float var7, float var8, int var9, boolean var10) {
      this.b(var1, var3, var5);
      this.b(var7, var8);
   }

   public float aI() {
      return 0.0F;
   }

   public bhc aJ() {
      return this.f(this.w, this.v);
   }

   public bhb aK() {
      return new bhb(this.w, this.v);
   }

   public bhc aL() {
      return bhc.a(this.aK());
   }

   public void e(et var1) {
      if (this.aj > 0) {
         this.aj = this.aM();
      } else {
         if (!this.l.G && !var1.equals(this.an)) {
            this.an = new et(var1);
            awv.b var2 = aov.aY.c(this.l, this.an);
            double var3 = var2.b().k() == fa.a.a ? (double)var2.a().r() : (double)var2.a().p();
            double var5 = var2.b().k() == fa.a.a ? this.r : this.p;
            var5 = Math.abs(ri.c(var5 - (double)(var2.b().e().c() == fa.b.b ? 1 : 0), var3, var3 - (double)var2.d()));
            double var7 = ri.c(this.q - 1.0D, (double)var2.a().q(), (double)(var2.a().q() - var2.e()));
            this.ao = new bhc(var5, var7, 0.0D);
            this.ap = var2.b();
         }

         this.ak = true;
      }
   }

   public int aM() {
      return 300;
   }

   public void h(double var1, double var3, double var5) {
      this.s = var1;
      this.t = var3;
      this.u = var5;
   }

   public void a(byte var1) {
   }

   public void aN() {
   }

   public Iterable<ain> aO() {
      return b;
   }

   public Iterable<ain> aP() {
      return b;
   }

   public Iterable<ain> aQ() {
      return Iterables.concat(this.aO(), this.aP());
   }

   public void a(vj var1, ain var2) {
   }

   public boolean aR() {
      boolean var1 = this.l != null && this.l.G;
      return !this.X && (this.az > 0 || var1 && this.k(0));
   }

   public boolean aS() {
      return this.bJ() != null;
   }

   public boolean aT() {
      return !this.bF().isEmpty();
   }

   public boolean aU() {
      return this.k(1);
   }

   public void e(boolean var1) {
      this.b(1, var1);
   }

   public boolean aV() {
      return this.k(3);
   }

   public void f(boolean var1) {
      this.b(3, var1);
   }

   public boolean aW() {
      return this.as || this.l.G && this.k(6);
   }

   public void g(boolean var1) {
      this.as = var1;
      if (!this.l.G) {
         this.b(6, this.as);
      }

   }

   public boolean aX() {
      return this.k(5);
   }

   public boolean e(aeb var1) {
      if (var1.y()) {
         return false;
      } else {
         bhk var2 = this.aY();
         return var2 != null && var1 != null && var1.aY() == var2 && var2.h() ? false : this.aX();
      }
   }

   @Nullable
   public bhk aY() {
      return this.l.af().g(this.bn());
   }

   public boolean r(ve var1) {
      return this.a(var1.aY());
   }

   public boolean a(bhk var1) {
      return this.aY() != null ? this.aY().a(var1) : false;
   }

   public void h(boolean var1) {
      this.b(5, var1);
   }

   protected boolean k(int var1) {
      return ((Byte)this.Y.a(Z) & 1 << var1) != 0;
   }

   protected void b(int var1, boolean var2) {
      byte var3 = (Byte)this.Y.a(Z);
      if (var2) {
         this.Y.b(Z, (byte)(var3 | 1 << var1));
      } else {
         this.Y.b(Z, (byte)(var3 & ~(1 << var1)));
      }

   }

   public int aZ() {
      return (Integer)this.Y.a(aA);
   }

   public void l(int var1) {
      this.Y.b(aA, var1);
   }

   public void a(acg var1) {
      this.a(up.b, 5.0F);
      ++this.az;
      if (this.az == 0) {
         this.i(8);
      }

   }

   public void b(vn var1) {
   }

   protected boolean i(double var1, double var3, double var5) {
      et var7 = new et(var1, var3, var5);
      double var8 = var1 - (double)var7.p();
      double var10 = var3 - (double)var7.q();
      double var12 = var5 - (double)var7.r();
      if (!this.l.a(this.bw())) {
         return false;
      } else {
         fa var14 = fa.b;
         double var15 = Double.MAX_VALUE;
         if (!this.l.t(var7.e()) && var8 < var15) {
            var15 = var8;
            var14 = fa.e;
         }

         if (!this.l.t(var7.f()) && 1.0D - var8 < var15) {
            var15 = 1.0D - var8;
            var14 = fa.f;
         }

         if (!this.l.t(var7.c()) && var12 < var15) {
            var15 = var12;
            var14 = fa.c;
         }

         if (!this.l.t(var7.d()) && 1.0D - var12 < var15) {
            var15 = 1.0D - var12;
            var14 = fa.d;
         }

         if (!this.l.t(var7.a()) && 1.0D - var10 < var15) {
            var15 = 1.0D - var10;
            var14 = fa.b;
         }

         float var17 = this.S.nextFloat() * 0.2F + 0.1F;
         float var18 = (float)var14.c().a();
         if (var14.k() == fa.a.a) {
            this.s = (double)(var18 * var17);
            this.t *= 0.75D;
            this.u *= 0.75D;
         } else if (var14.k() == fa.a.b) {
            this.s *= 0.75D;
            this.t = (double)(var18 * var17);
            this.u *= 0.75D;
         } else if (var14.k() == fa.a.c) {
            this.s *= 0.75D;
            this.t *= 0.75D;
            this.u = (double)(var18 * var17);
         }

         return true;
      }
   }

   public void ba() {
      this.E = true;
      this.L = 0.0F;
   }

   public String h_() {
      if (this.n_()) {
         return this.bq();
      } else {
         String var1 = vg.b(this);
         if (var1 == null) {
            var1 = "generic";
         }

         return ft.a("entity." + var1 + ".name");
      }
   }

   @Nullable
   public ve[] bb() {
      return null;
   }

   public boolean s(ve var1) {
      return this == var1;
   }

   public float bc() {
      return 0.0F;
   }

   public void g(float var1) {
   }

   public void h(float var1) {
   }

   public boolean bd() {
      return true;
   }

   public boolean t(ve var1) {
      return false;
   }

   public String toString() {
      return String.format("%s['%s'/%d, l='%s', x=%.2f, y=%.2f, z=%.2f]", this.getClass().getSimpleName(), this.h_(), this.h, this.l == null ? "~NULL~" : this.l.V().j(), this.p, this.q, this.r);
   }

   public boolean b(up var1) {
      return this.aF && var1 != up.m && !var1.u();
   }

   public boolean be() {
      return this.aF;
   }

   public void i(boolean var1) {
      this.aF = var1;
   }

   public void u(ve var1) {
      this.b(var1.p, var1.q, var1.r, var1.v, var1.w);
   }

   private void a(ve var1) {
      fy var2 = var1.e(new fy());
      var2.r("Dimension");
      this.f(var2);
      this.aj = var1.aj;
      this.an = var1.an;
      this.ao = var1.ao;
      this.ap = var1.ap;
   }

   @Nullable
   public ve b(int var1) {
      if (!this.l.G && !this.F) {
         this.l.E.a("changeDimension");
         MinecraftServer var2 = this.C_();
         int var3 = this.am;
         om var4 = var2.a(var3);
         om var5 = var2.a(var1);
         this.am = var1;
         if (var3 == 1 && var1 == 1) {
            var5 = var2.a(0);
            this.am = 0;
         }

         this.l.e(this);
         this.F = false;
         this.l.E.a("reposition");
         et var6;
         if (var1 == 1) {
            var6 = var5.p();
         } else {
            double var7 = this.p;
            double var9 = this.r;
            double var11 = 8.0D;
            if (var1 == -1) {
               var7 = ri.a(var7 / 8.0D, var5.al().b() + 16.0D, var5.al().d() - 16.0D);
               var9 = ri.a(var9 / 8.0D, var5.al().c() + 16.0D, var5.al().e() - 16.0D);
            } else if (var1 == 0) {
               var7 = ri.a(var7 * 8.0D, var5.al().b() + 16.0D, var5.al().d() - 16.0D);
               var9 = ri.a(var9 * 8.0D, var5.al().c() + 16.0D, var5.al().e() - 16.0D);
            }

            var7 = (double)ri.a((int)var7, -29999872, 29999872);
            var9 = (double)ri.a((int)var9, -29999872, 29999872);
            float var13 = this.v;
            this.b(var7, this.q, var9, 90.0F, 0.0F);
            ana var14 = var5.x();
            var14.b(this, var13);
            var6 = new et(this);
         }

         var4.a(this, false);
         this.l.E.c("reloading");
         ve var16 = vg.a((Class)this.getClass(), (ams)var5);
         if (var16 != null) {
            var16.a(this);
            if (var3 == 1 && var1 == 1) {
               et var8 = var5.q(var5.T());
               var16.a(var8, var16.v, var16.w);
            } else {
               var16.a(var6, var16.v, var16.w);
            }

            boolean var15 = var16.k;
            var16.k = true;
            var5.a(var16);
            var16.k = var15;
            var5.a(var16, false);
         }

         this.F = true;
         this.l.E.b();
         var4.m();
         var5.m();
         this.l.E.b();
         return var16;
      } else {
         return null;
      }
   }

   public boolean bf() {
      return true;
   }

   public float a(amn var1, ams var2, et var3, awr var4) {
      return var4.u().a(this);
   }

   public boolean a(amn var1, ams var2, et var3, awr var4, float var5) {
      return true;
   }

   public int bg() {
      return 3;
   }

   public bhc bi() {
      return this.ao;
   }

   public fa bj() {
      return this.ap;
   }

   public boolean bk() {
      return false;
   }

   public void a(c var1) {
      var1.a("Entity Type", new d<String>() {
         public String a() throws Exception {
            return vg.a(ve.this) + " (" + ve.this.getClass().getCanonicalName() + ")";
         }

         // $FF: synthetic method
         public Object call() throws Exception {
            return this.a();
         }
      });
      var1.a((String)"Entity ID", (Object)this.h);
      var1.a("Entity Name", new d<String>() {
         public String a() throws Exception {
            return ve.this.h_();
         }

         // $FF: synthetic method
         public Object call() throws Exception {
            return this.a();
         }
      });
      var1.a((String)"Entity's Exact location", (Object)String.format("%.2f, %.2f, %.2f", this.p, this.q, this.r));
      var1.a((String)"Entity's Block location", (Object)c.a(ri.c(this.p), ri.c(this.q), ri.c(this.r)));
      var1.a((String)"Entity's Momentum", (Object)String.format("%.2f, %.2f, %.2f", this.s, this.t, this.u));
      var1.a("Entity's Passengers", new d<String>() {
         public String a() throws Exception {
            return ve.this.bF().toString();
         }

         // $FF: synthetic method
         public Object call() throws Exception {
            return this.a();
         }
      });
      var1.a("Entity's Vehicle", new d<String>() {
         public String a() throws Exception {
            return ve.this.bJ().toString();
         }

         // $FF: synthetic method
         public Object call() throws Exception {
            return this.a();
         }
      });
   }

   public boolean bl() {
      return this.aR();
   }

   public void a(UUID var1) {
      this.aq = var1;
      this.ar = this.aq.toString();
   }

   public UUID bm() {
      return this.aq;
   }

   public String bn() {
      return this.ar;
   }

   public boolean bo() {
      return true;
   }

   public static double bp() {
      return f;
   }

   public static void b(double var0) {
      f = var0;
   }

   public hh i_() {
      ho var1 = new ho(bhf.a(this.aY(), this.h_()));
      var1.b().a(this.bv());
      var1.b().a(this.bn());
      return var1;
   }

   public void c(String var1) {
      this.Y.b(aB, var1);
   }

   public String bq() {
      return (String)this.Y.a(aB);
   }

   public boolean n_() {
      return !((String)this.Y.a(aB)).isEmpty();
   }

   public void j(boolean var1) {
      this.Y.b(aC, var1);
   }

   public boolean br() {
      return (Boolean)this.Y.a(aC);
   }

   public void a(double var1, double var3, double var5) {
      this.aI = true;
      this.b(var1, var3, var5, this.v, this.w);
      this.l.a(this, false);
   }

   public boolean bs() {
      return this.br();
   }

   public void a(mx<?> var1) {
   }

   public fa bt() {
      return fa.b(ri.c((double)(this.v * 4.0F / 360.0F) + 0.5D) & 3);
   }

   public fa bu() {
      return this.bt();
   }

   protected hj bv() {
      fy var1 = new fy();
      nd var2 = vg.a(this);
      var1.a("id", this.bn());
      if (var2 != null) {
         var1.a("type", var2.toString());
      }

      var1.a("name", this.h_());
      return new hj(hj.a.c, new ho(var1.toString()));
   }

   public boolean a(oo var1) {
      return true;
   }

   public bgz bw() {
      return this.av;
   }

   public bgz bx() {
      return this.bw();
   }

   public void a(bgz var1) {
      this.av = var1;
   }

   public float by() {
      return this.H * 0.85F;
   }

   public boolean bz() {
      return this.aw;
   }

   public void k(boolean var1) {
      this.aw = var1;
   }

   public boolean c(int var1, ain var2) {
      return false;
   }

   public void a(hh var1) {
   }

   public boolean a(int var1, String var2) {
      return true;
   }

   public et c() {
      return new et(this.p, this.q + 0.5D, this.r);
   }

   public bhc d() {
      return new bhc(this.p, this.q, this.r);
   }

   public ams e() {
      return this.l;
   }

   public ve f() {
      return this;
   }

   public boolean g() {
      return false;
   }

   public void a(bp.a var1, int var2) {
      if (this.l != null && !this.l.G) {
         this.aG.a(this.l.u(), this, var1, var2);
      }

   }

   @Nullable
   public MinecraftServer C_() {
      return this.l.u();
   }

   public bp bA() {
      return this.aG;
   }

   public void v(ve var1) {
      this.aG.a(var1.bA());
   }

   public ub a(aeb var1, bhc var2, tz var3) {
      return ub.b;
   }

   public boolean bB() {
      return false;
   }

   protected void a(vn var1, ve var2) {
      if (var2 instanceof vn) {
         alk.a((vn)((vn)var2), (ve)var1);
      }

      alk.b(var1, var2);
   }

   public void b(oo var1) {
   }

   public void c(oo var1) {
   }

   public float a(atk var1) {
      float var2 = ri.g(this.v);
      switch(var1) {
      case c:
         return var2 + 180.0F;
      case d:
         return var2 + 270.0F;
      case b:
         return var2 + 90.0F;
      default:
         return var2;
      }
   }

   public float a(arw var1) {
      float var2 = ri.g(this.v);
      switch(var1) {
      case b:
         return -var2;
      case c:
         return 180.0F - var2;
      default:
         return var2;
      }
   }

   public boolean bC() {
      return false;
   }

   public boolean bD() {
      boolean var1 = this.aI;
      this.aI = false;
      return var1;
   }

   @Nullable
   public ve bE() {
      return null;
   }

   public List<ve> bF() {
      return (List)(this.at.isEmpty() ? Collections.emptyList() : Lists.newArrayList(this.at));
   }

   public boolean w(ve var1) {
      Iterator var2 = this.bF().iterator();

      ve var3;
      do {
         if (!var2.hasNext()) {
            return false;
         }

         var3 = (ve)var2.next();
      } while(!var3.equals(var1));

      return true;
   }

   public Collection<ve> bG() {
      Set<ve> var1 = Sets.newHashSet();
      this.a((Class)ve.class, (Set)var1);
      return var1;
   }

   public <T extends ve> Collection<T> b(Class<T> var1) {
      Set<T> var2 = Sets.newHashSet();
      this.a((Class)var1, (Set)var2);
      return var2;
   }

   private <T extends ve> void a(Class<T> var1, Set<T> var2) {
      ve var4;
      for(Iterator var3 = this.bF().iterator(); var3.hasNext(); var4.a(var1, var2)) {
         var4 = (ve)var3.next();
         if (var1.isAssignableFrom(var4.getClass())) {
            var2.add(var4);
         }
      }

   }

   public ve bH() {
      ve var1;
      for(var1 = this; var1.aS(); var1 = var1.bJ()) {
      }

      return var1;
   }

   public boolean x(ve var1) {
      return this.bH() == var1.bH();
   }

   public boolean y(ve var1) {
      Iterator var2 = this.bF().iterator();

      ve var3;
      do {
         if (!var2.hasNext()) {
            return false;
         }

         var3 = (ve)var2.next();
         if (var3.equals(var1)) {
            return true;
         }
      } while(!var3.y(var1));

      return true;
   }

   public boolean bI() {
      ve var1 = this.bE();
      if (var1 instanceof aeb) {
         return ((aeb)var1).cZ();
      } else {
         return !this.l.G;
      }
   }

   @Nullable
   public ve bJ() {
      return this.au;
   }

   public bda o_() {
      return bda.a;
   }

   public qe bK() {
      return qe.g;
   }

   protected int bL() {
      return 1;
   }

   static {
      Z = na.a(ve.class, mz.a);
      aA = na.a(ve.class, mz.b);
      aB = na.a(ve.class, mz.d);
      aC = na.a(ve.class, mz.h);
      aD = na.a(ve.class, mz.h);
      aE = na.a(ve.class, mz.h);
   }
}
