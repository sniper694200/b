public class amj {
   private final et a;
   private final aou b;
   private final int c;
   private final int d;

   public amj(et var1, aou var2, int var3, int var4) {
      this.a = var1;
      this.c = var3;
      this.d = var4;
      this.b = var2;
   }

   public et a() {
      return this.a;
   }

   public int b() {
      return this.c;
   }

   public int c() {
      return this.d;
   }

   public aou d() {
      return this.b;
   }

   public boolean equals(Object var1) {
      if (!(var1 instanceof amj)) {
         return false;
      } else {
         amj var2 = (amj)var1;
         return this.a.equals(var2.a) && this.c == var2.c && this.d == var2.d && this.b == var2.b;
      }
   }

   public String toString() {
      return "TE(" + this.a + ")," + this.c + "," + this.d + "," + this.b;
   }
}
