import java.util.Random;

public class azj extends azs {
   private final apa a;

   public azj(apa var1) {
      this.a = var1;
   }

   public boolean b(ams var1, Random var2, et var3) {
      for(int var4 = 0; var4 < 64; ++var4) {
         et var5 = var3.a(var2.nextInt(8) - var2.nextInt(8), var2.nextInt(4) - var2.nextInt(4), var2.nextInt(8) - var2.nextInt(8));
         if (var1.d(var5) && (!var1.s.n() || var5.q() < 255) && this.a.f(var1, var5, this.a.t())) {
            var1.a((et)var5, (awr)this.a.t(), 2);
         }
      }

      return true;
   }
}
