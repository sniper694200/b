import java.util.Collection;
import java.util.Iterator;
import javax.annotation.Nullable;

public class acq extends adc {
   private static final mx<Integer> a;
   private static final mx<Boolean> b;
   private static final mx<Boolean> c;
   private int bx;
   private int by;
   private int bz = 30;
   private int bA = 3;
   private int bB;

   public acq(ams var1) {
      super(var1);
      this.a(0.6F, 1.7F);
   }

   protected void r() {
      this.br.a(1, new wx(this));
      this.br.a(2, new yh(this));
      this.br.a(3, new wq(this, zz.class, 6.0F, 1.0D, 1.2D));
      this.br.a(4, new xm(this, 1.0D, false));
      this.br.a(5, new yn(this, 0.8D));
      this.br.a(6, new xj(this, aeb.class, 8.0F));
      this.br.a(6, new xz(this));
      this.bs.a(1, new yu(this, aeb.class, true));
      this.bs.a(2, new yr(this, false, new Class[0]));
   }

   protected void bM() {
      super.bM();
      this.a((wa)adf.d).a(0.25D);
   }

   public int bg() {
      return this.z() == null ? 3 : 3 + (int)(this.cd() - 1.0F);
   }

   public void e(float var1, float var2) {
      super.e(var1, var2);
      this.by = (int)((float)this.by + var1 * 1.5F);
      if (this.by > this.bz - 5) {
         this.by = this.bz - 5;
      }

   }

   protected void i() {
      super.i();
      this.Y.a((mx)a, (int)-1);
      this.Y.a((mx)b, (Object)false);
      this.Y.a((mx)c, (Object)false);
   }

   public static void a(rw var0) {
      vo.a(var0, acq.class);
   }

   public void b(fy var1) {
      super.b(var1);
      if ((Boolean)this.Y.a(b)) {
         var1.a("powered", true);
      }

      var1.a("Fuse", (short)this.bz);
      var1.a("ExplosionRadius", (byte)this.bA);
      var1.a("ignited", this.dn());
   }

   public void a(fy var1) {
      super.a(var1);
      this.Y.b(b, var1.q("powered"));
      if (var1.b("Fuse", 99)) {
         this.bz = var1.g("Fuse");
      }

      if (var1.b("ExplosionRadius", 99)) {
         this.bA = var1.f("ExplosionRadius");
      }

      if (var1.q("ignited")) {
         this.do();
      }

   }

   public void B_() {
      if (this.aC()) {
         this.bx = this.by;
         if (this.dn()) {
            this.a(1);
         }

         int var1 = this.dm();
         if (var1 > 0 && this.by == 0) {
            this.a(qd.ay, 1.0F, 0.5F);
         }

         this.by += var1;
         if (this.by < 0) {
            this.by = 0;
         }

         if (this.by >= this.bz) {
            this.by = this.bz;
            this.dr();
         }
      }

      super.B_();
   }

   protected qc d(up var1) {
      return qd.ax;
   }

   protected qc cf() {
      return qd.aw;
   }

   public void a(up var1) {
      super.a(var1);
      if (this.l.W().b("doMobLoot")) {
         if (var1.j() instanceof adi) {
            int var2 = ail.a(aip.cB);
            int var3 = ail.a(aip.cM);
            int var4 = var2 + this.S.nextInt(var3 - var2 + 1);
            this.a(ail.c(var4), 1);
         } else if (var1.j() instanceof acq && var1.j() != this && ((acq)var1.j()).p() && ((acq)var1.j()).dp()) {
            ((acq)var1.j()).dq();
            this.a(new ain(aip.ci, 1, 4), 0.0F);
         }
      }

   }

   public boolean B(ve var1) {
      return true;
   }

   public boolean p() {
      return (Boolean)this.Y.a(b);
   }

   public float a(float var1) {
      return ((float)this.bx + (float)(this.by - this.bx) * var1) / (float)(this.bz - 2);
   }

   @Nullable
   protected nd J() {
      return bfl.r;
   }

   public int dm() {
      return (Integer)this.Y.a(a);
   }

   public void a(int var1) {
      this.Y.b(a, var1);
   }

   public void a(acg var1) {
      super.a(var1);
      this.Y.b(b, true);
   }

   protected boolean a(aeb var1, tz var2) {
      ain var3 = var1.b((tz)var2);
      if (var3.c() == aip.e) {
         this.l.a(var1, this.p, this.q, this.r, qd.bO, this.bK(), 1.0F, this.S.nextFloat() * 0.4F + 0.8F);
         var1.a((tz)var2);
         if (!this.l.G) {
            this.do();
            var3.a(1, var1);
            return true;
         }
      }

      return super.a(var1, var2);
   }

   private void dr() {
      if (!this.l.G) {
         boolean var1 = this.l.W().b("mobGriefing");
         float var2 = this.p() ? 2.0F : 1.0F;
         this.aU = true;
         this.l.a(this, this.p, this.q, this.r, (float)this.bA * var2, var1);
         this.X();
         this.ds();
      }

   }

   private void ds() {
      Collection<uy> var1 = this.ca();
      if (!var1.isEmpty()) {
         vc var2 = new vc(this.l, this.p, this.q, this.r);
         var2.a(2.5F);
         var2.b(-0.5F);
         var2.g(10);
         var2.e(var2.r() / 2);
         var2.c(-var2.j() / (float)var2.r());
         Iterator var3 = var1.iterator();

         while(var3.hasNext()) {
            uy var4 = (uy)var3.next();
            var2.a(new uy(var4));
         }

         this.l.a((ve)var2);
      }

   }

   public boolean dn() {
      return (Boolean)this.Y.a(c);
   }

   public void do() {
      this.Y.b(c, true);
   }

   public boolean dp() {
      return this.bB < 1 && this.l.W().b("doMobLoot");
   }

   public void dq() {
      ++this.bB;
   }

   static {
      a = na.a(acq.class, mz.b);
      b = na.a(acq.class, mz.h);
      c = na.a(acq.class, mz.h);
   }
}
