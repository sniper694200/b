public class xk extends xj {
   private final adw e;

   public xk(adw var1) {
      super(var1, aeb.class, 8.0F);
      this.e = var1;
   }

   public boolean a() {
      if (this.e.do()) {
         this.b = this.e.t_();
         return true;
      } else {
         return false;
      }
   }
}
