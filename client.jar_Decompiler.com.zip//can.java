public class can extends bze<aep> {
   private static final nd a = new nd("textures/entity/shulker/spark.png");
   private final bqp f = new bqp();

   public can(bzd var1) {
      super(var1);
   }

   private float a(float var1, float var2, float var3) {
      float var4;
      for(var4 = var2 - var1; var4 < -180.0F; var4 += 360.0F) {
      }

      while(var4 >= 180.0F) {
         var4 -= 360.0F;
      }

      return var1 + var3 * var4;
   }

   public void a(aep var1, double var2, double var4, double var6, float var8, float var9) {
      buq.G();
      float var10 = this.a(var1.x, var1.v, var9);
      float var11 = var1.y + (var1.w - var1.y) * var9;
      float var12 = (float)var1.T + var9;
      buq.c((float)var2, (float)var4 + 0.15F, (float)var6);
      buq.b(ri.a(var12 * 0.1F) * 180.0F, 0.0F, 1.0F, 0.0F);
      buq.b(ri.b(var12 * 0.1F) * 180.0F, 1.0F, 0.0F, 0.0F);
      buq.b(ri.a(var12 * 0.15F) * 360.0F, 0.0F, 0.0F, 1.0F);
      float var13 = 0.03125F;
      buq.D();
      buq.b(-1.0F, -1.0F, 1.0F);
      this.d(var1);
      this.f.a(var1, 0.0F, 0.0F, 0.0F, var10, var11, 0.03125F);
      buq.m();
      buq.c(1.0F, 1.0F, 1.0F, 0.5F);
      buq.b(1.5F, 1.5F, 1.5F);
      this.f.a(var1, 0.0F, 0.0F, 0.0F, var10, var11, 0.03125F);
      buq.l();
      buq.H();
      super.a(var1, var2, var4, var6, var8, var9);
   }

   protected nd a(aep var1) {
      return a;
   }
}
