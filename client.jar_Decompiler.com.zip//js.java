import java.io.IOException;

public class js implements ht<hw> {
   private int[] a;

   public js() {
   }

   public js(int... var1) {
      this.a = var1;
   }

   public void a(gy var1) throws IOException {
      this.a = new int[var1.g()];

      for(int var2 = 0; var2 < this.a.length; ++var2) {
         this.a[var2] = var1.g();
      }

   }

   public void b(gy var1) throws IOException {
      var1.d(this.a.length);
      int[] var2 = this.a;
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         int var5 = var2[var4];
         var1.d(var5);
      }

   }

   public void a(hw var1) {
      var1.a(this);
   }

   public int[] a() {
      return this.a;
   }
}
