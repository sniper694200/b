public class ape extends apq {
   private static final bgz[] a = new bgz[]{new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.125D, 1.0D), new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.1875D, 1.0D), new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.25D, 1.0D), new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.3125D, 1.0D), new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.375D, 1.0D), new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.4375D, 1.0D), new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.5D, 1.0D), new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.5625D, 1.0D)};

   protected ail h() {
      return aip.cc;
   }

   protected ail i() {
      return aip.cc;
   }

   public bgz b(awr var1, amw var2, et var3) {
      return a[(Integer)var1.c(this.e())];
   }
}
