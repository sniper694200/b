import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;

public class avj extends avy implements nv {
   private fi<ain> p;
   public boolean a;
   public avj f;
   public avj g;
   public avj h;
   public avj i;
   public float j;
   public float k;
   public int l;
   private int q;
   private apg.a r;

   public avj() {
      this.p = fi.a(27, ain.a);
   }

   public avj(apg.a var1) {
      this.p = fi.a(27, ain.a);
      this.r = var1;
   }

   public int w_() {
      return 27;
   }

   public boolean x_() {
      Iterator var1 = this.p.iterator();

      ain var2;
      do {
         if (!var1.hasNext()) {
            return true;
         }

         var2 = (ain)var1.next();
      } while(var2.b());

      return false;
   }

   public String h_() {
      return this.n_() ? this.o : "container.chest";
   }

   public static void a(rw var0) {
      var0.a((ru)ru.d, (ry)(new tl(avj.class, new String[]{"Items"})));
   }

   public void a(fy var1) {
      super.a((fy)var1);
      this.p = fi.a(this.w_(), ain.a);
      if (!this.c(var1)) {
         tu.b(var1, this.p);
      }

      if (var1.b("CustomName", 8)) {
         this.o = var1.l("CustomName");
      }

   }

   public fy b(fy var1) {
      super.b(var1);
      if (!this.d(var1)) {
         tu.a(var1, this.p);
      }

      if (this.n_()) {
         var1.a("CustomName", this.o);
      }

      return var1;
   }

   public int z_() {
      return 64;
   }

   public void B() {
      super.B();
      this.a = false;
   }

   private void a(avj var1, fa var2) {
      if (var1.y()) {
         this.a = false;
      } else if (this.a) {
         switch(var2) {
         case c:
            if (this.f != var1) {
               this.a = false;
            }
            break;
         case d:
            if (this.i != var1) {
               this.a = false;
            }
            break;
         case f:
            if (this.g != var1) {
               this.a = false;
            }
            break;
         case e:
            if (this.h != var1) {
               this.a = false;
            }
         }
      }

   }

   public void o() {
      if (!this.a) {
         this.a = true;
         this.h = this.a(fa.e);
         this.g = this.a(fa.f);
         this.f = this.a(fa.c);
         this.i = this.a(fa.d);
      }
   }

   @Nullable
   protected avj a(fa var1) {
      et var2 = this.c.a(var1);
      if (this.b(var2)) {
         avh var3 = this.b.r(var2);
         if (var3 instanceof avj) {
            avj var4 = (avj)var3;
            var4.a(this, var1.d());
            return var4;
         }
      }

      return null;
   }

   private boolean b(et var1) {
      if (this.b == null) {
         return false;
      } else {
         aou var2 = this.b.o(var1).u();
         return var2 instanceof apg && ((apg)var2).g == this.p();
      }
   }

   public void e() {
      this.o();
      int var1 = this.c.p();
      int var2 = this.c.q();
      int var3 = this.c.r();
      ++this.q;
      float var4;
      if (!this.b.G && this.l != 0 && (this.q + var1 + var2 + var3) % 200 == 0) {
         this.l = 0;
         var4 = 5.0F;
         List<aeb> var5 = this.b.a(aeb.class, new bgz((double)((float)var1 - 5.0F), (double)((float)var2 - 5.0F), (double)((float)var3 - 5.0F), (double)((float)(var1 + 1) + 5.0F), (double)((float)(var2 + 1) + 5.0F), (double)((float)(var3 + 1) + 5.0F)));
         Iterator var6 = var5.iterator();

         label93:
         while(true) {
            tt var8;
            do {
               aeb var7;
               do {
                  if (!var6.hasNext()) {
                     break label93;
                  }

                  var7 = (aeb)var6.next();
               } while(!(var7.by instanceof aft));

               var8 = ((aft)var7.by).e();
            } while(var8 != this && (!(var8 instanceof ts) || !((ts)var8).a((tt)this)));

            ++this.l;
         }
      }

      this.k = this.j;
      var4 = 0.1F;
      double var14;
      if (this.l > 0 && this.j == 0.0F && this.f == null && this.h == null) {
         double var11 = (double)var1 + 0.5D;
         var14 = (double)var3 + 0.5D;
         if (this.i != null) {
            var14 += 0.5D;
         }

         if (this.g != null) {
            var11 += 0.5D;
         }

         this.b.a((aeb)null, var11, (double)var2 + 0.5D, var14, qd.ac, qe.e, 0.5F, this.b.r.nextFloat() * 0.1F + 0.9F);
      }

      if (this.l == 0 && this.j > 0.0F || this.l > 0 && this.j < 1.0F) {
         float var12 = this.j;
         if (this.l > 0) {
            this.j += 0.1F;
         } else {
            this.j -= 0.1F;
         }

         if (this.j > 1.0F) {
            this.j = 1.0F;
         }

         float var13 = 0.5F;
         if (this.j < 0.5F && var12 >= 0.5F && this.f == null && this.h == null) {
            var14 = (double)var1 + 0.5D;
            double var9 = (double)var3 + 0.5D;
            if (this.i != null) {
               var9 += 0.5D;
            }

            if (this.g != null) {
               var14 += 0.5D;
            }

            this.b.a((aeb)null, var14, (double)var2 + 0.5D, var9, qd.aa, qe.e, 0.5F, this.b.r.nextFloat() * 0.1F + 0.9F);
         }

         if (this.j < 0.0F) {
            this.j = 0.0F;
         }
      }

   }

   public boolean c(int var1, int var2) {
      if (var1 == 1) {
         this.l = var2;
         return true;
      } else {
         return super.c(var1, var2);
      }
   }

   public void b(aeb var1) {
      if (!var1.y()) {
         if (this.l < 0) {
            this.l = 0;
         }

         ++this.l;
         this.b.c(this.c, this.x(), 1, this.l);
         this.b.b(this.c, this.x(), false);
         if (this.p() == apg.a.b) {
            this.b.b(this.c.b(), this.x(), false);
         }
      }

   }

   public void c(aeb var1) {
      if (!var1.y() && this.x() instanceof apg) {
         --this.l;
         this.b.c(this.c, this.x(), 1, this.l);
         this.b.b(this.c, this.x(), false);
         if (this.p() == apg.a.b) {
            this.b.b(this.c.b(), this.x(), false);
         }
      }

   }

   public void z() {
      super.z();
      this.B();
      this.o();
   }

   public apg.a p() {
      if (this.r == null) {
         if (this.b == null || !(this.x() instanceof apg)) {
            return apg.a.a;
         }

         this.r = ((apg)this.x()).g;
      }

      return this.r;
   }

   public String l() {
      return "minecraft:chest";
   }

   public afp a(aea var1, aeb var2) {
      this.d(var2);
      return new aft(var1, this, var2);
   }

   protected fi<ain> q() {
      return this.p;
   }
}
