import java.util.Iterator;
import java.util.List;

public class aeg extends aej {
   public aeg(ams var1) {
      super(var1);
      this.a(1.0F, 1.0F);
   }

   public aeg(ams var1, double var2, double var4, double var6, double var8, double var10, double var12) {
      super(var1, var2, var4, var6, var8, var10, var12);
      this.a(1.0F, 1.0F);
   }

   public aeg(ams var1, vn var2, double var3, double var5, double var7) {
      super(var1, var2, var3, var5, var7);
      this.a(1.0F, 1.0F);
   }

   public static void a(rw var0) {
      aej.a(var0, "DragonFireball");
   }

   protected void a(bha var1) {
      if (var1.d == null || !var1.d.s(this.a)) {
         if (!this.l.G) {
            List<vn> var2 = this.l.a(vn.class, this.bw().c(4.0D, 2.0D, 4.0D));
            vc var3 = new vc(this.l, this.p, this.q, this.r);
            var3.a(this.a);
            var3.a(fj.Q);
            var3.a(3.0F);
            var3.e(600);
            var3.c((7.0F - var3.j()) / (float)var3.r());
            var3.a(new uy(uz.g, 1, 1));
            if (!var2.isEmpty()) {
               Iterator var4 = var2.iterator();

               while(var4.hasNext()) {
                  vn var5 = (vn)var4.next();
                  double var6 = this.h(var5);
                  if (var6 < 16.0D) {
                     var3.b(var5.p, var5.q, var5.r);
                     break;
                  }
               }
            }

            this.l.b(2006, new et(this.p, this.q, this.r), 0);
            this.l.a((ve)var3);
            this.X();
         }

      }
   }

   public boolean ay() {
      return false;
   }

   public boolean a(up var1, float var2) {
      return false;
   }

   protected fj j() {
      return fj.Q;
   }

   protected boolean k() {
      return false;
   }
}
