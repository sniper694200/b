import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public class cn extends bi {
   private static final String[] a = new String[]{"Yolo", "Ask for help on twitter", "/deop @p", "Scoreboard deleted, commands blocked", "Contact helpdesk for help", "/testfornoob @p", "/trigger warning", "Oh my god, it's full of stats", "/kill @p[name=!Searge]", "Have you tried turning it off and on again?", "Sorry, no help today"};
   private final Random b = new Random();

   public String c() {
      return "help";
   }

   public int a() {
      return 0;
   }

   public String b(bn var1) {
      return "commands.help.usage";
   }

   public List<String> b() {
      return Arrays.asList("?");
   }

   public void a(MinecraftServer var1, bn var2, String[] var3) throws ei {
      if (var2 instanceof amh) {
         var2.a((new ho("Searge says: ")).a(a[this.b.nextInt(a.length) % a.length]));
      } else {
         List<bk> var4 = this.a(var2, var1);
         int var5 = true;
         int var6 = (var4.size() - 1) / 7;
         boolean var7 = false;

         int var14;
         try {
            var14 = var3.length == 0 ? 0 : a(var3[0], 1, var6 + 1) - 1;
         } catch (el var13) {
            Map<String, bk> var9 = this.a(var1);
            bk var10 = (bk)var9.get(var3[0]);
            if (var10 != null) {
               throw new ep(var10.b(var2), new Object[0]);
            }

            if (ri.a(var3[0], -1) == -1 && ri.a(var3[0], -2) == -2) {
               throw new eo();
            }

            throw var13;
         }

         int var8 = Math.min((var14 + 1) * 7, var4.size());
         hp var15 = new hp("commands.help.header", new Object[]{var14 + 1, var6 + 1});
         var15.b().a(.a.c);
         var2.a(var15);

         for(int var16 = var14 * 7; var16 < var8; ++var16) {
            bk var11 = (bk)var4.get(var16);
            hp var12 = new hp(var11.b(var2), new Object[0]);
            var12.b().a(new hg(hg.a.d, "/" + var11.c() + " "));
            var2.a(var12);
         }

         if (var14 == 0) {
            hp var17 = new hp("commands.help.footer", new Object[0]);
            var17.b().a(.a.k);
            var2.a(var17);
         }

      }
   }

   protected List<bk> a(bn var1, MinecraftServer var2) {
      List<bk> var3 = var2.N().a(var1);
      Collections.sort(var3);
      return var3;
   }

   protected Map<String, bk> a(MinecraftServer var1) {
      return var1.N().b();
   }

   public List<String> a(MinecraftServer var1, bn var2, String[] var3, @Nullable et var4) {
      if (var3.length == 1) {
         Set<String> var5 = this.a(var1).keySet();
         return a(var3, (String[])var5.toArray(new String[var5.size()]));
      } else {
         return Collections.emptyList();
      }
   }
}
