import javax.annotation.Nullable;

public class aif extends ail {
   public aif() {
      this.e(64);
      this.d(1);
      this.b(ahn.i);
      this.a(new nd("cast"), new aio() {
         public float a(ain var1, @Nullable ams var2, @Nullable vn var3) {
            if (var3 == null) {
               return 0.0F;
            } else {
               boolean var4 = var3.co() == var1;
               boolean var5 = var3.cp() == var1;
               if (var3.co().c() instanceof aif) {
                  var5 = false;
               }

               return (var4 || var5) && var3 instanceof aeb && ((aeb)var3).bU != null ? 1.0F : 0.0F;
            }
         }
      });
   }

   public boolean D_() {
      return true;
   }

   public boolean F_() {
      return true;
   }

   public uc<ain> a(ams var1, aeb var2, tz var3) {
      ain var4 = var2.b((tz)var3);
      if (var2.bU != null) {
         int var5 = var2.bU.j();
         var4.a(var5, var2);
         var2.a((tz)var3);
         var1.a((aeb)null, var2.p, var2.q, var2.r, qd.J, qe.g, 1.0F, 0.4F / (j.nextFloat() * 0.4F + 0.8F));
      } else {
         var1.a((aeb)null, var2.p, var2.q, var2.r, qd.L, qe.g, 0.5F, 0.4F / (j.nextFloat() * 0.4F + 0.8F));
         if (!var1.G) {
            acd var8 = new acd(var1, var2);
            int var6 = alk.c(var4);
            if (var6 > 0) {
               var8.a(var6);
            }

            int var7 = alk.b(var4);
            if (var7 > 0) {
               var8.c(var7);
            }

            var1.a((ve)var8);
         }

         var2.a((tz)var3);
         var2.b(qq.b((ail)this));
      }

      return new uc(ub.a, var4);
   }

   public int c() {
      return 1;
   }
}
