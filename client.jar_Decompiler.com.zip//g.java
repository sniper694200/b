import io.netty.util.ResourceLeakDetector;
import io.netty.util.ResourceLeakDetector.Level;

public class g {
   public static final Level a;
   public static final char[] b;
   public static final char[] c;

   public static boolean a(char var0) {
      return var0 != 167 && var0 >= ' ' && var0 != 127;
   }

   public static String a(String var0) {
      StringBuilder var1 = new StringBuilder();
      char[] var2 = var0.toCharArray();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         char var5 = var2[var4];
         if (a(var5)) {
            var1.append(var5);
         }
      }

      return var1.toString();
   }

   static {
      a = Level.DISABLED;
      b = new char[]{'.', '\n', '\r', '\t', '\u0000', '\f', '`', '?', '*', '\\', '<', '>', '|', '"'};
      c = new char[]{'/', '\n', '\r', '\t', '\u0000', '\f', '`', '?', '*', '\\', '<', '>', '|', '"', ':'};
      ResourceLeakDetector.setLevel(a);
   }
}
