import com.google.common.base.Predicate;
import javax.annotation.Nullable;

public class acy extends adc {
   private static final mx<Boolean> bA;
   private static final mx<Integer> bB;
   protected float a;
   protected float b;
   protected float c;
   protected float bx;
   protected float by;
   private vn bC;
   private int bD;
   private boolean bE;
   protected ya bz;

   public acy(ams var1) {
      super(var1);
      this.b_ = 10;
      this.a(0.85F, 0.85F);
      this.f = new acy.c(this);
      this.a = this.S.nextFloat();
      this.b = this.a;
   }

   protected void r() {
      xq var1 = new xq(this, 1.0D);
      this.bz = new ya(this, 1.0D, 80);
      this.br.a(4, new acy.a(this));
      this.br.a(5, var1);
      this.br.a(7, this.bz);
      this.br.a(8, new xj(this, aeb.class, 8.0F));
      this.br.a(8, new xj(this, acy.class, 12.0F, 0.01F));
      this.br.a(9, new xz(this));
      this.bz.a(3);
      var1.a(3);
      this.bs.a(1, new yu(this, vn.class, 10, true, false, new acy.b(this)));
   }

   protected void bM() {
      super.bM();
      this.a((wa)adf.f).a(6.0D);
      this.a((wa)adf.d).a(0.5D);
      this.a((wa)adf.b).a(16.0D);
      this.a((wa)adf.a).a(30.0D);
   }

   public static void c(rw var0) {
      vo.a(var0, acy.class);
   }

   protected zc b(ams var1) {
      return new zf(this, var1);
   }

   protected void i() {
      super.i();
      this.Y.a((mx)bA, (Object)false);
      this.Y.a((mx)bB, (int)0);
   }

   public boolean do() {
      return (Boolean)this.Y.a(bA);
   }

   private void a(boolean var1) {
      this.Y.b(bA, var1);
   }

   public int p() {
      return 80;
   }

   private void a(int var1) {
      this.Y.b(bB, var1);
   }

   public boolean dp() {
      return (Integer)this.Y.a(bB) != 0;
   }

   @Nullable
   public vn dq() {
      if (!this.dp()) {
         return null;
      } else if (this.l.G) {
         if (this.bC != null) {
            return this.bC;
         } else {
            ve var1 = this.l.a((Integer)this.Y.a(bB));
            if (var1 instanceof vn) {
               this.bC = (vn)var1;
               return this.bC;
            } else {
               return null;
            }
         }
      } else {
         return this.z();
      }
   }

   public void a(mx<?> var1) {
      super.a(var1);
      if (bB.equals(var1)) {
         this.bD = 0;
         this.bC = null;
      }

   }

   public int C() {
      return 160;
   }

   protected qc F() {
      return this.ao() ? qd.cw : qd.cx;
   }

   protected qc d(up var1) {
      return this.ao() ? qd.cC : qd.cD;
   }

   protected qc cf() {
      return this.ao() ? qd.cz : qd.cA;
   }

   protected boolean ak() {
      return false;
   }

   public float by() {
      return this.H * 0.5F;
   }

   public float a(et var1) {
      return this.l.o(var1).a() == bcx.h ? 10.0F + this.l.n(var1) - 0.5F : super.a(var1);
   }

   public void n() {
      if (this.l.G) {
         this.b = this.a;
         if (!this.ao()) {
            this.c = 2.0F;
            if (this.t > 0.0D && this.bE && !this.ai()) {
               this.l.a(this.p, this.q, this.r, this.dn(), this.bK(), 1.0F, 1.0F, false);
            }

            this.bE = this.t < 0.0D && this.l.d((new et(this)).b(), false);
         } else if (this.do()) {
            if (this.c < 0.5F) {
               this.c = 4.0F;
            } else {
               this.c += (0.5F - this.c) * 0.1F;
            }
         } else {
            this.c += (0.125F - this.c) * 0.2F;
         }

         this.a += this.c;
         this.by = this.bx;
         if (!this.ao()) {
            this.bx = this.S.nextFloat();
         } else if (this.do()) {
            this.bx += (0.0F - this.bx) * 0.25F;
         } else {
            this.bx += (1.0F - this.bx) * 0.06F;
         }

         if (this.do() && this.ao()) {
            bhc var1 = this.e(0.0F);

            for(int var2 = 0; var2 < 2; ++var2) {
               this.l.a(fj.e, this.p + (this.S.nextDouble() - 0.5D) * (double)this.G - var1.b * 1.5D, this.q + this.S.nextDouble() * (double)this.H - var1.c * 1.5D, this.r + (this.S.nextDouble() - 0.5D) * (double)this.G - var1.d * 1.5D, 0.0D, 0.0D, 0.0D);
            }
         }

         if (this.dp()) {
            if (this.bD < this.p()) {
               ++this.bD;
            }

            vn var14 = this.dq();
            if (var14 != null) {
               this.t().a(var14, 90.0F, 90.0F);
               this.t().a();
               double var15 = (double)this.s(0.0F);
               double var4 = var14.p - this.p;
               double var6 = var14.q + (double)(var14.H * 0.5F) - (this.q + (double)this.by());
               double var8 = var14.r - this.r;
               double var10 = Math.sqrt(var4 * var4 + var6 * var6 + var8 * var8);
               var4 /= var10;
               var6 /= var10;
               var8 /= var10;
               double var12 = this.S.nextDouble();

               while(var12 < var10) {
                  var12 += 1.8D - var15 + this.S.nextDouble() * (1.7D - var15);
                  this.l.a(fj.e, this.p + var4 * var12, this.q + var6 * var12 + (double)this.by(), this.r + var8 * var12, 0.0D, 0.0D, 0.0D);
               }
            }
         }
      }

      if (this.U) {
         this.l(300);
      } else if (this.z) {
         this.t += 0.5D;
         this.s += (double)((this.S.nextFloat() * 2.0F - 1.0F) * 0.4F);
         this.u += (double)((this.S.nextFloat() * 2.0F - 1.0F) * 0.4F);
         this.v = this.S.nextFloat() * 360.0F;
         this.z = false;
         this.ai = true;
      }

      if (this.dp()) {
         this.v = this.aP;
      }

      super.n();
   }

   protected qc dn() {
      return qd.cB;
   }

   public float a(float var1) {
      return this.b + (this.a - this.b) * var1;
   }

   public float r(float var1) {
      return this.by + (this.bx - this.by) * var1;
   }

   public float s(float var1) {
      return ((float)this.bD + var1) / (float)this.p();
   }

   @Nullable
   protected nd J() {
      return bfl.x;
   }

   protected boolean s_() {
      return true;
   }

   public boolean Q() {
      return this.l.a((bgz)this.bw(), (ve)this) && this.l.a((ve)this, (bgz)this.bw()).isEmpty();
   }

   public boolean P() {
      return (this.S.nextInt(20) == 0 || !this.l.i(new et(this))) && super.P();
   }

   public boolean a(up var1, float var2) {
      if (!this.do() && !var1.s() && var1.i() instanceof vn) {
         vn var3 = (vn)var1.i();
         if (!var1.c()) {
            var3.a(up.a((ve)this), 2.0F);
         }
      }

      if (this.bz != null) {
         this.bz.i();
      }

      return super.a(var1, var2);
   }

   public int N() {
      return 180;
   }

   public void a(float var1, float var2, float var3) {
      if (this.cC() && this.ao()) {
         this.b(var1, var2, var3, 0.1F);
         this.a(vt.a, this.s, this.t, this.u);
         this.s *= 0.8999999761581421D;
         this.t *= 0.8999999761581421D;
         this.u *= 0.8999999761581421D;
         if (!this.do() && this.z() == null) {
            this.t -= 0.005D;
         }
      } else {
         super.a(var1, var2, var3);
      }

   }

   static {
      bA = na.a(acy.class, mz.h);
      bB = na.a(acy.class, mz.b);
   }

   static class c extends wo {
      private final acy i;

      public c(acy var1) {
         super(var1);
         this.i = var1;
      }

      public void a() {
         if (this.h == wo.a.b && !this.i.x().o()) {
            double var1 = this.b - this.i.p;
            double var3 = this.c - this.i.q;
            double var5 = this.d - this.i.r;
            double var7 = (double)ri.a(var1 * var1 + var3 * var3 + var5 * var5);
            var3 /= var7;
            float var9 = (float)(ri.c(var5, var1) * 57.2957763671875D) - 90.0F;
            this.i.v = this.a(this.i.v, var9, 90.0F);
            this.i.aN = this.i.v;
            float var10 = (float)(this.e * this.i.a((wa)adf.d).e());
            this.i.k(this.i.cy() + (var10 - this.i.cy()) * 0.125F);
            double var11 = Math.sin((double)(this.i.T + this.i.S()) * 0.5D) * 0.05D;
            double var13 = Math.cos((double)(this.i.v * 0.017453292F));
            double var15 = Math.sin((double)(this.i.v * 0.017453292F));
            acy var10000 = this.i;
            var10000.s += var11 * var13;
            var10000 = this.i;
            var10000.u += var11 * var15;
            var11 = Math.sin((double)(this.i.T + this.i.S()) * 0.75D) * 0.05D;
            var10000 = this.i;
            var10000.t += var11 * (var15 + var13) * 0.25D;
            var10000 = this.i;
            var10000.t += (double)this.i.cy() * var3 * 0.1D;
            wn var17 = this.i.t();
            double var18 = this.i.p + var1 / var7 * 2.0D;
            double var20 = (double)this.i.by() + this.i.q + var3 / var7;
            double var22 = this.i.r + var5 / var7 * 2.0D;
            double var24 = var17.e();
            double var26 = var17.f();
            double var28 = var17.g();
            if (!var17.b()) {
               var24 = var18;
               var26 = var20;
               var28 = var22;
            }

            this.i.t().a(var24 + (var18 - var24) * 0.125D, var26 + (var20 - var26) * 0.125D, var28 + (var22 - var28) * 0.125D, 10.0F, 40.0F);
            this.i.a(true);
         } else {
            this.i.k(0.0F);
            this.i.a(false);
         }
      }
   }

   static class a extends xc {
      private final acy a;
      private int b;
      private final boolean c;

      public a(acy var1) {
         this.a = var1;
         this.c = var1 instanceof acr;
         this.a(3);
      }

      public boolean a() {
         vn var1 = this.a.z();
         return var1 != null && var1.aC();
      }

      public boolean b() {
         return super.b() && (this.c || this.a.h(this.a.z()) > 9.0D);
      }

      public void c() {
         this.b = -10;
         this.a.x().p();
         this.a.t().a(this.a.z(), 90.0F, 90.0F);
         this.a.ai = true;
      }

      public void d() {
         this.a.a(0);
         this.a.d((vn)null);
         this.a.bz.i();
      }

      public void e() {
         vn var1 = this.a.z();
         this.a.x().p();
         this.a.t().a(var1, 90.0F, 90.0F);
         if (!this.a.D(var1)) {
            this.a.d((vn)null);
         } else {
            ++this.b;
            if (this.b == 0) {
               this.a.a(this.a.z().S());
               this.a.l.a((ve)this.a, (byte)21);
            } else if (this.b >= this.a.p()) {
               float var2 = 1.0F;
               if (this.a.l.ag() == tx.d) {
                  var2 += 2.0F;
               }

               if (this.c) {
                  var2 += 2.0F;
               }

               var1.a(up.b(this.a, this.a), var2);
               var1.a(up.a((vn)this.a), (float)this.a.a((wa)adf.f).e());
               this.a.d((vn)null);
            }

            super.e();
         }
      }
   }

   static class b implements Predicate<vn> {
      private final acy a;

      public b(acy var1) {
         this.a = var1;
      }

      public boolean a(@Nullable vn var1) {
         return (var1 instanceof aeb || var1 instanceof aah) && var1.h(this.a) > 9.0D;
      }

      // $FF: synthetic method
      public boolean apply(@Nullable Object var1) {
         return this.a((vn)var1);
      }
   }
}
