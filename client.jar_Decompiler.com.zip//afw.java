import java.util.Iterator;

public class afw implements tt {
   private final fi<ain> a;
   private final int b;
   private final int c;
   private final afp d;

   public afw(afp var1, int var2, int var3) {
      this.a = fi.a(var2 * var3, ain.a);
      this.d = var1;
      this.b = var2;
      this.c = var3;
   }

   public int w_() {
      return this.a.size();
   }

   public boolean x_() {
      Iterator var1 = this.a.iterator();

      ain var2;
      do {
         if (!var1.hasNext()) {
            return true;
         }

         var2 = (ain)var1.next();
      } while(var2.b());

      return false;
   }

   public ain a(int var1) {
      return var1 >= this.w_() ? ain.a : (ain)this.a.get(var1);
   }

   public ain c(int var1, int var2) {
      return var1 >= 0 && var1 < this.b && var2 >= 0 && var2 <= this.c ? this.a(var1 + var2 * this.b) : ain.a;
   }

   public String h_() {
      return "container.crafting";
   }

   public boolean n_() {
      return false;
   }

   public hh i_() {
      return (hh)(this.n_() ? new ho(this.h_()) : new hp(this.h_(), new Object[0]));
   }

   public ain c_(int var1) {
      return tu.a(this.a, var1);
   }

   public ain a(int var1, int var2) {
      ain var3 = tu.a(this.a, var1, var2);
      if (!var3.b()) {
         this.d.a((tt)this);
      }

      return var3;
   }

   public void a(int var1, ain var2) {
      this.a.set(var1, var2);
      this.d.a((tt)this);
   }

   public int z_() {
      return 64;
   }

   public void y_() {
   }

   public boolean a(aeb var1) {
      return true;
   }

   public void b(aeb var1) {
   }

   public void c(aeb var1) {
   }

   public boolean b(int var1, ain var2) {
      return true;
   }

   public int c(int var1) {
      return 0;
   }

   public void b(int var1, int var2) {
   }

   public int h() {
      return 0;
   }

   public void m() {
      this.a.clear();
   }

   public int i() {
      return this.c;
   }

   public int j() {
      return this.b;
   }

   public void a(aed var1) {
      Iterator var2 = this.a.iterator();

      while(var2.hasNext()) {
         ain var3 = (ain)var2.next();
         var1.a(var3);
      }

   }
}
