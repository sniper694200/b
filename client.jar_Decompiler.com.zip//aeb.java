import com.google.common.base.Predicate;
import com.google.common.collect.Lists;
import com.mojang.authlib.GameProfile;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;

public abstract class aeb extends vn {
   private static final mx<Float> a;
   private static final mx<Integer> b;
   protected static final mx<Byte> br;
   protected static final mx<Byte> bs;
   protected static final mx<fy> bt;
   protected static final mx<fy> bu;
   public aea bv = new aea(this);
   protected agk bw = new agk();
   public afp bx;
   public afp by;
   protected afn bz = new afn();
   protected int bA;
   public float bB;
   public float bC;
   public int bD;
   public double bE;
   public double bF;
   public double bG;
   public double bH;
   public double bI;
   public double bJ;
   protected boolean bK;
   public et bL;
   private int c;
   public float bM;
   public float cx;
   public float bN;
   private et d;
   private boolean e;
   public adz bO = new adz();
   public int bP;
   public int bQ;
   public float bR;
   protected int bS;
   protected float bT = 0.02F;
   private int f;
   private final GameProfile g;
   private boolean h;
   private ain bV;
   private final aim bW;
   @Nullable
   public acd bU;

   protected aim l() {
      return new aim();
   }

   public aeb(ams var1, GameProfile var2) {
      super(var1);
      this.bV = ain.a;
      this.bW = this.l();
      this.a((UUID)a(var2));
      this.g = var2;
      this.bx = new agg(this.bv, !var1.G, this);
      this.by = this.bx;
      et var3 = var1.T();
      this.b((double)var3.p() + 0.5D, (double)(var3.q() + 1), (double)var3.r() + 0.5D, 0.0F, 0.0F);
      this.ba = 180.0F;
   }

   protected void bM() {
      super.bM();
      this.cm().b(adf.f).a(1.0D);
      this.a((wa)adf.d).a(0.10000000149011612D);
      this.cm().b(adf.g);
      this.cm().b(adf.j);
   }

   protected void i() {
      super.i();
      this.Y.a((mx)a, (Object)0.0F);
      this.Y.a((mx)b, (int)0);
      this.Y.a((mx)br, (byte)0);
      this.Y.a((mx)bs, (byte)1);
      this.Y.a((mx)bt, (Object)(new fy()));
      this.Y.a((mx)bu, (Object)(new fy()));
   }

   public void B_() {
      this.Q = this.y();
      if (this.y()) {
         this.z = false;
      }

      if (this.bD > 0) {
         --this.bD;
      }

      if (this.cz()) {
         ++this.c;
         if (this.c > 100) {
            this.c = 100;
         }

         if (!this.l.G) {
            if (!this.s()) {
               this.a(true, true, false);
            } else if (this.l.D()) {
               this.a(false, true, true);
            }
         }
      } else if (this.c > 0) {
         ++this.c;
         if (this.c >= 110) {
            this.c = 0;
         }
      }

      super.B_();
      if (!this.l.G && this.by != null && !this.by.a(this)) {
         this.p();
         this.by = this.bx;
      }

      if (this.aR() && this.bO.a) {
         this.ab();
      }

      this.r();
      if (!this.l.G) {
         this.bz.a(this);
         this.b(qq.g);
         if (this.aC()) {
            this.b(qq.h);
         }

         if (this.aU()) {
            this.b(qq.i);
         }
      }

      int var1 = 29999999;
      double var2 = ri.a(this.p, -2.9999999E7D, 2.9999999E7D);
      double var4 = ri.a(this.r, -2.9999999E7D, 2.9999999E7D);
      if (var2 != this.p || var4 != this.r) {
         this.b(var2, this.q, var4);
      }

      ++this.aE;
      ain var6 = this.co();
      if (!ain.b(this.bV, var6)) {
         if (!ain.d(this.bV, var6)) {
            this.ds();
         }

         this.bV = var6.b() ? ain.a : var6.l();
      }

      this.bW.a();
      this.cT();
   }

   private void r() {
      this.bE = this.bH;
      this.bF = this.bI;
      this.bG = this.bJ;
      double var1 = this.p - this.bH;
      double var3 = this.q - this.bI;
      double var5 = this.r - this.bJ;
      double var7 = 10.0D;
      if (var1 > 10.0D) {
         this.bH = this.p;
         this.bE = this.bH;
      }

      if (var5 > 10.0D) {
         this.bJ = this.r;
         this.bG = this.bJ;
      }

      if (var3 > 10.0D) {
         this.bI = this.q;
         this.bF = this.bI;
      }

      if (var1 < -10.0D) {
         this.bH = this.p;
         this.bE = this.bH;
      }

      if (var5 < -10.0D) {
         this.bJ = this.r;
         this.bG = this.bJ;
      }

      if (var3 < -10.0D) {
         this.bI = this.q;
         this.bF = this.bI;
      }

      this.bH += var1 * 0.25D;
      this.bJ += var5 * 0.25D;
      this.bI += var3 * 0.25D;
   }

   protected void cT() {
      float var1;
      float var2;
      if (this.cP()) {
         var1 = 0.6F;
         var2 = 0.6F;
      } else if (this.cz()) {
         var1 = 0.2F;
         var2 = 0.2F;
      } else if (this.aU()) {
         var1 = 0.6F;
         var2 = 1.65F;
      } else {
         var1 = 0.6F;
         var2 = 1.8F;
      }

      if (var1 != this.G || var2 != this.H) {
         bgz var3 = this.bw();
         var3 = new bgz(var3.a, var3.b, var3.c, var3.a + (double)var1, var3.b + (double)var2, var3.c + (double)var1);
         if (!this.l.a(var3)) {
            this.a(var1, var2);
         }
      }

   }

   public int Z() {
      return this.bO.a ? 1 : 80;
   }

   protected qc ae() {
      return qd.fL;
   }

   protected qc af() {
      return qd.fK;
   }

   public int aM() {
      return 10;
   }

   public void a(qc var1, float var2, float var3) {
      this.l.a(this, this.p, this.q, this.r, var1, this.bK(), var2, var3);
   }

   public qe bK() {
      return qe.h;
   }

   protected int bL() {
      return 20;
   }

   public void a(byte var1) {
      if (var1 == 9) {
         this.v();
      } else if (var1 == 23) {
         this.h = false;
      } else if (var1 == 22) {
         this.h = true;
      } else {
         super.a(var1);
      }

   }

   protected boolean cs() {
      return this.cd() <= 0.0F || this.cz();
   }

   protected void p() {
      this.by = this.bx;
   }

   public void aE() {
      if (!this.l.G && this.aU() && this.aS()) {
         this.o();
         this.e(false);
      } else {
         double var1 = this.p;
         double var3 = this.q;
         double var5 = this.r;
         float var7 = this.v;
         float var8 = this.w;
         super.aE();
         this.bB = this.bC;
         this.bC = 0.0F;
         this.l(this.p - var1, this.q - var3, this.r - var5);
         if (this.bJ() instanceof aab) {
            this.w = var8;
            this.v = var7;
            this.aN = ((aab)this.bJ()).aN;
         }

      }
   }

   public void W() {
      this.a(0.6F, 1.8F);
      super.W();
      this.c(this.cj());
      this.aB = 0;
   }

   protected void cA() {
      super.cA();
      this.cl();
      this.aP = this.v;
   }

   public void n() {
      if (this.bA > 0) {
         --this.bA;
      }

      if (this.l.ag() == tx.a && this.l.W().b("naturalRegeneration")) {
         if (this.cd() < this.cj() && this.T % 20 == 0) {
            this.b(1.0F);
         }

         if (this.bz.c() && this.T % 10 == 0) {
            this.bz.a(this.bz.a() + 1);
         }
      }

      this.bv.n();
      this.bB = this.bC;
      super.n();
      wb var1 = this.a((wa)adf.d);
      if (!this.l.G) {
         var1.a((double)this.bO.b());
      }

      this.aR = this.bT;
      if (this.aV()) {
         this.aR = (float)((double)this.aR + (double)this.bT * 0.3D);
      }

      this.k((float)var1.e());
      float var2 = ri.a(this.s * this.s + this.u * this.u);
      float var3 = (float)(Math.atan(-this.t * 0.20000000298023224D) * 15.0D);
      if (var2 > 0.1F) {
         var2 = 0.1F;
      }

      if (!this.z || this.cd() <= 0.0F) {
         var2 = 0.0F;
      }

      if (this.z || this.cd() <= 0.0F) {
         var3 = 0.0F;
      }

      this.bC += (var2 - this.bC) * 0.4F;
      this.aK += (var3 - this.aK) * 0.8F;
      if (this.cd() > 0.0F && !this.y()) {
         bgz var4;
         if (this.aS() && !this.bJ().F) {
            var4 = this.bw().b(this.bJ().bw()).c(1.0D, 0.0D, 1.0D);
         } else {
            var4 = this.bw().c(1.0D, 0.5D, 1.0D);
         }

         List<ve> var5 = this.l.b((ve)this, (bgz)var4);

         for(int var6 = 0; var6 < var5.size(); ++var6) {
            ve var7 = (ve)var5.get(var6);
            if (!var7.F) {
               this.c(var7);
            }
         }
      }

      this.j(this.dp());
      this.j(this.dq());
      if (!this.l.G && (this.L > 0.5F || this.ao() || this.aS()) || this.bO.b) {
         this.dm();
      }

   }

   private void j(@Nullable fy var1) {
      if (var1 != null && !var1.e("Silent") || !var1.q("Silent")) {
         String var2 = var1.l("id");
         if (var2.equals(vg.a(aaa.class).toString())) {
            aaa.a((ams)this.l, (ve)this);
         }
      }

   }

   private void c(ve var1) {
      var1.d(this);
   }

   public int cU() {
      return (Integer)this.Y.a(b);
   }

   public void c(int var1) {
      this.Y.b(b, var1);
   }

   public void g(int var1) {
      int var2 = this.cU();
      this.Y.b(b, var2 + var1);
   }

   public void a(up var1) {
      super.a(var1);
      this.a(0.2F, 0.2F);
      this.b(this.p, this.q, this.r);
      this.t = 0.10000000149011612D;
      if ("Notch".equals(this.h_())) {
         this.a(new ain(aip.f, 1), true, false);
      }

      if (!this.l.W().b("keepInventory") && !this.y()) {
         this.cV();
         this.bv.o();
      }

      if (var1 != null) {
         this.s = (double)(-ri.b((this.aA + this.v) * 0.017453292F) * 0.1F);
         this.u = (double)(-ri.a((this.aA + this.v) * 0.017453292F) * 0.1F);
      } else {
         this.s = 0.0D;
         this.u = 0.0D;
      }

      this.b(qq.A);
      this.a(qq.h);
      this.ab();
      this.b(0, false);
   }

   protected void cV() {
      for(int var1 = 0; var1 < this.bv.w_(); ++var1) {
         ain var2 = this.bv.a(var1);
         if (!var2.b() && alk.e(var2)) {
            this.bv.c_(var1);
         }
      }

   }

   protected qc d(up var1) {
      if (var1 == up.c) {
         return qd.fH;
      } else {
         return var1 == up.h ? qd.fG : qd.fF;
      }
   }

   protected qc cf() {
      return qd.fE;
   }

   @Nullable
   public acj a(boolean var1) {
      return this.a(this.bv.a(this.bv.d, var1 && !this.bv.i().b() ? this.bv.i().E() : 1), false, true);
   }

   @Nullable
   public acj a(ain var1, boolean var2) {
      return this.a(var1, false, var2);
   }

   @Nullable
   public acj a(ain var1, boolean var2, boolean var3) {
      if (var1.b()) {
         return null;
      } else {
         double var4 = this.q - 0.30000001192092896D + (double)this.by();
         acj var6 = new acj(this.l, this.p, var4, this.r, var1);
         var6.a(40);
         if (var3) {
            var6.e(this.h_());
         }

         float var7;
         float var8;
         if (var2) {
            var7 = this.S.nextFloat() * 0.5F;
            var8 = this.S.nextFloat() * 6.2831855F;
            var6.s = (double)(-ri.a(var8) * var7);
            var6.u = (double)(ri.b(var8) * var7);
            var6.t = 0.20000000298023224D;
         } else {
            var7 = 0.3F;
            var6.s = (double)(-ri.a(this.v * 0.017453292F) * ri.b(this.w * 0.017453292F) * var7);
            var6.u = (double)(ri.b(this.v * 0.017453292F) * ri.b(this.w * 0.017453292F) * var7);
            var6.t = (double)(-ri.a(this.w * 0.017453292F) * var7 + 0.1F);
            var8 = this.S.nextFloat() * 6.2831855F;
            var7 = 0.02F * this.S.nextFloat();
            var6.s += Math.cos((double)var8) * (double)var7;
            var6.t += (double)((this.S.nextFloat() - this.S.nextFloat()) * 0.1F);
            var6.u += Math.sin((double)var8) * (double)var7;
         }

         ain var9 = this.a(var6);
         if (var3) {
            if (!var9.b()) {
               this.a(qq.e(var9.c()), var1.E());
            }

            this.b(qq.x);
         }

         return var6;
      }
   }

   protected ain a(acj var1) {
      this.l.a((ve)var1);
      return var1.k();
   }

   public float b(awr var1) {
      float var2 = this.bv.a(var1);
      if (var2 > 1.0F) {
         int var3 = alk.f(this);
         ain var4 = this.co();
         if (var3 > 0 && !var4.b()) {
            var2 += (float)(var3 * var3 + 1);
         }
      }

      if (this.a((ux)uz.c)) {
         var2 *= 1.0F + (float)(this.b((ux)uz.c).c() + 1) * 0.2F;
      }

      if (this.a((ux)uz.d)) {
         float var5;
         switch(this.b((ux)uz.d).c()) {
         case 0:
            var5 = 0.3F;
            break;
         case 1:
            var5 = 0.09F;
            break;
         case 2:
            var5 = 0.0027F;
            break;
         case 3:
         default:
            var5 = 8.1E-4F;
         }

         var2 *= var5;
      }

      if (this.a((bcx)bcx.h) && !alk.h(this)) {
         var2 /= 5.0F;
      }

      if (!this.z) {
         var2 /= 5.0F;
      }

      return var2;
   }

   public boolean c(awr var1) {
      return this.bv.b(var1);
   }

   public static void c(rw var0) {
      var0.a(ru.b, new ry() {
         public fy a(rv var1, fy var2, int var3) {
            rx.b(var1, var2, var3, "Inventory");
            rx.b(var1, var2, var3, "EnderItems");
            if (var2.b("ShoulderEntityLeft", 10)) {
               var2.a((String)"ShoulderEntityLeft", (gn)var1.a(ru.e, var2.p("ShoulderEntityLeft"), var3));
            }

            if (var2.b("ShoulderEntityRight", 10)) {
               var2.a((String)"ShoulderEntityRight", (gn)var1.a(ru.e, var2.p("ShoulderEntityRight"), var3));
            }

            return var2;
         }
      });
   }

   public void a(fy var1) {
      super.a(var1);
      this.a((UUID)a(this.g));
      ge var2 = var1.c("Inventory", 10);
      this.bv.b(var2);
      this.bv.d = var1.h("SelectedItemSlot");
      this.bK = var1.q("Sleeping");
      this.c = var1.g("SleepTimer");
      this.bR = var1.j("XpP");
      this.bP = var1.h("XpLevel");
      this.bQ = var1.h("XpTotal");
      this.bS = var1.h("XpSeed");
      if (this.bS == 0) {
         this.bS = this.S.nextInt();
      }

      this.c(var1.h("Score"));
      if (this.bK) {
         this.bL = new et(this);
         this.a(true, true, false);
      }

      if (var1.b("SpawnX", 99) && var1.b("SpawnY", 99) && var1.b("SpawnZ", 99)) {
         this.d = new et(var1.h("SpawnX"), var1.h("SpawnY"), var1.h("SpawnZ"));
         this.e = var1.q("SpawnForced");
      }

      this.bz.a(var1);
      this.bO.b(var1);
      if (var1.b("EnderItems", 9)) {
         ge var3 = var1.c("EnderItems", 10);
         this.bw.a(var3);
      }

      if (var1.b("ShoulderEntityLeft", 10)) {
         this.h(var1.p("ShoulderEntityLeft"));
      }

      if (var1.b("ShoulderEntityRight", 10)) {
         this.i(var1.p("ShoulderEntityRight"));
      }

   }

   public void b(fy var1) {
      super.b(var1);
      var1.a("DataVersion", (int)1139);
      var1.a((String)"Inventory", (gn)this.bv.a(new ge()));
      var1.a("SelectedItemSlot", this.bv.d);
      var1.a("Sleeping", this.bK);
      var1.a("SleepTimer", (short)this.c);
      var1.a("XpP", this.bR);
      var1.a("XpLevel", this.bP);
      var1.a("XpTotal", this.bQ);
      var1.a("XpSeed", this.bS);
      var1.a("Score", this.cU());
      if (this.d != null) {
         var1.a("SpawnX", this.d.p());
         var1.a("SpawnY", this.d.q());
         var1.a("SpawnZ", this.d.r());
         var1.a("SpawnForced", this.e);
      }

      this.bz.b(var1);
      this.bO.a(var1);
      var1.a((String)"EnderItems", (gn)this.bw.i());
      if (!this.dp().b_()) {
         var1.a((String)"ShoulderEntityLeft", (gn)this.dp());
      }

      if (!this.dq().b_()) {
         var1.a((String)"ShoulderEntityRight", (gn)this.dq());
      }

   }

   public boolean a(up var1, float var2) {
      if (this.b((up)var1)) {
         return false;
      } else if (this.bO.a && !var1.g()) {
         return false;
      } else {
         this.aV = 0;
         if (this.cd() <= 0.0F) {
            return false;
         } else {
            if (this.cz() && !this.l.G) {
               this.a(true, true, false);
            }

            this.dm();
            if (var1.r()) {
               if (this.l.ag() == tx.a) {
                  var2 = 0.0F;
               }

               if (this.l.ag() == tx.b) {
                  var2 = Math.min(var2 / 2.0F + 1.0F, var2);
               }

               if (this.l.ag() == tx.d) {
                  var2 = var2 * 3.0F / 2.0F;
               }
            }

            return var2 == 0.0F ? false : super.a(var1, var2);
         }
      }
   }

   protected void c(vn var1) {
      super.c(var1);
      if (var1.co().c() instanceof agw) {
         this.m(true);
      }

   }

   public boolean a(aeb var1) {
      bhk var2 = this.aY();
      bhk var3 = var1.aY();
      if (var2 == null) {
         return true;
      } else {
         return !var2.a(var3) ? true : var2.g();
      }
   }

   protected void i(float var1) {
      this.bv.a(var1);
   }

   protected void j(float var1) {
      if (var1 >= 3.0F && this.bo.c() == aip.cR) {
         int var2 = 1 + ri.d(var1);
         this.bo.a(var2, this);
         if (this.bo.b()) {
            tz var3 = this.cH();
            if (var3 == tz.a) {
               this.a(vj.a, ain.a);
            } else {
               this.a(vj.b, ain.a);
            }

            this.bo = ain.a;
            this.a(qd.gy, 0.8F, 0.8F + this.l.r.nextFloat() * 0.4F);
         }
      }

   }

   public float cW() {
      int var1 = 0;
      Iterator var2 = this.bv.b.iterator();

      while(var2.hasNext()) {
         ain var3 = (ain)var2.next();
         if (!var3.b()) {
            ++var1;
         }
      }

      return (float)var1 / (float)this.bv.b.size();
   }

   protected void d(up var1, float var2) {
      if (!this.b((up)var1)) {
         var2 = this.b(var1, var2);
         var2 = this.c(var1, var2);
         float var3 = var2;
         var2 = Math.max(var2 - this.cD(), 0.0F);
         this.m(this.cD() - (var3 - var2));
         if (var2 != 0.0F) {
            this.a(var1.f());
            float var4 = this.cd();
            this.c(this.cd() - var2);
            this.ch().a(var1, var4, var2);
            if (var2 < 3.4028235E37F) {
               this.a(qq.z, Math.round(var2 * 10.0F));
            }

         }
      }
   }

   public void a(awa var1) {
   }

   public void a(amh var1) {
   }

   public void a(avk var1) {
   }

   public void a(awc var1) {
   }

   public void a(amd var1) {
   }

   public void a(tt var1) {
   }

   public void a(aam var1, tt var2) {
   }

   public void a(ua var1) {
   }

   public void a(ain var1, tz var2) {
   }

   public ub a(ve var1, tz var2) {
      if (this.y()) {
         if (var1 instanceof tt) {
            this.a((tt)var1);
         }

         return ub.b;
      } else {
         ain var3 = this.b((tz)var2);
         ain var4 = var3.b() ? ain.a : var3.l();
         if (var1.b(this, var2)) {
            if (this.bO.d && var3 == this.b((tz)var2) && var3.E() < var4.E()) {
               var3.e(var4.E());
            }

            return ub.a;
         } else {
            if (!var3.b() && var1 instanceof vn) {
               if (this.bO.d) {
                  var3 = var4;
               }

               if (var3.a(this, (vn)var1, var2)) {
                  if (var3.b() && !this.bO.d) {
                     this.a((tz)var2, (ain)ain.a);
                  }

                  return ub.a;
               }
            }

            return ub.b;
         }
      }
   }

   public double aF() {
      return -0.35D;
   }

   public void o() {
      super.o();
      this.j = 0;
   }

   public void f(ve var1) {
      if (var1.bd()) {
         if (!var1.t(this)) {
            float var2 = (float)this.a((wa)adf.f).e();
            float var3;
            if (var1 instanceof vn) {
               var3 = alk.a(this.co(), ((vn)var1).cn());
            } else {
               var3 = alk.a(this.co(), vs.a);
            }

            float var4 = this.n(0.5F);
            var2 *= 0.2F + var4 * var4 * 0.8F;
            var3 *= var4;
            this.ds();
            if (var2 > 0.0F || var3 > 0.0F) {
               boolean var5 = var4 > 0.9F;
               boolean var6 = false;
               int var7 = 0;
               int var26 = var7 + alk.b((vn)this);
               if (this.aV() && var5) {
                  this.l.a((aeb)null, this.p, this.q, this.r, qd.fw, this.bK(), 1.0F, 1.0F);
                  ++var26;
                  var6 = true;
               }

               boolean var8 = var5 && this.L > 0.0F && !this.z && !this.m_() && !this.ao() && !this.a((ux)uz.o) && !this.aS() && var1 instanceof vn;
               var8 = var8 && !this.aV();
               if (var8) {
                  var2 *= 1.5F;
               }

               var2 += var3;
               boolean var9 = false;
               double var10 = (double)(this.J - this.I);
               if (var5 && !var8 && !var6 && this.z && var10 < (double)this.cy()) {
                  ain var12 = this.b((tz)tz.a);
                  if (var12.c() instanceof ajw) {
                     var9 = true;
                  }
               }

               float var27 = 0.0F;
               boolean var13 = false;
               int var14 = alk.c((vn)this);
               if (var1 instanceof vn) {
                  var27 = ((vn)var1).cd();
                  if (var14 > 0 && !var1.aR()) {
                     var13 = true;
                     var1.i(1);
                  }
               }

               double var15 = var1.s;
               double var17 = var1.t;
               double var19 = var1.u;
               boolean var21 = var1.a(up.a(this), var2);
               if (var21) {
                  if (var26 > 0) {
                     if (var1 instanceof vn) {
                        ((vn)var1).a(this, (float)var26 * 0.5F, (double)ri.a(this.v * 0.017453292F), (double)(-ri.b(this.v * 0.017453292F)));
                     } else {
                        var1.f((double)(-ri.a(this.v * 0.017453292F) * (float)var26 * 0.5F), 0.1D, (double)(ri.b(this.v * 0.017453292F) * (float)var26 * 0.5F));
                     }

                     this.s *= 0.6D;
                     this.u *= 0.6D;
                     this.f(false);
                  }

                  if (var9) {
                     float var22 = 1.0F + alk.a((vn)this) * var2;
                     List<vn> var23 = this.l.a(vn.class, var1.bw().c(1.0D, 0.25D, 1.0D));
                     Iterator var24 = var23.iterator();

                     while(var24.hasNext()) {
                        vn var25 = (vn)var24.next();
                        if (var25 != this && var25 != var1 && !this.r(var25) && this.h(var25) < 9.0D) {
                           var25.a(this, 0.4F, (double)ri.a(this.v * 0.017453292F), (double)(-ri.b(this.v * 0.017453292F)));
                           var25.a(up.a(this), var22);
                        }
                     }

                     this.l.a((aeb)null, this.p, this.q, this.r, qd.fz, this.bK(), 1.0F, 1.0F);
                     this.cX();
                  }

                  if (var1 instanceof oo && var1.D) {
                     ((oo)var1).a.a((ht)(new ke(var1)));
                     var1.D = false;
                     var1.s = var15;
                     var1.t = var17;
                     var1.u = var19;
                  }

                  if (var8) {
                     this.l.a((aeb)null, this.p, this.q, this.r, qd.fv, this.bK(), 1.0F, 1.0F);
                     this.a(var1);
                  }

                  if (!var8 && !var9) {
                     if (var5) {
                        this.l.a((aeb)null, this.p, this.q, this.r, qd.fy, this.bK(), 1.0F, 1.0F);
                     } else {
                        this.l.a((aeb)null, this.p, this.q, this.r, qd.fA, this.bK(), 1.0F, 1.0F);
                     }
                  }

                  if (var3 > 0.0F) {
                     this.b(var1);
                  }

                  this.z(var1);
                  if (var1 instanceof vn) {
                     alk.a((vn)((vn)var1), (ve)this);
                  }

                  alk.b((vn)this, (ve)var1);
                  ain var28 = this.co();
                  ve var29 = var1;
                  if (var1 instanceof aaz) {
                     aay var30 = ((aaz)var1).a;
                     if (var30 instanceof vn) {
                        var29 = (vn)var30;
                     }
                  }

                  if (!var28.b() && var29 instanceof vn) {
                     var28.a((vn)var29, this);
                     if (var28.b()) {
                        this.a((tz)tz.a, (ain)ain.a);
                     }
                  }

                  if (var1 instanceof vn) {
                     float var31 = var27 - ((vn)var1).cd();
                     this.a(qq.y, Math.round(var31 * 10.0F));
                     if (var14 > 0) {
                        var1.i(var14 * 4);
                     }

                     if (this.l instanceof om && var31 > 2.0F) {
                        int var32 = (int)((double)var31 * 0.5D);
                        ((om)this.l).a(fj.S, var1.p, var1.q + (double)(var1.H * 0.5F), var1.r, var32, 0.1D, 0.0D, 0.1D, 0.2D);
                     }
                  }

                  this.a(0.1F);
               } else {
                  this.l.a((aeb)null, this.p, this.q, this.r, qd.fx, this.bK(), 1.0F, 1.0F);
                  if (var13) {
                     var1.ab();
                  }
               }
            }

         }
      }
   }

   public void m(boolean var1) {
      float var2 = 0.25F + (float)alk.f(this) * 0.05F;
      if (var1) {
         var2 += 0.75F;
      }

      if (this.S.nextFloat() < var2) {
         this.dt().a(aip.cR, 100);
         this.cN();
         this.l.a((ve)this, (byte)30);
      }

   }

   public void a(ve var1) {
   }

   public void b(ve var1) {
   }

   public void cX() {
      double var1 = (double)(-ri.a(this.v * 0.017453292F));
      double var3 = (double)ri.b(this.v * 0.017453292F);
      if (this.l instanceof om) {
         ((om)this.l).a(fj.T, this.p + var1, this.q + (double)this.H * 0.5D, this.r + var3, 0, var1, 0.0D, var3, 0.0D);
      }

   }

   public void cY() {
   }

   public void X() {
      super.X();
      this.bx.b(this);
      if (this.by != null) {
         this.by.b(this);
      }

   }

   public boolean aD() {
      return !this.bK && super.aD();
   }

   public boolean cZ() {
      return false;
   }

   public GameProfile da() {
      return this.g;
   }

   public aeb.a a(et var1) {
      fa var2 = (fa)this.l.o(var1).c(ark.D);
      if (!this.l.G) {
         if (this.cz() || !this.aC()) {
            return aeb.a.e;
         }

         if (!this.l.s.d()) {
            return aeb.a.b;
         }

         if (this.l.D()) {
            return aeb.a.c;
         }

         if (!this.a(var1, var2)) {
            return aeb.a.d;
         }

         double var3 = 8.0D;
         double var5 = 5.0D;
         List<adc> var7 = this.l.a((Class)adc.class, (bgz)(new bgz((double)var1.p() - 8.0D, (double)var1.q() - 5.0D, (double)var1.r() - 8.0D, (double)var1.p() + 8.0D, (double)var1.q() + 5.0D, (double)var1.r() + 8.0D)), (Predicate)(new aeb.c(this)));
         if (!var7.isEmpty()) {
            return aeb.a.f;
         }
      }

      if (this.aS()) {
         this.o();
      }

      this.dm();
      this.a(0.2F, 0.2F);
      if (this.l.e(var1)) {
         float var8 = 0.5F + (float)var2.g() * 0.4F;
         float var4 = 0.5F + (float)var2.i() * 0.4F;
         this.a(var2);
         this.b((double)((float)var1.p() + var8), (double)((float)var1.q() + 0.6875F), (double)((float)var1.r() + var4));
      } else {
         this.b((double)((float)var1.p() + 0.5F), (double)((float)var1.q() + 0.6875F), (double)((float)var1.r() + 0.5F));
      }

      this.bK = true;
      this.c = 0;
      this.bL = var1;
      this.s = 0.0D;
      this.t = 0.0D;
      this.u = 0.0D;
      if (!this.l.G) {
         this.l.e();
      }

      return aeb.a.a;
   }

   private boolean a(et var1, fa var2) {
      if (Math.abs(this.p - (double)var1.p()) <= 3.0D && Math.abs(this.q - (double)var1.q()) <= 2.0D && Math.abs(this.r - (double)var1.r()) <= 3.0D) {
         return true;
      } else {
         et var3 = var1.a(var2.d());
         return Math.abs(this.p - (double)var3.p()) <= 3.0D && Math.abs(this.q - (double)var3.q()) <= 2.0D && Math.abs(this.r - (double)var3.r()) <= 3.0D;
      }
   }

   private void a(fa var1) {
      this.bM = -1.8F * (float)var1.g();
      this.bN = -1.8F * (float)var1.i();
   }

   public void a(boolean var1, boolean var2, boolean var3) {
      this.a(0.6F, 1.8F);
      awr var4 = this.l.o(this.bL);
      if (this.bL != null && var4.u() == aov.C) {
         this.l.a((et)this.bL, (awr)var4.a(aos.b, false), 4);
         et var5 = aos.a((ams)this.l, (et)this.bL, 0);
         if (var5 == null) {
            var5 = this.bL.a();
         }

         this.b((double)((float)var5.p() + 0.5F), (double)((float)var5.q() + 0.1F), (double)((float)var5.r() + 0.5F));
      }

      this.bK = false;
      if (!this.l.G && var2) {
         this.l.e();
      }

      this.c = var1 ? 0 : 100;
      if (var3) {
         this.b(this.bL, false);
      }

   }

   private boolean s() {
      return this.l.o(this.bL).u() == aov.C;
   }

   @Nullable
   public static et a(ams var0, et var1, boolean var2) {
      aou var3 = var0.o(var1).u();
      if (var3 != aov.C) {
         if (!var2) {
            return null;
         } else {
            boolean var4 = var3.d();
            boolean var5 = var0.o(var1.a()).u().d();
            return var4 && var5 ? var1 : null;
         }
      } else {
         return aos.a((ams)var0, (et)var1, 0);
      }
   }

   public float db() {
      if (this.bL != null) {
         fa var1 = (fa)this.l.o(this.bL).c(ark.D);
         switch(var1) {
         case d:
            return 90.0F;
         case e:
            return 0.0F;
         case c:
            return 270.0F;
         case f:
            return 180.0F;
         }
      }

      return 0.0F;
   }

   public boolean cz() {
      return this.bK;
   }

   public boolean dc() {
      return this.bK && this.c >= 100;
   }

   public int dd() {
      return this.c;
   }

   public void a(hh var1, boolean var2) {
   }

   public et de() {
      return this.d;
   }

   public boolean df() {
      return this.e;
   }

   public void b(et var1, boolean var2) {
      if (var1 != null) {
         this.d = var1;
         this.e = var2;
      } else {
         this.d = null;
         this.e = false;
      }

   }

   public void b(qm var1) {
      this.a((qm)var1, 1);
   }

   public void a(qm var1, int var2) {
   }

   public void a(qm var1) {
   }

   public void a(List<akr> var1) {
   }

   public void a(nd[] var1) {
   }

   public void b(List<akr> var1) {
   }

   public void cu() {
      super.cu();
      this.b(qq.w);
      if (this.aV()) {
         this.a(0.2F);
      } else {
         this.a(0.05F);
      }

   }

   public void a(float var1, float var2, float var3) {
      double var4 = this.p;
      double var6 = this.q;
      double var8 = this.r;
      if (this.bO.b && !this.aS()) {
         double var10 = this.t;
         float var12 = this.aR;
         this.aR = this.bO.a() * (float)(this.aV() ? 2 : 1);
         super.a(var1, var2, var3);
         this.t = var10 * 0.6D;
         this.aR = var12;
         this.L = 0.0F;
         this.b(7, false);
      } else {
         super.a(var1, var2, var3);
      }

      this.k(this.p - var4, this.q - var6, this.r - var8);
   }

   public float cy() {
      return (float)this.a((wa)adf.d).e();
   }

   public void k(double var1, double var3, double var5) {
      if (!this.aS()) {
         int var7;
         if (this.a((bcx)bcx.h)) {
            var7 = Math.round(ri.a(var1 * var1 + var3 * var3 + var5 * var5) * 100.0F);
            if (var7 > 0) {
               this.a(qq.q, var7);
               this.a(0.01F * (float)var7 * 0.01F);
            }
         } else if (this.ao()) {
            var7 = Math.round(ri.a(var1 * var1 + var5 * var5) * 100.0F);
            if (var7 > 0) {
               this.a(qq.m, var7);
               this.a(0.01F * (float)var7 * 0.01F);
            }
         } else if (this.m_()) {
            if (var3 > 0.0D) {
               this.a(qq.o, (int)Math.round(var3 * 100.0D));
            }
         } else if (this.z) {
            var7 = Math.round(ri.a(var1 * var1 + var5 * var5) * 100.0F);
            if (var7 > 0) {
               if (this.aV()) {
                  this.a(qq.l, var7);
                  this.a(0.1F * (float)var7 * 0.01F);
               } else if (this.aU()) {
                  this.a(qq.k, var7);
                  this.a(0.0F * (float)var7 * 0.01F);
               } else {
                  this.a(qq.j, var7);
                  this.a(0.0F * (float)var7 * 0.01F);
               }
            }
         } else if (this.cP()) {
            var7 = Math.round(ri.a(var1 * var1 + var3 * var3 + var5 * var5) * 100.0F);
            this.a(qq.v, var7);
         } else {
            var7 = Math.round(ri.a(var1 * var1 + var5 * var5) * 100.0F);
            if (var7 > 25) {
               this.a(qq.p, var7);
            }
         }

      }
   }

   private void l(double var1, double var3, double var5) {
      if (this.aS()) {
         int var7 = Math.round(ri.a(var1 * var1 + var3 * var3 + var5 * var5) * 100.0F);
         if (var7 > 0) {
            if (this.bJ() instanceof afc) {
               this.a(qq.r, var7);
            } else if (this.bJ() instanceof afb) {
               this.a(qq.s, var7);
            } else if (this.bJ() instanceof aab) {
               this.a(qq.t, var7);
            } else if (this.bJ() instanceof aam) {
               this.a(qq.u, var7);
            }
         }
      }

   }

   public void e(float var1, float var2) {
      if (!this.bO.c) {
         if (var1 >= 2.0F) {
            this.a(qq.n, (int)Math.round((double)var1 * 100.0D));
         }

         super.e(var1, var2);
      }
   }

   protected void ar() {
      if (!this.y()) {
         super.ar();
      }

   }

   protected qc e(int var1) {
      return var1 > 4 ? qd.fB : qd.fJ;
   }

   public void b(vn var1) {
      vg.a var2 = (vg.a)vg.c.get(vg.a((ve)var1));
      if (var2 != null) {
         this.b(var2.d);
      }

   }

   public void ba() {
      if (!this.bO.b) {
         super.ba();
      }

   }

   public void m(int var1) {
      this.g(var1);
      int var2 = Integer.MAX_VALUE - this.bQ;
      if (var1 > var2) {
         var1 = var2;
      }

      this.bR += (float)var1 / (float)this.dh();

      for(this.bQ += var1; this.bR >= 1.0F; this.bR /= (float)this.dh()) {
         this.bR = (this.bR - 1.0F) * (float)this.dh();
         this.a((int)1);
      }

   }

   public int dg() {
      return this.bS;
   }

   public void a(ain var1, int var2) {
      this.bP -= var2;
      if (this.bP < 0) {
         this.bP = 0;
         this.bR = 0.0F;
         this.bQ = 0;
      }

      this.bS = this.S.nextInt();
   }

   public void a(int var1) {
      this.bP += var1;
      if (this.bP < 0) {
         this.bP = 0;
         this.bR = 0.0F;
         this.bQ = 0;
      }

      if (var1 > 0 && this.bP % 5 == 0 && (float)this.f < (float)this.T - 100.0F) {
         float var2 = this.bP > 30 ? 1.0F : (float)this.bP / 30.0F;
         this.l.a((aeb)null, this.p, this.q, this.r, qd.fI, this.bK(), var2 * 0.75F, 1.0F);
         this.f = this.T;
      }

   }

   public int dh() {
      if (this.bP >= 30) {
         return 112 + (this.bP - 30) * 9;
      } else {
         return this.bP >= 15 ? 37 + (this.bP - 15) * 5 : 7 + this.bP * 2;
      }
   }

   public void a(float var1) {
      if (!this.bO.a) {
         if (!this.l.G) {
            this.bz.a(var1);
         }

      }
   }

   public afn di() {
      return this.bz;
   }

   public boolean n(boolean var1) {
      return (var1 || this.bz.c()) && !this.bO.a;
   }

   public boolean dj() {
      return this.cd() > 0.0F && this.cd() < this.cj();
   }

   public boolean dk() {
      return this.bO.e;
   }

   public boolean a(et var1, fa var2, ain var3) {
      if (this.bO.e) {
         return true;
      } else if (var3.b()) {
         return false;
      } else {
         et var4 = var1.a(var2.d());
         aou var5 = this.l.o(var4).u();
         return var3.b(var5) || var3.y();
      }
   }

   protected int b(aeb var1) {
      if (!this.l.W().b("keepInventory") && !this.y()) {
         int var2 = this.bP * 7;
         return var2 > 100 ? 100 : var2;
      } else {
         return 0;
      }
   }

   protected boolean bQ() {
      return true;
   }

   public boolean bs() {
      return true;
   }

   protected boolean ak() {
      return !this.bO.b;
   }

   public void w() {
   }

   public void a(amq var1) {
   }

   public String h_() {
      return this.g.getName();
   }

   public agk dl() {
      return this.bw;
   }

   public ain b(vj var1) {
      if (var1 == vj.a) {
         return this.bv.i();
      } else if (var1 == vj.b) {
         return (ain)this.bv.c.get(0);
      } else {
         return var1.a() == vj.a.b ? (ain)this.bv.b.get(var1.b()) : ain.a;
      }
   }

   public void a(vj var1, ain var2) {
      if (var1 == vj.a) {
         this.a_(var2);
         this.bv.a.set(this.bv.d, var2);
      } else if (var1 == vj.b) {
         this.a_(var2);
         this.bv.c.set(0, var2);
      } else if (var1.a() == vj.a.b) {
         this.a_(var2);
         this.bv.b.set(var1.b(), var2);
      }

   }

   public boolean c(ain var1) {
      this.a_(var1);
      return this.bv.e(var1);
   }

   public Iterable<ain> aO() {
      return Lists.newArrayList(new ain[]{this.co(), this.cp()});
   }

   public Iterable<ain> aP() {
      return this.bv.b;
   }

   public boolean g(fy var1) {
      if (!this.aS() && this.z && !this.ao()) {
         if (this.dp().b_()) {
            this.h(var1);
            return true;
         } else if (this.dq().b_()) {
            this.i(var1);
            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   protected void dm() {
      this.k(this.dp());
      this.h(new fy());
      this.k(this.dq());
      this.i(new fy());
   }

   private void k(@Nullable fy var1) {
      if (!this.l.G && !var1.b_()) {
         ve var2 = vg.a(var1, this.l);
         if (var2 instanceof vz) {
            ((vz)var2).b(this.aq);
         }

         var2.b(this.p, this.q + 0.699999988079071D, this.r);
         this.l.a(var2);
      }

   }

   public boolean e(aeb var1) {
      if (!this.aX()) {
         return false;
      } else if (var1.y()) {
         return false;
      } else {
         bhk var2 = this.aY();
         return var2 == null || var1 == null || var1.aY() != var2 || !var2.h();
      }
   }

   public abstract boolean y();

   public abstract boolean z();

   public boolean bo() {
      return !this.bO.b;
   }

   public bhi dn() {
      return this.l.af();
   }

   public bhk aY() {
      return this.dn().g(this.h_());
   }

   public hh i_() {
      hh var1 = new ho(bhf.a(this.aY(), this.h_()));
      var1.b().a(new hg(hg.a.d, "/msg " + this.h_() + " "));
      var1.b().a(this.bv());
      var1.b().a(this.h_());
      return var1;
   }

   public float by() {
      float var1 = 1.62F;
      if (this.cz()) {
         var1 = 0.2F;
      } else if (!this.aU() && this.H != 1.65F) {
         if (this.cP() || this.H == 0.6F) {
            var1 = 0.4F;
         }
      } else {
         var1 -= 0.08F;
      }

      return var1;
   }

   public void m(float var1) {
      if (var1 < 0.0F) {
         var1 = 0.0F;
      }

      this.V().b(a, var1);
   }

   public float cD() {
      return (Float)this.V().a(a);
   }

   public static UUID a(GameProfile var0) {
      UUID var1 = var0.getId();
      if (var1 == null) {
         var1 = d(var0.getName());
      }

      return var1;
   }

   public static UUID d(String var0) {
      return UUID.nameUUIDFromBytes(("OfflinePlayer:" + var0).getBytes(StandardCharsets.UTF_8));
   }

   public boolean a(ue var1) {
      if (var1.a()) {
         return true;
      } else {
         ain var2 = this.co();
         return !var2.b() && var2.t() ? var2.r().equals(var1.b()) : false;
      }
   }

   public boolean a(aec var1) {
      return ((Byte)this.V().a(br) & var1.a()) == var1.a();
   }

   public boolean g() {
      return this.C_().d[0].W().b("sendCommandFeedback");
   }

   public boolean c(int var1, ain var2) {
      if (var1 >= 0 && var1 < this.bv.a.size()) {
         this.bv.a(var1, var2);
         return true;
      } else {
         vj var3;
         if (var1 == 100 + vj.f.b()) {
            var3 = vj.f;
         } else if (var1 == 100 + vj.e.b()) {
            var3 = vj.e;
         } else if (var1 == 100 + vj.d.b()) {
            var3 = vj.d;
         } else if (var1 == 100 + vj.c.b()) {
            var3 = vj.c;
         } else {
            var3 = null;
         }

         if (var1 == 98) {
            this.a(vj.a, var2);
            return true;
         } else if (var1 == 99) {
            this.a(vj.b, var2);
            return true;
         } else if (var3 == null) {
            int var4 = var1 - 200;
            if (var4 >= 0 && var4 < this.bw.w_()) {
               this.bw.a(var4, var2);
               return true;
            } else {
               return false;
            }
         } else {
            if (!var2.b()) {
               if (!(var2.c() instanceof agt) && !(var2.c() instanceof ahu)) {
                  if (var3 != vj.f) {
                     return false;
                  }
               } else if (vo.d(var2) != var3) {
                  return false;
               }
            }

            this.bv.a(var3.b() + this.bv.a.size(), var2);
            return true;
         }
      }
   }

   public boolean do() {
      return this.h;
   }

   public void o(boolean var1) {
      this.h = var1;
   }

   public vm cF() {
      return (Byte)this.Y.a(bs) == 0 ? vm.a : vm.b;
   }

   public void a(vm var1) {
      this.Y.b(bs, (byte)(var1 == vm.a ? 0 : 1));
   }

   public fy dp() {
      return (fy)this.Y.a(bt);
   }

   protected void h(fy var1) {
      this.Y.b(bt, var1);
   }

   public fy dq() {
      return (fy)this.Y.a(bu);
   }

   protected void i(fy var1) {
      this.Y.b(bu, var1);
   }

   public float dr() {
      return (float)(1.0D / this.a((wa)adf.g).e() * 20.0D);
   }

   public float n(float var1) {
      return ri.a(((float)this.aE + var1) / this.dr(), 0.0F, 1.0F);
   }

   public void ds() {
      this.aE = 0;
   }

   public aim dt() {
      return this.bW;
   }

   public void i(ve var1) {
      if (!this.cz()) {
         super.i(var1);
      }

   }

   public float du() {
      return (float)this.a((wa)adf.j).e();
   }

   public boolean dv() {
      return this.bO.d && this.a(2, "");
   }

   static {
      a = na.a(aeb.class, mz.c);
      b = na.a(aeb.class, mz.b);
      br = na.a(aeb.class, mz.a);
      bs = na.a(aeb.class, mz.a);
      bt = na.a(aeb.class, mz.n);
      bu = na.a(aeb.class, mz.n);
   }

   static class c implements Predicate<adc> {
      private final aeb a;

      private c(aeb var1) {
         this.a = var1;
      }

      public boolean a(@Nullable adc var1) {
         return var1.c(this.a);
      }

      // $FF: synthetic method
      public boolean apply(@Nullable Object var1) {
         return this.a((adc)var1);
      }

      // $FF: synthetic method
      c(aeb var1, Object var2) {
         this(var1);
      }
   }

   public static enum a {
      a,
      b,
      c,
      d,
      e,
      f;
   }

   public static enum b {
      a(0, "options.chat.visibility.full"),
      b(1, "options.chat.visibility.system"),
      c(2, "options.chat.visibility.hidden");

      private static final aeb.b[] d = new aeb.b[values().length];
      private final int e;
      private final String f;

      private b(int var3, String var4) {
         this.e = var3;
         this.f = var4;
      }

      public int a() {
         return this.e;
      }

      public static aeb.b a(int var0) {
         return d[var0 % d.length];
      }

      public String b() {
         return this.f;
      }

      static {
         aeb.b[] var0 = values();
         int var1 = var0.length;

         for(int var2 = 0; var2 < var1; ++var2) {
            aeb.b var3 = var0[var2];
            d[var3.e] = var3;
         }

      }
   }
}
