public class bvk implements ceo {
   private final bvj a;
   private final bvm b;
   private final bvi c = new bvi();
   private final bvl d;

   public bvk(bvj var1, bii var2) {
      this.a = var1;
      this.b = new bvm(var2);
      this.d = new bvl(var2);
   }

   public bvj a() {
      return this.a;
   }

   public void a(awr var1, et var2, cdo var3, amw var4) {
      if (var1.i() == ath.d) {
         var1 = var1.c(var4, var2);
         cfw var5 = this.a.b(var1);
         cfw var6 = (new cgd.a(var1, var5, var3, var2)).b();
         this.b.a(var4, var6, var1, var2, bvc.a().c(), true);
      }
   }

   public boolean a(awr var1, et var2, amw var3, bui var4) {
      try {
         ath var5 = var1.i();
         if (var5 == ath.a) {
            return false;
         } else {
            if (var3.N() != amx.g) {
               try {
                  var1 = var1.c(var3, var2);
               } catch (Exception var8) {
               }
            }

            switch(var5) {
            case d:
               return this.b.a(var3, this.a(var1), var1, var2, var4, true);
            case c:
               return false;
            case b:
               return this.d.a(var3, var1, var2, var4);
            default:
               return false;
            }
         }
      } catch (Throwable var9) {
         b var6 = b.a(var9, "Tesselating block in world");
         c var7 = var6.a("Block being tesselated");
         c.a(var7, var2, var1.u(), var1.u().e(var1));
         throw new f(var6);
      }
   }

   public bvm b() {
      return this.b;
   }

   public cfw a(awr var1) {
      return this.a.b(var1);
   }

   public void a(awr var1, float var2) {
      ath var3 = var1.i();
      if (var3 != ath.a) {
         switch(var3) {
         case d:
            cfw var4 = this.a(var1);
            this.b.a(var4, var1, var2, true);
            break;
         case c:
            this.c.a(var1.u(), var2);
         case b:
         }

      }
   }

   public void a(cen var1) {
      this.d.a();
   }
}
