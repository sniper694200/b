import java.util.Iterator;
import java.util.List;

public class bjw implements bjz {
   private final i c;
   private boolean d = false;

   public bjw(i var1) {
      this.c = var1;
   }

   public bjz.a a(bka var1, long var2) {
      var1.b().N().a(a);
      buq.d(1.0F, 1.0F, 1.0F);
      r var4 = this.c.c();
      var1.b(0, 0, 0, 0, 160, 32);
      if (var4 != null) {
         List<String> var5 = var1.b().k.c(var4.a().d(), 125);
         int var6 = var4.e() == s.b ? 16746751 : 16776960;
         if (var5.size() == 1) {
            var1.b().k.a(cew.a("advancements.toast." + var4.e().a()), 30, 7, var6 | -16777216);
            var1.b().k.a(var4.a().d(), 30, 18, -1);
         } else {
            int var7 = true;
            float var8 = 300.0F;
            int var9;
            if (var2 < 1500L) {
               var9 = ri.d(ri.a((float)(1500L - var2) / 300.0F, 0.0F, 1.0F) * 255.0F) << 24 | 67108864;
               var1.b().k.a(cew.a("advancements.toast." + var4.e().a()), 30, 11, var6 | var9);
            } else {
               var9 = ri.d(ri.a((float)(var2 - 1500L) / 300.0F, 0.0F, 1.0F) * 252.0F) << 24 | 67108864;
               int var10 = 16 - var5.size() * var1.b().k.a / 2;

               for(Iterator var11 = var5.iterator(); var11.hasNext(); var10 += var1.b().k.a) {
                  String var12 = (String)var11.next();
                  var1.b().k.a(var12, 30, var10, 16777215 | var9);
               }
            }
         }

         if (!this.d && var2 > 0L) {
            this.d = true;
            if (var4.e() == s.b) {
               var1.b().U().a((cgr)cgn.a(qd.if, 1.0F, 1.0F));
            }
         }

         bhx.c();
         var1.b().ad().a((vn)null, var4.c(), 8, 8);
         return var2 >= 5000L ? bjz.a.b : bjz.a.a;
      } else {
         return bjz.a.b;
      }
   }
}
