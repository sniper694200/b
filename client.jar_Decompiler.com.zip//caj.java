public class caj extends bzp<add> {
   private static final nd a = new nd("textures/entity/zombie_pigman.png");

   public caj(bzd var1) {
      super(var1, new brj(), 0.5F);
      this.a((cce)(new cbz(this) {
         protected void M_() {
            this.c = new brj(0.5F, true);
            this.d = new brj(1.0F, true);
         }
      }));
   }

   protected nd a(add var1) {
      return a;
   }
}
