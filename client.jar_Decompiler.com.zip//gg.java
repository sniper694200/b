import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class gg extends gk {
   private long b;

   gg() {
   }

   public gg(long var1) {
      this.b = var1;
   }

   void a(DataOutput var1) throws IOException {
      var1.writeLong(this.b);
   }

   void a(DataInput var1, int var2, gh var3) throws IOException {
      var3.a(128L);
      this.b = var1.readLong();
   }

   public byte a() {
      return 4;
   }

   public String toString() {
      return this.b + "L";
   }

   public gg c() {
      return new gg(this.b);
   }

   public boolean equals(Object var1) {
      return super.equals(var1) && this.b == ((gg)var1).b;
   }

   public int hashCode() {
      return super.hashCode() ^ (int)(this.b ^ this.b >>> 32);
   }

   public long d() {
      return this.b;
   }

   public int e() {
      return (int)(this.b & -1L);
   }

   public short f() {
      return (short)((int)(this.b & 65535L));
   }

   public byte g() {
      return (byte)((int)(this.b & 255L));
   }

   public double h() {
      return (double)this.b;
   }

   public float i() {
      return (float)this.b;
   }

   // $FF: synthetic method
   public gn b() {
      return this.c();
   }
}
