import com.google.common.collect.Lists;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class che {
   private static final AtomicInteger a = new AtomicInteger(0);
   private static final Logger b = LogManager.getLogger();

   public static class a extends Thread {
      private final che.b a;
      private final InetAddress b;
      private final MulticastSocket c;

      public a(che.b var1) throws IOException {
         super("LanServerDetector #" + che.a.incrementAndGet());
         this.a = var1;
         this.setDaemon(true);
         this.c = new MulticastSocket(4445);
         this.b = InetAddress.getByName("224.0.2.60");
         this.c.setSoTimeout(5000);
         this.c.joinGroup(this.b);
      }

      public void run() {
         byte[] var2 = new byte[1024];

         while(!this.isInterrupted()) {
            DatagramPacket var1 = new DatagramPacket(var2, var2.length);

            try {
               this.c.receive(var1);
            } catch (SocketTimeoutException var5) {
               continue;
            } catch (IOException var6) {
               che.b.error("Couldn't ping server", var6);
               break;
            }

            String var3 = new String(var1.getData(), var1.getOffset(), var1.getLength(), StandardCharsets.UTF_8);
            che.b.debug("{}: {}", var1.getAddress(), var3);
            this.a.a(var3, var1.getAddress());
         }

         try {
            this.c.leaveGroup(this.b);
         } catch (IOException var4) {
         }

         this.c.close();
      }
   }

   public static class b {
      private final List<chd> b = Lists.newArrayList();
      boolean a;

      public synchronized boolean a() {
         return this.a;
      }

      public synchronized void b() {
         this.a = false;
      }

      public synchronized List<chd> c() {
         return Collections.unmodifiableList(this.b);
      }

      public synchronized void a(String var1, InetAddress var2) {
         String var3 = chf.a(var1);
         String var4 = chf.b(var1);
         if (var4 != null) {
            var4 = var2.getHostAddress() + ":" + var4;
            boolean var5 = false;
            Iterator var6 = this.b.iterator();

            while(var6.hasNext()) {
               chd var7 = (chd)var6.next();
               if (var7.b().equals(var4)) {
                  var7.c();
                  var5 = true;
                  break;
               }
            }

            if (!var5) {
               this.b.add(new chd(var3, var4));
               this.a = true;
            }

         }
      }
   }
}
