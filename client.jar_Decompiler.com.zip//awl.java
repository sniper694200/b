import com.google.common.collect.Lists;
import java.util.List;

public class awl {
   private final ams a;
   private final et b;
   private final et c;
   private final fa d;
   private final List<et> e = Lists.newArrayList();
   private final List<et> f = Lists.newArrayList();

   public awl(ams var1, et var2, fa var3, boolean var4) {
      this.a = var1;
      this.b = var2;
      if (var4) {
         this.d = var3;
         this.c = var2.a(var3);
      } else {
         this.d = var3.d();
         this.c = var2.a(var3, 2);
      }

   }

   public boolean a() {
      this.e.clear();
      this.f.clear();
      awr var1 = this.a.o(this.c);
      if (!awh.a(var1, this.a, this.c, this.d, false, this.d)) {
         if (var1.o() == bda.b) {
            this.f.add(this.c);
            return true;
         } else {
            return false;
         }
      } else if (!this.a(this.c, this.d)) {
         return false;
      } else {
         for(int var2 = 0; var2 < this.e.size(); ++var2) {
            et var3 = (et)this.e.get(var2);
            if (this.a.o(var3).u() == aov.cE && !this.a(var3)) {
               return false;
            }
         }

         return true;
      }
   }

   private boolean a(et var1, fa var2) {
      awr var3 = this.a.o(var1);
      aou var4 = var3.u();
      if (var3.a() == bcx.a) {
         return true;
      } else if (!awh.a(var3, this.a, var1, this.d, false, var2)) {
         return true;
      } else if (var1.equals(this.b)) {
         return true;
      } else if (this.e.contains(var1)) {
         return true;
      } else {
         int var5 = 1;
         if (var5 + this.e.size() > 12) {
            return false;
         } else {
            while(var4 == aov.cE) {
               et var6 = var1.a(this.d.d(), var5);
               var3 = this.a.o(var6);
               var4 = var3.u();
               if (var3.a() == bcx.a || !awh.a(var3, this.a, var6, this.d, false, this.d.d()) || var6.equals(this.b)) {
                  break;
               }

               ++var5;
               if (var5 + this.e.size() > 12) {
                  return false;
               }
            }

            int var12 = 0;

            int var7;
            for(var7 = var5 - 1; var7 >= 0; --var7) {
               this.e.add(var1.a(this.d.d(), var7));
               ++var12;
            }

            var7 = 1;

            while(true) {
               et var8 = var1.a(this.d, var7);
               int var9 = this.e.indexOf(var8);
               if (var9 > -1) {
                  this.a(var12, var9);

                  for(int var10 = 0; var10 <= var9 + var12; ++var10) {
                     et var11 = (et)this.e.get(var10);
                     if (this.a.o(var11).u() == aov.cE && !this.a(var11)) {
                        return false;
                     }
                  }

                  return true;
               }

               var3 = this.a.o(var8);
               if (var3.a() == bcx.a) {
                  return true;
               }

               if (!awh.a(var3, this.a, var8, this.d, true, this.d) || var8.equals(this.b)) {
                  return false;
               }

               if (var3.o() == bda.b) {
                  this.f.add(var8);
                  return true;
               }

               if (this.e.size() >= 12) {
                  return false;
               }

               this.e.add(var8);
               ++var12;
               ++var7;
            }
         }
      }
   }

   private void a(int var1, int var2) {
      List<et> var3 = Lists.newArrayList();
      List<et> var4 = Lists.newArrayList();
      List<et> var5 = Lists.newArrayList();
      var3.addAll(this.e.subList(0, var2));
      var4.addAll(this.e.subList(this.e.size() - var1, this.e.size()));
      var5.addAll(this.e.subList(var2, this.e.size() - var1));
      this.e.clear();
      this.e.addAll(var3);
      this.e.addAll(var4);
      this.e.addAll(var5);
   }

   private boolean a(et var1) {
      fa[] var2 = fa.values();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         fa var5 = var2[var4];
         if (var5.k() != this.d.k() && !this.a(var1.a(var5), var5)) {
            return false;
         }
      }

      return true;
   }

   public List<et> c() {
      return this.e;
   }

   public List<et> d() {
      return this.f;
   }
}
