import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;

public class awi extends apv {
   public static final axf<awi.a> a = axf.a("type", awi.a.class);
   public static final axd b = axd.a("short");
   protected static final bgz c = new bgz(0.75D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
   protected static final bgz d = new bgz(0.0D, 0.0D, 0.0D, 0.25D, 1.0D, 1.0D);
   protected static final bgz e = new bgz(0.0D, 0.0D, 0.75D, 1.0D, 1.0D, 1.0D);
   protected static final bgz f = new bgz(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 0.25D);
   protected static final bgz g = new bgz(0.0D, 0.75D, 0.0D, 1.0D, 1.0D, 1.0D);
   protected static final bgz B = new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.25D, 1.0D);
   protected static final bgz C = new bgz(0.375D, -0.25D, 0.375D, 0.625D, 0.75D, 0.625D);
   protected static final bgz D = new bgz(0.375D, 0.25D, 0.375D, 0.625D, 1.25D, 0.625D);
   protected static final bgz E = new bgz(0.375D, 0.375D, -0.25D, 0.625D, 0.625D, 0.75D);
   protected static final bgz F = new bgz(0.375D, 0.375D, 0.25D, 0.625D, 0.625D, 1.25D);
   protected static final bgz G = new bgz(-0.25D, 0.375D, 0.375D, 0.75D, 0.625D, 0.625D);
   protected static final bgz I = new bgz(0.25D, 0.375D, 0.375D, 1.25D, 0.625D, 0.625D);
   protected static final bgz J = new bgz(0.375D, 0.0D, 0.375D, 0.625D, 0.75D, 0.625D);
   protected static final bgz K = new bgz(0.375D, 0.25D, 0.375D, 0.625D, 1.0D, 0.625D);
   protected static final bgz L = new bgz(0.375D, 0.375D, 0.0D, 0.625D, 0.625D, 0.75D);
   protected static final bgz M = new bgz(0.375D, 0.375D, 0.25D, 0.625D, 0.625D, 1.0D);
   protected static final bgz N = new bgz(0.0D, 0.375D, 0.375D, 0.75D, 0.625D, 0.625D);
   protected static final bgz O = new bgz(0.25D, 0.375D, 0.375D, 1.0D, 0.625D, 0.625D);

   public awi() {
      super(bcx.H);
      this.w(this.A.b().a(H, fa.c).a(a, awi.a.a).a(b, false));
      this.a(atw.d);
      this.c(0.5F);
   }

   public bgz b(awr var1, amw var2, et var3) {
      switch((fa)var1.c(H)) {
      case a:
      default:
         return B;
      case b:
         return g;
      case c:
         return f;
      case d:
         return e;
      case e:
         return d;
      case f:
         return c;
      }
   }

   public void a(awr var1, ams var2, et var3, bgz var4, List<bgz> var5, @Nullable ve var6, boolean var7) {
      a((et)var3, (bgz)var4, (List)var5, (bgz)var1.e(var2, var3));
      a((et)var3, (bgz)var4, (List)var5, (bgz)this.x(var1));
   }

   private bgz x(awr var1) {
      boolean var2 = (Boolean)var1.c(b);
      switch((fa)var1.c(H)) {
      case a:
      default:
         return var2 ? K : D;
      case b:
         return var2 ? J : C;
      case c:
         return var2 ? M : F;
      case d:
         return var2 ? L : E;
      case e:
         return var2 ? O : I;
      case f:
         return var2 ? N : G;
      }
   }

   public boolean k(awr var1) {
      return var1.c(H) == fa.b;
   }

   public void a(ams var1, et var2, awr var3, aeb var4) {
      if (var4.bO.d) {
         et var5 = var2.a(((fa)var3.c(H)).d());
         aou var6 = var1.o(var5).u();
         if (var6 == aov.J || var6 == aov.F) {
            var1.g(var5);
         }
      }

      super.a(var1, var2, var3, var4);
   }

   public void b(ams var1, et var2, awr var3) {
      super.b(var1, var2, var3);
      fa var4 = ((fa)var3.c(H)).d();
      var2 = var2.a(var4);
      awr var5 = var1.o(var2);
      if ((var5.u() == aov.J || var5.u() == aov.F) && (Boolean)var5.c(awh.a)) {
         var5.u().b(var1, var2, var5, 0);
         var1.g(var2);
      }

   }

   public boolean b(awr var1) {
      return false;
   }

   public boolean c(awr var1) {
      return false;
   }

   public boolean a(ams var1, et var2) {
      return false;
   }

   public boolean b(ams var1, et var2, fa var3) {
      return false;
   }

   public int a(Random var1) {
      return 0;
   }

   public void a(awr var1, ams var2, et var3, aou var4, et var5) {
      fa var6 = (fa)var1.c(H);
      et var7 = var3.a(var6.d());
      awr var8 = var2.o(var7);
      if (var8.u() != aov.J && var8.u() != aov.F) {
         var2.g(var3);
      } else {
         var8.a(var2, var7, var4, var5);
      }

   }

   public boolean a(awr var1, amw var2, et var3, fa var4) {
      return true;
   }

   @Nullable
   public static fa b(int var0) {
      int var1 = var0 & 7;
      return var1 > 5 ? null : fa.a(var1);
   }

   public ain a(ams var1, et var2, awr var3) {
      return new ain(var3.c(a) == awi.a.b ? aov.F : aov.J);
   }

   public awr a(int var1) {
      return this.t().a(H, b(var1)).a(a, (var1 & 8) > 0 ? awi.a.b : awi.a.a);
   }

   public int e(awr var1) {
      int var2 = 0;
      int var3 = var2 | ((fa)var1.c(H)).a();
      if (var1.c(a) == awi.a.b) {
         var3 |= 8;
      }

      return var3;
   }

   public awr a(awr var1, atk var2) {
      return var1.a(H, var2.a((fa)var1.c(H)));
   }

   public awr a(awr var1, arw var2) {
      return var1.a(var2.a((fa)var1.c(H)));
   }

   protected aws b() {
      return new aws(this, new axh[]{H, a, b});
   }

   public awp a(amw var1, awr var2, et var3, fa var4) {
      return var4 == var2.c(H) ? awp.a : awp.i;
   }

   public static enum a implements rm {
      a("normal"),
      b("sticky");

      private final String c;

      private a(String var3) {
         this.c = var3;
      }

      public String toString() {
         return this.c;
      }

      public String m() {
         return this.c;
      }
   }
}
