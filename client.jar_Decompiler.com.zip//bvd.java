import java.util.Iterator;

public class bvd extends bul {
   public void a(amk var1) {
      if (this.b) {
         Iterator var2 = this.a.iterator();

         while(var2.hasNext()) {
            bxp var3 = (bxp)var2.next();
            cdx var4 = var3.b(var1.ordinal());
            buq.G();
            this.a(var3);
            var3.g();
            var4.a();
            this.a();
            var4.a(7);
            buq.H();
         }

         cig.g(cig.R, 0);
         buq.I();
         this.a.clear();
      }
   }

   private void a() {
      buq.d(3, 5126, 28, 0);
      buq.e(4, 5121, 28, 12);
      buq.c(2, 5126, 28, 16);
      cig.l(cig.r);
      buq.c(2, 5122, 28, 24);
      cig.l(cig.q);
   }
}
