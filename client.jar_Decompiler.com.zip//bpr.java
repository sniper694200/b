import java.util.Random;

public class bpr extends bqd {
   brq a;
   brq[] b = new brq[9];

   public bpr() {
      int var1 = true;
      this.a = new brq(this, 0, 0);
      this.a.a(-8.0F, -8.0F, -8.0F, 16, 16, 16);
      brq var10000 = this.a;
      var10000.d += 8.0F;
      Random var2 = new Random(1660L);

      for(int var3 = 0; var3 < this.b.length; ++var3) {
         this.b[var3] = new brq(this, 0, 0);
         float var4 = (((float)(var3 % 3) - (float)(var3 / 3 % 2) * 0.5F + 0.25F) / 2.0F * 2.0F - 1.0F) * 5.0F;
         float var5 = ((float)(var3 / 3) / 2.0F * 2.0F - 1.0F) * 5.0F;
         int var6 = var2.nextInt(7) + 8;
         this.b[var3].a(-1.0F, 0.0F, -1.0F, 2, var6, 2);
         this.b[var3].c = var4;
         this.b[var3].e = var5;
         this.b[var3].d = 15.0F;
      }

   }

   public void a(float var1, float var2, float var3, float var4, float var5, float var6, ve var7) {
      for(int var8 = 0; var8 < this.b.length; ++var8) {
         this.b[var8].f = 0.2F * ri.a(var3 * 0.3F + (float)var8) + 0.4F;
      }

   }

   public void a(ve var1, float var2, float var3, float var4, float var5, float var6, float var7) {
      this.a(var2, var3, var4, var5, var6, var7, var1);
      buq.G();
      buq.c(0.0F, 0.6F, 0.0F);
      this.a.a(var7);
      brq[] var8 = this.b;
      int var9 = var8.length;

      for(int var10 = 0; var10 < var9; ++var10) {
         brq var11 = var8[var10];
         var11.a(var7);
      }

      buq.H();
   }
}
