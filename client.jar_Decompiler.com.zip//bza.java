public class bza extends cad<abb> {
   public static final nd a = new nd("textures/entity/endercrystal/endercrystal_beam.png");
   private static final nd j = new nd("textures/entity/enderdragon/dragon_exploding.png");
   private static final nd k = new nd("textures/entity/enderdragon/dragon.png");

   public bza(bzd var1) {
      super(var1, new brl(0.0F), 0.5F);
      this.a((cce)(new cbw(this)));
      this.a((cce)(new cbv()));
   }

   protected void a(abb var1, float var2, float var3, float var4) {
      float var5 = (float)var1.a(7, var4)[0];
      float var6 = (float)(var1.a(5, var4)[1] - var1.a(10, var4)[1]);
      buq.b(-var5, 0.0F, 1.0F, 0.0F);
      buq.b(var6 * 10.0F, 1.0F, 0.0F, 0.0F);
      buq.c(0.0F, 0.0F, 1.0F);
      if (var1.aB > 0) {
         float var7 = ((float)var1.aB + var4 - 1.0F) / 20.0F * 1.6F;
         var7 = ri.c(var7);
         if (var7 > 1.0F) {
            var7 = 1.0F;
         }

         buq.b(var7 * this.b(var1), 0.0F, 0.0F, 1.0F);
      }

   }

   protected void a(abb var1, float var2, float var3, float var4, float var5, float var6, float var7) {
      if (var1.bH > 0) {
         float var8 = (float)var1.bH / 200.0F;
         buq.c(515);
         buq.e();
         buq.a(516, var8);
         this.a((nd)j);
         this.f.a(var1, var2, var3, var4, var5, var6, var7);
         buq.a(516, 0.1F);
         buq.c(514);
      }

      this.d(var1);
      this.f.a(var1, var2, var3, var4, var5, var6, var7);
      if (var1.ay > 0) {
         buq.c(514);
         buq.z();
         buq.m();
         buq.a(buq.r.l, buq.l.j);
         buq.c(1.0F, 0.0F, 0.0F, 0.5F);
         this.f.a(var1, var2, var3, var4, var5, var6, var7);
         buq.y();
         buq.l();
         buq.c(515);
      }

   }

   public void a(abb var1, double var2, double var4, double var6, float var8, float var9) {
      super.a((vo)var1, var2, var4, var6, var8, var9);
      if (var1.bI != null) {
         this.a((nd)a);
         float var10 = ri.a(((float)var1.bI.T + var9) * 0.2F) / 2.0F + 0.5F;
         var10 = (var10 * var10 + var10) * 0.2F;
         a(var2, var4, var6, var9, var1.p + (var1.m - var1.p) * (double)(1.0F - var9), var1.q + (var1.n - var1.q) * (double)(1.0F - var9), var1.r + (var1.o - var1.r) * (double)(1.0F - var9), var1.T, var1.bI.p, (double)var10 + var1.bI.q, var1.bI.r);
      }

   }

   public static void a(double var0, double var2, double var4, float var6, double var7, double var9, double var11, int var13, double var14, double var16, double var18) {
      float var20 = (float)(var14 - var7);
      float var21 = (float)(var16 - 1.0D - var9);
      float var22 = (float)(var18 - var11);
      float var23 = ri.c(var20 * var20 + var22 * var22);
      float var24 = ri.c(var20 * var20 + var21 * var21 + var22 * var22);
      buq.G();
      buq.c((float)var0, (float)var2 + 2.0F, (float)var4);
      buq.b((float)(-Math.atan2((double)var22, (double)var20)) * 57.295776F - 90.0F, 0.0F, 1.0F, 0.0F);
      buq.b((float)(-Math.atan2((double)var23, (double)var21)) * 57.295776F - 90.0F, 1.0F, 0.0F, 0.0F);
      bvc var25 = bvc.a();
      bui var26 = var25.c();
      bhx.a();
      buq.r();
      buq.j(7425);
      float var27 = 0.0F - ((float)var13 + var6) * 0.01F;
      float var28 = ri.c(var20 * var20 + var21 * var21 + var22 * var22) / 32.0F - ((float)var13 + var6) * 0.01F;
      var26.a(5, cdw.i);
      int var29 = true;

      for(int var30 = 0; var30 <= 8; ++var30) {
         float var31 = ri.a((float)(var30 % 8) * 6.2831855F / 8.0F) * 0.75F;
         float var32 = ri.b((float)(var30 % 8) * 6.2831855F / 8.0F) * 0.75F;
         float var33 = (float)(var30 % 8) / 8.0F;
         var26.b((double)(var31 * 0.2F), (double)(var32 * 0.2F), 0.0D).a((double)var33, (double)var27).b(0, 0, 0, 255).d();
         var26.b((double)var31, (double)var32, (double)var24).a((double)var33, (double)var28).b(255, 255, 255, 255).d();
      }

      var25.b();
      buq.q();
      buq.j(7424);
      bhx.b();
      buq.H();
   }

   protected nd a(abb var1) {
      return k;
   }
}
