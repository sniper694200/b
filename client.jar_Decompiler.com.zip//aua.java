public class aua extends apl {
   private static final bcy[] b;

   public aua() {
      super(bcx.e);
   }

   public bcy c(awr var1, amw var2, et var3) {
      return b[((ahq)var1.c(a)).a()];
   }

   static {
      b = new bcy[]{bcy.M, bcy.N, bcy.O, bcy.P, bcy.Q, bcy.R, bcy.S, bcy.T, bcy.U, bcy.V, bcy.W, bcy.X, bcy.Y, bcy.Z, bcy.aa, bcy.ab};
   }
}
