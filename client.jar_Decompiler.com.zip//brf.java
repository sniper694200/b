public class brf extends bpv {
   public brf() {
      this(0.0F, 0.0F, false);
   }

   public brf(float var1, float var2, boolean var3) {
      super(var1, 0.0F, 64, var3 ? 32 : 64);
      if (var3) {
         this.e = new brq(this, 0, 0);
         this.e.a(-4.0F, -10.0F, -4.0F, 8, 8, 8, var1);
         this.e.a(0.0F, 0.0F + var2, 0.0F);
         this.g = new brq(this, 16, 16);
         this.g.a(0.0F, 0.0F + var2, 0.0F);
         this.g.a(-4.0F, 0.0F, -2.0F, 8, 12, 4, var1 + 0.1F);
         this.j = new brq(this, 0, 16);
         this.j.a(-2.0F, 12.0F + var2, 0.0F);
         this.j.a(-2.0F, 0.0F, -2.0F, 4, 12, 4, var1 + 0.1F);
         this.k = new brq(this, 0, 16);
         this.k.i = true;
         this.k.a(2.0F, 12.0F + var2, 0.0F);
         this.k.a(-2.0F, 0.0F, -2.0F, 4, 12, 4, var1 + 0.1F);
      } else {
         this.e = new brq(this, 0, 0);
         this.e.a(0.0F, var2, 0.0F);
         this.e.a(0, 0).a(-4.0F, -10.0F, -4.0F, 8, 10, 8, var1);
         this.e.a(24, 0).a(-1.0F, -3.0F, -6.0F, 2, 4, 2, var1);
         this.g = new brq(this, 16, 20);
         this.g.a(0.0F, 0.0F + var2, 0.0F);
         this.g.a(-4.0F, 0.0F, -3.0F, 8, 12, 6, var1);
         this.g.a(0, 38).a(-4.0F, 0.0F, -3.0F, 8, 18, 6, var1 + 0.05F);
         this.h = new brq(this, 44, 38);
         this.h.a(-3.0F, -2.0F, -2.0F, 4, 12, 4, var1);
         this.h.a(-5.0F, 2.0F + var2, 0.0F);
         this.i = new brq(this, 44, 38);
         this.i.i = true;
         this.i.a(-1.0F, -2.0F, -2.0F, 4, 12, 4, var1);
         this.i.a(5.0F, 2.0F + var2, 0.0F);
         this.j = new brq(this, 0, 22);
         this.j.a(-2.0F, 12.0F + var2, 0.0F);
         this.j.a(-2.0F, 0.0F, -2.0F, 4, 12, 4, var1);
         this.k = new brq(this, 0, 22);
         this.k.i = true;
         this.k.a(2.0F, 12.0F + var2, 0.0F);
         this.k.a(-2.0F, 0.0F, -2.0F, 4, 12, 4, var1);
      }

   }

   public void a(float var1, float var2, float var3, float var4, float var5, float var6, ve var7) {
      super.a(var1, var2, var3, var4, var5, var6, var7);
      adr var8 = (adr)var7;
      float var9 = ri.a(this.o * 3.1415927F);
      float var10 = ri.a((1.0F - (1.0F - this.o) * (1.0F - this.o)) * 3.1415927F);
      this.h.h = 0.0F;
      this.i.h = 0.0F;
      this.h.g = -(0.1F - var9 * 0.6F);
      this.i.g = 0.1F - var9 * 0.6F;
      float var11 = -3.1415927F / (var8.dq() ? 1.5F : 2.25F);
      this.h.f = var11;
      this.i.f = var11;
      brq var10000 = this.h;
      var10000.f += var9 * 1.2F - var10 * 0.4F;
      var10000 = this.i;
      var10000.f += var9 * 1.2F - var10 * 0.4F;
      var10000 = this.h;
      var10000.h += ri.b(var3 * 0.09F) * 0.05F + 0.05F;
      var10000 = this.i;
      var10000.h -= ri.b(var3 * 0.09F) * 0.05F + 0.05F;
      var10000 = this.h;
      var10000.f += ri.a(var3 * 0.067F) * 0.05F;
      var10000 = this.i;
      var10000.f -= ri.a(var3 * 0.067F) * 0.05F;
   }
}
