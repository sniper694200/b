import java.io.IOException;

public class kb implements ht<hw> {
   private int a;
   private String b;

   public kb() {
   }

   public kb(int var1, bhe var2) {
      this.a = var1;
      if (var2 == null) {
         this.b = "";
      } else {
         this.b = var2.b();
      }

   }

   public void a(gy var1) throws IOException {
      this.a = var1.readByte();
      this.b = var1.e(16);
   }

   public void b(gy var1) throws IOException {
      var1.writeByte(this.a);
      var1.a(this.b);
   }

   public void a(hw var1) {
      var1.a(this);
   }

   public int a() {
      return this.a;
   }

   public String b() {
      return this.b;
   }
}
