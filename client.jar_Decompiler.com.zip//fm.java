import java.util.Set;
import javax.annotation.Nullable;

public interface fm<K, V> extends Iterable<V> {
   @Nullable
   V c(K var1);

   void a(K var1, V var2);

   Set<K> c();
}
