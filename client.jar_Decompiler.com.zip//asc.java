import java.util.Random;

public class asc extends apa {
   public static final axg a = axg.a("age", 0, 3);
   private static final bgz[] c = new bgz[]{new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.3125D, 1.0D), new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.5D, 1.0D), new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.6875D, 1.0D), new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.875D, 1.0D)};

   protected asc() {
      super(bcx.k, bcy.E);
      this.w(this.A.b().a(a, 0));
      this.a(true);
      this.a((ahn)null);
   }

   public bgz b(awr var1, amw var2, et var3) {
      return c[(Integer)var1.c(a)];
   }

   protected boolean x(awr var1) {
      return var1.u() == aov.aW;
   }

   public boolean f(ams var1, et var2, awr var3) {
      return this.x(var1.o(var2.b()));
   }

   public void b(ams var1, et var2, awr var3, Random var4) {
      int var5 = (Integer)var3.c(a);
      if (var5 < 3 && var4.nextInt(10) == 0) {
         var3 = var3.a(a, var5 + 1);
         var1.a((et)var2, (awr)var3, 2);
      }

      super.b(var1, var2, var3, var4);
   }

   public void a(ams var1, et var2, awr var3, float var4, int var5) {
      if (!var1.G) {
         int var6 = 1;
         if ((Integer)var3.c(a) >= 3) {
            var6 = 2 + var1.r.nextInt(3);
            if (var5 > 0) {
               var6 += var1.r.nextInt(var5 + 1);
            }
         }

         for(int var7 = 0; var7 < var6; ++var7) {
            a(var1, var2, new ain(aip.bG));
         }

      }
   }

   public ail a(awr var1, Random var2, int var3) {
      return aip.a;
   }

   public int a(Random var1) {
      return 0;
   }

   public ain a(ams var1, et var2, awr var3) {
      return new ain(aip.bG);
   }

   public awr a(int var1) {
      return this.t().a(a, var1);
   }

   public int e(awr var1) {
      return (Integer)var1.c(a);
   }

   protected aws b() {
      return new aws(this, new axh[]{a});
   }
}
