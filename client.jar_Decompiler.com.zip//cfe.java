import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

public class cfe {
   private final fm<String, cfe.a<? extends cfc>> a = new fo();
   private final GsonBuilder b = new GsonBuilder();
   private Gson c;

   public cfe() {
      this.b.registerTypeHierarchyAdapter(hh.class, new hh.a());
      this.b.registerTypeHierarchyAdapter(hn.class, new hn.a());
      this.b.registerTypeAdapterFactory(new rh());
   }

   public <T extends cfc> void a(cfd<T> var1, Class<T> var2) {
      this.a.a(var1.a(), new cfe.a(var1, var2));
      this.b.registerTypeAdapter(var2, var1);
      this.c = null;
   }

   public <T extends cfc> T a(String var1, JsonObject var2) {
      if (var1 == null) {
         throw new IllegalArgumentException("Metadata section name cannot be null");
      } else if (!var2.has(var1)) {
         return null;
      } else if (!var2.get(var1).isJsonObject()) {
         throw new IllegalArgumentException("Invalid metadata for '" + var1 + "' - expected object, found " + var2.get(var1));
      } else {
         cfe.a<?> var3 = (cfe.a)this.a.c(var1);
         if (var3 == null) {
            throw new IllegalArgumentException("Don't know how to handle metadata section '" + var1 + "'");
         } else {
            return (cfc)this.a().fromJson(var2.getAsJsonObject(var1), var3.b);
         }
      }
   }

   private Gson a() {
      if (this.c == null) {
         this.c = this.b.create();
      }

      return this.c;
   }

   class a<T extends cfc> {
      final cfd<T> a;
      final Class<T> b;

      private a(cfd<T> var2, Class<T> var3) {
         this.a = var2;
         this.b = var3;
      }

      // $FF: synthetic method
      a(cfd var2, Class var3, Object var4) {
         this(var2, var3);
      }
   }
}
