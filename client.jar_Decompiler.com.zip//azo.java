import java.util.Random;

public class azo extends azs {
   private apz.b a;

   public void a(apz.b var1) {
      this.a = var1;
   }

   public boolean b(ams var1, Random var2, et var3) {
      boolean var4 = false;

      for(int var5 = 0; var5 < 64; ++var5) {
         et var6 = var3.a(var2.nextInt(8) - var2.nextInt(8), var2.nextInt(4) - var2.nextInt(4), var2.nextInt(8) - var2.nextInt(8));
         if (var1.d(var6) && (!var1.s.n() || var6.q() < 254) && aov.cF.a(var1, var6)) {
            aov.cF.a(var1, var6, this.a, 2);
            var4 = true;
         }
      }

      return var4;
   }
}
