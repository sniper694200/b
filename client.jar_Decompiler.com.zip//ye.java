public class ye extends xc {
   private final vv a;

   public ye(vv var1) {
      this.a = var1;
   }

   public boolean a() {
      return this.a.l.D() && this.a.b(vj.f).b();
   }

   public void c() {
      ((zb)this.a.x()).d(true);
   }

   public void d() {
      ((zb)this.a.x()).d(false);
   }
}
