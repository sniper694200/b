import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class cet implements cel {
   private static final Logger a = LogManager.getLogger();
   private static final Joiner b = Joiner.on(", ");
   private final Map<String, ceg> c = Maps.newHashMap();
   private final List<ceo> d = Lists.newArrayList();
   private final Set<String> e = Sets.newLinkedHashSet();
   private final cfe f;

   public cet(cfe var1) {
      this.f = var1;
   }

   public void a(cep var1) {
      ceg var4;
      for(Iterator var2 = var1.c().iterator(); var2.hasNext(); var4.a(var1)) {
         String var3 = (String)var2.next();
         this.e.add(var3);
         var4 = (ceg)this.c.get(var3);
         if (var4 == null) {
            var4 = new ceg(this.f);
            this.c.put(var3, var4);
         }
      }

   }

   public Set<String> a() {
      return this.e;
   }

   public cem a(nd var1) throws IOException {
      cen var2 = (cen)this.c.get(var1.b());
      if (var2 != null) {
         return var2.a(var1);
      } else {
         throw new FileNotFoundException(var1.toString());
      }
   }

   public List<cem> b(nd var1) throws IOException {
      cen var2 = (cen)this.c.get(var1.b());
      if (var2 != null) {
         return var2.b(var1);
      } else {
         throw new FileNotFoundException(var1.toString());
      }
   }

   private void b() {
      this.c.clear();
      this.e.clear();
   }

   public void a(List<cep> var1) {
      this.b();
      a.info("Reloading ResourceManager: {}", b.join(Iterables.transform(var1, new Function<cep, String>() {
         public String a(@Nullable cep var1) {
            return var1 == null ? "<NULL>" : var1.b();
         }

         // $FF: synthetic method
         public Object apply(@Nullable Object var1) {
            return this.a((cep)var1);
         }
      })));
      Iterator var2 = var1.iterator();

      while(var2.hasNext()) {
         cep var3 = (cep)var2.next();
         this.a(var3);
      }

      this.c();
   }

   public void a(ceo var1) {
      this.d.add(var1);
      var1.a(this);
   }

   private void c() {
      Iterator var1 = this.d.iterator();

      while(var1.hasNext()) {
         ceo var2 = (ceo)var1.next();
         var2.a(this);
      }

   }
}
