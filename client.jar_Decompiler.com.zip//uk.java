public interface uk {
   void a(uj var1);

   void b(uj var1);

   boolean Z();
}
