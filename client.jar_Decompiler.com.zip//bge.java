import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSyntaxException;
import java.util.Random;

public class bge extends bfx {
   private final fy a;

   public bge(bgj[] var1, fy var2) {
      super(var1);
      this.a = var2;
   }

   public ain a(ain var1, Random var2, bfr var3) {
      fy var4 = var1.p();
      if (var4 == null) {
         var4 = this.a.g();
      } else {
         var4.a(this.a);
      }

      var1.b(var4);
      return var1;
   }

   public static class a extends bfx.a<bge> {
      public a() {
         super(new nd("set_nbt"), bge.class);
      }

      public void a(JsonObject var1, bge var2, JsonSerializationContext var3) {
         var1.addProperty("tag", var2.a.toString());
      }

      public bge a(JsonObject var1, JsonDeserializationContext var2, bgj[] var3) {
         try {
            fy var4 = gp.a(ra.h(var1, "tag"));
            return new bge(var3, var4);
         } catch (go var5) {
            throw new JsonSyntaxException(var5);
         }
      }

      // $FF: synthetic method
      public bfx b(JsonObject var1, JsonDeserializationContext var2, bgj[] var3) {
         return this.a(var1, var2, var3);
      }
   }
}
