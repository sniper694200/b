public class ccl implements cce<aai> {
   private final cbd a;

   public ccl(cbd var1) {
      this.a = var1;
   }

   public void a(aai var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8) {
      if (var1.dm() != 0) {
         bvk var9 = bhz.z().ab();
         buq.D();
         buq.G();
         buq.b(5.0F + 180.0F * ((brd)this.a.b()).c.f / 3.1415927F, 1.0F, 0.0F, 0.0F);
         buq.b(90.0F, 1.0F, 0.0F, 0.0F);
         buq.c(-0.9375F, -0.625F, -0.9375F);
         float var10 = 0.5F;
         buq.b(0.5F, -0.5F, 0.5F);
         int var11 = var1.av();
         int var12 = var11 % 65536;
         int var13 = var11 / 65536;
         cig.a(cig.r, (float)var12, (float)var13);
         buq.c(1.0F, 1.0F, 1.0F, 1.0F);
         this.a.a((nd)cdn.g);
         var9.a(aov.O.t(), 1.0F);
         buq.H();
         buq.E();
      }
   }

   public boolean a() {
      return false;
   }
}
