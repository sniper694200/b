public class agn extends afp {
   private final tt a;

   public agn(aea var1, tt var2, aeb var3) {
      this.a = var2;
      var2.b(var3);
      int var4 = true;
      int var5 = true;

      int var6;
      int var7;
      for(var6 = 0; var6 < 3; ++var6) {
         for(var7 = 0; var7 < 9; ++var7) {
            this.a(new ago(var2, var7 + var6 * 9, 8 + var7 * 18, 18 + var6 * 18));
         }
      }

      for(var6 = 0; var6 < 3; ++var6) {
         for(var7 = 0; var7 < 9; ++var7) {
            this.a(new agp(var1, var7 + var6 * 9 + 9, 8 + var7 * 18, 84 + var6 * 18));
         }
      }

      for(var6 = 0; var6 < 9; ++var6) {
         this.a(new agp(var1, var6, 8 + var6 * 18, 142));
      }

   }

   public boolean a(aeb var1) {
      return this.a.a(var1);
   }

   public ain b(aeb var1, int var2) {
      ain var3 = ain.a;
      agp var4 = (agp)this.c.get(var2);
      if (var4 != null && var4.e()) {
         ain var5 = var4.d();
         var3 = var5.l();
         if (var2 < this.a.w_()) {
            if (!this.a(var5, this.a.w_(), this.c.size(), true)) {
               return ain.a;
            }
         } else if (!this.a(var5, 0, this.a.w_(), false)) {
            return ain.a;
         }

         if (var5.b()) {
            var4.d(ain.a);
         } else {
            var4.f();
         }
      }

      return var3;
   }

   public void b(aeb var1) {
      super.b(var1);
      this.a.c(var1);
   }
}
