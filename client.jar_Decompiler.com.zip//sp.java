public class sp implements rs {
   public int a() {
      return 135;
   }

   public fy a(fy var1) {
      while(var1.b("Riding", 10)) {
         fy var2 = this.b(var1);
         this.a(var1, var2);
         var1 = var2;
      }

      return var1;
   }

   protected void a(fy var1, fy var2) {
      ge var3 = new ge();
      var3.a((gn)var1);
      var2.a((String)"Passengers", (gn)var3);
   }

   protected fy b(fy var1) {
      fy var2 = var1.p("Riding");
      var1.r("Riding");
      return var2;
   }
}
