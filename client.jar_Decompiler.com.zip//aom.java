import java.util.Random;
import javax.annotation.Nullable;

public class aom extends aoo {
   public static final axe a;
   public static final axg b;
   protected static final bgz c;

   protected aom() {
      super(bcx.d);
   }

   public String c() {
      return ft.a("item.banner.white.name");
   }

   @Nullable
   public bgz a(awr var1, amw var2, et var3) {
      return k;
   }

   public boolean c(awr var1) {
      return false;
   }

   public boolean b(amw var1, et var2) {
      return true;
   }

   public boolean b(awr var1) {
      return false;
   }

   public boolean d() {
      return true;
   }

   public avh a(ams var1, int var2) {
      return new avd();
   }

   public ail a(awr var1, Random var2, int var3) {
      return aip.cP;
   }

   private ain c(ams var1, et var2) {
      avh var3 = var1.r(var2);
      return var3 instanceof avd ? ((avd)var3).l() : ain.a;
   }

   public ain a(ams var1, et var2, awr var3) {
      ain var4 = this.c(var1, var2);
      return var4.b() ? new ain(aip.cP) : var4;
   }

   public void a(ams var1, et var2, awr var3, float var4, int var5) {
      ain var6 = this.c(var1, var2);
      if (var6.b()) {
         super.a(var1, var2, var3, var4, var5);
      } else {
         a((ams)var1, (et)var2, (ain)var6);
      }

   }

   public boolean a(ams var1, et var2) {
      return !this.b(var1, var2) && super.a(var1, var2);
   }

   public void a(ams var1, aeb var2, et var3, awr var4, @Nullable avh var5, ain var6) {
      if (var5 instanceof avd) {
         avd var7 = (avd)var5;
         ain var8 = var7.l();
         a((ams)var1, (et)var3, (ain)var8);
      } else {
         super.a(var1, var2, var3, var4, (avh)null, var6);
      }

   }

   public awp a(amw var1, awr var2, et var3, fa var4) {
      return awp.i;
   }

   static {
      a = ark.D;
      b = axg.a("rotation", 0, 15);
      c = new bgz(0.25D, 0.0D, 0.25D, 0.75D, 1.0D, 0.75D);
   }

   public static class a extends aom {
      public a() {
         this.w(this.A.b().a(b, 0));
      }

      public bgz b(awr var1, amw var2, et var3) {
         return c;
      }

      public awr a(awr var1, atk var2) {
         return var1.a(b, var2.a((Integer)var1.c(b), 16));
      }

      public awr a(awr var1, arw var2) {
         return var1.a(b, var2.a((Integer)var1.c(b), 16));
      }

      public void a(awr var1, ams var2, et var3, aou var4, et var5) {
         if (!var2.o(var3.b()).a().a()) {
            this.b(var2, var3, var1, 0);
            var2.g(var3);
         }

         super.a(var1, var2, var3, var4, var5);
      }

      public awr a(int var1) {
         return this.t().a(b, var1);
      }

      public int e(awr var1) {
         return (Integer)var1.c(b);
      }

      protected aws b() {
         return new aws(this, new axh[]{b});
      }
   }

   public static class b extends aom {
      protected static final bgz d = new bgz(0.0D, 0.0D, 0.875D, 1.0D, 0.78125D, 1.0D);
      protected static final bgz e = new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.78125D, 0.125D);
      protected static final bgz f = new bgz(0.875D, 0.0D, 0.0D, 1.0D, 0.78125D, 1.0D);
      protected static final bgz g = new bgz(0.0D, 0.0D, 0.0D, 0.125D, 0.78125D, 1.0D);

      public b() {
         this.w(this.A.b().a(a, fa.c));
      }

      public awr a(awr var1, atk var2) {
         return var1.a(a, var2.a((fa)var1.c(a)));
      }

      public awr a(awr var1, arw var2) {
         return var1.a(var2.a((fa)var1.c(a)));
      }

      public bgz b(awr var1, amw var2, et var3) {
         switch((fa)var1.c(a)) {
         case c:
         default:
            return d;
         case d:
            return e;
         case e:
            return f;
         case f:
            return g;
         }
      }

      public void a(awr var1, ams var2, et var3, aou var4, et var5) {
         fa var6 = (fa)var1.c(a);
         if (!var2.o(var3.a(var6.d())).a().a()) {
            this.b(var2, var3, var1, 0);
            var2.g(var3);
         }

         super.a(var1, var2, var3, var4, var5);
      }

      public awr a(int var1) {
         fa var2 = fa.a(var1);
         if (var2.k() == fa.a.b) {
            var2 = fa.c;
         }

         return this.t().a(a, var2);
      }

      public int e(awr var1) {
         return ((fa)var1.c(a)).a();
      }

      protected aws b() {
         return new aws(this, new axh[]{a});
      }
   }
}
