public class cax<T extends ve> extends bze<T> {
   protected final ail a;
   private final bzu f;

   public cax(bzd var1, ail var2, bzu var3) {
      super(var1);
      this.a = var2;
      this.f = var3;
   }

   public void a(T var1, double var2, double var4, double var6, float var8, float var9) {
      buq.G();
      buq.c((float)var2, (float)var4, (float)var6);
      buq.D();
      buq.b(-this.b.e, 0.0F, 1.0F, 0.0F);
      buq.b((float)(this.b.g.aw == 2 ? -1 : 1) * this.b.f, 1.0F, 0.0F, 0.0F);
      buq.b(180.0F, 0.0F, 1.0F, 0.0F);
      this.a(cdn.g);
      if (this.e) {
         buq.h();
         buq.e(this.c(var1));
      }

      this.f.a(this.e(var1), bwa.b.h);
      if (this.e) {
         buq.n();
         buq.i();
      }

      buq.E();
      buq.H();
      super.a(var1, var2, var4, var6, var8, var9);
   }

   public ain e(T var1) {
      return new ain(this.a);
   }

   protected nd a(ve var1) {
      return cdn.g;
   }
}
