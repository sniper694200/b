import java.util.List;

public class bwt extends bww<avf> {
   public static final nd a = new nd("textures/entity/beacon_beam.png");

   public void a(avf var1, double var2, double var4, double var6, float var8, int var9, float var10) {
      this.a(var2, var4, var6, (double)var8, (double)var1.p(), var1.o(), (double)var1.D().R());
   }

   public void a(double var1, double var3, double var5, double var7, double var9, List<avf.a> var11, double var12) {
      buq.a(516, 0.1F);
      this.a((nd)a);
      if (var9 > 0.0D) {
         buq.p();
         int var14 = 0;

         for(int var15 = 0; var15 < var11.size(); ++var15) {
            avf.a var16 = (avf.a)var11.get(var15);
            a(var1, var3, var5, var7, var9, var12, var14, var16.c(), var16.b());
            var14 += var16.c();
         }

         buq.o();
      }

   }

   public static void a(double var0, double var2, double var4, double var6, double var8, double var10, int var12, int var13, float[] var14) {
      a(var0, var2, var4, var6, var8, var10, var12, var13, var14, 0.2D, 0.25D);
   }

   public static void a(double var0, double var2, double var4, double var6, double var8, double var10, int var12, int var13, float[] var14, double var15, double var17) {
      int var19 = var12 + var13;
      buq.b(3553, 10242, 10497);
      buq.b(3553, 10243, 10497);
      buq.g();
      buq.r();
      buq.l();
      buq.a(true);
      buq.a(buq.r.l, buq.l.e, buq.r.e, buq.l.n);
      bvc var20 = bvc.a();
      bui var21 = var20.c();
      double var22 = var10 + var6;
      double var24 = var13 < 0 ? var22 : -var22;
      double var26 = ri.h(var24 * 0.2D - (double)ri.c(var24 * 0.1D));
      float var28 = var14[0];
      float var29 = var14[1];
      float var30 = var14[2];
      double var31 = var22 * 0.025D * -1.5D;
      double var33 = 0.5D + Math.cos(var31 + 2.356194490192345D) * var15;
      double var35 = 0.5D + Math.sin(var31 + 2.356194490192345D) * var15;
      double var37 = 0.5D + Math.cos(var31 + 0.7853981633974483D) * var15;
      double var39 = 0.5D + Math.sin(var31 + 0.7853981633974483D) * var15;
      double var41 = 0.5D + Math.cos(var31 + 3.9269908169872414D) * var15;
      double var43 = 0.5D + Math.sin(var31 + 3.9269908169872414D) * var15;
      double var45 = 0.5D + Math.cos(var31 + 5.497787143782138D) * var15;
      double var47 = 0.5D + Math.sin(var31 + 5.497787143782138D) * var15;
      double var49 = 0.0D;
      double var51 = 1.0D;
      double var53 = -1.0D + var26;
      double var55 = (double)var13 * var8 * (0.5D / var15) + var53;
      var21.a(7, cdw.i);
      var21.b(var0 + var33, var2 + (double)var19, var4 + var35).a(1.0D, var55).a(var28, var29, var30, 1.0F).d();
      var21.b(var0 + var33, var2 + (double)var12, var4 + var35).a(1.0D, var53).a(var28, var29, var30, 1.0F).d();
      var21.b(var0 + var37, var2 + (double)var12, var4 + var39).a(0.0D, var53).a(var28, var29, var30, 1.0F).d();
      var21.b(var0 + var37, var2 + (double)var19, var4 + var39).a(0.0D, var55).a(var28, var29, var30, 1.0F).d();
      var21.b(var0 + var45, var2 + (double)var19, var4 + var47).a(1.0D, var55).a(var28, var29, var30, 1.0F).d();
      var21.b(var0 + var45, var2 + (double)var12, var4 + var47).a(1.0D, var53).a(var28, var29, var30, 1.0F).d();
      var21.b(var0 + var41, var2 + (double)var12, var4 + var43).a(0.0D, var53).a(var28, var29, var30, 1.0F).d();
      var21.b(var0 + var41, var2 + (double)var19, var4 + var43).a(0.0D, var55).a(var28, var29, var30, 1.0F).d();
      var21.b(var0 + var37, var2 + (double)var19, var4 + var39).a(1.0D, var55).a(var28, var29, var30, 1.0F).d();
      var21.b(var0 + var37, var2 + (double)var12, var4 + var39).a(1.0D, var53).a(var28, var29, var30, 1.0F).d();
      var21.b(var0 + var45, var2 + (double)var12, var4 + var47).a(0.0D, var53).a(var28, var29, var30, 1.0F).d();
      var21.b(var0 + var45, var2 + (double)var19, var4 + var47).a(0.0D, var55).a(var28, var29, var30, 1.0F).d();
      var21.b(var0 + var41, var2 + (double)var19, var4 + var43).a(1.0D, var55).a(var28, var29, var30, 1.0F).d();
      var21.b(var0 + var41, var2 + (double)var12, var4 + var43).a(1.0D, var53).a(var28, var29, var30, 1.0F).d();
      var21.b(var0 + var33, var2 + (double)var12, var4 + var35).a(0.0D, var53).a(var28, var29, var30, 1.0F).d();
      var21.b(var0 + var33, var2 + (double)var19, var4 + var35).a(0.0D, var55).a(var28, var29, var30, 1.0F).d();
      var20.b();
      buq.m();
      buq.a(buq.r.l, buq.l.j, buq.r.e, buq.l.n);
      buq.a(false);
      var31 = 0.5D - var17;
      var33 = 0.5D - var17;
      var35 = 0.5D + var17;
      var37 = 0.5D - var17;
      var39 = 0.5D - var17;
      var41 = 0.5D + var17;
      var43 = 0.5D + var17;
      var45 = 0.5D + var17;
      var47 = 0.0D;
      var49 = 1.0D;
      var51 = -1.0D + var26;
      var53 = (double)var13 * var8 + var51;
      var21.a(7, cdw.i);
      var21.b(var0 + var31, var2 + (double)var19, var4 + var33).a(1.0D, var53).a(var28, var29, var30, 0.125F).d();
      var21.b(var0 + var31, var2 + (double)var12, var4 + var33).a(1.0D, var51).a(var28, var29, var30, 0.125F).d();
      var21.b(var0 + var35, var2 + (double)var12, var4 + var37).a(0.0D, var51).a(var28, var29, var30, 0.125F).d();
      var21.b(var0 + var35, var2 + (double)var19, var4 + var37).a(0.0D, var53).a(var28, var29, var30, 0.125F).d();
      var21.b(var0 + var43, var2 + (double)var19, var4 + var45).a(1.0D, var53).a(var28, var29, var30, 0.125F).d();
      var21.b(var0 + var43, var2 + (double)var12, var4 + var45).a(1.0D, var51).a(var28, var29, var30, 0.125F).d();
      var21.b(var0 + var39, var2 + (double)var12, var4 + var41).a(0.0D, var51).a(var28, var29, var30, 0.125F).d();
      var21.b(var0 + var39, var2 + (double)var19, var4 + var41).a(0.0D, var53).a(var28, var29, var30, 0.125F).d();
      var21.b(var0 + var35, var2 + (double)var19, var4 + var37).a(1.0D, var53).a(var28, var29, var30, 0.125F).d();
      var21.b(var0 + var35, var2 + (double)var12, var4 + var37).a(1.0D, var51).a(var28, var29, var30, 0.125F).d();
      var21.b(var0 + var43, var2 + (double)var12, var4 + var45).a(0.0D, var51).a(var28, var29, var30, 0.125F).d();
      var21.b(var0 + var43, var2 + (double)var19, var4 + var45).a(0.0D, var53).a(var28, var29, var30, 0.125F).d();
      var21.b(var0 + var39, var2 + (double)var19, var4 + var41).a(1.0D, var53).a(var28, var29, var30, 0.125F).d();
      var21.b(var0 + var39, var2 + (double)var12, var4 + var41).a(1.0D, var51).a(var28, var29, var30, 0.125F).d();
      var21.b(var0 + var31, var2 + (double)var12, var4 + var33).a(0.0D, var51).a(var28, var29, var30, 0.125F).d();
      var21.b(var0 + var31, var2 + (double)var19, var4 + var33).a(0.0D, var53).a(var28, var29, var30, 0.125F).d();
      var20.b();
      buq.f();
      buq.y();
      buq.a(true);
   }

   public boolean a(avf var1) {
      return true;
   }
}
