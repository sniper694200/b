import com.google.common.collect.HashMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import java.text.DecimalFormat;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Map.Entry;
import javax.annotation.Nullable;

public final class ain {
   public static final ain a = new ain((ail)null);
   public static final DecimalFormat b = new DecimalFormat("#.##");
   private int c;
   private int d;
   private final ail e;
   private fy f;
   private boolean g;
   private int h;
   private abz i;
   private aou j;
   private boolean k;
   private aou l;
   private boolean m;

   public ain(aou var1) {
      this((aou)var1, 1);
   }

   public ain(aou var1, int var2) {
      this((aou)var1, var2, 0);
   }

   public ain(aou var1, int var2, int var3) {
      this(ail.a(var1), var2, var3);
   }

   public ain(ail var1) {
      this((ail)var1, 1);
   }

   public ain(ail var1, int var2) {
      this((ail)var1, var2, 0);
   }

   public ain(ail var1, int var2, int var3) {
      this.e = var1;
      this.h = var3;
      this.c = var2;
      if (this.h < 0) {
         this.h = 0;
      }

      this.F();
   }

   private void F() {
      this.g = this.b();
   }

   public ain(fy var1) {
      this.e = ail.b(var1.l("id"));
      this.c = var1.f("Count");
      this.h = Math.max(0, var1.g("Damage"));
      if (var1.b("tag", 10)) {
         this.f = var1.p("tag");
         if (this.e != null) {
            this.e.a(var1);
         }
      }

      this.F();
   }

   public boolean b() {
      if (this == a) {
         return true;
      } else if (this.e != null && this.e != ail.a(aov.a)) {
         if (this.c <= 0) {
            return true;
         } else {
            return this.h < -32768 || this.h > 65535;
         }
      } else {
         return true;
      }
   }

   public static void a(rw var0) {
      var0.a((ru)ru.f, (ry)(new tj()));
      var0.a((ru)ru.f, (ry)(new tk()));
   }

   public ain a(int var1) {
      int var2 = Math.min(var1, this.c);
      ain var3 = this.l();
      var3.e(var2);
      this.g(var2);
      return var3;
   }

   public ail c() {
      return this.g ? ail.a(aov.a) : this.e;
   }

   public ub a(aeb var1, ams var2, et var3, tz var4, fa var5, float var6, float var7, float var8) {
      ub var9 = this.c().a(var1, var2, var3, var4, var5, var6, var7, var8);
      if (var9 == ub.a) {
         var1.b(qq.b(this.e));
      }

      return var9;
   }

   public float a(awr var1) {
      return this.c().a(this, var1);
   }

   public uc<ain> a(ams var1, aeb var2, tz var3) {
      return this.c().a(var1, var2, var3);
   }

   public ain a(ams var1, vn var2) {
      return this.c().a(this, var1, var2);
   }

   public fy a(fy var1) {
      nd var2 = (nd)ail.g.b(this.e);
      var1.a("id", var2 == null ? "minecraft:air" : var2.toString());
      var1.a("Count", (byte)this.c);
      var1.a("Damage", (short)this.h);
      if (this.f != null) {
         var1.a((String)"tag", (gn)this.f);
      }

      return var1;
   }

   public int d() {
      return this.c().j();
   }

   public boolean e() {
      return this.d() > 1 && (!this.f() || !this.h());
   }

   public boolean f() {
      if (this.g) {
         return false;
      } else if (this.e.l() <= 0) {
         return false;
      } else {
         return !this.o() || !this.p().q("Unbreakable");
      }
   }

   public boolean g() {
      return this.c().k();
   }

   public boolean h() {
      return this.f() && this.h > 0;
   }

   public int i() {
      return this.h;
   }

   public int j() {
      return this.h;
   }

   public void b(int var1) {
      this.h = var1;
      if (this.h < 0) {
         this.h = 0;
      }

   }

   public int k() {
      return this.c().l();
   }

   public boolean a(int var1, Random var2, @Nullable oo var3) {
      if (!this.f()) {
         return false;
      } else {
         if (var1 > 0) {
            int var4 = alk.a(alm.u, this);
            int var5 = 0;

            for(int var6 = 0; var4 > 0 && var6 < var1; ++var6) {
               if (alg.a(this, var4, var2)) {
                  ++var5;
               }
            }

            var1 -= var5;
            if (var1 <= 0) {
               return false;
            }
         }

         if (var3 != null && var1 != 0) {
            m.s.a(var3, this, this.h + var1);
         }

         this.h += var1;
         return this.h > this.k();
      }
   }

   public void a(int var1, vn var2) {
      if (!(var2 instanceof aeb) || !((aeb)var2).bO.d) {
         if (this.f()) {
            if (this.a(var1, var2.bR(), var2 instanceof oo ? (oo)var2 : null)) {
               var2.b(this);
               this.g(1);
               if (var2 instanceof aeb) {
                  aeb var3 = (aeb)var2;
                  var3.b(qq.c(this.e));
               }

               this.h = 0;
            }

         }
      }
   }

   public void a(vn var1, aeb var2) {
      boolean var3 = this.e.a((ain)this, (vn)var1, (vn)var2);
      if (var3) {
         var2.b(qq.b(this.e));
      }

   }

   public void a(ams var1, awr var2, et var3, aeb var4) {
      boolean var5 = this.c().a(this, var1, var2, var3, var4);
      if (var5) {
         var4.b(qq.b(this.e));
      }

   }

   public boolean b(awr var1) {
      return this.c().a(var1);
   }

   public boolean a(aeb var1, vn var2, tz var3) {
      return this.c().a(this, var1, var2, var3);
   }

   public ain l() {
      ain var1 = new ain(this.e, this.c, this.h);
      var1.d(this.D());
      if (this.f != null) {
         var1.f = this.f.g();
      }

      return var1;
   }

   public static boolean a(ain var0, ain var1) {
      if (var0.b() && var1.b()) {
         return true;
      } else if (!var0.b() && !var1.b()) {
         if (var0.f == null && var1.f != null) {
            return false;
         } else {
            return var0.f == null || var0.f.equals(var1.f);
         }
      } else {
         return false;
      }
   }

   public static boolean b(ain var0, ain var1) {
      if (var0.b() && var1.b()) {
         return true;
      } else {
         return !var0.b() && !var1.b() ? var0.d(var1) : false;
      }
   }

   private boolean d(ain var1) {
      if (this.c != var1.c) {
         return false;
      } else if (this.c() != var1.c()) {
         return false;
      } else if (this.h != var1.h) {
         return false;
      } else if (this.f == null && var1.f != null) {
         return false;
      } else {
         return this.f == null || this.f.equals(var1.f);
      }
   }

   public static boolean c(ain var0, ain var1) {
      if (var0 == var1) {
         return true;
      } else {
         return !var0.b() && !var1.b() ? var0.a(var1) : false;
      }
   }

   public static boolean d(ain var0, ain var1) {
      if (var0 == var1) {
         return true;
      } else {
         return !var0.b() && !var1.b() ? var0.b(var1) : false;
      }
   }

   public boolean a(ain var1) {
      return !var1.b() && this.e == var1.e && this.h == var1.h;
   }

   public boolean b(ain var1) {
      if (!this.f()) {
         return this.a(var1);
      } else {
         return !var1.b() && this.e == var1.e;
      }
   }

   public String a() {
      return this.c().a(this);
   }

   public String toString() {
      return this.c + "x" + this.c().a() + "@" + this.h;
   }

   public void a(ams var1, ve var2, int var3, boolean var4) {
      if (this.d > 0) {
         --this.d;
      }

      if (this.e != null) {
         this.e.a(this, var1, var2, var3, var4);
      }

   }

   public void a(ams var1, aeb var2, int var3) {
      var2.a(qq.a(this.e), var3);
      this.c().b(this, var1, var2);
   }

   public int m() {
      return this.c().e(this);
   }

   public aka n() {
      return this.c().f(this);
   }

   public void a(ams var1, vn var2, int var3) {
      this.c().a(this, var1, var2, var3);
   }

   public boolean o() {
      return !this.g && this.f != null;
   }

   @Nullable
   public fy p() {
      return this.f;
   }

   public fy c(String var1) {
      if (this.f != null && this.f.b(var1, 10)) {
         return this.f.p(var1);
      } else {
         fy var2 = new fy();
         this.a((String)var1, (gn)var2);
         return var2;
      }
   }

   @Nullable
   public fy d(String var1) {
      return this.f != null && this.f.b(var1, 10) ? this.f.p(var1) : null;
   }

   public void e(String var1) {
      if (this.f != null && this.f.b(var1, 10)) {
         this.f.r(var1);
      }

   }

   public ge q() {
      return this.f != null ? this.f.c("ench", 10) : new ge();
   }

   public void b(@Nullable fy var1) {
      this.f = var1;
   }

   public String r() {
      fy var1 = this.d("display");
      if (var1 != null) {
         if (var1.b("Name", 8)) {
            return var1.l("Name");
         }

         if (var1.b("LocName", 8)) {
            return ft.a(var1.l("LocName"));
         }
      }

      return this.c().b(this);
   }

   public ain f(String var1) {
      this.c("display").a("LocName", var1);
      return this;
   }

   public ain g(String var1) {
      this.c("display").a("Name", var1);
      return this;
   }

   public void s() {
      fy var1 = this.d("display");
      if (var1 != null) {
         var1.r("Name");
         if (var1.b_()) {
            this.e("display");
         }
      }

      if (this.f != null && this.f.b_()) {
         this.f = null;
      }

   }

   public boolean t() {
      fy var1 = this.d("display");
      return var1 != null && var1.b("Name", 8);
   }

   public List<String> a(@Nullable aeb var1, ajz var2) {
      List<String> var3 = Lists.newArrayList();
      String var4 = this.r();
      if (this.t()) {
         var4 = a.u + var4;
      }

      var4 = var4 + a.v;
      if (var2.a()) {
         String var5 = "";
         if (!var4.isEmpty()) {
            var4 = var4 + " (";
            var5 = ")";
         }

         int var6 = ail.a(this.e);
         if (this.g()) {
            var4 = var4 + String.format("#%04d/%d%s", var6, this.h, var5);
         } else {
            var4 = var4 + String.format("#%04d%s", var6, var5);
         }
      } else if (!this.t() && this.e == aip.bl) {
         var4 = var4 + " #" + this.h;
      }

      var3.add(var4);
      int var19 = 0;
      if (this.o() && this.f.b("HideFlags", 99)) {
         var19 = this.f.h("HideFlags");
      }

      if ((var19 & 32) == 0) {
         this.c().a(this, (ams)(var1 == null ? null : var1.l), (List)var3, (ajz)var2);
      }

      int var7;
      ge var20;
      int var24;
      if (this.o()) {
         if ((var19 & 1) == 0) {
            var20 = this.q();

            for(var7 = 0; var7 < var20.c(); ++var7) {
               fy var8 = var20.b(var7);
               int var9 = var8.g("id");
               int var10 = var8.g("lvl");
               ali var11 = ali.c(var9);
               if (var11 != null) {
                  var3.add(var11.d(var10));
               }
            }
         }

         if (this.f.b("display", 10)) {
            fy var21 = this.f.p("display");
            if (var21.b("color", 3)) {
               if (var2.a()) {
                  var3.add(ft.a("item.color", String.format("#%06X", var21.h("color"))));
               } else {
                  var3.add(a.u + ft.a("item.dyed"));
               }
            }

            if (var21.d("Lore") == 9) {
               ge var23 = var21.c("Lore", 8);
               if (!var23.b_()) {
                  for(var24 = 0; var24 < var23.c(); ++var24) {
                     var3.add(a.f + "" + a.u + var23.h(var24));
                  }
               }
            }
         }
      }

      vj[] var22 = vj.values();
      var7 = var22.length;

      for(var24 = 0; var24 < var7; ++var24) {
         vj var25 = var22[var24];
         Multimap<String, wc> var27 = this.a(var25);
         if (!var27.isEmpty() && (var19 & 2) == 0) {
            var3.add("");
            var3.add(ft.a("item.modifiers." + var25.d()));
            Iterator var28 = var27.entries().iterator();

            while(var28.hasNext()) {
               Entry<String, wc> var12 = (Entry)var28.next();
               wc var13 = (wc)var12.getValue();
               double var14 = var13.d();
               boolean var18 = false;
               if (var1 != null) {
                  if (var13.a() == ail.h) {
                     var14 += var1.a((wa)adf.f).b();
                     var14 += (double)alk.a(this, vs.a);
                     var18 = true;
                  } else if (var13.a() == ail.i) {
                     var14 += var1.a((wa)adf.g).b();
                     var18 = true;
                  }
               }

               double var16;
               if (var13.c() != 1 && var13.c() != 2) {
                  var16 = var14;
               } else {
                  var16 = var14 * 100.0D;
               }

               if (var18) {
                  var3.add(" " + ft.a("attribute.modifier.equals." + var13.c(), b.format(var16), ft.a("attribute.name." + (String)var12.getKey())));
               } else if (var14 > 0.0D) {
                  var3.add(a.j + " " + ft.a("attribute.modifier.plus." + var13.c(), b.format(var16), ft.a("attribute.name." + (String)var12.getKey())));
               } else if (var14 < 0.0D) {
                  var16 *= -1.0D;
                  var3.add(a.m + " " + ft.a("attribute.modifier.take." + var13.c(), b.format(var16), ft.a("attribute.name." + (String)var12.getKey())));
               }
            }
         }
      }

      if (this.o() && this.p().q("Unbreakable") && (var19 & 4) == 0) {
         var3.add(a.j + ft.a("item.unbreakable"));
      }

      aou var26;
      if (this.o() && this.f.b("CanDestroy", 9) && (var19 & 8) == 0) {
         var20 = this.f.c("CanDestroy", 8);
         if (!var20.b_()) {
            var3.add("");
            var3.add(a.h + ft.a("item.canBreak"));

            for(var7 = 0; var7 < var20.c(); ++var7) {
               var26 = aou.b(var20.h(var7));
               if (var26 != null) {
                  var3.add(a.i + var26.c());
               } else {
                  var3.add(a.i + "missingno");
               }
            }
         }
      }

      if (this.o() && this.f.b("CanPlaceOn", 9) && (var19 & 16) == 0) {
         var20 = this.f.c("CanPlaceOn", 8);
         if (!var20.b_()) {
            var3.add("");
            var3.add(a.h + ft.a("item.canPlace"));

            for(var7 = 0; var7 < var20.c(); ++var7) {
               var26 = aou.b(var20.h(var7));
               if (var26 != null) {
                  var3.add(a.i + var26.c());
               } else {
                  var3.add(a.i + "missingno");
               }
            }
         }
      }

      if (var2.a()) {
         if (this.h()) {
            var3.add(ft.a("item.durability", this.k() - this.i(), this.k()));
         }

         var3.add(a.i + ((nd)ail.g.b(this.e)).toString());
         if (this.o()) {
            var3.add(a.i + ft.a("item.nbt_tags", this.p().c().size()));
         }
      }

      return var3;
   }

   public boolean u() {
      return this.c().f_(this);
   }

   public ajc v() {
      return this.c().g(this);
   }

   public boolean w() {
      if (!this.c().g_(this)) {
         return false;
      } else {
         return !this.x();
      }
   }

   public void a(ali var1, int var2) {
      if (this.f == null) {
         this.b(new fy());
      }

      if (!this.f.b("ench", 9)) {
         this.f.a((String)"ench", (gn)(new ge()));
      }

      ge var3 = this.f.c("ench", 10);
      fy var4 = new fy();
      var4.a("id", (short)ali.b(var1));
      var4.a("lvl", (short)((byte)var2));
      var3.a((gn)var4);
   }

   public boolean x() {
      if (this.f != null && this.f.b("ench", 9)) {
         return !this.f.c("ench", 10).b_();
      } else {
         return false;
      }
   }

   public void a(String var1, gn var2) {
      if (this.f == null) {
         this.b(new fy());
      }

      this.f.a(var1, var2);
   }

   public boolean y() {
      return this.c().s();
   }

   public boolean z() {
      return this.i != null;
   }

   public void a(abz var1) {
      this.i = var1;
   }

   @Nullable
   public abz A() {
      return this.g ? null : this.i;
   }

   public int B() {
      return this.o() && this.f.b("RepairCost", 3) ? this.f.h("RepairCost") : 0;
   }

   public void c(int var1) {
      if (!this.o()) {
         this.f = new fy();
      }

      this.f.a("RepairCost", var1);
   }

   public Multimap<String, wc> a(vj var1) {
      Object var2;
      if (this.o() && this.f.b("AttributeModifiers", 9)) {
         var2 = HashMultimap.create();
         ge var3 = this.f.c("AttributeModifiers", 10);

         for(int var4 = 0; var4 < var3.c(); ++var4) {
            fy var5 = var3.b(var4);
            wc var6 = adf.a(var5);
            if (var6 != null && (!var5.b("Slot", 8) || var5.l("Slot").equals(var1.d())) && var6.a().getLeastSignificantBits() != 0L && var6.a().getMostSignificantBits() != 0L) {
               ((Multimap)var2).put(var5.l("AttributeName"), var6);
            }
         }
      } else {
         var2 = this.c().a(var1);
      }

      return (Multimap)var2;
   }

   public void a(String var1, wc var2, @Nullable vj var3) {
      if (this.f == null) {
         this.f = new fy();
      }

      if (!this.f.b("AttributeModifiers", 9)) {
         this.f.a((String)"AttributeModifiers", (gn)(new ge()));
      }

      ge var4 = this.f.c("AttributeModifiers", 10);
      fy var5 = adf.a(var2);
      var5.a("AttributeName", var1);
      if (var3 != null) {
         var5.a("Slot", var3.d());
      }

      var4.a((gn)var5);
   }

   public hh C() {
      ho var1 = new ho(this.r());
      if (this.t()) {
         var1.b().b(true);
      }

      hh var2 = (new ho("[")).a(var1).a("]");
      if (!this.g) {
         fy var3 = this.a(new fy());
         var2.b().a(new hj(hj.a.b, new ho(var3.toString())));
         var2.b().a(this.v().e);
      }

      return var2;
   }

   public boolean a(aou var1) {
      if (var1 == this.j) {
         return this.k;
      } else {
         this.j = var1;
         if (this.o() && this.f.b("CanDestroy", 9)) {
            ge var2 = this.f.c("CanDestroy", 8);

            for(int var3 = 0; var3 < var2.c(); ++var3) {
               aou var4 = aou.b(var2.h(var3));
               if (var4 == var1) {
                  this.k = true;
                  return true;
               }
            }
         }

         this.k = false;
         return false;
      }
   }

   public boolean b(aou var1) {
      if (var1 == this.l) {
         return this.m;
      } else {
         this.l = var1;
         if (this.o() && this.f.b("CanPlaceOn", 9)) {
            ge var2 = this.f.c("CanPlaceOn", 8);

            for(int var3 = 0; var3 < var2.c(); ++var3) {
               aou var4 = aou.b(var2.h(var3));
               if (var4 == var1) {
                  this.m = true;
                  return true;
               }
            }
         }

         this.m = false;
         return false;
      }
   }

   public int D() {
      return this.d;
   }

   public void d(int var1) {
      this.d = var1;
   }

   public int E() {
      return this.g ? 0 : this.c;
   }

   public void e(int var1) {
      this.c = var1;
      this.F();
   }

   public void f(int var1) {
      this.e(this.c + var1);
   }

   public void g(int var1) {
      this.f(-var1);
   }
}
