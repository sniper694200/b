public class brc extends bpv {
   protected brq a;
   protected brq b;

   public brc() {
      this(0.0F);
   }

   public brc(float var1) {
      super(var1, 0.0F, 64, 64);
      this.k.j = false;
      this.f.j = false;
      this.j = new brq(this, 32, 0);
      this.j.a(-1.0F, -1.0F, -2.0F, 6, 10, 4, 0.0F);
      this.j.a(-1.9F, 12.0F, 0.0F);
      this.b = new brq(this, 0, 32);
      this.b.a(-20.0F, 0.0F, 0.0F, 20, 12, 1);
      this.a = new brq(this, 0, 32);
      this.a.i = true;
      this.a.a(0.0F, 0.0F, 0.0F, 20, 12, 1);
   }

   public void a(ve var1, float var2, float var3, float var4, float var5, float var6, float var7) {
      super.a(var1, var2, var3, var4, var5, var6, var7);
      this.b.a(var7);
      this.a.a(var7);
   }

   public void a(float var1, float var2, float var3, float var4, float var5, float var6, ve var7) {
      super.a(var1, var2, var3, var4, var5, var6, var7);
      adn var8 = (adn)var7;
      if (var8.dn()) {
         if (var8.cF() == vm.b) {
            this.h.f = 3.7699115F;
         } else {
            this.i.f = 3.7699115F;
         }
      }

      brq var10000 = this.j;
      var10000.f += 0.62831855F;
      this.b.e = 2.0F;
      this.a.e = 2.0F;
      this.b.d = 1.0F;
      this.a.d = 1.0F;
      this.b.g = 0.47123894F + ri.b(var3 * 0.8F) * 3.1415927F * 0.05F;
      this.a.g = -this.b.g;
      this.a.h = -0.47123894F;
      this.a.f = 0.47123894F;
      this.b.f = 0.47123894F;
      this.b.h = 0.47123894F;
   }

   public int a() {
      return 23;
   }
}
