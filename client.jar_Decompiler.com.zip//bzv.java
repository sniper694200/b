public class bzv extends cad<adb> {
   private static final nd a = new nd("textures/entity/slime/magmacube.png");

   public bzv(bzd var1) {
      super(var1, new bpy(), 0.25F);
   }

   protected nd a(adb var1) {
      return a;
   }

   protected void a(adb var1, float var2) {
      int var3 = var1.dl();
      float var4 = (var1.c + (var1.b - var1.c) * var2) / ((float)var3 * 0.5F + 1.0F);
      float var5 = 1.0F / (var4 + 1.0F);
      buq.b(var5 * (float)var3, 1.0F / var5 * (float)var3, var5 * (float)var3);
   }
}
