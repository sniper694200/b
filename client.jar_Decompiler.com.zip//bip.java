public class bip {
   public static final nd b = new nd("textures/gui/options_background.png");
   public static final nd c = new nd("textures/gui/container/stats_icons.png");
   public static final nd d = new nd("textures/gui/icons.png");
   protected float e;

   protected void a(int var1, int var2, int var3, int var4) {
      if (var2 < var1) {
         int var5 = var1;
         var1 = var2;
         var2 = var5;
      }

      a(var1, var3, var2 + 1, var3 + 1, var4);
   }

   protected void b(int var1, int var2, int var3, int var4) {
      if (var3 < var2) {
         int var5 = var2;
         var2 = var3;
         var3 = var5;
      }

      a(var1, var2 + 1, var1 + 1, var3, var4);
   }

   public static void a(int var0, int var1, int var2, int var3, int var4) {
      int var5;
      if (var0 < var2) {
         var5 = var0;
         var0 = var2;
         var2 = var5;
      }

      if (var1 < var3) {
         var5 = var1;
         var1 = var3;
         var3 = var5;
      }

      float var11 = (float)(var4 >> 24 & 255) / 255.0F;
      float var6 = (float)(var4 >> 16 & 255) / 255.0F;
      float var7 = (float)(var4 >> 8 & 255) / 255.0F;
      float var8 = (float)(var4 & 255) / 255.0F;
      bvc var9 = bvc.a();
      bui var10 = var9.c();
      buq.m();
      buq.z();
      buq.a(buq.r.l, buq.l.j, buq.r.e, buq.l.n);
      buq.c(var6, var7, var8, var11);
      var10.a(7, cdw.e);
      var10.b((double)var0, (double)var3, 0.0D).d();
      var10.b((double)var2, (double)var3, 0.0D).d();
      var10.b((double)var2, (double)var1, 0.0D).d();
      var10.b((double)var0, (double)var1, 0.0D).d();
      var9.b();
      buq.y();
      buq.l();
   }

   protected void a(int var1, int var2, int var3, int var4, int var5, int var6) {
      float var7 = (float)(var5 >> 24 & 255) / 255.0F;
      float var8 = (float)(var5 >> 16 & 255) / 255.0F;
      float var9 = (float)(var5 >> 8 & 255) / 255.0F;
      float var10 = (float)(var5 & 255) / 255.0F;
      float var11 = (float)(var6 >> 24 & 255) / 255.0F;
      float var12 = (float)(var6 >> 16 & 255) / 255.0F;
      float var13 = (float)(var6 >> 8 & 255) / 255.0F;
      float var14 = (float)(var6 & 255) / 255.0F;
      buq.z();
      buq.m();
      buq.d();
      buq.a(buq.r.l, buq.l.j, buq.r.e, buq.l.n);
      buq.j(7425);
      bvc var15 = bvc.a();
      bui var16 = var15.c();
      var16.a(7, cdw.f);
      var16.b((double)var3, (double)var2, (double)this.e).a(var8, var9, var10, var7).d();
      var16.b((double)var1, (double)var2, (double)this.e).a(var8, var9, var10, var7).d();
      var16.b((double)var1, (double)var4, (double)this.e).a(var12, var13, var14, var11).d();
      var16.b((double)var3, (double)var4, (double)this.e).a(var12, var13, var14, var11).d();
      var15.b();
      buq.j(7424);
      buq.l();
      buq.e();
      buq.y();
   }

   public void a(bin var1, String var2, int var3, int var4, int var5) {
      var1.a(var2, (float)(var3 - var1.a(var2) / 2), (float)var4, var5);
   }

   public void c(bin var1, String var2, int var3, int var4, int var5) {
      var1.a(var2, (float)var3, (float)var4, var5);
   }

   public void b(int var1, int var2, int var3, int var4, int var5, int var6) {
      float var7 = 0.00390625F;
      float var8 = 0.00390625F;
      bvc var9 = bvc.a();
      bui var10 = var9.c();
      var10.a(7, cdw.g);
      var10.b((double)(var1 + 0), (double)(var2 + var6), (double)this.e).a((double)((float)(var3 + 0) * 0.00390625F), (double)((float)(var4 + var6) * 0.00390625F)).d();
      var10.b((double)(var1 + var5), (double)(var2 + var6), (double)this.e).a((double)((float)(var3 + var5) * 0.00390625F), (double)((float)(var4 + var6) * 0.00390625F)).d();
      var10.b((double)(var1 + var5), (double)(var2 + 0), (double)this.e).a((double)((float)(var3 + var5) * 0.00390625F), (double)((float)(var4 + 0) * 0.00390625F)).d();
      var10.b((double)(var1 + 0), (double)(var2 + 0), (double)this.e).a((double)((float)(var3 + 0) * 0.00390625F), (double)((float)(var4 + 0) * 0.00390625F)).d();
      var9.b();
   }

   public void a(float var1, float var2, int var3, int var4, int var5, int var6) {
      float var7 = 0.00390625F;
      float var8 = 0.00390625F;
      bvc var9 = bvc.a();
      bui var10 = var9.c();
      var10.a(7, cdw.g);
      var10.b((double)(var1 + 0.0F), (double)(var2 + (float)var6), (double)this.e).a((double)((float)(var3 + 0) * 0.00390625F), (double)((float)(var4 + var6) * 0.00390625F)).d();
      var10.b((double)(var1 + (float)var5), (double)(var2 + (float)var6), (double)this.e).a((double)((float)(var3 + var5) * 0.00390625F), (double)((float)(var4 + var6) * 0.00390625F)).d();
      var10.b((double)(var1 + (float)var5), (double)(var2 + 0.0F), (double)this.e).a((double)((float)(var3 + var5) * 0.00390625F), (double)((float)(var4 + 0) * 0.00390625F)).d();
      var10.b((double)(var1 + 0.0F), (double)(var2 + 0.0F), (double)this.e).a((double)((float)(var3 + 0) * 0.00390625F), (double)((float)(var4 + 0) * 0.00390625F)).d();
      var9.b();
   }

   public void a(int var1, int var2, cdo var3, int var4, int var5) {
      bvc var6 = bvc.a();
      bui var7 = var6.c();
      var7.a(7, cdw.g);
      var7.b((double)(var1 + 0), (double)(var2 + var5), (double)this.e).a((double)var3.e(), (double)var3.h()).d();
      var7.b((double)(var1 + var4), (double)(var2 + var5), (double)this.e).a((double)var3.f(), (double)var3.h()).d();
      var7.b((double)(var1 + var4), (double)(var2 + 0), (double)this.e).a((double)var3.f(), (double)var3.g()).d();
      var7.b((double)(var1 + 0), (double)(var2 + 0), (double)this.e).a((double)var3.e(), (double)var3.g()).d();
      var6.b();
   }

   public static void a(int var0, int var1, float var2, float var3, int var4, int var5, float var6, float var7) {
      float var8 = 1.0F / var6;
      float var9 = 1.0F / var7;
      bvc var10 = bvc.a();
      bui var11 = var10.c();
      var11.a(7, cdw.g);
      var11.b((double)var0, (double)(var1 + var5), 0.0D).a((double)(var2 * var8), (double)((var3 + (float)var5) * var9)).d();
      var11.b((double)(var0 + var4), (double)(var1 + var5), 0.0D).a((double)((var2 + (float)var4) * var8), (double)((var3 + (float)var5) * var9)).d();
      var11.b((double)(var0 + var4), (double)var1, 0.0D).a((double)((var2 + (float)var4) * var8), (double)(var3 * var9)).d();
      var11.b((double)var0, (double)var1, 0.0D).a((double)(var2 * var8), (double)(var3 * var9)).d();
      var10.b();
   }

   public static void a(int var0, int var1, float var2, float var3, int var4, int var5, int var6, int var7, float var8, float var9) {
      float var10 = 1.0F / var8;
      float var11 = 1.0F / var9;
      bvc var12 = bvc.a();
      bui var13 = var12.c();
      var13.a(7, cdw.g);
      var13.b((double)var0, (double)(var1 + var7), 0.0D).a((double)(var2 * var10), (double)((var3 + (float)var5) * var11)).d();
      var13.b((double)(var0 + var6), (double)(var1 + var7), 0.0D).a((double)((var2 + (float)var4) * var10), (double)((var3 + (float)var5) * var11)).d();
      var13.b((double)(var0 + var6), (double)var1, 0.0D).a((double)((var2 + (float)var4) * var10), (double)(var3 * var11)).d();
      var13.b((double)var0, (double)var1, 0.0D).a((double)(var2 * var10), (double)(var3 * var11)).d();
      var12.b();
   }
}
