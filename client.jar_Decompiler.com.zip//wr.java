public class wr extends xc {
   private final aak a;
   private aeb b;
   private final ams c;
   private final float d;
   private int e;

   public wr(aak var1, float var2) {
      this.a = var1;
      this.c = var1.l;
      this.d = var2;
      this.a(2);
   }

   public boolean a() {
      this.b = this.c.a(this.a, (double)this.d);
      return this.b == null ? false : this.a(this.b);
   }

   public boolean b() {
      if (!this.b.aC()) {
         return false;
      } else if (this.a.h(this.b) > (double)(this.d * this.d)) {
         return false;
      } else {
         return this.e > 0 && this.a(this.b);
      }
   }

   public void c() {
      this.a.t(true);
      this.e = 40 + this.a.bR().nextInt(40);
   }

   public void d() {
      this.a.t(false);
      this.b = null;
   }

   public void e() {
      this.a.t().a(this.b.p, this.b.q + (double)this.b.by(), this.b.r, 10.0F, (float)this.a.N());
      --this.e;
   }

   private boolean a(aeb var1) {
      tz[] var2 = tz.values();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         tz var5 = var2[var4];
         ain var6 = var1.b((tz)var5);
         if (this.a.dl() && var6.c() == aip.bf) {
            return true;
         }

         if (this.a.e(var6)) {
            return true;
         }
      }

      return false;
   }
}
