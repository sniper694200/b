import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Map.Entry;

public class bby extends bbs {
   public static final List<anf> a;
   private int b;
   private int d;
   private final int h;

   public bby() {
      this.d = 32;
      this.h = 8;
   }

   public bby(Map<String, String> var1) {
      this();
      Iterator var2 = var1.entrySet().iterator();

      while(var2.hasNext()) {
         Entry<String, String> var3 = (Entry)var2.next();
         if (((String)var3.getKey()).equals("size")) {
            this.b = ri.a((String)((String)var3.getValue()), this.b, 0);
         } else if (((String)var3.getKey()).equals("distance")) {
            this.d = ri.a((String)((String)var3.getValue()), this.d, 9);
         }
      }

   }

   public String a() {
      return "Village";
   }

   protected boolean a(int var1, int var2) {
      int var3 = var1;
      int var4 = var2;
      if (var1 < 0) {
         var1 -= this.d - 1;
      }

      if (var2 < 0) {
         var2 -= this.d - 1;
      }

      int var5 = var1 / this.d;
      int var6 = var2 / this.d;
      Random var7 = this.g.a(var5, var6, 10387312);
      var5 *= this.d;
      var6 *= this.d;
      var5 += var7.nextInt(this.d - 8);
      var6 += var7.nextInt(this.d - 8);
      if (var3 == var5 && var4 == var6) {
         boolean var8 = this.g.C().a(var3 * 16 + 8, var4 * 16 + 8, 0, a);
         if (var8) {
            return true;
         }
      }

      return false;
   }

   public et a(ams var1, et var2, boolean var3) {
      this.g = var1;
      return a(var1, this, var2, this.d, 8, 10387312, false, 100, var3);
   }

   protected bbw b(int var1, int var2) {
      return new bby.a(this.g, this.f, var1, var2, this.b);
   }

   static {
      a = Arrays.asList(ank.c, ank.d, ank.K, ank.g);
   }

   public static class a extends bbw {
      private boolean c;

      public a() {
      }

      public a(ams var1, Random var2, int var3, int var4, int var5) {
         super(var3, var4);
         List<bbz.e> var6 = bbz.a(var2, var5);
         bbz.k var7 = new bbz.k(var1.C(), 0, var2, (var3 << 4) + 2, (var4 << 4) + 2, var6, var5);
         this.a.add(var7);
         var7.a(var7, this.a, var2);
         List<bbv> var8 = var7.f;
         List var9 = var7.e;

         int var10;
         while(!var8.isEmpty() || !var9.isEmpty()) {
            bbv var11;
            if (var8.isEmpty()) {
               var10 = var2.nextInt(var9.size());
               var11 = (bbv)var9.remove(var10);
               var11.a((bbv)var7, (List)this.a, (Random)var2);
            } else {
               var10 = var2.nextInt(var8.size());
               var11 = (bbv)var8.remove(var10);
               var11.a((bbv)var7, (List)this.a, (Random)var2);
            }
         }

         this.d();
         var10 = 0;
         Iterator var13 = this.a.iterator();

         while(var13.hasNext()) {
            bbv var12 = (bbv)var13.next();
            if (!(var12 instanceof bbz.o)) {
               ++var10;
            }
         }

         this.c = var10 > 2;
      }

      public boolean a() {
         return this.c;
      }

      public void a(fy var1) {
         super.a(var1);
         var1.a("Valid", this.c);
      }

      public void b(fy var1) {
         super.b(var1);
         this.c = var1.q("Valid");
      }
   }
}
