import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public class cl extends bi {
   public String c() {
      return "gamerule";
   }

   public int a() {
      return 2;
   }

   public String b(bn var1) {
      return "commands.gamerule.usage";
   }

   public void a(MinecraftServer var1, bn var2, String[] var3) throws ei {
      amp var4 = this.a(var1);
      String var5 = var3.length > 0 ? var3[0] : "";
      String var6 = var3.length > 1 ? a(var3, 1) : "";
      switch(var3.length) {
      case 0:
         var2.a(new ho(a(var4.b())));
         break;
      case 1:
         if (!var4.e(var5)) {
            throw new ei("commands.gamerule.norule", new Object[]{var5});
         }

         String var7 = var4.a(var5);
         var2.a((new ho(var5)).a(" = ").a(var7));
         var2.a(bp.a.e, var4.c(var5));
         break;
      default:
         if (var4.a(var5, amp.b.b) && !"true".equals(var6) && !"false".equals(var6)) {
            throw new ei("commands.generic.boolean.invalid", new Object[]{var6});
         }

         var4.a(var5, var6);
         a(var4, var5, var1);
         a(var2, this, "commands.gamerule.success", new Object[]{var5, var6});
      }

   }

   public static void a(amp var0, String var1, MinecraftServer var2) {
      if ("reducedDebugInfo".equals(var1)) {
         byte var3 = var0.b(var1) ? 22 : 23;
         Iterator var4 = var2.am().v().iterator();

         while(var4.hasNext()) {
            oo var5 = (oo)var4.next();
            var5.a.a((ht)(new iz(var5, (byte)var3)));
         }
      }

   }

   public List<String> a(MinecraftServer var1, bn var2, String[] var3, @Nullable et var4) {
      if (var3.length == 1) {
         return a(var3, this.a(var1).b());
      } else {
         if (var3.length == 2) {
            amp var5 = this.a(var1);
            if (var5.a(var3[0], amp.b.b)) {
               return a(var3, new String[]{"true", "false"});
            }

            if (var5.a(var3[0], amp.b.d)) {
               return a(var3, var1.aL().d().keySet());
            }
         }

         return Collections.emptyList();
      }
   }

   private amp a(MinecraftServer var1) {
      return var1.a(0).W();
   }
}
