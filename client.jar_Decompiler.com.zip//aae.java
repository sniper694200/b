import com.google.common.collect.Maps;
import java.util.Map;
import java.util.Random;
import javax.annotation.Nullable;

public class aae extends zt {
   private static final mx<Byte> bx;
   private final afw by = new afw(new afp() {
      public boolean a(aeb var1) {
         return false;
      }
   }, 2, 1);
   private static final Map<ahq, float[]> bz;
   private int bB;
   private wv bC;

   private static float[] c(ahq var0) {
      float[] var1 = var0.f();
      float var2 = 0.75F;
      return new float[]{var1[0] * 0.75F, var1[1] * 0.75F, var1[2] * 0.75F};
   }

   public static float[] a(ahq var0) {
      return (float[])bz.get(var0);
   }

   public aae(ams var1) {
      super(var1);
      this.a(0.9F, 1.3F);
      this.by.a(0, new ain(aip.be));
      this.by.a(1, new ain(aip.be));
   }

   protected void r() {
      this.bC = new wv(this);
      this.br.a(0, new wx(this));
      this.br.a(1, new xw(this, 1.25D));
      this.br.a(2, new wt(this, 1.0D));
      this.br.a(3, new yj(this, 1.1D, aip.R, false));
      this.br.a(4, new xb(this, 1.1D));
      this.br.a(5, this.bC);
      this.br.a(6, new yn(this, 1.0D));
      this.br.a(7, new xj(this, aeb.class, 6.0F));
      this.br.a(8, new xz(this));
   }

   protected void M() {
      this.bB = this.bC.f();
      super.M();
   }

   public void n() {
      if (this.l.G) {
         this.bB = Math.max(0, this.bB - 1);
      }

      super.n();
   }

   protected void bM() {
      super.bM();
      this.a((wa)adf.a).a(8.0D);
      this.a((wa)adf.d).a(0.23000000417232513D);
   }

   protected void i() {
      super.i();
      this.Y.a((mx)bx, (byte)0);
   }

   @Nullable
   protected nd J() {
      if (this.dm()) {
         return bfl.P;
      } else {
         switch(this.dl()) {
         case a:
         default:
            return bfl.Q;
         case b:
            return bfl.R;
         case c:
            return bfl.S;
         case d:
            return bfl.T;
         case e:
            return bfl.U;
         case f:
            return bfl.V;
         case g:
            return bfl.W;
         case h:
            return bfl.X;
         case i:
            return bfl.Y;
         case j:
            return bfl.Z;
         case k:
            return bfl.aa;
         case l:
            return bfl.ab;
         case m:
            return bfl.ac;
         case n:
            return bfl.ad;
         case o:
            return bfl.ae;
         case p:
            return bfl.af;
         }
      }
   }

   public void a(byte var1) {
      if (var1 == 10) {
         this.bB = 40;
      } else {
         super.a(var1);
      }

   }

   public float r(float var1) {
      if (this.bB <= 0) {
         return 0.0F;
      } else if (this.bB >= 4 && this.bB <= 36) {
         return 1.0F;
      } else {
         return this.bB < 4 ? ((float)this.bB - var1) / 4.0F : -((float)(this.bB - 40) - var1) / 4.0F;
      }
   }

   public float s(float var1) {
      if (this.bB > 4 && this.bB <= 36) {
         float var2 = ((float)(this.bB - 4) - var1) / 32.0F;
         return 0.62831855F + 0.21991149F * ri.a(var2 * 28.7F);
      } else {
         return this.bB > 0 ? 0.62831855F : this.w * 0.017453292F;
      }
   }

   public boolean a(aeb var1, tz var2) {
      ain var3 = var1.b((tz)var2);
      if (var3.c() == aip.bm && !this.dm() && !this.l_()) {
         if (!this.l.G) {
            this.p(true);
            int var4 = 1 + this.S.nextInt(3);

            for(int var5 = 0; var5 < var4; ++var5) {
               acj var6 = this.a(new ain(ail.a(aov.L), 1, this.dl().a()), 1.0F);
               var6.t += (double)(this.S.nextFloat() * 0.05F);
               var6.s += (double)((this.S.nextFloat() - this.S.nextFloat()) * 0.1F);
               var6.u += (double)((this.S.nextFloat() - this.S.nextFloat()) * 0.1F);
            }
         }

         var3.a(1, var1);
         this.a(qd.gv, 1.0F, 1.0F);
      }

      return super.a(var1, var2);
   }

   public static void a(rw var0) {
      vo.a(var0, aae.class);
   }

   public void b(fy var1) {
      super.b(var1);
      var1.a("Sheared", this.dm());
      var1.a("Color", (byte)this.dl().a());
   }

   public void a(fy var1) {
      super.a(var1);
      this.p(var1.q("Sheared"));
      this.b(ahq.b(var1.f("Color")));
   }

   protected qc F() {
      return qd.gs;
   }

   protected qc d(up var1) {
      return qd.gu;
   }

   protected qc cf() {
      return qd.gt;
   }

   protected void a(et var1, aou var2) {
      this.a(qd.gw, 0.15F, 1.0F);
   }

   public ahq dl() {
      return ahq.b((Byte)this.Y.a(bx) & 15);
   }

   public void b(ahq var1) {
      byte var2 = (Byte)this.Y.a(bx);
      this.Y.b(bx, (byte)(var2 & 240 | var1.a() & 15));
   }

   public boolean dm() {
      return ((Byte)this.Y.a(bx) & 16) != 0;
   }

   public void p(boolean var1) {
      byte var2 = (Byte)this.Y.a(bx);
      if (var1) {
         this.Y.b(bx, (byte)(var2 | 16));
      } else {
         this.Y.b(bx, (byte)(var2 & -17));
      }

   }

   public static ahq a(Random var0) {
      int var1 = var0.nextInt(100);
      if (var1 < 5) {
         return ahq.p;
      } else if (var1 < 10) {
         return ahq.h;
      } else if (var1 < 15) {
         return ahq.i;
      } else if (var1 < 18) {
         return ahq.m;
      } else {
         return var0.nextInt(500) == 0 ? ahq.g : ahq.a;
      }
   }

   public aae b(vb var1) {
      aae var2 = (aae)var1;
      aae var3 = new aae(this.l);
      var3.b(this.a((zt)this, (zt)var2));
      return var3;
   }

   public void A() {
      this.p(false);
      if (this.l_()) {
         this.a(60);
      }

   }

   @Nullable
   public vq a(ty var1, @Nullable vq var2) {
      var2 = super.a((ty)var1, (vq)var2);
      this.b(a(this.l.r));
      return var2;
   }

   private ahq a(zt var1, zt var2) {
      int var3 = ((aae)var1).dl().b();
      int var4 = ((aae)var2).dl().b();
      this.by.a(0).b(var3);
      this.by.a(1).b(var4);
      ain var5 = aks.a(this.by, ((aae)var1).l);
      int var6;
      if (var5.c() == aip.be) {
         var6 = var5.j();
      } else {
         var6 = this.l.r.nextBoolean() ? var3 : var4;
      }

      return ahq.a(var6);
   }

   public float by() {
      return 0.95F * this.H;
   }

   // $FF: synthetic method
   public vb a(vb var1) {
      return this.b(var1);
   }

   static {
      bx = na.a(aae.class, mz.a);
      bz = Maps.newEnumMap(ahq.class);
      ahq[] var0 = ahq.values();
      int var1 = var0.length;

      for(int var2 = 0; var2 < var1; ++var2) {
         ahq var3 = var0[var2];
         bz.put(var3, c(var3));
      }

      bz.put(ahq.a, new float[]{0.9019608F, 0.9019608F, 0.9019608F});
   }
}
