public class bml extends bme implements bns {
   private static final nd v = new nd("textures/gui/container/crafting_table.png");
   private bje w;
   private final bnm x;
   private boolean y;

   public bml(aea var1, ams var2) {
      this(var1, var2, et.a);
   }

   public bml(aea var1, ams var2, et var3) {
      super(new afx(var1, var2, var3));
      this.x = new bnm();
   }

   public void b() {
      super.b();
      this.y = this.l < 379;
      this.x.a(this.l, this.m, this.j, this.y, this.h, ((afx)this.h).a);
      this.i = this.x.a(this.y, this.l, this.f);
      this.w = new bje(10, this.i + 5, this.m / 2 - 49, 20, 18, 0, 168, 19, v);
      this.n.add(this.w);
   }

   public void e() {
      super.e();
      this.x.d();
   }

   public void a(int var1, int var2, float var3) {
      this.c();
      if (this.x.c() && this.y) {
         this.a(var3, var1, var2);
         this.x.a(var1, var2, var3);
      } else {
         this.x.a(var1, var2, var3);
         super.a(var1, var2, var3);
         this.x.a(this.i, this.s, true, var3);
      }

      this.b(var1, var2);
      this.x.c(this.i, this.s, var1, var2);
   }

   protected void c(int var1, int var2) {
      this.q.a(cew.a("container.crafting"), 28, 6, 4210752);
      this.q.a(cew.a("container.inventory"), 8, this.g - 96 + 2, 4210752);
   }

   protected void a(float var1, int var2, int var3) {
      buq.c(1.0F, 1.0F, 1.0F, 1.0F);
      this.j.N().a(v);
      int var4 = this.i;
      int var5 = (this.m - this.g) / 2;
      this.b(var4, var5, 0, 0, this.f, this.g);
   }

   protected boolean c(int var1, int var2, int var3, int var4, int var5, int var6) {
      return (!this.y || !this.x.c()) && super.c(var1, var2, var3, var4, var5, var6);
   }

   protected void a(int var1, int var2, int var3) {
      if (!this.x.a(var1, var2, var3)) {
         if (!this.y || !this.x.c()) {
            super.a(var1, var2, var3);
         }
      }
   }

   protected boolean c(int var1, int var2, int var3, int var4) {
      boolean var5 = var1 < var3 || var2 < var4 || var1 >= var3 + this.f || var2 >= var4 + this.g;
      return this.x.c(var1, var2, this.i, this.s, this.f, this.g) && var5;
   }

   protected void a(biy var1) {
      if (var1.k == 10) {
         this.x.a(this.y, ((afx)this.h).a);
         this.x.b();
         this.i = this.x.a(this.y, this.l, this.f);
         this.w.c(this.i + 5, this.m / 2 - 49);
      }

   }

   protected void a(char var1, int var2) {
      if (!this.x.a(var1, var2)) {
         super.a(var1, var2);
      }

   }

   protected void a(agp var1, int var2, int var3, afu var4) {
      super.a(var1, var2, var3, var4);
      this.x.a(var1);
   }

   public void I_() {
      this.x.e();
   }

   public void m() {
      this.x.a();
      super.m();
   }
}
