public class xr extends xc {
   private final vv a;
   private vn b;
   private double c;
   private double d;
   private double e;
   private final double f;
   private final float g;

   public xr(vv var1, double var2, float var4) {
      this.a = var1;
      this.f = var2;
      this.g = var4;
      this.a(1);
   }

   public boolean a() {
      this.b = this.a.z();
      if (this.b == null) {
         return false;
      } else if (this.b.h(this.a) > (double)(this.g * this.g)) {
         return false;
      } else {
         bhc var1 = zj.a(this.a, 16, 7, new bhc(this.b.p, this.b.q, this.b.r));
         if (var1 == null) {
            return false;
         } else {
            this.c = var1.b;
            this.d = var1.c;
            this.e = var1.d;
            return true;
         }
      }
   }

   public boolean b() {
      return !this.a.x().o() && this.b.aC() && this.b.h(this.a) < (double)(this.g * this.g);
   }

   public void d() {
      this.b = null;
   }

   public void c() {
      this.a.x().a(this.c, this.d, this.e, this.f);
   }
}
