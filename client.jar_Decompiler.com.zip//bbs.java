import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.Iterator;
import java.util.Random;
import javax.annotation.Nullable;

public abstract class bbs extends ayz {
   private bbu a;
   protected Long2ObjectMap<bbw> c = new Long2ObjectOpenHashMap(1024);

   public abstract String a();

   protected final synchronized void a(ams var1, final int var2, final int var3, int var4, int var5, ayu var6) {
      this.a(var1);
      if (!this.c.containsKey(aml.a(var2, var3))) {
         this.f.nextInt();

         try {
            if (this.a(var2, var3)) {
               bbw var7 = this.b(var2, var3);
               this.c.put(aml.a(var2, var3), var7);
               if (var7.a()) {
                  this.a(var2, var3, var7);
               }
            }

         } catch (Throwable var10) {
            b var8 = b.a(var10, "Exception preparing structure feature");
            c var9 = var8.a("Feature being prepared");
            var9.a("Is feature chunk", new d<String>() {
               public String a() throws Exception {
                  return bbs.this.a(var2, var3) ? "True" : "False";
               }

               // $FF: synthetic method
               public Object call() throws Exception {
                  return this.a();
               }
            });
            var9.a((String)"Chunk location", (Object)String.format("%d,%d", var2, var3));
            var9.a("Chunk pos hash", new d<String>() {
               public String a() throws Exception {
                  return String.valueOf(aml.a(var2, var3));
               }

               // $FF: synthetic method
               public Object call() throws Exception {
                  return this.a();
               }
            });
            var9.a("Structure type", new d<String>() {
               public String a() throws Exception {
                  return bbs.this.getClass().getCanonicalName();
               }

               // $FF: synthetic method
               public Object call() throws Exception {
                  return this.a();
               }
            });
            throw new f(var8);
         }
      }
   }

   public synchronized boolean a(ams var1, Random var2, aml var3) {
      this.a(var1);
      int var4 = (var3.a << 4) + 8;
      int var5 = (var3.b << 4) + 8;
      boolean var6 = false;
      ObjectIterator var7 = this.c.values().iterator();

      while(var7.hasNext()) {
         bbw var8 = (bbw)var7.next();
         if (var8.a() && var8.a(var3) && var8.b().a(var4, var5, var4 + 15, var5 + 15)) {
            var8.a(var1, var2, new bbe(var4, var5, var4 + 15, var5 + 15));
            var8.b(var3);
            var6 = true;
            this.a(var8.e(), var8.f(), var8);
         }
      }

      return var6;
   }

   public boolean b(et var1) {
      if (this.g == null) {
         return false;
      } else {
         this.a(this.g);
         return this.c(var1) != null;
      }
   }

   @Nullable
   protected bbw c(et var1) {
      ObjectIterator var2 = this.c.values().iterator();

      while(true) {
         bbw var3;
         do {
            do {
               if (!var2.hasNext()) {
                  return null;
               }

               var3 = (bbw)var2.next();
            } while(!var3.a());
         } while(!var3.b().b((fq)var1));

         Iterator var4 = var3.c().iterator();

         while(var4.hasNext()) {
            bbv var5 = (bbv)var4.next();
            if (var5.d().b((fq)var1)) {
               return var3;
            }
         }
      }
   }

   public boolean a(ams var1, et var2) {
      this.a(var1);
      ObjectIterator var3 = this.c.values().iterator();

      bbw var4;
      do {
         if (!var3.hasNext()) {
            return false;
         }

         var4 = (bbw)var3.next();
      } while(!var4.a() || !var4.b().b((fq)var2));

      return true;
   }

   @Nullable
   public abstract et a(ams var1, et var2, boolean var3);

   protected void a(ams var1) {
      if (this.a == null && var1 != null) {
         this.a = (bbu)var1.a(bbu.class, this.a());
         if (this.a == null) {
            this.a = new bbu(this.a());
            var1.a((String)this.a(), (ber)this.a);
         } else {
            fy var2 = this.a.a();
            Iterator var3 = var2.c().iterator();

            while(var3.hasNext()) {
               String var4 = (String)var3.next();
               gn var5 = var2.c(var4);
               if (var5.a() == 10) {
                  fy var6 = (fy)var5;
                  if (var6.e("ChunkX") && var6.e("ChunkZ")) {
                     int var7 = var6.h("ChunkX");
                     int var8 = var6.h("ChunkZ");
                     bbw var9 = bbt.a(var6, var1);
                     if (var9 != null) {
                        this.c.put(aml.a(var7, var8), var9);
                     }
                  }
               }
            }
         }
      }

   }

   private void a(int var1, int var2, bbw var3) {
      this.a.a(var3.a(var1, var2), var1, var2);
      this.a.c();
   }

   protected abstract boolean a(int var1, int var2);

   protected abstract bbw b(int var1, int var2);

   protected static et a(ams var0, bbs var1, et var2, int var3, int var4, int var5, boolean var6, int var7, boolean var8) {
      int var9 = var2.p() >> 4;
      int var10 = var2.r() >> 4;
      int var11 = 0;

      for(Random var12 = new Random(); var11 <= var7; ++var11) {
         for(int var13 = -var11; var13 <= var11; ++var13) {
            boolean var14 = var13 == -var11 || var13 == var11;

            for(int var15 = -var11; var15 <= var11; ++var15) {
               boolean var16 = var15 == -var11 || var15 == var11;
               if (var14 || var16) {
                  int var17 = var9 + var3 * var13;
                  int var18 = var10 + var3 * var15;
                  if (var17 < 0) {
                     var17 -= var3 - 1;
                  }

                  if (var18 < 0) {
                     var18 -= var3 - 1;
                  }

                  int var19 = var17 / var3;
                  int var20 = var18 / var3;
                  Random var21 = var0.a(var19, var20, var5);
                  var19 *= var3;
                  var20 *= var3;
                  if (var6) {
                     var19 += (var21.nextInt(var3 - var4) + var21.nextInt(var3 - var4)) / 2;
                     var20 += (var21.nextInt(var3 - var4) + var21.nextInt(var3 - var4)) / 2;
                  } else {
                     var19 += var21.nextInt(var3 - var4);
                     var20 += var21.nextInt(var3 - var4);
                  }

                  ayz.a(var0.Q(), var12, var19, var20);
                  var12.nextInt();
                  if (var1.a(var19, var20)) {
                     if (!var8 || !var0.b(var19, var20)) {
                        return new et((var19 << 4) + 8, 64, (var20 << 4) + 8);
                     }
                  } else if (var11 == 0) {
                     break;
                  }
               }
            }

            if (var11 == 0) {
               break;
            }
         }
      }

      return null;
   }
}
