public enum atk {
   a("rotate_0"),
   b("rotate_90"),
   c("rotate_180"),
   d("rotate_270");

   private final String e;
   private static final String[] f = new String[values().length];

   private atk(String var3) {
      this.e = var3;
   }

   public atk a(atk var1) {
      switch(var1) {
      case c:
         switch(this) {
         case a:
            return c;
         case b:
            return d;
         case c:
            return a;
         case d:
            return b;
         }
      case d:
         switch(this) {
         case a:
            return d;
         case b:
            return a;
         case c:
            return b;
         case d:
            return c;
         }
      case b:
         switch(this) {
         case a:
            return b;
         case b:
            return c;
         case c:
            return d;
         case d:
            return a;
         }
      default:
         return this;
      }
   }

   public fa a(fa var1) {
      if (var1.k() == fa.a.b) {
         return var1;
      } else {
         switch(this) {
         case b:
            return var1.e();
         case c:
            return var1.d();
         case d:
            return var1.f();
         default:
            return var1;
         }
      }
   }

   public int a(int var1, int var2) {
      switch(this) {
      case b:
         return (var1 + var2 / 4) % var2;
      case c:
         return (var1 + var2 / 2) % var2;
      case d:
         return (var1 + var2 * 3 / 4) % var2;
      default:
         return var1;
      }
   }

   static {
      int var0 = 0;
      atk[] var1 = values();
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         atk var4 = var1[var3];
         f[var0++] = var4.e;
      }

   }
}
