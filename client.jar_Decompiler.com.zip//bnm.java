import com.google.common.collect.Lists;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import it.unimi.dsi.fastutil.ints.IntListIterator;
import it.unimi.dsi.fastutil.objects.ObjectLinkedOpenHashSet;
import it.unimi.dsi.fastutil.objects.ObjectSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.input.Keyboard;

public class bnm extends bip implements bnr {
   protected static final nd a = new nd("textures/gui/recipe_book.png");
   private int f;
   private int g;
   private int h;
   private static final Logger i = LogManager.getLogger();
   private final bnk j = new bnk();
   private final List<bno> k;
   private bno l;
   private bjr m;
   private afp n;
   private afw o;
   private bhz p;
   private bjc q;
   private String r;
   private qj s;
   private final bnn t;
   private aed u;
   private int v;

   public bnm() {
      this.k = Lists.newArrayList(new bno[]{new bno(0, ahn.g), new bno(0, ahn.i), new bno(0, ahn.b), new bno(0, ahn.f), new bno(0, ahn.d)});
      this.r = "";
      this.t = new bnn();
      this.u = new aed();
   }

   public void a(int var1, int var2, bhz var3, boolean var4, afp var5, afw var6) {
      this.p = var3;
      this.g = var1;
      this.h = var2;
      this.n = var5;
      this.o = var6;
      this.s = var3.h.E();
      this.v = var3.h.bv.p();
      this.l = (bno)this.k.get(0);
      this.l.b(true);
      if (this.c()) {
         this.a(var4, var6);
      }

      Keyboard.enableRepeatEvents(true);
   }

   public void a(boolean var1, afw var2) {
      this.f = var1 ? 0 : 86;
      int var3 = (this.g - 147) / 2 - this.f;
      int var4 = (this.h - 166) / 2;
      this.u.a();
      this.p.h.bv.a(this.u, false);
      var2.a(this.u);
      this.q = new bjc(0, this.p.k, var3 + 25, var4 + 14, 80, this.p.k.a + 5);
      this.q.f(50);
      this.q.a(false);
      this.q.e(true);
      this.q.g(16777215);
      this.t.a(this.p, var3, var4);
      this.t.a(this);
      this.m = new bjr(0, var3 + 110, var4 + 12, 26, 16, this.s.b());
      this.m.a(152, 41, 28, 18, a);
      this.b(false);
      this.f();
   }

   public void a() {
      Keyboard.enableRepeatEvents(false);
   }

   public int a(boolean var1, int var2, int var3) {
      int var4;
      if (this.c() && !var1) {
         var4 = 177 + (var2 - var3 - 200) / 2;
      } else {
         var4 = (var2 - var3) / 2;
      }

      return var4;
   }

   public void b() {
      this.a(!this.c());
   }

   public boolean c() {
      return this.s.a();
   }

   private void a(boolean var1) {
      this.s.a(var1);
      if (!var1) {
         this.t.c();
      }

      this.j();
   }

   public void a(@Nullable agp var1) {
      if (var1 != null && var1.e <= 9) {
         this.j.a();
         if (this.c()) {
            this.g();
         }
      }

   }

   private void b(boolean var1) {
      List<bnq> var2 = (List)cif.e.get(this.l.d());
      var2.forEach((var1x) -> {
         var1x.a(this.u, this.o.j(), this.o.i(), this.s);
      });
      List<bnq> var3 = Lists.newArrayList(var2);
      var3.removeIf((var0) -> {
         return !var0.a();
      });
      var3.removeIf((var0) -> {
         return !var0.c();
      });
      String var4 = this.q.b();
      if (!var4.isEmpty()) {
         ObjectSet<bnq> var5 = new ObjectLinkedOpenHashSet(this.p.a(cgv.b).a(var4.toLowerCase(Locale.ROOT)));
         var3.removeIf((var1x) -> {
            return !var5.contains(var1x);
         });
      }

      if (this.s.b()) {
         var3.removeIf((var0) -> {
            return !var0.b();
         });
      }

      this.t.a(var3, var1);
   }

   private void f() {
      int var1 = (this.g - 147) / 2 - this.f - 30;
      int var2 = (this.h - 166) / 2 + 3;
      int var3 = true;
      int var4 = 0;
      Iterator var5 = this.k.iterator();

      while(var5.hasNext()) {
         bno var6 = (bno)var5.next();
         ahn var7 = var6.d();
         if (var7 == ahn.g) {
            var6.m = true;
            var6.c(var1, var2 + 27 * var4++);
         } else if (var6.e()) {
            var6.c(var1, var2 + 27 * var4++);
            var6.a(this.p);
         }
      }

   }

   public void d() {
      if (this.c()) {
         if (this.v != this.p.h.bv.p()) {
            this.g();
            this.v = this.p.h.bv.p();
         }

      }
   }

   private void g() {
      this.u.a();
      this.p.h.bv.a(this.u, false);
      this.o.a(this.u);
      this.b(false);
   }

   public void a(int var1, int var2, float var3) {
      if (this.c()) {
         bhx.c();
         buq.g();
         buq.G();
         buq.c(0.0F, 0.0F, 100.0F);
         this.p.N().a(a);
         buq.c(1.0F, 1.0F, 1.0F, 1.0F);
         int var4 = (this.g - 147) / 2 - this.f;
         int var5 = (this.h - 166) / 2;
         this.b(var4, var5, 1, 1, 147, 166);
         this.q.g();
         bhx.a();
         Iterator var6 = this.k.iterator();

         while(var6.hasNext()) {
            bno var7 = (bno)var6.next();
            var7.a(this.p, var1, var2, var3);
         }

         this.m.a(this.p, var1, var2, var3);
         this.t.a(var4, var5, var1, var2, var3);
         buq.H();
      }
   }

   public void c(int var1, int var2, int var3, int var4) {
      if (this.c()) {
         this.t.a(var3, var4);
         if (this.m.a()) {
            String var5 = cew.a(this.m.c() ? "gui.recipebook.toggleRecipes.craftable" : "gui.recipebook.toggleRecipes.all");
            if (this.p.m != null) {
               this.p.m.a(var5, var3, var4);
            }
         }

         this.d(var1, var2, var3, var4);
      }
   }

   private void d(int var1, int var2, int var3, int var4) {
      ain var5 = null;

      for(int var6 = 0; var6 < this.j.b(); ++var6) {
         bnk.a var7 = this.j.a(var6);
         int var8 = var7.a() + var1;
         int var9 = var7.b() + var2;
         if (var3 >= var8 && var4 >= var9 && var3 < var8 + 16 && var4 < var9 + 16) {
            var5 = var7.c();
         }
      }

      if (var5 != null && this.p.m != null) {
         this.p.m.a(this.p.m.a(var5), var3, var4);
      }

   }

   public void a(int var1, int var2, boolean var3, float var4) {
      this.j.a(this.p, var1, var2, var3, var4);
   }

   public boolean a(int var1, int var2, int var3) {
      if (this.c() && !this.p.h.y()) {
         if (this.t.a(var1, var2, var3, (this.g - 147) / 2 - this.f, (this.h - 166) / 2, 147, 166)) {
            akr var7 = this.t.a();
            bnq var8 = this.t.b();
            if (var7 != null && var8 != null) {
               this.a(var7, var8);
               if (!this.h() && var3 == 0) {
                  this.a(false);
               }
            }

            return true;
         } else if (var3 != 0) {
            return false;
         } else if (this.q.a(var1, var2, var3)) {
            return true;
         } else if (this.m.b(this.p, var1, var2)) {
            boolean var6 = !this.s.b();
            this.s.b(var6);
            this.m.b(var6);
            this.m.a(this.p.U());
            this.j();
            this.b(false);
            return true;
         } else {
            Iterator var4 = this.k.iterator();

            bno var5;
            do {
               if (!var4.hasNext()) {
                  return false;
               }

               var5 = (bno)var4.next();
            } while(!var5.b(this.p, var1, var2));

            if (this.l != var5) {
               var5.a((chm)this.p.U());
               this.l.b(false);
               this.l = var5;
               this.l.b(true);
               this.b(true);
            }

            return true;
         }
      } else {
         return false;
      }
   }

   public boolean c(int var1, int var2, int var3, int var4, int var5, int var6) {
      if (!this.c()) {
         return true;
      } else {
         boolean var7 = var1 < var3 || var2 < var4 || var1 >= var3 + var5 || var2 >= var4 + var6;
         boolean var8 = var3 - 147 < var1 && var1 < var3 && var4 < var2 && var2 < var4 + var6;
         return var7 && !var8 && !this.l.b(this.p, var1, var2);
      }
   }

   public boolean a(char var1, int var2) {
      if (this.c() && !this.p.h.y()) {
         if (var2 == 1 && !this.h()) {
            this.a(false);
            return true;
         } else {
            if (bib.a(this.p.t.ag) && !this.q.m()) {
               this.q.b(true);
            } else if (this.q.a(var1, var2)) {
               String var3 = this.q.b().toLowerCase(Locale.ROOT);
               this.a(var3);
               if (!var3.equals(this.r)) {
                  this.b(false);
                  this.r = var3;
               }

               return true;
            }

            return false;
         }
      } else {
         return false;
      }
   }

   private void a(String var1) {
      if ("excitedze".equals(var1)) {
         cey var2 = this.p.Q();
         cex var3 = var2.a("en_pt");
         if (var2.c().a(var3) == 0) {
            return;
         }

         var2.a(var3);
         this.p.t.aJ = var3.a();
         this.p.f();
         this.p.k.a(this.p.Q().a() || this.p.t.aK);
         this.p.k.b(var2.b());
         this.p.t.b();
      }

   }

   private boolean h() {
      return this.f == 86;
   }

   public void e() {
      this.f();
      if (this.c()) {
         this.b(false);
      }

   }

   public void a(List<akr> var1) {
      Iterator var2 = var1.iterator();

      while(var2.hasNext()) {
         akr var3 = (akr)var2.next();
         this.p.h.a(var3);
      }

   }

   private void a(akr var1, bnq var2) {
      boolean var3 = var2.a(var1);
      agl var4 = null;
      if (this.n instanceof afx) {
         var4 = ((afx)this.n).f;
      } else if (this.n instanceof agg) {
         var4 = ((agg)this.n).f;
      }

      if (var4 != null) {
         if (!var3 && this.j.c() == var1) {
            return;
         }

         if (!this.i() && !this.p.h.z()) {
            return;
         }

         if (var3) {
            this.a(var1, this.n.c, this.n.d, var4);
         } else {
            List<ky.a> var5 = this.a(var4);
            this.a(var1, this.n.c);
            if (!var5.isEmpty()) {
               this.p.c.a(this.n.d, var5, Lists.newArrayList(), this.p.h);
               if (this.s.b()) {
                  this.p.h.bv.y_();
               }
            }
         }

         if (!this.h()) {
            this.b();
         }
      }

   }

   private void a(akr var1, List<agp> var2, int var3, agl var4) {
      boolean var5 = var1.a(this.o, this.p.f);
      int var6 = this.u.b(var1, (IntList)null);
      if (var5) {
         boolean var7 = true;

         for(int var8 = 0; var8 < this.o.w_(); ++var8) {
            ain var9 = this.o.a(var8);
            if (!var9.b() && var6 > var9.E()) {
               var7 = false;
            }
         }

         if (var7) {
            return;
         }
      }

      int var13 = this.a(var6, var5);
      IntList var14 = new IntArrayList();
      if (this.u.a(var1, var14, var13)) {
         int var15 = var13;
         IntListIterator var10 = var14.iterator();

         while(var10.hasNext()) {
            int var11 = (Integer)var10.next();
            int var12 = aed.b(var11).d();
            if (var12 < var15) {
               var15 = var12;
            }
         }

         if (this.u.a(var1, var14, var15)) {
            List<ky.a> var16 = this.a(var4);
            List<ky.a> var17 = Lists.newArrayList();
            this.a(var1, var2, var15, var14, var17);
            this.p.c.a(var3, var16, var17, this.p.h);
            this.p.h.bv.y_();
         }
      }
   }

   private List<ky.a> a(agl var1) {
      this.j.a();
      aea var2 = this.p.h.bv;
      List<ky.a> var3 = Lists.newArrayList();

      for(int var4 = 0; var4 < this.o.w_(); ++var4) {
         ain var5 = this.o.a(var4);
         if (!var5.b()) {
            while(var5.E() > 0) {
               int var6 = var2.d(var5);
               if (var6 == -1) {
                  var6 = var2.k();
               }

               ain var7 = var5.l();
               var7.e(1);
               if (var2.c(var6, var7)) {
                  var7.f(1);
               } else {
                  i.error("Can't find any space for item in inventory");
               }

               this.o.a(var4, 1);
               int var8 = var4 + 1;
               var3.add(new ky.a(var7.l(), var8, var6));
            }
         }
      }

      this.o.m();
      var1.m();
      return var3;
   }

   private int a(int var1, boolean var2) {
      int var3 = 1;
      if (bli.s()) {
         var3 = var1;
      } else if (var2) {
         var3 = 64;

         for(int var4 = 0; var4 < this.o.w_(); ++var4) {
            ain var5 = this.o.a(var4);
            if (!var5.b() && var3 > var5.E()) {
               var3 = var5.E();
            }
         }

         if (var3 < 64) {
            ++var3;
         }
      }

      return var3;
   }

   private void a(akr var1, List<agp> var2, int var3, IntList var4, List<ky.a> var5) {
      int var6 = this.o.j();
      int var7 = this.o.i();
      if (var1 instanceof aku) {
         aku var8 = (aku)var1;
         var6 = var8.f();
         var7 = var8.g();
      }

      int var16 = 1;
      Iterator<Integer> var9 = var4.iterator();

      for(int var10 = 0; var10 < this.o.j() && var7 != var10; ++var10) {
         for(int var11 = 0; var11 < this.o.i(); ++var11) {
            if (var6 == var11 || !var9.hasNext()) {
               var16 += this.o.j() - var11;
               break;
            }

            agp var12 = (agp)var2.get(var16);
            ain var13 = aed.b((Integer)var9.next());
            if (var13.b()) {
               ++var16;
            } else {
               for(int var14 = 0; var14 < var3; ++var14) {
                  ky.a var15 = this.a(var16, var12, var13);
                  if (var15 != null) {
                     var5.add(var15);
                  }
               }

               ++var16;
            }
         }

         if (!var9.hasNext()) {
            break;
         }
      }

   }

   @Nullable
   private ky.a a(int var1, agp var2, ain var3) {
      aea var4 = this.p.h.bv;
      int var5 = var4.c(var3);
      if (var5 == -1) {
         return null;
      } else {
         ain var6 = var4.a(var5).l();
         if (var6.b()) {
            i.error("Matched: " + var3.a() + " with empty item.");
            return null;
         } else {
            if (var6.E() > 1) {
               var4.a(var5, 1);
            } else {
               var4.c_(var5);
            }

            var6.e(1);
            if (var2.d().b()) {
               var2.d(var6);
            } else {
               var2.d().f(1);
            }

            return new ky.a(var6, var1, var5);
         }
      }
   }

   private boolean i() {
      aea var1 = this.p.h.bv;

      for(int var2 = 0; var2 < this.o.w_(); ++var2) {
         ain var3 = this.o.a(var2);
         if (!var3.b()) {
            int var4 = var1.d(var3);
            if (var4 == -1) {
               var4 = var1.k();
            }

            if (var4 == -1) {
               return false;
            }
         }
      }

      return true;
   }

   private void a(akr var1, List<agp> var2) {
      ain var3 = var1.b();
      this.j.a(var1);
      this.j.a(ako.a(var3), ((agp)var2.get(0)).f, ((agp)var2.get(0)).g);
      int var4 = this.o.j();
      int var5 = this.o.i();
      int var6 = var1 instanceof aku ? ((aku)var1).f() : var4;
      int var7 = 1;
      Iterator<ako> var8 = var1.d().iterator();

      for(int var9 = 0; var9 < var5; ++var9) {
         for(int var10 = 0; var10 < var6; ++var10) {
            if (!var8.hasNext()) {
               return;
            }

            ako var11 = (ako)var8.next();
            if (var11 != ako.a) {
               agp var12 = (agp)var2.get(var7);
               this.j.a(var11, var12.f, var12.g);
            }

            ++var7;
         }

         if (var6 < var4) {
            var7 += var4 - var6;
         }
      }

   }

   private void j() {
      if (this.p.v() != null) {
         this.p.v().a((ht)(new lr(this.c(), this.s.b())));
      }

   }
}
