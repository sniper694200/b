import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;

public class awj extends aoo {
   public static final axe a;
   public static final axf<awi.a> b;

   public awj() {
      super(bcx.H);
      this.w(this.A.b().a(a, fa.c).a(b, awi.a.a));
      this.c(-1.0F);
   }

   @Nullable
   public avh a(ams var1, int var2) {
      return null;
   }

   public static avh a(awr var0, fa var1, boolean var2, boolean var3) {
      return new awk(var0, var1, var2, var3);
   }

   public void b(ams var1, et var2, awr var3) {
      avh var4 = var1.r(var2);
      if (var4 instanceof awk) {
         ((awk)var4).j();
      } else {
         super.b(var1, var2, var3);
      }

   }

   public boolean a(ams var1, et var2) {
      return false;
   }

   public boolean b(ams var1, et var2, fa var3) {
      return false;
   }

   public void d(ams var1, et var2, awr var3) {
      et var4 = var2.a(((fa)var3.c(a)).d());
      awr var5 = var1.o(var4);
      if (var5.u() instanceof awh && (Boolean)var5.c(awh.a)) {
         var1.g(var4);
      }

   }

   public boolean b(awr var1) {
      return false;
   }

   public boolean c(awr var1) {
      return false;
   }

   public boolean a(ams var1, et var2, awr var3, aeb var4, tz var5, fa var6, float var7, float var8, float var9) {
      if (!var1.G && var1.r(var2) == null) {
         var1.g(var2);
         return true;
      } else {
         return false;
      }
   }

   public ail a(awr var1, Random var2, int var3) {
      return aip.a;
   }

   public void a(ams var1, et var2, awr var3, float var4, int var5) {
      if (!var1.G) {
         awk var6 = this.c(var1, var2);
         if (var6 != null) {
            awr var7 = var6.a();
            var7.u().b(var1, var2, var7, 0);
         }
      }
   }

   @Nullable
   public bha a(awr var1, ams var2, et var3, bhc var4, bhc var5) {
      return null;
   }

   public void a(awr var1, ams var2, et var3, aou var4, et var5) {
      if (!var2.G) {
         var2.r(var3);
      }

   }

   @Nullable
   public bgz a(awr var1, amw var2, et var3) {
      awk var4 = this.c(var2, var3);
      return var4 == null ? null : var4.a(var2, var3);
   }

   public void a(awr var1, ams var2, et var3, bgz var4, List<bgz> var5, @Nullable ve var6, boolean var7) {
      awk var8 = this.c(var2, var3);
      if (var8 != null) {
         var8.a(var2, var3, var4, var5, var6);
      }

   }

   public bgz b(awr var1, amw var2, et var3) {
      awk var4 = this.c(var2, var3);
      return var4 != null ? var4.a(var2, var3) : j;
   }

   @Nullable
   private awk c(amw var1, et var2) {
      avh var3 = var1.r(var2);
      return var3 instanceof awk ? (awk)var3 : null;
   }

   public ain a(ams var1, et var2, awr var3) {
      return ain.a;
   }

   public awr a(int var1) {
      return this.t().a(a, awi.b(var1)).a(b, (var1 & 8) > 0 ? awi.a.b : awi.a.a);
   }

   public awr a(awr var1, atk var2) {
      return var1.a(a, var2.a((fa)var1.c(a)));
   }

   public awr a(awr var1, arw var2) {
      return var1.a(var2.a((fa)var1.c(a)));
   }

   public int e(awr var1) {
      int var2 = 0;
      int var3 = var2 | ((fa)var1.c(a)).a();
      if (var1.c(b) == awi.a.b) {
         var3 |= 8;
      }

      return var3;
   }

   protected aws b() {
      return new aws(this, new axh[]{a, b});
   }

   public awp a(amw var1, awr var2, et var3, fa var4) {
      return awp.i;
   }

   static {
      a = awi.H;
      b = awi.a;
   }
}
