import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Map.Entry;

public class alk {
   private static final alk.e a = new alk.e();
   private static final alk.d b = new alk.d();
   private static final alk.b c = new alk.b();
   private static final alk.a d = new alk.a();

   public static int a(ali var0, ain var1) {
      if (var1.b()) {
         return 0;
      } else {
         ge var2 = var1.q();

         for(int var3 = 0; var3 < var2.c(); ++var3) {
            fy var4 = var2.b(var3);
            ali var5 = ali.c(var4.g("id"));
            int var6 = var4.g("lvl");
            if (var5 == var0) {
               return var6;
            }
         }

         return 0;
      }
   }

   public static Map<ali, Integer> a(ain var0) {
      Map<ali, Integer> var1 = Maps.newLinkedHashMap();
      ge var2 = var0.c() == aip.co ? ahw.h(var0) : var0.q();

      for(int var3 = 0; var3 < var2.c(); ++var3) {
         fy var4 = var2.b(var3);
         ali var5 = ali.c(var4.g("id"));
         int var6 = var4.g("lvl");
         var1.put(var5, Integer.valueOf(var6));
      }

      return var1;
   }

   public static void a(Map<ali, Integer> var0, ain var1) {
      ge var2 = new ge();
      Iterator var3 = var0.entrySet().iterator();

      while(var3.hasNext()) {
         Entry<ali, Integer> var4 = (Entry)var3.next();
         ali var5 = (ali)var4.getKey();
         if (var5 != null) {
            int var6 = (Integer)var4.getValue();
            fy var7 = new fy();
            var7.a("id", (short)ali.b(var5));
            var7.a("lvl", (short)var6);
            var2.a((gn)var7);
            if (var1.c() == aip.co) {
               ahw.a(var1, new all(var5, var6));
            }
         }
      }

      if (var2.b_()) {
         if (var1.o()) {
            var1.p().r("ench");
         }
      } else if (var1.c() != aip.co) {
         var1.a((String)"ench", (gn)var2);
      }

   }

   private static void a(alk.c var0, ain var1) {
      if (!var1.b()) {
         ge var2 = var1.q();

         for(int var3 = 0; var3 < var2.c(); ++var3) {
            int var4 = var2.b(var3).g("id");
            int var5 = var2.b(var3).g("lvl");
            if (ali.c(var4) != null) {
               var0.a(ali.c(var4), var5);
            }
         }

      }
   }

   private static void a(alk.c var0, Iterable<ain> var1) {
      Iterator var2 = var1.iterator();

      while(var2.hasNext()) {
         ain var3 = (ain)var2.next();
         a(var0, var3);
      }

   }

   public static int a(Iterable<ain> var0, up var1) {
      a.a = 0;
      a.b = var1;
      a((alk.c)a, (Iterable)var0);
      return a.a;
   }

   public static float a(ain var0, vs var1) {
      b.a = 0.0F;
      b.b = var1;
      a((alk.c)b, (ain)var0);
      return b.a;
   }

   public static float a(vn var0) {
      int var1 = a(alm.r, var0);
      return var1 > 0 ? alv.e(var1) : 0.0F;
   }

   public static void a(vn var0, ve var1) {
      c.b = var1;
      c.a = var0;
      if (var0 != null) {
         a((alk.c)c, (Iterable)var0.aQ());
      }

      if (var1 instanceof aeb) {
         a((alk.c)c, (ain)var0.co());
      }

   }

   public static void b(vn var0, ve var1) {
      d.a = var0;
      d.b = var1;
      if (var0 != null) {
         a((alk.c)d, (Iterable)var0.aQ());
      }

      if (var0 instanceof aeb) {
         a((alk.c)d, (ain)var0.co());
      }

   }

   public static int a(ali var0, vn var1) {
      Iterable<ain> var2 = var0.a(var1);
      if (var2 == null) {
         return 0;
      } else {
         int var3 = 0;
         Iterator var4 = var2.iterator();

         while(var4.hasNext()) {
            ain var5 = (ain)var4.next();
            int var6 = a(var0, var5);
            if (var6 > var3) {
               var3 = var6;
            }
         }

         return var3;
      }
   }

   public static int b(vn var0) {
      return a(alm.o, var0);
   }

   public static int c(vn var0) {
      return a(alm.p, var0);
   }

   public static int d(vn var0) {
      return a(alm.f, var0);
   }

   public static int e(vn var0) {
      return a(alm.i, var0);
   }

   public static int f(vn var0) {
      return a(alm.s, var0);
   }

   public static int b(ain var0) {
      return a(alm.A, var0);
   }

   public static int c(ain var0) {
      return a(alm.B, var0);
   }

   public static int g(vn var0) {
      return a(alm.q, var0);
   }

   public static boolean h(vn var0) {
      return a(alm.g, var0) > 0;
   }

   public static boolean i(vn var0) {
      return a(alm.j, var0) > 0;
   }

   public static boolean d(ain var0) {
      return a(alm.k, var0) > 0;
   }

   public static boolean e(ain var0) {
      return a(alm.D, var0) > 0;
   }

   public static ain b(ali var0, vn var1) {
      List<ain> var2 = var0.a(var1);
      if (var2.isEmpty()) {
         return ain.a;
      } else {
         List<ain> var3 = Lists.newArrayList();
         Iterator var4 = var2.iterator();

         while(var4.hasNext()) {
            ain var5 = (ain)var4.next();
            if (!var5.b() && a(var0, var5) > 0) {
               var3.add(var5);
            }
         }

         return var3.isEmpty() ? ain.a : (ain)var3.get(var1.bR().nextInt(var3.size()));
      }
   }

   public static int a(Random var0, int var1, int var2, ain var3) {
      ail var4 = var3.c();
      int var5 = var4.c();
      if (var5 <= 0) {
         return 0;
      } else {
         if (var2 > 15) {
            var2 = 15;
         }

         int var6 = var0.nextInt(8) + 1 + (var2 >> 1) + var0.nextInt(var2 + 1);
         if (var1 == 0) {
            return Math.max(var6 / 3, 1);
         } else {
            return var1 == 1 ? var6 * 2 / 3 + 1 : Math.max(var6, var2 * 2);
         }
      }
   }

   public static ain a(Random var0, ain var1, int var2, boolean var3) {
      List<all> var4 = b(var0, var1, var2, var3);
      boolean var5 = var1.c() == aip.aT;
      if (var5) {
         var1 = new ain(aip.co);
      }

      Iterator var6 = var4.iterator();

      while(var6.hasNext()) {
         all var7 = (all)var6.next();
         if (var5) {
            ahw.a(var1, var7);
         } else {
            var1.a(var7.b, var7.c);
         }
      }

      return var1;
   }

   public static List<all> b(Random var0, ain var1, int var2, boolean var3) {
      List<all> var4 = Lists.newArrayList();
      ail var5 = var1.c();
      int var6 = var5.c();
      if (var6 <= 0) {
         return var4;
      } else {
         var2 += 1 + var0.nextInt(var6 / 4 + 1) + var0.nextInt(var6 / 4 + 1);
         float var7 = (var0.nextFloat() + var0.nextFloat() - 1.0F) * 0.15F;
         var2 = ri.a(Math.round((float)var2 + (float)var2 * var7), 1, Integer.MAX_VALUE);
         List<all> var8 = a(var2, var1, var3);
         if (!var8.isEmpty()) {
            var4.add(rq.a(var0, var8));

            while(var0.nextInt(50) <= var2) {
               a(var8, (all)h.a(var4));
               if (var8.isEmpty()) {
                  break;
               }

               var4.add(rq.a(var0, var8));
               var2 /= 2;
            }
         }

         return var4;
      }
   }

   public static void a(List<all> var0, all var1) {
      Iterator var2 = var0.iterator();

      while(var2.hasNext()) {
         if (!var1.b.c(((all)var2.next()).b)) {
            var2.remove();
         }
      }

   }

   public static List<all> a(int var0, ain var1, boolean var2) {
      List<all> var3 = Lists.newArrayList();
      ail var4 = var1.c();
      boolean var5 = var1.c() == aip.aT;
      Iterator var6 = ali.b.iterator();

      while(true) {
         while(true) {
            ali var7;
            do {
               do {
                  if (!var6.hasNext()) {
                     return var3;
                  }

                  var7 = (ali)var6.next();
               } while(var7.c() && !var2);
            } while(!var7.c.a(var4) && !var5);

            for(int var8 = var7.b(); var8 > var7.f() - 1; --var8) {
               if (var0 >= var7.a(var8) && var0 <= var7.b(var8)) {
                  var3.add(new all(var7, var8));
                  break;
               }
            }
         }
      }
   }

   static final class a implements alk.c {
      public vn a;
      public ve b;

      private a() {
      }

      public void a(ali var1, int var2) {
         var1.a(this.a, this.b, var2);
      }

      // $FF: synthetic method
      a(Object var1) {
         this();
      }
   }

   static final class b implements alk.c {
      public vn a;
      public ve b;

      private b() {
      }

      public void a(ali var1, int var2) {
         var1.b(this.a, this.b, var2);
      }

      // $FF: synthetic method
      b(Object var1) {
         this();
      }
   }

   static final class d implements alk.c {
      public float a;
      public vs b;

      private d() {
      }

      public void a(ali var1, int var2) {
         this.a += var1.a(var2, this.b);
      }

      // $FF: synthetic method
      d(Object var1) {
         this();
      }
   }

   static final class e implements alk.c {
      public int a;
      public up b;

      private e() {
      }

      public void a(ali var1, int var2) {
         this.a += var1.a(var2, this.b);
      }

      // $FF: synthetic method
      e(Object var1) {
         this();
      }
   }

   interface c {
      void a(ali var1, int var2);
   }
}
