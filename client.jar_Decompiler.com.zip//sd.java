public class sd implements rs {
   public int a() {
      return 813;
   }

   public fy a(fy var1) {
      if ("minecraft:shulker".equals(var1.l("id"))) {
         var1.r("Color");
      }

      return var1;
   }
}
