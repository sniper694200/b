import java.awt.image.BufferedImage;
import java.io.IOException;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class cdk extends cdd {
   private static final Logger g = LogManager.getLogger();
   protected final nd f;

   public cdk(nd var1) {
      this.f = var1;
   }

   public void a(cen var1) throws IOException {
      this.c();
      cem var2 = null;

      try {
         var2 = var1.a(this.f);
         BufferedImage var3 = cdr.a(var2.b());
         boolean var4 = false;
         boolean var5 = false;
         if (var2.c()) {
            try {
               cft var6 = (cft)var2.a("texture");
               if (var6 != null) {
                  var4 = var6.a();
                  var5 = var6.b();
               }
            } catch (RuntimeException var10) {
               g.warn("Failed reading metadata of: {}", this.f, var10);
            }
         }

         cdr.a(this.b(), var3, var4, var5);
      } finally {
         IOUtils.closeQuietly(var2);
      }

   }
}
