import javax.annotation.Nullable;

public class aas extends aam {
   private final aat bH = new aat(this);
   private boolean bI;
   private int bJ;

   public aas(ams var1) {
      super(var1);
   }

   protected void bM() {
      super.bM();
      this.a((wa)adf.a).a(15.0D);
      this.a((wa)adf.d).a(0.20000000298023224D);
      this.a((wa)bx).a(this.dN());
   }

   protected qc F() {
      super.F();
      return qd.gS;
   }

   protected qc cf() {
      super.cf();
      return qd.gT;
   }

   protected qc d(up var1) {
      super.d(var1);
      return qd.gU;
   }

   public vs cn() {
      return vs.b;
   }

   public double aG() {
      return super.aG() - 0.1875D;
   }

   @Nullable
   protected nd J() {
      return bfl.K;
   }

   public void n() {
      super.n();
      if (this.dl() && this.bJ++ >= 18000) {
         this.X();
      }

   }

   public static void a(rw var0) {
      aam.c(var0, aas.class);
   }

   public void b(fy var1) {
      super.b(var1);
      var1.a("SkeletonTrap", this.dl());
      var1.a("SkeletonTrapTime", this.bJ);
   }

   public void a(fy var1) {
      super.a(var1);
      this.p(var1.q("SkeletonTrap"));
      this.bJ = var1.h("SkeletonTrapTime");
   }

   public boolean dl() {
      return this.bI;
   }

   public void p(boolean var1) {
      if (var1 != this.bI) {
         this.bI = var1;
         if (var1) {
            this.br.a(1, this.bH);
         } else {
            this.br.a((xc)this.bH);
         }

      }
   }

   public boolean a(aeb var1, tz var2) {
      ain var3 = var1.b((tz)var2);
      boolean var4 = !var3.b();
      if (var4 && var3.c() == aip.bU) {
         return super.a((aeb)var1, (tz)var2);
      } else if (!this.du()) {
         return false;
      } else if (this.l_()) {
         return super.a((aeb)var1, (tz)var2);
      } else if (var1.aU()) {
         this.c(var1);
         return true;
      } else if (this.aT()) {
         return super.a((aeb)var1, (tz)var2);
      } else {
         if (var4) {
            if (var3.c() == aip.aD && !this.dG()) {
               this.c(var1);
               return true;
            }

            if (var3.a((aeb)var1, (vn)this, (tz)var2)) {
               return true;
            }
         }

         this.g(var1);
         return true;
      }
   }
}
