import com.google.common.collect.Maps;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import javax.annotation.Nullable;

public class bvx {
   private final nd a;
   private final Map<nd, Float> b;

   public bvx(nd var1, Map<nd, Float> var2) {
      this.a = var1;
      this.b = var2;
   }

   public nd a() {
      return this.a;
   }

   boolean a(ain var1, @Nullable ams var2, @Nullable vn var3) {
      ail var4 = var1.c();
      Iterator var5 = this.b.entrySet().iterator();

      Entry var6;
      aio var7;
      do {
         if (!var5.hasNext()) {
            return true;
         }

         var6 = (Entry)var5.next();
         var7 = var4.a((nd)var6.getKey());
      } while(var7 != null && !(var7.a(var1, var2, var3) < (Float)var6.getValue()));

      return false;
   }

   static class a implements JsonDeserializer<bvx> {
      public bvx a(JsonElement var1, Type var2, JsonDeserializationContext var3) throws JsonParseException {
         JsonObject var4 = var1.getAsJsonObject();
         nd var5 = new nd(ra.h(var4, "model"));
         Map<nd, Float> var6 = this.a(var4);
         return new bvx(var5, var6);
      }

      protected Map<nd, Float> a(JsonObject var1) {
         Map<nd, Float> var2 = Maps.newLinkedHashMap();
         JsonObject var3 = ra.t(var1, "predicate");
         Iterator var4 = var3.entrySet().iterator();

         while(var4.hasNext()) {
            Entry<String, JsonElement> var5 = (Entry)var4.next();
            var2.put(new nd((String)var5.getKey()), ra.e((JsonElement)var5.getValue(), (String)var5.getKey()));
         }

         return var2;
      }

      // $FF: synthetic method
      public Object deserialize(JsonElement var1, Type var2, JsonDeserializationContext var3) throws JsonParseException {
         return this.a(var1, var2, var3);
      }
   }
}
