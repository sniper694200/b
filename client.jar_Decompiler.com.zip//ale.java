public class ale extends ali {
   public ale(ali.a var1, vj... var2) {
      super(var1, alj.l, var2);
      this.c("binding_curse");
   }

   public int a(int var1) {
      return 25;
   }

   public int b(int var1) {
      return 50;
   }

   public int b() {
      return 1;
   }

   public boolean c() {
      return true;
   }

   public boolean d() {
      return true;
   }
}
