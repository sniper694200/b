public class aei extends ve {
   private double a;
   private double b;
   private double c;
   private int d;
   private boolean e;

   public aei(ams var1) {
      super(var1);
      this.a(0.25F, 0.25F);
   }

   protected void i() {
   }

   public boolean a(double var1) {
      double var3 = this.bw().a() * 4.0D;
      if (Double.isNaN(var3)) {
         var3 = 4.0D;
      }

      var3 *= 64.0D;
      return var1 < var3 * var3;
   }

   public aei(ams var1, double var2, double var4, double var6) {
      super(var1);
      this.d = 0;
      this.a(0.25F, 0.25F);
      this.b(var2, var4, var6);
   }

   public void a(et var1) {
      double var2 = (double)var1.p();
      int var4 = var1.q();
      double var5 = (double)var1.r();
      double var7 = var2 - this.p;
      double var9 = var5 - this.r;
      float var11 = ri.a(var7 * var7 + var9 * var9);
      if (var11 > 12.0F) {
         this.a = this.p + var7 / (double)var11 * 12.0D;
         this.c = this.r + var9 / (double)var11 * 12.0D;
         this.b = this.q + 8.0D;
      } else {
         this.a = var2;
         this.b = (double)var4;
         this.c = var5;
      }

      this.d = 0;
      this.e = this.S.nextInt(5) > 0;
   }

   public void h(double var1, double var3, double var5) {
      this.s = var1;
      this.t = var3;
      this.u = var5;
      if (this.y == 0.0F && this.x == 0.0F) {
         float var7 = ri.a(var1 * var1 + var5 * var5);
         this.v = (float)(ri.c(var1, var5) * 57.2957763671875D);
         this.w = (float)(ri.c(var3, (double)var7) * 57.2957763671875D);
         this.x = this.v;
         this.y = this.w;
      }

   }

   public void B_() {
      this.M = this.p;
      this.N = this.q;
      this.O = this.r;
      super.B_();
      this.p += this.s;
      this.q += this.t;
      this.r += this.u;
      float var1 = ri.a(this.s * this.s + this.u * this.u);
      this.v = (float)(ri.c(this.s, this.u) * 57.2957763671875D);

      for(this.w = (float)(ri.c(this.t, (double)var1) * 57.2957763671875D); this.w - this.y < -180.0F; this.y -= 360.0F) {
      }

      while(this.w - this.y >= 180.0F) {
         this.y += 360.0F;
      }

      while(this.v - this.x < -180.0F) {
         this.x -= 360.0F;
      }

      while(this.v - this.x >= 180.0F) {
         this.x += 360.0F;
      }

      this.w = this.y + (this.w - this.y) * 0.2F;
      this.v = this.x + (this.v - this.x) * 0.2F;
      if (!this.l.G) {
         double var2 = this.a - this.p;
         double var4 = this.c - this.r;
         float var6 = (float)Math.sqrt(var2 * var2 + var4 * var4);
         float var7 = (float)ri.c(var4, var2);
         double var8 = (double)var1 + (double)(var6 - var1) * 0.0025D;
         if (var6 < 1.0F) {
            var8 *= 0.8D;
            this.t *= 0.8D;
         }

         this.s = Math.cos((double)var7) * var8;
         this.u = Math.sin((double)var7) * var8;
         if (this.q < this.b) {
            this.t += (1.0D - this.t) * 0.014999999664723873D;
         } else {
            this.t += (-1.0D - this.t) * 0.014999999664723873D;
         }
      }

      float var10 = 0.25F;
      if (this.ao()) {
         for(int var3 = 0; var3 < 4; ++var3) {
            this.l.a(fj.e, this.p - this.s * 0.25D, this.q - this.t * 0.25D, this.r - this.u * 0.25D, this.s, this.t, this.u);
         }
      } else {
         this.l.a(fj.y, this.p - this.s * 0.25D + this.S.nextDouble() * 0.6D - 0.3D, this.q - this.t * 0.25D - 0.5D, this.r - this.u * 0.25D + this.S.nextDouble() * 0.6D - 0.3D, this.s, this.t, this.u);
      }

      if (!this.l.G) {
         this.b(this.p, this.q, this.r);
         ++this.d;
         if (this.d > 80 && !this.l.G) {
            this.a(qd.bb, 1.0F, 1.0F);
            this.X();
            if (this.e) {
               this.l.a((ve)(new acj(this.l, this.p, this.q, this.r, new ain(aip.bS))));
            } else {
               this.l.b(2003, new et(this), 0);
            }
         }
      }

   }

   public void b(fy var1) {
   }

   public void a(fy var1) {
   }

   public float aw() {
      return 1.0F;
   }

   public int av() {
      return 15728880;
   }

   public boolean bd() {
      return false;
   }
}
