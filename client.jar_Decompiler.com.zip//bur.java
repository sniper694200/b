import java.awt.image.BufferedImage;

public interface bur {
   BufferedImage a(BufferedImage var1);

   void a();
}
