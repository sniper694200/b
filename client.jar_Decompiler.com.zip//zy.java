import javax.annotation.Nullable;

public class zy extends zv {
   public zy(ams var1) {
      super(var1);
      this.a(0.9F, 1.4F);
      this.bA = aov.bw;
   }

   public static void c(rw var0) {
      vo.a(var0, zy.class);
   }

   public boolean a(aeb var1, tz var2) {
      ain var3 = var1.b((tz)var2);
      if (var3.c() == aip.C && this.l() >= 0 && !var1.bO.d) {
         var3.g(1);
         if (var3.b()) {
            var1.a((tz)var2, (ain)(new ain(aip.D)));
         } else if (!var1.bv.e(new ain(aip.D))) {
            var1.a(new ain(aip.D), false);
         }

         return true;
      } else if (var3.c() == aip.bm && this.l() >= 0) {
         this.X();
         this.l.a(fj.b, this.p, this.q + (double)(this.H / 2.0F), this.r, 0.0D, 0.0D, 0.0D);
         if (!this.l.G) {
            zv var4 = new zv(this.l);
            var4.b(this.p, this.q, this.r, this.v, this.w);
            var4.c(this.cd());
            var4.aN = this.aN;
            if (this.n_()) {
               var4.c(this.bq());
            }

            this.l.a((ve)var4);

            for(int var5 = 0; var5 < 5; ++var5) {
               this.l.a((ve)(new acj(this.l, this.p, this.q + (double)this.H, this.r, new ain(aov.Q))));
            }

            var3.a(1, var1);
            this.a(qd.ei, 1.0F, 1.0F);
         }

         return true;
      } else {
         return super.a(var1, var2);
      }
   }

   public zy c(vb var1) {
      return new zy(this.l);
   }

   @Nullable
   protected nd J() {
      return bfl.M;
   }

   // $FF: synthetic method
   public zv b(vb var1) {
      return this.c(var1);
   }

   // $FF: synthetic method
   public vb a(vb var1) {
      return this.c(var1);
   }
}
