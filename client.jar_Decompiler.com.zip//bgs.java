import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import java.util.Random;

public class bgs implements bgr {
   private final boolean a;

   public bgs(boolean var1) {
      this.a = var1;
   }

   public boolean a(Random var1, ve var2) {
      return var2.aR() == this.a;
   }

   public static class a extends bgr.a<bgs> {
      protected a() {
         super(new nd("on_fire"), bgs.class);
      }

      public JsonElement a(bgs var1, JsonSerializationContext var2) {
         return new JsonPrimitive(var1.a);
      }

      public bgs b(JsonElement var1, JsonDeserializationContext var2) {
         return new bgs(ra.c(var1, "on_fire"));
      }

      // $FF: synthetic method
      public bgr a(JsonElement var1, JsonDeserializationContext var2) {
         return this.b(var1, var2);
      }
   }
}
