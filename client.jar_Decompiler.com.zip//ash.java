import java.util.Random;

public class ash extends aou {
   public ash(bcx var1) {
      super(var1);
   }

   public int a(Random var1) {
      return 0;
   }

   public ail a(awr var1, Random var2, int var3) {
      return aip.a;
   }
}
