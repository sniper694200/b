import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import java.util.List;
import javax.annotation.Nullable;

public abstract class aef extends ve implements aen {
   private static final Predicate<ve> f;
   private static final mx<Byte> g;
   private int h;
   private int at;
   private int au;
   private aou av;
   private int aw;
   protected boolean a;
   protected int b;
   public aef.a c;
   public int d;
   public ve e;
   private int ax;
   private int ay;
   private double az;
   private int aA;

   public aef(ams var1) {
      super(var1);
      this.h = -1;
      this.at = -1;
      this.au = -1;
      this.c = aef.a.a;
      this.az = 2.0D;
      this.a(0.5F, 0.5F);
   }

   public aef(ams var1, double var2, double var4, double var6) {
      this(var1);
      this.b(var2, var4, var6);
   }

   public aef(ams var1, vn var2) {
      this(var1, var2.p, var2.q + (double)var2.by() - 0.10000000149011612D, var2.r);
      this.e = var2;
      if (var2 instanceof aeb) {
         this.c = aef.a.b;
      }

   }

   public boolean a(double var1) {
      double var3 = this.bw().a() * 10.0D;
      if (Double.isNaN(var3)) {
         var3 = 1.0D;
      }

      var3 *= 64.0D * bp();
      return var1 < var3 * var3;
   }

   protected void i() {
      this.Y.a((mx)g, (byte)0);
   }

   public void a(ve var1, float var2, float var3, float var4, float var5, float var6) {
      float var7 = -ri.a(var3 * 0.017453292F) * ri.b(var2 * 0.017453292F);
      float var8 = -ri.a(var2 * 0.017453292F);
      float var9 = ri.b(var3 * 0.017453292F) * ri.b(var2 * 0.017453292F);
      this.c((double)var7, (double)var8, (double)var9, var5, var6);
      this.s += var1.s;
      this.u += var1.u;
      if (!var1.z) {
         this.t += var1.t;
      }

   }

   public void c(double var1, double var3, double var5, float var7, float var8) {
      float var9 = ri.a(var1 * var1 + var3 * var3 + var5 * var5);
      var1 /= (double)var9;
      var3 /= (double)var9;
      var5 /= (double)var9;
      var1 += this.S.nextGaussian() * 0.007499999832361937D * (double)var8;
      var3 += this.S.nextGaussian() * 0.007499999832361937D * (double)var8;
      var5 += this.S.nextGaussian() * 0.007499999832361937D * (double)var8;
      var1 *= (double)var7;
      var3 *= (double)var7;
      var5 *= (double)var7;
      this.s = var1;
      this.t = var3;
      this.u = var5;
      float var10 = ri.a(var1 * var1 + var5 * var5);
      this.v = (float)(ri.c(var1, var5) * 57.2957763671875D);
      this.w = (float)(ri.c(var3, (double)var10) * 57.2957763671875D);
      this.x = this.v;
      this.y = this.w;
      this.ax = 0;
   }

   public void a(double var1, double var3, double var5, float var7, float var8, int var9, boolean var10) {
      this.b(var1, var3, var5);
      this.b(var7, var8);
   }

   public void h(double var1, double var3, double var5) {
      this.s = var1;
      this.t = var3;
      this.u = var5;
      if (this.y == 0.0F && this.x == 0.0F) {
         float var7 = ri.a(var1 * var1 + var5 * var5);
         this.w = (float)(ri.c(var3, (double)var7) * 57.2957763671875D);
         this.v = (float)(ri.c(var1, var5) * 57.2957763671875D);
         this.y = this.w;
         this.x = this.v;
         this.b(this.p, this.q, this.r, this.v, this.w);
         this.ax = 0;
      }

   }

   public void B_() {
      super.B_();
      if (this.y == 0.0F && this.x == 0.0F) {
         float var1 = ri.a(this.s * this.s + this.u * this.u);
         this.v = (float)(ri.c(this.s, this.u) * 57.2957763671875D);
         this.w = (float)(ri.c(this.t, (double)var1) * 57.2957763671875D);
         this.x = this.v;
         this.y = this.w;
      }

      et var13 = new et(this.h, this.at, this.au);
      awr var2 = this.l.o(var13);
      aou var3 = var2.u();
      if (var2.a() != bcx.a) {
         bgz var4 = var2.d(this.l, var13);
         if (var4 != aou.k && var4.a(var13).b(new bhc(this.p, this.q, this.r))) {
            this.a = true;
         }
      }

      if (this.d > 0) {
         --this.d;
      }

      if (this.a) {
         int var15 = var3.e(var2);
         if ((var3 != this.av || var15 != this.aw) && !this.l.a(this.bw().g(0.05D))) {
            this.a = false;
            this.s *= (double)(this.S.nextFloat() * 0.2F);
            this.t *= (double)(this.S.nextFloat() * 0.2F);
            this.u *= (double)(this.S.nextFloat() * 0.2F);
            this.ax = 0;
            this.ay = 0;
         } else {
            ++this.ax;
            if (this.ax >= 1200) {
               this.X();
            }
         }

         ++this.b;
      } else {
         this.b = 0;
         ++this.ay;
         bhc var14 = new bhc(this.p, this.q, this.r);
         bhc var5 = new bhc(this.p + this.s, this.q + this.t, this.r + this.u);
         bha var6 = this.l.a(var14, var5, false, true, false);
         var14 = new bhc(this.p, this.q, this.r);
         var5 = new bhc(this.p + this.s, this.q + this.t, this.r + this.u);
         if (var6 != null) {
            var5 = new bhc(var6.c.b, var6.c.c, var6.c.d);
         }

         ve var7 = this.a(var14, var5);
         if (var7 != null) {
            var6 = new bha(var7);
         }

         if (var6 != null && var6.d instanceof aeb) {
            aeb var8 = (aeb)var6.d;
            if (this.e instanceof aeb && !((aeb)this.e).a(var8)) {
               var6 = null;
            }
         }

         if (var6 != null) {
            this.a(var6);
         }

         if (this.n()) {
            for(int var16 = 0; var16 < 4; ++var16) {
               this.l.a(fj.j, this.p + this.s * (double)var16 / 4.0D, this.q + this.t * (double)var16 / 4.0D, this.r + this.u * (double)var16 / 4.0D, -this.s, -this.t + 0.2D, -this.u);
            }
         }

         this.p += this.s;
         this.q += this.t;
         this.r += this.u;
         float var17 = ri.a(this.s * this.s + this.u * this.u);
         this.v = (float)(ri.c(this.s, this.u) * 57.2957763671875D);

         for(this.w = (float)(ri.c(this.t, (double)var17) * 57.2957763671875D); this.w - this.y < -180.0F; this.y -= 360.0F) {
         }

         while(this.w - this.y >= 180.0F) {
            this.y += 360.0F;
         }

         while(this.v - this.x < -180.0F) {
            this.x -= 360.0F;
         }

         while(this.v - this.x >= 180.0F) {
            this.x += 360.0F;
         }

         this.w = this.y + (this.w - this.y) * 0.2F;
         this.v = this.x + (this.v - this.x) * 0.2F;
         float var9 = 0.99F;
         float var10 = 0.05F;
         if (this.ao()) {
            for(int var11 = 0; var11 < 4; ++var11) {
               float var12 = 0.25F;
               this.l.a(fj.e, this.p - this.s * 0.25D, this.q - this.t * 0.25D, this.r - this.u * 0.25D, this.s, this.t, this.u);
            }

            var9 = 0.6F;
         }

         if (this.an()) {
            this.ab();
         }

         this.s *= (double)var9;
         this.t *= (double)var9;
         this.u *= (double)var9;
         if (!this.aj()) {
            this.t -= 0.05000000074505806D;
         }

         this.b(this.p, this.q, this.r);
         this.ag();
      }
   }

   protected void a(bha var1) {
      ve var2 = var1.d;
      if (var2 != null) {
         float var3 = ri.a(this.s * this.s + this.t * this.t + this.u * this.u);
         int var4 = ri.f((double)var3 * this.az);
         if (this.n()) {
            var4 += this.S.nextInt(var4 / 2 + 2);
         }

         up var5;
         if (this.e == null) {
            var5 = up.a((aef)this, (ve)this);
         } else {
            var5 = up.a(this, this.e);
         }

         if (this.aR() && !(var2 instanceof acs)) {
            var2.i(5);
         }

         if (var2.a(var5, (float)var4)) {
            if (var2 instanceof vn) {
               vn var6 = (vn)var2;
               if (!this.l.G) {
                  var6.f(var6.ck() + 1);
               }

               if (this.aA > 0) {
                  float var7 = ri.a(this.s * this.s + this.u * this.u);
                  if (var7 > 0.0F) {
                     var6.f(this.s * (double)this.aA * 0.6000000238418579D / (double)var7, 0.1D, this.u * (double)this.aA * 0.6000000238418579D / (double)var7);
                  }
               }

               if (this.e instanceof vn) {
                  alk.a(var6, this.e);
                  alk.b((vn)((vn)this.e), (ve)var6);
               }

               this.a(var6);
               if (this.e != null && var6 != this.e && var6 instanceof aeb && this.e instanceof oo) {
                  ((oo)this.e).a.a((ht)(new jc(6, 0.0F)));
               }
            }

            this.a(qd.u, 1.0F, 1.2F / (this.S.nextFloat() * 0.2F + 0.9F));
            if (!(var2 instanceof acs)) {
               this.X();
            }
         } else {
            this.s *= -0.10000000149011612D;
            this.t *= -0.10000000149011612D;
            this.u *= -0.10000000149011612D;
            this.v += 180.0F;
            this.x += 180.0F;
            this.ay = 0;
            if (!this.l.G && this.s * this.s + this.t * this.t + this.u * this.u < 0.0010000000474974513D) {
               if (this.c == aef.a.b) {
                  this.a(this.j(), 0.1F);
               }

               this.X();
            }
         }
      } else {
         et var8 = var1.a();
         this.h = var8.p();
         this.at = var8.q();
         this.au = var8.r();
         awr var9 = this.l.o(var8);
         this.av = var9.u();
         this.aw = this.av.e(var9);
         this.s = (double)((float)(var1.c.b - this.p));
         this.t = (double)((float)(var1.c.c - this.q));
         this.u = (double)((float)(var1.c.d - this.r));
         float var10 = ri.a(this.s * this.s + this.t * this.t + this.u * this.u);
         this.p -= this.s / (double)var10 * 0.05000000074505806D;
         this.q -= this.t / (double)var10 * 0.05000000074505806D;
         this.r -= this.u / (double)var10 * 0.05000000074505806D;
         this.a(qd.u, 1.0F, 1.2F / (this.S.nextFloat() * 0.2F + 0.9F));
         this.a = true;
         this.d = 7;
         this.a(false);
         if (var9.a() != bcx.a) {
            this.av.a((ams)this.l, (et)var8, (awr)var9, (ve)this);
         }
      }

   }

   public void a(vt var1, double var2, double var4, double var6) {
      super.a(var1, var2, var4, var6);
      if (this.a) {
         this.h = ri.c(this.p);
         this.at = ri.c(this.q);
         this.au = ri.c(this.r);
      }

   }

   protected void a(vn var1) {
   }

   @Nullable
   protected ve a(bhc var1, bhc var2) {
      ve var3 = null;
      List<ve> var4 = this.l.a((ve)this, (bgz)this.bw().b(this.s, this.t, this.u).g(1.0D), (Predicate)f);
      double var5 = 0.0D;

      for(int var7 = 0; var7 < var4.size(); ++var7) {
         ve var8 = (ve)var4.get(var7);
         if (var8 != this.e || this.ay >= 5) {
            bgz var9 = var8.bw().g(0.30000001192092896D);
            bha var10 = var9.b(var1, var2);
            if (var10 != null) {
               double var11 = var1.g(var10.c);
               if (var11 < var5 || var5 == 0.0D) {
                  var3 = var8;
                  var5 = var11;
               }
            }
         }
      }

      return var3;
   }

   public static void a(rw var0, String var1) {
   }

   public static void a(rw var0) {
      a(var0, "Arrow");
   }

   public void b(fy var1) {
      var1.a("xTile", this.h);
      var1.a("yTile", this.at);
      var1.a("zTile", this.au);
      var1.a("life", (short)this.ax);
      nd var2 = (nd)aou.h.b(this.av);
      var1.a("inTile", var2 == null ? "" : var2.toString());
      var1.a("inData", (byte)this.aw);
      var1.a("shake", (byte)this.d);
      var1.a("inGround", (byte)(this.a ? 1 : 0));
      var1.a("pickup", (byte)this.c.ordinal());
      var1.a("damage", this.az);
      var1.a("crit", this.n());
   }

   public void a(fy var1) {
      this.h = var1.h("xTile");
      this.at = var1.h("yTile");
      this.au = var1.h("zTile");
      this.ax = var1.g("life");
      if (var1.b("inTile", 8)) {
         this.av = aou.b(var1.l("inTile"));
      } else {
         this.av = aou.c(var1.f("inTile") & 255);
      }

      this.aw = var1.f("inData") & 255;
      this.d = var1.f("shake") & 255;
      this.a = var1.f("inGround") == 1;
      if (var1.b("damage", 99)) {
         this.az = var1.k("damage");
      }

      if (var1.b("pickup", 99)) {
         this.c = aef.a.a(var1.f("pickup"));
      } else if (var1.b("player", 99)) {
         this.c = var1.q("player") ? aef.a.b : aef.a.a;
      }

      this.a(var1.q("crit"));
   }

   public void d(aeb var1) {
      if (!this.l.G && this.a && this.d <= 0) {
         boolean var2 = this.c == aef.a.b || this.c == aef.a.c && var1.bO.d;
         if (this.c == aef.a.b && !var1.bv.e(this.j())) {
            var2 = false;
         }

         if (var2) {
            var1.a((ve)this, 1);
            this.X();
         }

      }
   }

   protected abstract ain j();

   protected boolean ak() {
      return false;
   }

   public void c(double var1) {
      this.az = var1;
   }

   public double k() {
      return this.az;
   }

   public void a(int var1) {
      this.aA = var1;
   }

   public boolean bd() {
      return false;
   }

   public float by() {
      return 0.0F;
   }

   public void a(boolean var1) {
      byte var2 = (Byte)this.Y.a(g);
      if (var1) {
         this.Y.b(g, (byte)(var2 | 1));
      } else {
         this.Y.b(g, (byte)(var2 & -2));
      }

   }

   public boolean n() {
      byte var1 = (Byte)this.Y.a(g);
      return (var1 & 1) != 0;
   }

   public void a(vn var1, float var2) {
      int var3 = alk.a(alm.w, var1);
      int var4 = alk.a(alm.x, var1);
      this.c((double)(var2 * 2.0F) + this.S.nextGaussian() * 0.25D + (double)((float)this.l.ag().a() * 0.11F));
      if (var3 > 0) {
         this.c(this.k() + (double)var3 * 0.5D + 0.5D);
      }

      if (var4 > 0) {
         this.a(var4);
      }

      if (alk.a(alm.y, var1) > 0) {
         this.i(100);
      }

   }

   static {
      f = Predicates.and(new Predicate[]{vi.e, vi.a, new Predicate<ve>() {
         public boolean a(@Nullable ve var1) {
            return var1.ay();
         }

         // $FF: synthetic method
         public boolean apply(@Nullable Object var1) {
            return this.a((ve)var1);
         }
      }});
      g = na.a(aef.class, mz.a);
   }

   public static enum a {
      a,
      b,
      c;

      public static aef.a a(int var0) {
         if (var0 < 0 || var0 > values().length) {
            var0 = 0;
         }

         return values()[var0];
      }
   }
}
