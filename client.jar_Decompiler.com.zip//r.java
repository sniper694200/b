import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import javax.annotation.Nullable;

public class r {
   private final hh a;
   private final hh b;
   private final ain c;
   private final nd d;
   private final s e;
   private final boolean f;
   private final boolean g;
   private final boolean h;
   private float i;
   private float j;

   public r(ain var1, hh var2, hh var3, @Nullable nd var4, s var5, boolean var6, boolean var7, boolean var8) {
      this.a = var2;
      this.b = var3;
      this.c = var1;
      this.d = var4;
      this.e = var5;
      this.f = var6;
      this.g = var7;
      this.h = var8;
   }

   public void a(float var1, float var2) {
      this.i = var1;
      this.j = var2;
   }

   public hh a() {
      return this.a;
   }

   public hh b() {
      return this.b;
   }

   public ain c() {
      return this.c;
   }

   @Nullable
   public nd d() {
      return this.d;
   }

   public s e() {
      return this.e;
   }

   public float f() {
      return this.i;
   }

   public float g() {
      return this.j;
   }

   public boolean h() {
      return this.f;
   }

   public boolean i() {
      return this.g;
   }

   public boolean j() {
      return this.h;
   }

   public static r a(JsonObject var0, JsonDeserializationContext var1) {
      hh var2 = (hh)ra.a(var0, "title", var1, hh.class);
      hh var3 = (hh)ra.a(var0, "description", var1, hh.class);
      if (var2 != null && var3 != null) {
         ain var4 = a(ra.t(var0, "icon"));
         nd var5 = var0.has("background") ? new nd(ra.h(var0, "background")) : null;
         s var6 = var0.has("frame") ? s.a(ra.h(var0, "frame")) : s.a;
         boolean var7 = ra.a(var0, "show_toast", true);
         boolean var8 = ra.a(var0, "announce_to_chat", true);
         boolean var9 = ra.a(var0, "hidden", false);
         return new r(var4, var2, var3, var5, var6, var7, var8, var9);
      } else {
         throw new JsonSyntaxException("Both title and description must be set");
      }
   }

   private static ain a(JsonObject var0) {
      if (!var0.has("item")) {
         throw new JsonSyntaxException("Unsupported icon type, currently only items are supported (add 'item' key)");
      } else {
         ail var1 = ra.i(var0, "item");
         int var2 = ra.a(var0, "data", 0);
         return new ain(var1, 1, var2);
      }
   }

   public void a(gy var1) {
      var1.a(this.a);
      var1.a(this.b);
      var1.a(this.c);
      var1.a((Enum)this.e);
      int var2 = 0;
      if (this.d != null) {
         var2 |= 1;
      }

      if (this.f) {
         var2 |= 2;
      }

      if (this.h) {
         var2 |= 4;
      }

      var1.writeInt(var2);
      if (this.d != null) {
         var1.a(this.d);
      }

      var1.writeFloat(this.i);
      var1.writeFloat(this.j);
   }

   public static r b(gy var0) {
      hh var1 = var0.f();
      hh var2 = var0.f();
      ain var3 = var0.k();
      s var4 = (s)var0.a(s.class);
      int var5 = var0.readInt();
      nd var6 = (var5 & 1) != 0 ? var0.l() : null;
      boolean var7 = (var5 & 2) != 0;
      boolean var8 = (var5 & 4) != 0;
      r var9 = new r(var3, var1, var2, var6, var4, var7, false, var8);
      var9.a(var0.readFloat(), var0.readFloat());
      return var9;
   }
}
