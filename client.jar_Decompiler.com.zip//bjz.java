public interface bjz {
   nd a = new nd("textures/gui/toasts.png");
   Object b = new Object();

   bjz.a a(bka var1, long var2);

   default Object b() {
      return b;
   }

   public static enum a {
      a(qd.id),
      b(qd.ie);

      private final qc c;

      private a(qc var3) {
         this.c = var3;
      }

      public void a(chm var1) {
         var1.a((cgr)cgn.a(this.c, 1.0F, 1.0F));
      }
   }
}
