public class ajr extends agz {
   public ajr(aou var1) {
      super(var1);
      this.e(0);
   }

   public ub a(aeb var1, ams var2, et var3, tz var4, fa var5, float var6, float var7, float var8) {
      ain var9 = var1.b((tz)var4);
      if (!var9.b() && var1.a(var3, var5, var9)) {
         awr var10 = var2.o(var3);
         aou var11 = var10.u();
         et var12 = var3;
         if ((var5 != fa.b || var11 != this.a) && !var11.a((amw)var2, (et)var3)) {
            var12 = var3.a(var5);
            var10 = var2.o(var12);
            var11 = var10.u();
         }

         if (var11 == this.a) {
            int var13 = (Integer)var10.c(atu.a);
            if (var13 < 8) {
               awr var14 = var10.a(atu.a, var13 + 1);
               bgz var15 = var14.d(var2, var12);
               if (var15 != aou.k && var2.b(var15.a(var12)) && var2.a((et)var12, (awr)var14, 10)) {
                  atw var16 = this.a.v();
                  var2.a(var1, var12, var16.e(), qe.e, (var16.a() + 1.0F) / 2.0F, var16.b() * 0.8F);
                  if (var1 instanceof oo) {
                     m.x.a((oo)var1, var3, var9);
                  }

                  var9.g(1);
                  return ub.a;
               }
            }
         }

         return super.a(var1, var2, var3, var4, var5, var6, var7, var8);
      } else {
         return ub.c;
      }
   }

   public int a(int var1) {
      return var1;
   }
}
