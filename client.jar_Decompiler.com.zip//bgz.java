import com.google.common.annotations.VisibleForTesting;
import javax.annotation.Nullable;

public class bgz {
   public final double a;
   public final double b;
   public final double c;
   public final double d;
   public final double e;
   public final double f;

   public bgz(double var1, double var3, double var5, double var7, double var9, double var11) {
      this.a = Math.min(var1, var7);
      this.b = Math.min(var3, var9);
      this.c = Math.min(var5, var11);
      this.d = Math.max(var1, var7);
      this.e = Math.max(var3, var9);
      this.f = Math.max(var5, var11);
   }

   public bgz(et var1) {
      this((double)var1.p(), (double)var1.q(), (double)var1.r(), (double)(var1.p() + 1), (double)(var1.q() + 1), (double)(var1.r() + 1));
   }

   public bgz(et var1, et var2) {
      this((double)var1.p(), (double)var1.q(), (double)var1.r(), (double)var2.p(), (double)var2.q(), (double)var2.r());
   }

   public bgz(bhc var1, bhc var2) {
      this(var1.b, var1.c, var1.d, var2.b, var2.c, var2.d);
   }

   public bgz e(double var1) {
      return new bgz(this.a, this.b, this.c, this.d, var1, this.f);
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof bgz)) {
         return false;
      } else {
         bgz var2 = (bgz)var1;
         if (Double.compare(var2.a, this.a) != 0) {
            return false;
         } else if (Double.compare(var2.b, this.b) != 0) {
            return false;
         } else if (Double.compare(var2.c, this.c) != 0) {
            return false;
         } else if (Double.compare(var2.d, this.d) != 0) {
            return false;
         } else if (Double.compare(var2.e, this.e) != 0) {
            return false;
         } else {
            return Double.compare(var2.f, this.f) == 0;
         }
      }
   }

   public int hashCode() {
      long var1 = Double.doubleToLongBits(this.a);
      int var3 = (int)(var1 ^ var1 >>> 32);
      var1 = Double.doubleToLongBits(this.b);
      var3 = 31 * var3 + (int)(var1 ^ var1 >>> 32);
      var1 = Double.doubleToLongBits(this.c);
      var3 = 31 * var3 + (int)(var1 ^ var1 >>> 32);
      var1 = Double.doubleToLongBits(this.d);
      var3 = 31 * var3 + (int)(var1 ^ var1 >>> 32);
      var1 = Double.doubleToLongBits(this.e);
      var3 = 31 * var3 + (int)(var1 ^ var1 >>> 32);
      var1 = Double.doubleToLongBits(this.f);
      var3 = 31 * var3 + (int)(var1 ^ var1 >>> 32);
      return var3;
   }

   public bgz a(double var1, double var3, double var5) {
      double var7 = this.a;
      double var9 = this.b;
      double var11 = this.c;
      double var13 = this.d;
      double var15 = this.e;
      double var17 = this.f;
      if (var1 < 0.0D) {
         var7 -= var1;
      } else if (var1 > 0.0D) {
         var13 -= var1;
      }

      if (var3 < 0.0D) {
         var9 -= var3;
      } else if (var3 > 0.0D) {
         var15 -= var3;
      }

      if (var5 < 0.0D) {
         var11 -= var5;
      } else if (var5 > 0.0D) {
         var17 -= var5;
      }

      return new bgz(var7, var9, var11, var13, var15, var17);
   }

   public bgz b(double var1, double var3, double var5) {
      double var7 = this.a;
      double var9 = this.b;
      double var11 = this.c;
      double var13 = this.d;
      double var15 = this.e;
      double var17 = this.f;
      if (var1 < 0.0D) {
         var7 += var1;
      } else if (var1 > 0.0D) {
         var13 += var1;
      }

      if (var3 < 0.0D) {
         var9 += var3;
      } else if (var3 > 0.0D) {
         var15 += var3;
      }

      if (var5 < 0.0D) {
         var11 += var5;
      } else if (var5 > 0.0D) {
         var17 += var5;
      }

      return new bgz(var7, var9, var11, var13, var15, var17);
   }

   public bgz c(double var1, double var3, double var5) {
      double var7 = this.a - var1;
      double var9 = this.b - var3;
      double var11 = this.c - var5;
      double var13 = this.d + var1;
      double var15 = this.e + var3;
      double var17 = this.f + var5;
      return new bgz(var7, var9, var11, var13, var15, var17);
   }

   public bgz g(double var1) {
      return this.c(var1, var1, var1);
   }

   public bgz a(bgz var1) {
      double var2 = Math.max(this.a, var1.a);
      double var4 = Math.max(this.b, var1.b);
      double var6 = Math.max(this.c, var1.c);
      double var8 = Math.min(this.d, var1.d);
      double var10 = Math.min(this.e, var1.e);
      double var12 = Math.min(this.f, var1.f);
      return new bgz(var2, var4, var6, var8, var10, var12);
   }

   public bgz b(bgz var1) {
      double var2 = Math.min(this.a, var1.a);
      double var4 = Math.min(this.b, var1.b);
      double var6 = Math.min(this.c, var1.c);
      double var8 = Math.max(this.d, var1.d);
      double var10 = Math.max(this.e, var1.e);
      double var12 = Math.max(this.f, var1.f);
      return new bgz(var2, var4, var6, var8, var10, var12);
   }

   public bgz d(double var1, double var3, double var5) {
      return new bgz(this.a + var1, this.b + var3, this.c + var5, this.d + var1, this.e + var3, this.f + var5);
   }

   public bgz a(et var1) {
      return new bgz(this.a + (double)var1.p(), this.b + (double)var1.q(), this.c + (double)var1.r(), this.d + (double)var1.p(), this.e + (double)var1.q(), this.f + (double)var1.r());
   }

   public bgz a(bhc var1) {
      return this.d(var1.b, var1.c, var1.d);
   }

   public double a(bgz var1, double var2) {
      if (!(var1.e <= this.b) && !(var1.b >= this.e) && !(var1.f <= this.c) && !(var1.c >= this.f)) {
         double var4;
         if (var2 > 0.0D && var1.d <= this.a) {
            var4 = this.a - var1.d;
            if (var4 < var2) {
               var2 = var4;
            }
         } else if (var2 < 0.0D && var1.a >= this.d) {
            var4 = this.d - var1.a;
            if (var4 > var2) {
               var2 = var4;
            }
         }

         return var2;
      } else {
         return var2;
      }
   }

   public double b(bgz var1, double var2) {
      if (!(var1.d <= this.a) && !(var1.a >= this.d) && !(var1.f <= this.c) && !(var1.c >= this.f)) {
         double var4;
         if (var2 > 0.0D && var1.e <= this.b) {
            var4 = this.b - var1.e;
            if (var4 < var2) {
               var2 = var4;
            }
         } else if (var2 < 0.0D && var1.b >= this.e) {
            var4 = this.e - var1.b;
            if (var4 > var2) {
               var2 = var4;
            }
         }

         return var2;
      } else {
         return var2;
      }
   }

   public double c(bgz var1, double var2) {
      if (!(var1.d <= this.a) && !(var1.a >= this.d) && !(var1.e <= this.b) && !(var1.b >= this.e)) {
         double var4;
         if (var2 > 0.0D && var1.f <= this.c) {
            var4 = this.c - var1.f;
            if (var4 < var2) {
               var2 = var4;
            }
         } else if (var2 < 0.0D && var1.c >= this.f) {
            var4 = this.f - var1.c;
            if (var4 > var2) {
               var2 = var4;
            }
         }

         return var2;
      } else {
         return var2;
      }
   }

   public boolean c(bgz var1) {
      return this.a(var1.a, var1.b, var1.c, var1.d, var1.e, var1.f);
   }

   public boolean a(double var1, double var3, double var5, double var7, double var9, double var11) {
      return this.a < var7 && this.d > var1 && this.b < var9 && this.e > var3 && this.c < var11 && this.f > var5;
   }

   public boolean a(bhc var1, bhc var2) {
      return this.a(Math.min(var1.b, var2.b), Math.min(var1.c, var2.c), Math.min(var1.d, var2.d), Math.max(var1.b, var2.b), Math.max(var1.c, var2.c), Math.max(var1.d, var2.d));
   }

   public boolean b(bhc var1) {
      if (!(var1.b <= this.a) && !(var1.b >= this.d)) {
         if (!(var1.c <= this.b) && !(var1.c >= this.e)) {
            return !(var1.d <= this.c) && !(var1.d >= this.f);
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public double a() {
      double var1 = this.d - this.a;
      double var3 = this.e - this.b;
      double var5 = this.f - this.c;
      return (var1 + var3 + var5) / 3.0D;
   }

   public bgz h(double var1) {
      return this.g(-var1);
   }

   @Nullable
   public bha b(bhc var1, bhc var2) {
      bhc var3 = this.a(this.a, var1, var2);
      fa var4 = fa.e;
      bhc var5 = this.a(this.d, var1, var2);
      if (var5 != null && this.a(var1, var3, var5)) {
         var3 = var5;
         var4 = fa.f;
      }

      var5 = this.b(this.b, var1, var2);
      if (var5 != null && this.a(var1, var3, var5)) {
         var3 = var5;
         var4 = fa.a;
      }

      var5 = this.b(this.e, var1, var2);
      if (var5 != null && this.a(var1, var3, var5)) {
         var3 = var5;
         var4 = fa.b;
      }

      var5 = this.c(this.c, var1, var2);
      if (var5 != null && this.a(var1, var3, var5)) {
         var3 = var5;
         var4 = fa.c;
      }

      var5 = this.c(this.f, var1, var2);
      if (var5 != null && this.a(var1, var3, var5)) {
         var3 = var5;
         var4 = fa.d;
      }

      return var3 == null ? null : new bha(var3, var4);
   }

   @VisibleForTesting
   boolean a(bhc var1, @Nullable bhc var2, bhc var3) {
      return var2 == null || var1.g(var3) < var1.g(var2);
   }

   @Nullable
   @VisibleForTesting
   bhc a(double var1, bhc var3, bhc var4) {
      bhc var5 = var3.a(var4, var1);
      return var5 != null && this.c(var5) ? var5 : null;
   }

   @Nullable
   @VisibleForTesting
   bhc b(double var1, bhc var3, bhc var4) {
      bhc var5 = var3.b(var4, var1);
      return var5 != null && this.d(var5) ? var5 : null;
   }

   @Nullable
   @VisibleForTesting
   bhc c(double var1, bhc var3, bhc var4) {
      bhc var5 = var3.c(var4, var1);
      return var5 != null && this.e(var5) ? var5 : null;
   }

   @VisibleForTesting
   public boolean c(bhc var1) {
      return var1.c >= this.b && var1.c <= this.e && var1.d >= this.c && var1.d <= this.f;
   }

   @VisibleForTesting
   public boolean d(bhc var1) {
      return var1.b >= this.a && var1.b <= this.d && var1.d >= this.c && var1.d <= this.f;
   }

   @VisibleForTesting
   public boolean e(bhc var1) {
      return var1.b >= this.a && var1.b <= this.d && var1.c >= this.b && var1.c <= this.e;
   }

   public String toString() {
      return "box[" + this.a + ", " + this.b + ", " + this.c + " -> " + this.d + ", " + this.e + ", " + this.f + "]";
   }

   public boolean b() {
      return Double.isNaN(this.a) || Double.isNaN(this.b) || Double.isNaN(this.c) || Double.isNaN(this.d) || Double.isNaN(this.e) || Double.isNaN(this.f);
   }

   public bhc c() {
      return new bhc(this.a + (this.d - this.a) * 0.5D, this.b + (this.e - this.b) * 0.5D, this.c + (this.f - this.c) * 0.5D);
   }
}
