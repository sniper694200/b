public interface bkn {
   void a(boolean var1, int var2);
}
