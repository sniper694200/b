public class akc extends ail {
   public akc() {
      this.d(1);
   }

   public uc<ain> a(ams var1, aeb var2, tz var3) {
      ain var4 = var2.b((tz)var3);
      var2.a(var4, var3);
      var2.b(qq.b((ail)this));
      return new uc(ub.a, var4);
   }

   public static boolean b(fy var0) {
      if (var0 == null) {
         return false;
      } else if (!var0.b("pages", 9)) {
         return false;
      } else {
         ge var1 = var0.c("pages", 8);

         for(int var2 = 0; var2 < var1.c(); ++var2) {
            String var3 = var1.h(var2);
            if (var3.length() > 32767) {
               return false;
            }
         }

         return true;
      }
   }
}
