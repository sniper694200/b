public class ccb implements cce<aaq> {
   private static final nd[] a = new nd[]{new nd("textures/entity/llama/decor/decor_white.png"), new nd("textures/entity/llama/decor/decor_orange.png"), new nd("textures/entity/llama/decor/decor_magenta.png"), new nd("textures/entity/llama/decor/decor_light_blue.png"), new nd("textures/entity/llama/decor/decor_yellow.png"), new nd("textures/entity/llama/decor/decor_lime.png"), new nd("textures/entity/llama/decor/decor_pink.png"), new nd("textures/entity/llama/decor/decor_gray.png"), new nd("textures/entity/llama/decor/decor_silver.png"), new nd("textures/entity/llama/decor/decor_cyan.png"), new nd("textures/entity/llama/decor/decor_purple.png"), new nd("textures/entity/llama/decor/decor_blue.png"), new nd("textures/entity/llama/decor/decor_brown.png"), new nd("textures/entity/llama/decor/decor_green.png"), new nd("textures/entity/llama/decor/decor_red.png"), new nd("textures/entity/llama/decor/decor_black.png")};
   private final bzz b;
   private final bqa c = new bqa(0.5F);

   public ccb(bzz var1) {
      this.b = var1;
   }

   public void a(aaq var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8) {
      if (var1.dS()) {
         this.b.a((nd)a[var1.dT().a()]);
         this.c.a(this.b.b());
         this.c.a(var1, var2, var3, var5, var6, var7, var8);
      }
   }

   public boolean a() {
      return false;
   }
}
