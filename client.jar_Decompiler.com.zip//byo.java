public abstract class byo<T extends aef> extends bze<T> {
   public byo(bzd var1) {
      super(var1);
   }

   public void a(T var1, double var2, double var4, double var6, float var8, float var9) {
      this.d(var1);
      buq.c(1.0F, 1.0F, 1.0F, 1.0F);
      buq.G();
      buq.g();
      buq.c((float)var2, (float)var4, (float)var6);
      buq.b(var1.x + (var1.v - var1.x) * var9 - 90.0F, 0.0F, 1.0F, 0.0F);
      buq.b(var1.y + (var1.w - var1.y) * var9, 0.0F, 0.0F, 1.0F);
      bvc var10 = bvc.a();
      bui var11 = var10.c();
      int var12 = false;
      float var13 = 0.0F;
      float var14 = 0.5F;
      float var15 = 0.0F;
      float var16 = 0.15625F;
      float var17 = 0.0F;
      float var18 = 0.15625F;
      float var19 = 0.15625F;
      float var20 = 0.3125F;
      float var21 = 0.05625F;
      buq.D();
      float var22 = (float)var1.d - var9;
      if (var22 > 0.0F) {
         float var23 = -ri.a(var22 * 3.0F) * var22;
         buq.b(var23, 0.0F, 0.0F, 1.0F);
      }

      buq.b(45.0F, 1.0F, 0.0F, 0.0F);
      buq.b(0.05625F, 0.05625F, 0.05625F);
      buq.c(-4.0F, 0.0F, 0.0F);
      if (this.e) {
         buq.h();
         buq.e(this.c(var1));
      }

      buq.a(0.05625F, 0.0F, 0.0F);
      var11.a(7, cdw.g);
      var11.b(-7.0D, -2.0D, -2.0D).a(0.0D, 0.15625D).d();
      var11.b(-7.0D, -2.0D, 2.0D).a(0.15625D, 0.15625D).d();
      var11.b(-7.0D, 2.0D, 2.0D).a(0.15625D, 0.3125D).d();
      var11.b(-7.0D, 2.0D, -2.0D).a(0.0D, 0.3125D).d();
      var10.b();
      buq.a(-0.05625F, 0.0F, 0.0F);
      var11.a(7, cdw.g);
      var11.b(-7.0D, 2.0D, -2.0D).a(0.0D, 0.15625D).d();
      var11.b(-7.0D, 2.0D, 2.0D).a(0.15625D, 0.15625D).d();
      var11.b(-7.0D, -2.0D, 2.0D).a(0.15625D, 0.3125D).d();
      var11.b(-7.0D, -2.0D, -2.0D).a(0.0D, 0.3125D).d();
      var10.b();

      for(int var24 = 0; var24 < 4; ++var24) {
         buq.b(90.0F, 1.0F, 0.0F, 0.0F);
         buq.a(0.0F, 0.0F, 0.05625F);
         var11.a(7, cdw.g);
         var11.b(-8.0D, -2.0D, 0.0D).a(0.0D, 0.0D).d();
         var11.b(8.0D, -2.0D, 0.0D).a(0.5D, 0.0D).d();
         var11.b(8.0D, 2.0D, 0.0D).a(0.5D, 0.15625D).d();
         var11.b(-8.0D, 2.0D, 0.0D).a(0.0D, 0.15625D).d();
         var10.b();
      }

      if (this.e) {
         buq.n();
         buq.i();
      }

      buq.E();
      buq.f();
      buq.H();
      super.a(var1, var2, var4, var6, var8, var9);
   }
}
