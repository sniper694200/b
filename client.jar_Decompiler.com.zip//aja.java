public class aja extends agz {
   public aja(aou var1) {
      super(var1);
   }

   public int a(int var1) {
      return 7;
   }
}
