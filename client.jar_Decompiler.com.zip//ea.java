import com.google.gson.JsonParseException;
import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ea extends bi {
   private static final Logger a = LogManager.getLogger();

   public String c() {
      return "title";
   }

   public int a() {
      return 2;
   }

   public String b(bn var1) {
      return "commands.title.usage";
   }

   public void a(MinecraftServer var1, bn var2, String[] var3) throws ei {
      if (var3.length < 2) {
         throw new ep("commands.title.usage", new Object[0]);
      } else {
         if (var3.length < 3) {
            if ("title".equals(var3[1]) || "subtitle".equals(var3[1]) || "actionbar".equals(var3[1])) {
               throw new ep("commands.title.usage.title", new Object[0]);
            }

            if ("times".equals(var3[1])) {
               throw new ep("commands.title.usage.times", new Object[0]);
            }
         }

         oo var4 = b(var1, var2, var3[0]);
         ko.a var5 = ko.a.a(var3[1]);
         if (var5 != ko.a.e && var5 != ko.a.f) {
            if (var5 == ko.a.d) {
               if (var3.length != 5) {
                  throw new ep("commands.title.usage", new Object[0]);
               } else {
                  int var12 = a(var3[2]);
                  int var13 = a(var3[3]);
                  int var14 = a(var3[4]);
                  ko var9 = new ko(var12, var13, var14);
                  var4.a.a((ht)var9);
                  a(var2, this, "commands.title.success", new Object[0]);
               }
            } else if (var3.length < 3) {
               throw new ep("commands.title.usage", new Object[0]);
            } else {
               String var11 = a(var3, 2);

               hh var7;
               try {
                  var7 = hh.a.a(var11);
               } catch (JsonParseException var10) {
                  throw a(var10);
               }

               ko var8 = new ko(var5, hi.a(var2, var7, var4));
               var4.a.a((ht)var8);
               a(var2, this, "commands.title.success", new Object[0]);
            }
         } else if (var3.length != 2) {
            throw new ep("commands.title.usage", new Object[0]);
         } else {
            ko var6 = new ko(var5, (hh)null);
            var4.a.a((ht)var6);
            a(var2, this, "commands.title.success", new Object[0]);
         }
      }
   }

   public List<String> a(MinecraftServer var1, bn var2, String[] var3, @Nullable et var4) {
      if (var3.length == 1) {
         return a(var3, var1.J());
      } else {
         return var3.length == 2 ? a(var3, ko.a.a()) : Collections.emptyList();
      }
   }

   public boolean b(String[] var1, int var2) {
      return var2 == 0;
   }
}
