import java.io.IOException;

public class iy implements ht<hw> {
   private hh a;

   public iy() {
   }

   public iy(hh var1) {
      this.a = var1;
   }

   public void a(gy var1) throws IOException {
      this.a = var1.f();
   }

   public void b(gy var1) throws IOException {
      var1.a(this.a);
   }

   public void a(hw var1) {
      var1.a(this);
   }

   public hh a() {
      return this.a;
   }
}
