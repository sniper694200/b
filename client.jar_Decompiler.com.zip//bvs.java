import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.io.Reader;
import java.io.StringReader;
import java.lang.reflect.Type;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class bvs {
   private static final Logger f = LogManager.getLogger();
   @VisibleForTesting
   static final Gson a = (new GsonBuilder()).registerTypeAdapter(bvs.class, new bvs.b()).registerTypeAdapter(bvo.class, new bvo.a()).registerTypeAdapter(bvp.class, new bvp.a()).registerTypeAdapter(bvr.class, new bvr.a()).registerTypeAdapter(bvz.class, new bvz.a()).registerTypeAdapter(bwa.class, new bwa.a()).registerTypeAdapter(bvx.class, new bvx.a()).create();
   private final List<bvo> g;
   private final boolean h;
   private final boolean i;
   private final bwa j;
   private final List<bvx> k;
   public String b = "";
   @VisibleForTesting
   protected final Map<String, String> c;
   @VisibleForTesting
   protected bvs d;
   @VisibleForTesting
   protected nd e;

   public static bvs a(Reader var0) {
      return (bvs)ra.a(a, var0, bvs.class, false);
   }

   public static bvs a(String var0) {
      return a((Reader)(new StringReader(var0)));
   }

   public bvs(@Nullable nd var1, List<bvo> var2, Map<String, String> var3, boolean var4, boolean var5, bwa var6, List<bvx> var7) {
      this.g = var2;
      this.i = var4;
      this.h = var5;
      this.c = var3;
      this.e = var1;
      this.j = var6;
      this.k = var7;
   }

   public List<bvo> a() {
      return this.g.isEmpty() && this.k() ? this.d.a() : this.g;
   }

   private boolean k() {
      return this.d != null;
   }

   public boolean b() {
      return this.k() ? this.d.b() : this.i;
   }

   public boolean c() {
      return this.h;
   }

   public boolean d() {
      return this.e == null || this.d != null && this.d.d();
   }

   public void a(Map<nd, bvs> var1) {
      if (this.e != null) {
         this.d = (bvs)var1.get(this.e);
      }

   }

   public Collection<nd> e() {
      Set<nd> var1 = Sets.newHashSet();
      Iterator var2 = this.k.iterator();

      while(var2.hasNext()) {
         bvx var3 = (bvx)var2.next();
         var1.add(var3.a());
      }

      return var1;
   }

   protected List<bvx> f() {
      return this.k;
   }

   public bvy g() {
      return this.k.isEmpty() ? bvy.a : new bvy(this.k);
   }

   public boolean b(String var1) {
      return !"missingno".equals(this.c(var1));
   }

   public String c(String var1) {
      if (!this.d(var1)) {
         var1 = '#' + var1;
      }

      return this.a(var1, new bvs.a(this));
   }

   private String a(String var1, bvs.a var2) {
      if (this.d(var1)) {
         if (this == var2.b) {
            f.warn("Unable to resolve texture due to upward reference: {} in {}", var1, this.b);
            return "missingno";
         } else {
            String var3 = (String)this.c.get(var1.substring(1));
            if (var3 == null && this.k()) {
               var3 = this.d.a(var1, var2);
            }

            var2.b = this;
            if (var3 != null && this.d(var3)) {
               var3 = var2.a.a(var3, var2);
            }

            return var3 != null && !this.d(var3) ? var3 : "missingno";
         }
      } else {
         return var1;
      }
   }

   private boolean d(String var1) {
      return var1.charAt(0) == '#';
   }

   @Nullable
   public nd h() {
      return this.e;
   }

   public bvs i() {
      return this.k() ? this.d.i() : this;
   }

   public bwa j() {
      bvz var1 = this.a(bwa.b.b);
      bvz var2 = this.a(bwa.b.c);
      bvz var3 = this.a(bwa.b.d);
      bvz var4 = this.a(bwa.b.e);
      bvz var5 = this.a(bwa.b.f);
      bvz var6 = this.a(bwa.b.g);
      bvz var7 = this.a(bwa.b.h);
      bvz var8 = this.a(bwa.b.i);
      return new bwa(var1, var2, var3, var4, var5, var6, var7, var8);
   }

   private bvz a(bwa.b var1) {
      return this.d != null && !this.j.c(var1) ? this.d.a(var1) : this.j.b(var1);
   }

   public static void b(Map<nd, bvs> var0) {
      Iterator var1 = var0.values().iterator();

      while(var1.hasNext()) {
         bvs var2 = (bvs)var1.next();

         try {
            bvs var3 = var2.d;

            for(bvs var4 = var3.d; var3 != var4; var4 = var4.d.d) {
               var3 = var3.d;
            }

            throw new bvs.c();
         } catch (NullPointerException var5) {
         }
      }

   }

   public static class c extends RuntimeException {
   }

   public static class b implements JsonDeserializer<bvs> {
      public bvs a(JsonElement var1, Type var2, JsonDeserializationContext var3) throws JsonParseException {
         JsonObject var4 = var1.getAsJsonObject();
         List<bvo> var5 = this.b(var3, var4);
         String var6 = this.c(var4);
         Map<String, String> var7 = this.b(var4);
         boolean var8 = this.a(var4);
         bwa var9 = bwa.a;
         if (var4.has("display")) {
            JsonObject var10 = ra.t(var4, "display");
            var9 = (bwa)var3.deserialize(var10, bwa.class);
         }

         List<bvx> var12 = this.a(var3, var4);
         nd var11 = var6.isEmpty() ? null : new nd(var6);
         return new bvs(var11, var5, var7, var8, true, var9, var12);
      }

      protected List<bvx> a(JsonDeserializationContext var1, JsonObject var2) {
         List<bvx> var3 = Lists.newArrayList();
         if (var2.has("overrides")) {
            JsonArray var4 = ra.u(var2, "overrides");
            Iterator var5 = var4.iterator();

            while(var5.hasNext()) {
               JsonElement var6 = (JsonElement)var5.next();
               var3.add((bvx)var1.deserialize(var6, bvx.class));
            }
         }

         return var3;
      }

      private Map<String, String> b(JsonObject var1) {
         Map<String, String> var2 = Maps.newHashMap();
         if (var1.has("textures")) {
            JsonObject var3 = var1.getAsJsonObject("textures");
            Iterator var4 = var3.entrySet().iterator();

            while(var4.hasNext()) {
               Entry<String, JsonElement> var5 = (Entry)var4.next();
               var2.put(var5.getKey(), ((JsonElement)var5.getValue()).getAsString());
            }
         }

         return var2;
      }

      private String c(JsonObject var1) {
         return ra.a(var1, "parent", "");
      }

      protected boolean a(JsonObject var1) {
         return ra.a(var1, "ambientocclusion", true);
      }

      protected List<bvo> b(JsonDeserializationContext var1, JsonObject var2) {
         List<bvo> var3 = Lists.newArrayList();
         if (var2.has("elements")) {
            Iterator var4 = ra.u(var2, "elements").iterator();

            while(var4.hasNext()) {
               JsonElement var5 = (JsonElement)var4.next();
               var3.add((bvo)var1.deserialize(var5, bvo.class));
            }
         }

         return var3;
      }

      // $FF: synthetic method
      public Object deserialize(JsonElement var1, Type var2, JsonDeserializationContext var3) throws JsonParseException {
         return this.a(var1, var2, var3);
      }
   }

   static final class a {
      public final bvs a;
      public bvs b;

      private a(bvs var1) {
         this.a = var1;
      }

      // $FF: synthetic method
      a(bvs var1, Object var2) {
         this(var1);
      }
   }
}
