public class bnx extends bnv {
   private final ces.a c;

   public bnx(bnu var1, ces.a var2) {
      super(var1);
      this.c = var2;
   }

   protected void d() {
      this.c.a(this.a.N());
   }

   protected int a() {
      return this.c.f();
   }

   protected String b() {
      return this.c.e();
   }

   protected String c() {
      return this.c.d();
   }

   public ces.a k() {
      return this.c;
   }
}
