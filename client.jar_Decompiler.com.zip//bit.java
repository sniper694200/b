import com.mojang.text2speech.Narrator;

public class bit implements bis {
   public static final bit a = new bit();
   private final Narrator b = Narrator.getNarrator();

   public void a(hf var1, hh var2) {
      int var3 = bhz.z().t.aI;
      if (var3 != 0 && this.b.active()) {
         if (var3 == 1 || var3 == 2 && var1 == hf.a || var3 == 3 && var1 == hf.b) {
            if (var2 instanceof hp && "chat.type.text".equals(((hp)var2).i())) {
               this.b.say((new hp("chat.type.text.narrate", ((hp)var2).j())).c());
            } else {
               this.b.say(var2.c());
            }
         }

      }
   }

   public void a(int var1) {
      this.b.clear();
      this.b.say((new hp("options.narrator", new Object[0])).c() + " : " + (new hp(bib.b[var1], new Object[0])).c());
      bka var2 = bhz.z().ao();
      if (this.b.active()) {
         if (var1 == 0) {
            bjy.a(var2, bjy.a.b, new hp("narrator.toast.disabled", new Object[0]), (hh)null);
         } else {
            bjy.a(var2, bjy.a.b, new hp("narrator.toast.enabled", new Object[0]), new hp(bib.b[var1], new Object[0]));
         }
      } else {
         bjy.a(var2, bjy.a.b, new hp("narrator.toast.disabled", new Object[0]), new hp("options.narrator.notavailable", new Object[0]));
      }

   }

   public boolean a() {
      return this.b.active();
   }

   public void b() {
      this.b.clear();
   }
}
