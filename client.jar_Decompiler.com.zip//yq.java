public class yq extends yy {
   aai a;
   vn b;

   public yq(aai var1) {
      super(var1, false, true);
      this.a = var1;
      this.a(1);
   }

   public boolean a() {
      zm var1 = this.a.p();
      if (var1 == null) {
         return false;
      } else {
         this.b = var1.b((vn)this.a);
         if (this.b instanceof acq) {
            return false;
         } else if (this.a(this.b, false)) {
            return true;
         } else if (this.e.bR().nextInt(20) == 0) {
            this.b = var1.c((vn)this.a);
            return this.a(this.b, false);
         } else {
            return false;
         }
      }
   }

   public void c() {
      this.a.d((vn)this.b);
      super.c();
   }
}
