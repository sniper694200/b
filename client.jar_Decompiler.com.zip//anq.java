public class anq extends anf {
   public anq(anf.a var1) {
      super(var1);
      this.t.clear();
      this.u.clear();
      this.v.clear();
      this.w.clear();
      this.t.add(new anf.c(acw.class, 50, 4, 4));
      this.t.add(new anf.c(add.class, 100, 4, 4));
      this.t.add(new anf.c(adb.class, 2, 4, 4));
      this.t.add(new anf.c(acs.class, 1, 4, 4));
      this.s = new anr();
   }
}
