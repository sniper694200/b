import com.mojang.authlib.GameProfile;

public class bom implements boq {
   private final GameProfile a;
   private final nd b;

   public bom(GameProfile var1) {
      this.a = var1;
      this.b = bty.e(var1.getName());
      bty.a(this.b, var1.getName());
   }

   public void a(boo var1) {
      bhz.z().v().a((ht)(new ly(this.a.getId())));
   }

   public hh J_() {
      return new ho(this.a.getName());
   }

   public void a(float var1, int var2) {
      bhz.z().N().a(this.b);
      buq.c(1.0F, 1.0F, 1.0F, (float)var2 / 255.0F);
      bip.a(2, 2, 8.0F, 8.0F, 8, 8, 12, 12, 64.0F, 64.0F);
      bip.a(2, 2, 40.0F, 8.0F, 8, 8, 12, 12, 64.0F, 64.0F);
   }

   public boolean K_() {
      return true;
   }
}
