public class bhp extends bhm {
   public bhp(String var1) {
      super(var1);
   }

   public boolean b() {
      return true;
   }
}
