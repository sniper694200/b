public class yw extends yy {
   vz a;
   vn b;
   private int c;

   public yw(vz var1) {
      super(var1, false);
      this.a = var1;
      this.a(1);
   }

   public boolean a() {
      if (!this.a.dl()) {
         return false;
      } else {
         vn var1 = this.a.do();
         if (var1 == null) {
            return false;
         } else {
            this.b = var1.bS();
            int var2 = var1.bT();
            return var2 != this.c && this.a(this.b, false) && this.a.a(this.b, var1);
         }
      }
   }

   public void c() {
      this.e.d(this.b);
      vn var1 = this.a.do();
      if (var1 != null) {
         this.c = var1.bT();
      }

      super.c();
   }
}
