public class tb implements rs {
   public int a() {
      return 820;
   }

   public fy a(fy var1) {
      if ("minecraft:totem".equals(var1.l("id"))) {
         var1.a("id", "minecraft:totem_of_undying");
      }

      return var1;
   }
}
