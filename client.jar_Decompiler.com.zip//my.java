public interface my<T> {
   void a(gy var1, T var2);

   T a(gy var1);

   mx<T> a(int var1);

   T a(T var1);
}
