public class byt extends cad<zu> {
   private static final nd a = new nd("textures/entity/chicken.png");

   public byt(bzd var1) {
      super(var1, new bpk(), 0.3F);
   }

   protected nd a(zu var1) {
      return a;
   }

   protected float a(zu var1, float var2) {
      float var3 = var1.bB + (var1.bx - var1.bB) * var2;
      float var4 = var1.bz + (var1.by - var1.bz) * var2;
      return (ri.a(var3) + 1.0F) * var4;
   }

   // $FF: synthetic method
   protected float b(vn var1, float var2) {
      return this.a((zu)var1, var2);
   }
}
