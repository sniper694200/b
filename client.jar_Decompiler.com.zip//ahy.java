public class ahy extends ail {
   public ahy() {
      this.b(ahn.f);
   }

   public ub a(aeb var1, ams var2, et var3, tz var4, fa var5, float var6, float var7, float var8) {
      awr var9 = var2.o(var3);
      ain var10 = var1.b((tz)var4);
      if (var1.a(var3.a(var5), var5, var10) && var9.u() == aov.bG && !(Boolean)var9.c(aqg.b)) {
         if (var2.G) {
            return ub.a;
         } else {
            var2.a((et)var3, (awr)var9.a(aqg.b, true), 2);
            var2.d(var3, aov.bG);
            var10.g(1);

            for(int var11 = 0; var11 < 16; ++var11) {
               double var12 = (double)((float)var3.p() + (5.0F + j.nextFloat() * 6.0F) / 16.0F);
               double var14 = (double)((float)var3.q() + 0.8125F);
               double var16 = (double)((float)var3.r() + (5.0F + j.nextFloat() * 6.0F) / 16.0F);
               double var18 = 0.0D;
               double var20 = 0.0D;
               double var22 = 0.0D;
               var2.a(fj.l, var12, var14, var16, 0.0D, 0.0D, 0.0D);
            }

            var2.a((aeb)null, var3, qd.bp, qe.e, 1.0F, 1.0F);
            awv.b var24 = aqg.e().a(var2, var3);
            if (var24 != null) {
               et var25 = var24.a().a(-3, 0, -3);

               for(int var13 = 0; var13 < 3; ++var13) {
                  for(int var26 = 0; var26 < 3; ++var26) {
                     var2.a((et)var25.a(var13, 0, var26), (awr)aov.bF.t(), 2);
                  }
               }

               var2.a(1038, var25.a(1, 0, 1), 0);
            }

            return ub.a;
         }
      } else {
         return ub.c;
      }
   }

   public uc<ain> a(ams var1, aeb var2, tz var3) {
      ain var4 = var2.b((tz)var3);
      bha var5 = this.a(var1, var2, false);
      if (var5 != null && var5.a == bha.a.b && var1.o(var5.a()).u() == aov.bG) {
         return new uc(ub.b, var4);
      } else {
         var2.c((tz)var3);
         if (!var1.G) {
            et var6 = ((om)var1).r().a(var1, "Stronghold", new et(var2), false);
            if (var6 != null) {
               aei var7 = new aei(var1, var2.p, var2.q + (double)(var2.H / 2.0F), var2.r);
               var7.a(var6);
               var1.a((ve)var7);
               if (var2 instanceof oo) {
                  m.l.a((oo)var2, var6);
               }

               var1.a((aeb)null, var2.p, var2.q, var2.r, qd.bc, qe.g, 0.5F, 0.4F / (j.nextFloat() * 0.4F + 0.8F));
               var1.a((aeb)null, 1003, new et(var2), 0);
               if (!var2.bO.d) {
                  var4.g(1);
               }

               var2.b(qq.b((ail)this));
               return new uc(ub.a, var4);
            }
         }

         return new uc(ub.a, var4);
      }
   }
}
