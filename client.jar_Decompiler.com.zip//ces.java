import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.SettableFuture;
import java.awt.image.BufferedImage;
import java.io.Closeable;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;
import java.util.regex.Pattern;
import javax.annotation.Nullable;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.IOFileFilter;
import org.apache.commons.io.filefilter.TrueFileFilter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ces {
   private static final Logger c = LogManager.getLogger();
   private static final FileFilter d = new FileFilter() {
      public boolean accept(File var1) {
         boolean var2 = var1.isFile() && var1.getName().endsWith(".zip");
         boolean var3 = var1.isDirectory() && (new File(var1, "pack.mcmeta")).isFile();
         return var2 || var3;
      }
   };
   private static final Pattern e = Pattern.compile("^[a-fA-F0-9]{40}$");
   private static final nd f = new nd("textures/misc/unknown_pack.png");
   private final File g;
   public final cep a;
   private final File h;
   public final cfe b;
   private cep i;
   private final ReentrantLock j = new ReentrantLock();
   private ListenableFuture<Object> k;
   private List<ces.a> l = Lists.newArrayList();
   private final List<ces.a> m = Lists.newArrayList();

   public ces(File var1, File var2, cep var3, cfe var4, bib var5) {
      this.g = var1;
      this.h = var2;
      this.a = var3;
      this.b = var4;
      this.k();
      this.b();
      Iterator var6 = var5.m.iterator();

      while(true) {
         while(var6.hasNext()) {
            String var7 = (String)var6.next();
            Iterator var8 = this.l.iterator();

            while(var8.hasNext()) {
               ces.a var9 = (ces.a)var8.next();
               if (var9.d().equals(var7)) {
                  if (var9.f() == 3 || var5.n.contains(var9.d())) {
                     this.m.add(var9);
                     break;
                  }

                  var6.remove();
                  c.warn("Removed selected resource pack {} because it's no longer compatible", var9.d());
               }
            }
         }

         return;
      }
   }

   public static Map<String, String> a() {
      Map<String, String> var0 = Maps.newHashMap();
      var0.put("X-Minecraft-Username", bhz.z().K().c());
      var0.put("X-Minecraft-UUID", bhz.z().K().b());
      var0.put("X-Minecraft-Version", "1.12");
      return var0;
   }

   private void k() {
      if (this.g.exists()) {
         if (!this.g.isDirectory() && (!this.g.delete() || !this.g.mkdirs())) {
            c.warn("Unable to recreate resourcepack folder, it exists but is not a directory: {}", this.g);
         }
      } else if (!this.g.mkdirs()) {
         c.warn("Unable to create resourcepack folder: {}", this.g);
      }

   }

   private List<File> l() {
      return this.g.isDirectory() ? Arrays.asList(this.g.listFiles(d)) : Collections.emptyList();
   }

   private cep b(File var1) {
      Object var2;
      if (var1.isDirectory()) {
         var2 = new cei(var1);
      } else {
         var2 = new ceh(var1);
      }

      try {
         cfp var3 = (cfp)((cep)var2).a(this.b, "pack");
         if (var3 != null && var3.b() == 2) {
            return new ceq((cep)var2);
         }
      } catch (Exception var4) {
      }

      return (cep)var2;
   }

   public void b() {
      List<ces.a> var1 = Lists.newArrayList();
      Iterator var2 = this.l().iterator();

      while(var2.hasNext()) {
         File var3 = (File)var2.next();
         ces.a var4 = new ces.a(var3);
         if (this.l.contains(var4)) {
            int var5 = this.l.indexOf(var4);
            if (var5 > -1 && var5 < this.l.size()) {
               var1.add(this.l.get(var5));
            }
         } else {
            try {
               var4.a();
               var1.add(var4);
            } catch (Exception var6) {
               var1.remove(var4);
            }
         }
      }

      this.l.removeAll(var1);
      var2 = this.l.iterator();

      while(var2.hasNext()) {
         ces.a var7 = (ces.a)var2.next();
         var7.b();
      }

      this.l = var1;
   }

   @Nullable
   public ces.a c() {
      if (this.i != null) {
         ces.a var1 = new ces.a(this.i);

         try {
            var1.a();
            return var1;
         } catch (IOException var3) {
         }
      }

      return null;
   }

   public List<ces.a> d() {
      return ImmutableList.copyOf(this.l);
   }

   public List<ces.a> e() {
      return ImmutableList.copyOf(this.m);
   }

   public void a(List<ces.a> var1) {
      this.m.clear();
      this.m.addAll(var1);
   }

   public File f() {
      return this.g;
   }

   public ListenableFuture<Object> a(String var1, String var2) {
      String var3 = DigestUtils.sha1Hex(var1);
      final String var4 = e.matcher(var2).matches() ? var2 : "";
      final File var5 = new File(this.h, var3);
      this.j.lock();

      try {
         this.h();
         if (var5.exists()) {
            if (this.a(var4, var5)) {
               ListenableFuture var14 = this.a(var5);
               return var14;
            }

            c.warn("Deleting file {}", var5);
            FileUtils.deleteQuietly(var5);
         }

         this.m();
         final blg var6 = new blg();
         Map<String, String> var7 = a();
         final bhz var8 = bhz.z();
         Futures.getUnchecked(var8.a(new Runnable() {
            public void run() {
               var8.a((bli)var6);
            }
         }));
         final SettableFuture<Object> var9 = SettableFuture.create();
         this.k = rb.a(var5, var1, var7, 52428800, var6, var8.M());
         Futures.addCallback(this.k, new FutureCallback<Object>() {
            public void onSuccess(@Nullable Object var1) {
               if (ces.this.a(var4, var5)) {
                  ces.this.a(var5);
                  var9.set((Object)null);
               } else {
                  ces.c.warn("Deleting file {}", var5);
                  FileUtils.deleteQuietly(var5);
               }

            }

            public void onFailure(Throwable var1) {
               FileUtils.deleteQuietly(var5);
               var9.setException(var1);
            }
         });
         ListenableFuture var10 = this.k;
         return var10;
      } finally {
         this.j.unlock();
      }
   }

   private boolean a(String var1, File var2) {
      try {
         String var3 = DigestUtils.sha1Hex(new FileInputStream(var2));
         if (var1.isEmpty()) {
            c.info("Found file {} without verification hash", var2);
            return true;
         }

         if (var3.toLowerCase(Locale.ROOT).equals(var1.toLowerCase(Locale.ROOT))) {
            c.info("Found file {} matching requested hash {}", var2, var1);
            return true;
         }

         c.warn("File {} had wrong hash (expected {}, found {}).", var2, var1, var3);
      } catch (IOException var4) {
         c.warn("File {} couldn't be hashed.", var2, var4);
      }

      return false;
   }

   private boolean c(File var1) {
      ces.a var2 = new ces.a(var1);

      try {
         var2.a();
         return true;
      } catch (Exception var4) {
         c.warn("Server resourcepack is invalid, ignoring it", var4);
         return false;
      }
   }

   private void m() {
      try {
         List<File> var1 = Lists.newArrayList(FileUtils.listFiles(this.h, TrueFileFilter.TRUE, (IOFileFilter)null));
         Collections.sort(var1, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
         int var2 = 0;
         Iterator var3 = var1.iterator();

         while(var3.hasNext()) {
            File var4 = (File)var3.next();
            if (var2++ >= 10) {
               c.info("Deleting old server resource pack {}", var4.getName());
               FileUtils.deleteQuietly(var4);
            }
         }
      } catch (IllegalArgumentException var5) {
         c.error("Error while deleting old server resource pack : {}", var5.getMessage());
      }

   }

   public ListenableFuture<Object> a(File var1) {
      if (!this.c(var1)) {
         return Futures.immediateFailedFuture(new RuntimeException("Invalid resourcepack"));
      } else {
         this.i = new ceh(var1);
         return bhz.z().A();
      }
   }

   @Nullable
   public cep g() {
      return this.i;
   }

   public void h() {
      this.j.lock();

      try {
         if (this.k != null) {
            this.k.cancel(true);
         }

         this.k = null;
         if (this.i != null) {
            this.i = null;
            bhz.z().A();
         }
      } finally {
         this.j.unlock();
      }

   }

   public class a {
      private final cep b;
      private cfp c;
      private nd d;

      private a(File var2) {
         this((cep)ces.this.b(var2));
      }

      private a(cep var2) {
         this.b = var2;
      }

      public void a() throws IOException {
         this.c = (cfp)this.b.a(ces.this.b, "pack");
         this.b();
      }

      public void a(cdp var1) {
         BufferedImage var2 = null;

         try {
            var2 = this.b.a();
         } catch (IOException var5) {
         }

         if (var2 == null) {
            try {
               var2 = cdr.a(bhz.z().O().a(ces.f).b());
            } catch (IOException var4) {
               throw new Error("Couldn't bind resource pack icon", var4);
            }
         }

         if (this.d == null) {
            this.d = var1.a("texturepackicon", new cde(var2));
         }

         var1.a(this.d);
      }

      public void b() {
         if (this.b instanceof Closeable) {
            IOUtils.closeQuietly((Closeable)this.b);
         }

      }

      public cep c() {
         return this.b;
      }

      public String d() {
         return this.b.b();
      }

      public String e() {
         return this.c == null ? .a.m + "Invalid pack.mcmeta (or missing 'pack' section)" : this.c.a().d();
      }

      public int f() {
         return this.c == null ? 0 : this.c.b();
      }

      public boolean equals(Object var1) {
         if (this == var1) {
            return true;
         } else {
            return var1 instanceof ces.a ? this.toString().equals(var1.toString()) : false;
         }
      }

      public int hashCode() {
         return this.toString().hashCode();
      }

      public String toString() {
         return String.format("%s:%s", this.b.b(), this.b instanceof cei ? "folder" : "zip");
      }

      // $FF: synthetic method
      a(File var2, Object var3) {
         this((File)var2);
      }

      // $FF: synthetic method
      a(cep var2, Object var3) {
         this((cep)var2);
      }
   }
}
