import com.google.common.base.Predicate;
import javax.annotation.Nullable;

public class awu {
   private final ams a;
   private final et b;
   private final boolean c;
   private awr d;
   private avh e;
   private boolean f;

   public awu(ams var1, et var2, boolean var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }

   public awr a() {
      if (this.d == null && (this.c || this.a.e(this.b))) {
         this.d = this.a.o(this.b);
      }

      return this.d;
   }

   @Nullable
   public avh b() {
      if (this.e == null && !this.f) {
         this.e = this.a.r(this.b);
         this.f = true;
      }

      return this.e;
   }

   public et d() {
      return this.b;
   }

   public static Predicate<awu> a(final Predicate<awr> var0) {
      return new Predicate<awu>() {
         public boolean a(@Nullable awu var1) {
            return var1 != null && var0.apply(var1.a());
         }

         // $FF: synthetic method
         public boolean apply(@Nullable Object var1) {
            return this.a((awu)var1);
         }
      };
   }
}
