public class bth extends btd {
   private final float a;
   private final double b;
   private final double L;
   private final double M;

   protected bth(ams var1, double var2, double var4, double var6, double var8, double var10, double var12) {
      super(var1, var2, var4, var6, var8, var10, var12);
      this.j = var8;
      this.k = var10;
      this.l = var12;
      this.g = var2;
      this.h = var4;
      this.i = var6;
      this.b = this.g;
      this.L = this.h;
      this.M = this.i;
      float var14 = this.r.nextFloat() * 0.6F + 0.4F;
      this.y = this.r.nextFloat() * 0.2F + 0.5F;
      this.a = this.y;
      this.A = var14 * 0.9F;
      this.B = var14 * 0.3F;
      this.C = var14;
      this.x = (int)(Math.random() * 10.0D) + 40;
      this.b((int)(Math.random() * 8.0D));
   }

   public void a(double var1, double var3, double var5) {
      this.a(this.l().d(var1, var3, var5));
      this.j();
   }

   public void a(bui var1, ve var2, float var3, float var4, float var5, float var6, float var7, float var8) {
      float var9 = ((float)this.w + var3) / (float)this.x;
      var9 = 1.0F - var9;
      var9 *= var9;
      var9 = 1.0F - var9;
      this.y = this.a * var9;
      super.a(var1, var2, var3, var4, var5, var6, var7, var8);
   }

   public int a(float var1) {
      int var2 = super.a(var1);
      float var3 = (float)this.w / (float)this.x;
      var3 *= var3;
      var3 *= var3;
      int var4 = var2 & 255;
      int var5 = var2 >> 16 & 255;
      var5 += (int)(var3 * 15.0F * 16.0F);
      if (var5 > 240) {
         var5 = 240;
      }

      return var4 | var5 << 16;
   }

   public void a() {
      this.d = this.g;
      this.e = this.h;
      this.f = this.i;
      float var1 = (float)this.w / (float)this.x;
      float var2 = var1;
      var1 = -var1 + var1 * var1 * 2.0F;
      var1 = 1.0F - var1;
      this.g = this.b + this.j * (double)var1;
      this.h = this.L + this.k * (double)var1 + (double)(1.0F - var2);
      this.i = this.M + this.l * (double)var1;
      if (this.w++ >= this.x) {
         this.i();
      }

   }

   public static class a implements btf {
      public btd a(int var1, ams var2, double var3, double var5, double var7, double var9, double var11, double var13, int... var15) {
         return new bth(var2, var3, var5, var7, var9, var11, var13);
      }
   }
}
