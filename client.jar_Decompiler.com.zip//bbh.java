import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class bbh extends bbs {
   private double a = 0.004D;

   public bbh() {
   }

   public String a() {
      return "Mineshaft";
   }

   public bbh(Map<String, String> var1) {
      Iterator var2 = var1.entrySet().iterator();

      while(var2.hasNext()) {
         Entry<String, String> var3 = (Entry)var2.next();
         if (((String)var3.getKey()).equals("chance")) {
            this.a = ri.a((String)var3.getValue(), this.a);
         }
      }

   }

   protected boolean a(int var1, int var2) {
      return this.f.nextDouble() < this.a && this.f.nextInt(80) < Math.max(Math.abs(var1), Math.abs(var2));
   }

   public et a(ams var1, et var2, boolean var3) {
      int var4 = true;
      int var5 = var2.p() >> 4;
      int var6 = var2.r() >> 4;

      for(int var7 = 0; var7 <= 1000; ++var7) {
         for(int var8 = -var7; var8 <= var7; ++var8) {
            boolean var9 = var8 == -var7 || var8 == var7;

            for(int var10 = -var7; var10 <= var7; ++var10) {
               boolean var11 = var10 == -var7 || var10 == var7;
               if (var9 || var11) {
                  int var12 = var5 + var8;
                  int var13 = var6 + var10;
                  this.f.setSeed((long)(var12 ^ var13) ^ var1.Q());
                  this.f.nextInt();
                  if (this.a(var12, var13) && (!var3 || !var1.b(var12, var13))) {
                     return new et((var12 << 4) + 8, 64, (var13 << 4) + 8);
                  }
               }
            }
         }
      }

      return null;
   }

   protected bbw b(int var1, int var2) {
      anf var3 = this.g.b(new et((var1 << 4) + 8, 64, (var2 << 4) + 8));
      bbh.a var4 = var3 instanceof anu ? bbh.a.b : bbh.a.a;
      return new bbj(this.g, this.f, var1, var2, var4);
   }

   public static enum a {
      a,
      b;

      public static bbh.a a(int var0) {
         return var0 >= 0 && var0 < values().length ? values()[var0] : a;
      }
   }
}
