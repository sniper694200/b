public class afr extends afp {
   private final tt a;
   private final afr.a f;

   public afr(tt var1, tt var2) {
      this.a = var2;
      this.f = new afr.a(var2, 0, 136, 110);
      this.a((agp)this.f);
      int var3 = true;
      int var4 = true;

      int var5;
      for(var5 = 0; var5 < 3; ++var5) {
         for(int var6 = 0; var6 < 9; ++var6) {
            this.a((agp)(new agp(var1, var6 + var5 * 9 + 9, 36 + var6 * 18, 137 + var5 * 18)));
         }
      }

      for(var5 = 0; var5 < 9; ++var5) {
         this.a((agp)(new agp(var1, var5, 36 + var5 * 18, 195)));
      }

   }

   public void a(afv var1) {
      super.a(var1);
      var1.a(this, (tt)this.a);
   }

   public void b(int var1, int var2) {
      this.a.b(var1, var2);
   }

   public tt e() {
      return this.a;
   }

   public void b(aeb var1) {
      super.b(var1);
      if (!var1.l.G) {
         ain var2 = this.f.a(this.f.a());
         if (!var2.b()) {
            var1.a(var2, false);
         }

      }
   }

   public boolean a(aeb var1) {
      return this.a.a(var1);
   }

   public ain b(aeb var1, int var2) {
      ain var3 = ain.a;
      agp var4 = (agp)this.c.get(var2);
      if (var4 != null && var4.e()) {
         ain var5 = var4.d();
         var3 = var5.l();
         if (var2 == 0) {
            if (!this.a(var5, 1, 37, true)) {
               return ain.a;
            }

            var4.a(var5, var3);
         } else if (!this.f.e() && this.f.a(var5) && var5.E() == 1) {
            if (!this.a(var5, 0, 1, false)) {
               return ain.a;
            }
         } else if (var2 >= 1 && var2 < 28) {
            if (!this.a(var5, 28, 37, false)) {
               return ain.a;
            }
         } else if (var2 >= 28 && var2 < 37) {
            if (!this.a(var5, 1, 28, false)) {
               return ain.a;
            }
         } else if (!this.a(var5, 1, 37, false)) {
            return ain.a;
         }

         if (var5.b()) {
            var4.d(ain.a);
         } else {
            var4.f();
         }

         if (var5.E() == var3.E()) {
            return ain.a;
         }

         var4.a(var1, var5);
      }

      return var3;
   }

   class a extends agp {
      public a(tt var2, int var3, int var4, int var5) {
         super(var2, var3, var4, var5);
      }

      public boolean a(ain var1) {
         ail var2 = var1.c();
         return var2 == aip.bZ || var2 == aip.l || var2 == aip.n || var2 == aip.m;
      }

      public int a() {
         return 1;
      }
   }
}
