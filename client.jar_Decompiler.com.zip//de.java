import net.minecraft.server.MinecraftServer;

public class de extends bi {
   public String c() {
      return "save-on";
   }

   public String b(bn var1) {
      return "commands.save-on.usage";
   }

   public void a(MinecraftServer var1, bn var2, String[] var3) throws ei {
      boolean var4 = false;

      for(int var5 = 0; var5 < var1.d.length; ++var5) {
         if (var1.d[var5] != null) {
            om var6 = var1.d[var5];
            if (var6.b) {
               var6.b = false;
               var4 = true;
            }
         }
      }

      if (var4) {
         a(var2, this, "commands.save.enabled", new Object[0]);
      } else {
         throw new ei("commands.save-on.alreadyOn", new Object[0]);
      }
   }
}
