public class bky extends bli {
   private final String a;
   private final String f;

   public bky(String var1, String var2) {
      this.a = var1;
      this.f = var2;
   }

   public void b() {
      super.b();
      this.n.add(new biy(0, this.l / 2 - 100, 140, cew.a("gui.cancel")));
   }

   public void a(int var1, int var2, float var3) {
      this.a(0, 0, this.l, this.m, -12574688, -11530224);
      this.a(this.q, this.a, this.l / 2, 90, 16777215);
      this.a(this.q, this.f, this.l / 2, 110, 16777215);
      super.a(var1, var2, var3);
   }

   protected void a(char var1, int var2) {
   }

   protected void a(biy var1) {
      this.j.a((bli)null);
   }
}
