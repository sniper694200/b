import com.google.common.collect.Lists;
import java.util.List;
import org.lwjgl.input.Keyboard;

public class bkr extends bli {
   private static final List<bkr.a> f = Lists.newArrayList();
   private bkr.b g;
   private biy h;
   private bjc i;
   private final bks s;
   protected String a = "Customize World Presets";
   private String t;
   private String u;

   public bkr(bks var1) {
      this.s = var1;
   }

   public void b() {
      this.n.clear();
      Keyboard.enableRepeatEvents(true);
      this.a = cew.a("createWorld.customize.custom.presets.title");
      this.t = cew.a("createWorld.customize.presets.share");
      this.u = cew.a("createWorld.customize.presets.list");
      this.i = new bjc(2, this.q, 50, 40, this.l - 100, 20);
      this.g = new bkr.b();
      this.i.f(2000);
      this.i.a(this.s.a());
      this.h = this.b(new biy(0, this.l / 2 - 102, this.m - 27, 100, 20, cew.a("createWorld.customize.presets.select")));
      this.n.add(new biy(1, this.l / 2 + 3, this.m - 27, 100, 20, cew.a("gui.cancel")));
      this.a();
   }

   public void k() {
      super.k();
      this.g.p();
   }

   public void m() {
      Keyboard.enableRepeatEvents(false);
   }

   protected void a(int var1, int var2, int var3) {
      this.i.a(var1, var2, var3);
      super.a(var1, var2, var3);
   }

   protected void a(char var1, int var2) {
      if (!this.i.a(var1, var2)) {
         super.a(var1, var2);
      }

   }

   protected void a(biy var1) {
      switch(var1.k) {
      case 0:
         this.s.a(this.i.b());
         this.j.a((bli)this.s);
         break;
      case 1:
         this.j.a((bli)this.s);
      }

   }

   public void a(int var1, int var2, float var3) {
      this.c();
      this.g.a(var1, var2, var3);
      this.a(this.q, this.a, this.l / 2, 8, 16777215);
      this.c(this.q, this.t, 50, 30, 10526880);
      this.c(this.q, this.u, 50, 70, 10526880);
      this.i.g();
      super.a(var1, var2, var3);
   }

   public void e() {
      this.i.a();
      super.e();
   }

   public void a() {
      this.h.l = this.g();
   }

   private boolean g() {
      return this.g.u > -1 && this.g.u < f.size() || this.i.b().length() > 1;
   }

   static {
      ayv.a var0 = ayv.a.a("{ \"coordinateScale\":684.412, \"heightScale\":684.412, \"upperLimitScale\":512.0, \"lowerLimitScale\":512.0, \"depthNoiseScaleX\":200.0, \"depthNoiseScaleZ\":200.0, \"depthNoiseScaleExponent\":0.5, \"mainNoiseScaleX\":5000.0, \"mainNoiseScaleY\":1000.0, \"mainNoiseScaleZ\":5000.0, \"baseSize\":8.5, \"stretchY\":8.0, \"biomeDepthWeight\":2.0, \"biomeDepthOffset\":0.5, \"biomeScaleWeight\":2.0, \"biomeScaleOffset\":0.375, \"useCaves\":true, \"useDungeons\":true, \"dungeonChance\":8, \"useStrongholds\":true, \"useVillages\":true, \"useMineShafts\":true, \"useTemples\":true, \"useRavines\":true, \"useWaterLakes\":true, \"waterLakeChance\":4, \"useLavaLakes\":true, \"lavaLakeChance\":80, \"useLavaOceans\":false, \"seaLevel\":255 }");
      nd var1 = new nd("textures/gui/presets/water.png");
      f.add(new bkr.a(cew.a("createWorld.customize.custom.preset.waterWorld"), var1, var0));
      var0 = ayv.a.a("{\"coordinateScale\":3000.0, \"heightScale\":6000.0, \"upperLimitScale\":250.0, \"lowerLimitScale\":512.0, \"depthNoiseScaleX\":200.0, \"depthNoiseScaleZ\":200.0, \"depthNoiseScaleExponent\":0.5, \"mainNoiseScaleX\":80.0, \"mainNoiseScaleY\":160.0, \"mainNoiseScaleZ\":80.0, \"baseSize\":8.5, \"stretchY\":10.0, \"biomeDepthWeight\":1.0, \"biomeDepthOffset\":0.0, \"biomeScaleWeight\":1.0, \"biomeScaleOffset\":0.0, \"useCaves\":true, \"useDungeons\":true, \"dungeonChance\":8, \"useStrongholds\":true, \"useVillages\":true, \"useMineShafts\":true, \"useTemples\":true, \"useRavines\":true, \"useWaterLakes\":true, \"waterLakeChance\":4, \"useLavaLakes\":true, \"lavaLakeChance\":80, \"useLavaOceans\":false, \"seaLevel\":63 }");
      var1 = new nd("textures/gui/presets/isles.png");
      f.add(new bkr.a(cew.a("createWorld.customize.custom.preset.isleLand"), var1, var0));
      var0 = ayv.a.a("{\"coordinateScale\":684.412, \"heightScale\":684.412, \"upperLimitScale\":512.0, \"lowerLimitScale\":512.0, \"depthNoiseScaleX\":200.0, \"depthNoiseScaleZ\":200.0, \"depthNoiseScaleExponent\":0.5, \"mainNoiseScaleX\":5000.0, \"mainNoiseScaleY\":1000.0, \"mainNoiseScaleZ\":5000.0, \"baseSize\":8.5, \"stretchY\":5.0, \"biomeDepthWeight\":2.0, \"biomeDepthOffset\":1.0, \"biomeScaleWeight\":4.0, \"biomeScaleOffset\":1.0, \"useCaves\":true, \"useDungeons\":true, \"dungeonChance\":8, \"useStrongholds\":true, \"useVillages\":true, \"useMineShafts\":true, \"useTemples\":true, \"useRavines\":true, \"useWaterLakes\":true, \"waterLakeChance\":4, \"useLavaLakes\":true, \"lavaLakeChance\":80, \"useLavaOceans\":false, \"seaLevel\":63 }");
      var1 = new nd("textures/gui/presets/delight.png");
      f.add(new bkr.a(cew.a("createWorld.customize.custom.preset.caveDelight"), var1, var0));
      var0 = ayv.a.a("{\"coordinateScale\":738.41864, \"heightScale\":157.69133, \"upperLimitScale\":801.4267, \"lowerLimitScale\":1254.1643, \"depthNoiseScaleX\":374.93652, \"depthNoiseScaleZ\":288.65228, \"depthNoiseScaleExponent\":1.2092624, \"mainNoiseScaleX\":1355.9908, \"mainNoiseScaleY\":745.5343, \"mainNoiseScaleZ\":1183.464, \"baseSize\":1.8758626, \"stretchY\":1.7137525, \"biomeDepthWeight\":1.7553768, \"biomeDepthOffset\":3.4701107, \"biomeScaleWeight\":1.0, \"biomeScaleOffset\":2.535211, \"useCaves\":true, \"useDungeons\":true, \"dungeonChance\":8, \"useStrongholds\":true, \"useVillages\":true, \"useMineShafts\":true, \"useTemples\":true, \"useRavines\":true, \"useWaterLakes\":true, \"waterLakeChance\":4, \"useLavaLakes\":true, \"lavaLakeChance\":80, \"useLavaOceans\":false, \"seaLevel\":63 }");
      var1 = new nd("textures/gui/presets/madness.png");
      f.add(new bkr.a(cew.a("createWorld.customize.custom.preset.mountains"), var1, var0));
      var0 = ayv.a.a("{\"coordinateScale\":684.412, \"heightScale\":684.412, \"upperLimitScale\":512.0, \"lowerLimitScale\":512.0, \"depthNoiseScaleX\":200.0, \"depthNoiseScaleZ\":200.0, \"depthNoiseScaleExponent\":0.5, \"mainNoiseScaleX\":1000.0, \"mainNoiseScaleY\":3000.0, \"mainNoiseScaleZ\":1000.0, \"baseSize\":8.5, \"stretchY\":10.0, \"biomeDepthWeight\":1.0, \"biomeDepthOffset\":0.0, \"biomeScaleWeight\":1.0, \"biomeScaleOffset\":0.0, \"useCaves\":true, \"useDungeons\":true, \"dungeonChance\":8, \"useStrongholds\":true, \"useVillages\":true, \"useMineShafts\":true, \"useTemples\":true, \"useRavines\":true, \"useWaterLakes\":true, \"waterLakeChance\":4, \"useLavaLakes\":true, \"lavaLakeChance\":80, \"useLavaOceans\":false, \"seaLevel\":20 }");
      var1 = new nd("textures/gui/presets/drought.png");
      f.add(new bkr.a(cew.a("createWorld.customize.custom.preset.drought"), var1, var0));
      var0 = ayv.a.a("{\"coordinateScale\":684.412, \"heightScale\":684.412, \"upperLimitScale\":2.0, \"lowerLimitScale\":64.0, \"depthNoiseScaleX\":200.0, \"depthNoiseScaleZ\":200.0, \"depthNoiseScaleExponent\":0.5, \"mainNoiseScaleX\":80.0, \"mainNoiseScaleY\":160.0, \"mainNoiseScaleZ\":80.0, \"baseSize\":8.5, \"stretchY\":12.0, \"biomeDepthWeight\":1.0, \"biomeDepthOffset\":0.0, \"biomeScaleWeight\":1.0, \"biomeScaleOffset\":0.0, \"useCaves\":true, \"useDungeons\":true, \"dungeonChance\":8, \"useStrongholds\":true, \"useVillages\":true, \"useMineShafts\":true, \"useTemples\":true, \"useRavines\":true, \"useWaterLakes\":true, \"waterLakeChance\":4, \"useLavaLakes\":true, \"lavaLakeChance\":80, \"useLavaOceans\":false, \"seaLevel\":6 }");
      var1 = new nd("textures/gui/presets/chaos.png");
      f.add(new bkr.a(cew.a("createWorld.customize.custom.preset.caveChaos"), var1, var0));
      var0 = ayv.a.a("{\"coordinateScale\":684.412, \"heightScale\":684.412, \"upperLimitScale\":512.0, \"lowerLimitScale\":512.0, \"depthNoiseScaleX\":200.0, \"depthNoiseScaleZ\":200.0, \"depthNoiseScaleExponent\":0.5, \"mainNoiseScaleX\":80.0, \"mainNoiseScaleY\":160.0, \"mainNoiseScaleZ\":80.0, \"baseSize\":8.5, \"stretchY\":12.0, \"biomeDepthWeight\":1.0, \"biomeDepthOffset\":0.0, \"biomeScaleWeight\":1.0, \"biomeScaleOffset\":0.0, \"useCaves\":true, \"useDungeons\":true, \"dungeonChance\":8, \"useStrongholds\":true, \"useVillages\":true, \"useMineShafts\":true, \"useTemples\":true, \"useRavines\":true, \"useWaterLakes\":true, \"waterLakeChance\":4, \"useLavaLakes\":true, \"lavaLakeChance\":80, \"useLavaOceans\":true, \"seaLevel\":40 }");
      var1 = new nd("textures/gui/presets/luck.png");
      f.add(new bkr.a(cew.a("createWorld.customize.custom.preset.goodLuck"), var1, var0));
   }

   static class a {
      public String a;
      public nd b;
      public ayv.a c;

      public a(String var1, nd var2, ayv.a var3) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }
   }

   class b extends bjp {
      public int u = -1;

      public b() {
         super(bkr.this.j, bkr.this.l, bkr.this.m, 80, bkr.this.m - 32, 38);
      }

      protected int b() {
         return bkr.f.size();
      }

      protected void a(int var1, boolean var2, int var3, int var4) {
         this.u = var1;
         bkr.this.a();
         bkr.this.i.a(((bkr.a)bkr.f.get(bkr.this.g.u)).c.toString());
      }

      protected boolean a(int var1) {
         return var1 == this.u;
      }

      protected void a() {
      }

      private void a(int var1, int var2, nd var3) {
         int var4 = var1 + 5;
         bkr.this.a(var4 - 1, var4 + 32, var2 - 1, -2039584);
         bkr.this.a(var4 - 1, var4 + 32, var2 + 32, -6250336);
         bkr.this.b(var4 - 1, var2 - 1, var2 + 32, -2039584);
         bkr.this.b(var4 + 32, var2 - 1, var2 + 32, -6250336);
         buq.c(1.0F, 1.0F, 1.0F, 1.0F);
         this.a.N().a(var3);
         int var6 = true;
         int var7 = true;
         bvc var8 = bvc.a();
         bui var9 = var8.c();
         var9.a(7, cdw.g);
         var9.b((double)(var4 + 0), (double)(var2 + 32), 0.0D).a(0.0D, 1.0D).d();
         var9.b((double)(var4 + 32), (double)(var2 + 32), 0.0D).a(1.0D, 1.0D).d();
         var9.b((double)(var4 + 32), (double)(var2 + 0), 0.0D).a(1.0D, 0.0D).d();
         var9.b((double)(var4 + 0), (double)(var2 + 0), 0.0D).a(0.0D, 0.0D).d();
         var8.b();
      }

      protected void a(int var1, int var2, int var3, int var4, int var5, int var6, float var7) {
         bkr.a var8 = (bkr.a)bkr.f.get(var1);
         this.a(var2, var3, var8.b);
         bkr.this.q.a(var8.a, var2 + 32 + 10, var3 + 14, 16777215);
      }
   }
}
