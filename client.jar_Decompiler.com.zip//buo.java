import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.gson.JsonSyntaxException;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.IOException;
import java.nio.FloatBuffer;
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import javax.imageio.ImageIO;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GLContext;
import org.lwjgl.util.glu.Project;

public class buo implements ceo {
   private static final Logger e = LogManager.getLogger();
   private static final nd f = new nd("textures/environment/rain.png");
   private static final nd g = new nd("textures/environment/snow.png");
   public static boolean a;
   public static int b;
   private final bhz h;
   private final cen i;
   private final Random j = new Random();
   private float k;
   public final bus c;
   private final biq l;
   private int m;
   private ve n;
   private final rl o = new rl();
   private final rl p = new rl();
   private final float q = 4.0F;
   private float r = 4.0F;
   private float s;
   private float t;
   private float u;
   private float v;
   private float w;
   private float x;
   private float y;
   private float z;
   private float A;
   private boolean B;
   private boolean C = true;
   private boolean D = true;
   private long E;
   private long F = bhz.I();
   private long G;
   private final cde H;
   private final int[] I;
   private final nd J;
   private boolean K;
   private float L;
   private float M;
   private int N;
   private final float[] O = new float[1024];
   private final float[] P = new float[1024];
   private final FloatBuffer Q = bhy.h(16);
   private float R;
   private float S;
   private float T;
   private float U;
   private float V;
   private int W;
   private boolean X;
   private double Y = 1.0D;
   private double Z;
   private double aa;
   private ain ab;
   private int ac;
   private float ad;
   private float ae;
   private ccw af;
   private static final nd[] ag = new nd[]{new nd("shaders/post/notch.json"), new nd("shaders/post/fxaa.json"), new nd("shaders/post/art.json"), new nd("shaders/post/bumpy.json"), new nd("shaders/post/blobs2.json"), new nd("shaders/post/pencil.json"), new nd("shaders/post/color_convolve.json"), new nd("shaders/post/deconverge.json"), new nd("shaders/post/flip.json"), new nd("shaders/post/invert.json"), new nd("shaders/post/ntsc.json"), new nd("shaders/post/outline.json"), new nd("shaders/post/phosphor.json"), new nd("shaders/post/scan_pincushion.json"), new nd("shaders/post/sobel.json"), new nd("shaders/post/bits.json"), new nd("shaders/post/desaturate.json"), new nd("shaders/post/green.json"), new nd("shaders/post/blur.json"), new nd("shaders/post/wobble.json"), new nd("shaders/post/blobs.json"), new nd("shaders/post/antialias.json"), new nd("shaders/post/creeper.json"), new nd("shaders/post/spider.json")};
   public static final int d;
   private int ah;
   private boolean ai;
   private int aj;

   public buo(bhz var1, cen var2) {
      this.ah = d;
      this.h = var1;
      this.i = var2;
      this.c = var1.ae();
      this.l = new biq(var1.N());
      this.H = new cde(16, 16);
      this.J = var1.N().a("lightMap", this.H);
      this.I = this.H.e();
      this.af = null;

      for(int var3 = 0; var3 < 32; ++var3) {
         for(int var4 = 0; var4 < 32; ++var4) {
            float var5 = (float)(var4 - 16);
            float var6 = (float)(var3 - 16);
            float var7 = ri.c(var5 * var5 + var6 * var6);
            this.O[var3 << 5 | var4] = -var6 / var7;
            this.P[var3 << 5 | var4] = var5 / var7;
         }
      }

   }

   public boolean a() {
      return cig.O && this.af != null;
   }

   public void b() {
      if (this.af != null) {
         this.af.a();
      }

      this.af = null;
      this.ah = d;
   }

   public void c() {
      this.ai = !this.ai;
   }

   public void a(@Nullable ve var1) {
      if (cig.O) {
         if (this.af != null) {
            this.af.a();
         }

         this.af = null;
         if (var1 instanceof acq) {
            this.a(new nd("shaders/post/creeper.json"));
         } else if (var1 instanceof adl) {
            this.a(new nd("shaders/post/spider.json"));
         } else if (var1 instanceof acs) {
            this.a(new nd("shaders/post/invert.json"));
         }

      }
   }

   private void a(nd var1) {
      try {
         this.af = new ccw(this.h.N(), this.i, this.h.b(), var1);
         this.af.a(this.h.d, this.h.e);
         this.ai = true;
      } catch (IOException var3) {
         e.warn("Failed to load shader: {}", var1, var3);
         this.ah = d;
         this.ai = false;
      } catch (JsonSyntaxException var4) {
         e.warn("Failed to load shader: {}", var1, var4);
         this.ah = d;
         this.ai = false;
      }

   }

   public void a(cen var1) {
      if (this.af != null) {
         this.af.a();
      }

      this.af = null;
      if (this.ah == d) {
         this.a(this.h.aa());
      } else {
         this.a(ag[this.ah]);
      }

   }

   public void e() {
      if (cig.O && ccz.b() == null) {
         ccz.a();
      }

      this.m();
      this.n();
      this.U = this.V;
      this.r = 4.0F;
      float var1;
      float var2;
      if (this.h.t.aB) {
         var1 = this.h.t.c * 0.6F + 0.2F;
         var2 = var1 * var1 * var1 * 8.0F;
         this.u = this.o.a(this.s, 0.05F * var2);
         this.v = this.p.a(this.t, 0.05F * var2);
         this.w = 0.0F;
         this.s = 0.0F;
         this.t = 0.0F;
      } else {
         this.u = 0.0F;
         this.v = 0.0F;
         this.o.a();
         this.p.a();
      }

      if (this.h.aa() == null) {
         this.h.a((ve)this.h.h);
      }

      var1 = this.h.f.n(new et(this.h.aa()));
      var2 = (float)this.h.t.e / 32.0F;
      float var3 = var1 * (1.0F - var2) + var2;
      this.V += (var3 - this.V) * 0.1F;
      ++this.m;
      this.c.a();
      this.q();
      this.A = this.z;
      if (this.h.q.j().e()) {
         this.z += 0.05F;
         if (this.z > 1.0F) {
            this.z = 1.0F;
         }
      } else if (this.z > 0.0F) {
         this.z -= 0.0125F;
      }

      if (this.ac > 0) {
         --this.ac;
         if (this.ac == 0) {
            this.ab = null;
         }
      }

   }

   public ccw f() {
      return this.af;
   }

   public void a(int var1, int var2) {
      if (cig.O) {
         if (this.af != null) {
            this.af.a(var1, var2);
         }

         this.h.g.a(var1, var2);
      }
   }

   public void a(float var1) {
      ve var2 = this.h.aa();
      if (var2 != null) {
         if (this.h.f != null) {
            this.h.B.a("pick");
            this.h.i = null;
            double var3 = (double)this.h.c.d();
            this.h.s = var2.a(var3, var1);
            bhc var5 = var2.f(var1);
            boolean var6 = false;
            int var7 = true;
            double var8 = var3;
            if (this.h.c.i()) {
               var8 = 6.0D;
               var3 = var8;
            } else {
               if (var3 > 3.0D) {
                  var6 = true;
               }

               var3 = var3;
            }

            if (this.h.s != null) {
               var8 = this.h.s.c.f(var5);
            }

            bhc var10 = var2.e(1.0F);
            bhc var11 = var5.b(var10.b * var3, var10.c * var3, var10.d * var3);
            this.n = null;
            bhc var12 = null;
            float var13 = 1.0F;
            List<ve> var14 = this.h.f.a(var2, var2.bw().b(var10.b * var3, var10.c * var3, var10.d * var3).c(1.0D, 1.0D, 1.0D), Predicates.and(vi.e, new Predicate<ve>() {
               public boolean a(@Nullable ve var1) {
                  return var1 != null && var1.ay();
               }

               // $FF: synthetic method
               public boolean apply(@Nullable Object var1) {
                  return this.a((ve)var1);
               }
            }));
            double var15 = var8;

            for(int var17 = 0; var17 < var14.size(); ++var17) {
               ve var18 = (ve)var14.get(var17);
               bgz var19 = var18.bw().g((double)var18.aI());
               bha var20 = var19.b(var5, var11);
               if (var19.b(var5)) {
                  if (var15 >= 0.0D) {
                     this.n = var18;
                     var12 = var20 == null ? var5 : var20.c;
                     var15 = 0.0D;
                  }
               } else if (var20 != null) {
                  double var21 = var5.f(var20.c);
                  if (var21 < var15 || var15 == 0.0D) {
                     if (var18.bH() == var2.bH()) {
                        if (var15 == 0.0D) {
                           this.n = var18;
                           var12 = var20.c;
                        }
                     } else {
                        this.n = var18;
                        var12 = var20.c;
                        var15 = var21;
                     }
                  }
               }
            }

            if (this.n != null && var6 && var5.f(var12) > 3.0D) {
               this.n = null;
               this.h.s = new bha(bha.a.a, var12, (fa)null, new et(var12));
            }

            if (this.n != null && (var15 < var8 || this.h.s == null)) {
               this.h.s = new bha(this.n, var12);
               if (this.n instanceof vn || this.n instanceof abz) {
                  this.h.i = this.n;
               }
            }

            this.h.B.b();
         }
      }
   }

   private void m() {
      float var1 = 1.0F;
      if (this.h.aa() instanceof bty) {
         bty var2 = (bty)this.h.aa();
         var1 = var2.u();
      }

      this.y = this.x;
      this.x += (var1 - this.x) * 0.5F;
      if (this.x > 1.5F) {
         this.x = 1.5F;
      }

      if (this.x < 0.1F) {
         this.x = 0.1F;
      }

   }

   private float a(float var1, boolean var2) {
      if (this.X) {
         return 90.0F;
      } else {
         ve var3 = this.h.aa();
         float var4 = 70.0F;
         if (var2) {
            var4 = this.h.t.aD;
            var4 *= this.y + (this.x - this.y) * var1;
         }

         if (var3 instanceof vn && ((vn)var3).cd() <= 0.0F) {
            float var5 = (float)((vn)var3).aB + var1;
            var4 /= (1.0F - 500.0F / (var5 + 500.0F)) * 2.0F + 1.0F;
         }

         awr var6 = bht.a(this.h.f, var3, var1);
         if (var6.a() == bcx.h) {
            var4 = var4 * 60.0F / 70.0F;
         }

         return var4;
      }
   }

   private void d(float var1) {
      if (this.h.aa() instanceof vn) {
         vn var2 = (vn)this.h.aa();
         float var3 = (float)var2.ay - var1;
         float var4;
         if (var2.cd() <= 0.0F) {
            var4 = (float)var2.aB + var1;
            buq.b(40.0F - 8000.0F / (var4 + 200.0F), 0.0F, 0.0F, 1.0F);
         }

         if (var3 < 0.0F) {
            return;
         }

         var3 /= (float)var2.az;
         var3 = ri.a(var3 * var3 * var3 * var3 * 3.1415927F);
         var4 = var2.aA;
         buq.b(-var4, 0.0F, 1.0F, 0.0F);
         buq.b(-var3 * 14.0F, 0.0F, 0.0F, 1.0F);
         buq.b(var4, 0.0F, 1.0F, 0.0F);
      }

   }

   private void e(float var1) {
      if (this.h.aa() instanceof aeb) {
         aeb var2 = (aeb)this.h.aa();
         float var3 = var2.J - var2.I;
         float var4 = -(var2.J + var3 * var1);
         float var5 = var2.bB + (var2.bC - var2.bB) * var1;
         float var6 = var2.aJ + (var2.aK - var2.aJ) * var1;
         buq.c(ri.a(var4 * 3.1415927F) * var5 * 0.5F, -Math.abs(ri.b(var4 * 3.1415927F) * var5), 0.0F);
         buq.b(ri.a(var4 * 3.1415927F) * var5 * 3.0F, 0.0F, 0.0F, 1.0F);
         buq.b(Math.abs(ri.b(var4 * 3.1415927F - 0.2F) * var5) * 5.0F, 1.0F, 0.0F, 0.0F);
         buq.b(var6, 1.0F, 0.0F, 0.0F);
      }
   }

   private void f(float var1) {
      ve var2 = this.h.aa();
      float var3 = var2.by();
      double var4 = var2.m + (var2.p - var2.m) * (double)var1;
      double var6 = var2.n + (var2.q - var2.n) * (double)var1 + (double)var3;
      double var8 = var2.o + (var2.r - var2.o) * (double)var1;
      if (var2 instanceof vn && ((vn)var2).cz()) {
         var3 = (float)((double)var3 + 1.0D);
         buq.c(0.0F, 0.3F, 0.0F);
         if (!this.h.t.aC) {
            et var27 = new et(var2);
            awr var11 = this.h.f.o(var27);
            aou var29 = var11.u();
            if (var29 == aov.C) {
               int var30 = ((fa)var11.c(aos.D)).b();
               buq.b((float)(var30 * 90), 0.0F, 1.0F, 0.0F);
            }

            buq.b(var2.x + (var2.v - var2.x) * var1 + 180.0F, 0.0F, -1.0F, 0.0F);
            buq.b(var2.y + (var2.w - var2.y) * var1, -1.0F, 0.0F, 0.0F);
         }
      } else if (this.h.t.aw > 0) {
         double var10 = (double)(this.r + (4.0F - this.r) * var1);
         if (this.h.t.aC) {
            buq.c(0.0F, 0.0F, (float)(-var10));
         } else {
            float var12 = var2.v;
            float var13 = var2.w;
            if (this.h.t.aw == 2) {
               var13 += 180.0F;
            }

            double var14 = (double)(-ri.a(var12 * 0.017453292F) * ri.b(var13 * 0.017453292F)) * var10;
            double var16 = (double)(ri.b(var12 * 0.017453292F) * ri.b(var13 * 0.017453292F)) * var10;
            double var18 = (double)(-ri.a(var13 * 0.017453292F)) * var10;

            for(int var20 = 0; var20 < 8; ++var20) {
               float var21 = (float)((var20 & 1) * 2 - 1);
               float var22 = (float)((var20 >> 1 & 1) * 2 - 1);
               float var23 = (float)((var20 >> 2 & 1) * 2 - 1);
               var21 *= 0.1F;
               var22 *= 0.1F;
               var23 *= 0.1F;
               bha var24 = this.h.f.a(new bhc(var4 + (double)var21, var6 + (double)var22, var8 + (double)var23), new bhc(var4 - var14 + (double)var21 + (double)var23, var6 - var18 + (double)var22, var8 - var16 + (double)var23));
               if (var24 != null) {
                  double var25 = var24.c.f(new bhc(var4, var6, var8));
                  if (var25 < var10) {
                     var10 = var25;
                  }
               }
            }

            if (this.h.t.aw == 2) {
               buq.b(180.0F, 0.0F, 1.0F, 0.0F);
            }

            buq.b(var2.w - var13, 1.0F, 0.0F, 0.0F);
            buq.b(var2.v - var12, 0.0F, 1.0F, 0.0F);
            buq.c(0.0F, 0.0F, (float)(-var10));
            buq.b(var12 - var2.v, 0.0F, 1.0F, 0.0F);
            buq.b(var13 - var2.w, 1.0F, 0.0F, 0.0F);
         }
      } else {
         buq.c(0.0F, 0.0F, 0.05F);
      }

      if (!this.h.t.aC) {
         buq.b(var2.y + (var2.w - var2.y) * var1, 1.0F, 0.0F, 0.0F);
         if (var2 instanceof zt) {
            zt var28 = (zt)var2;
            buq.b(var28.aQ + (var28.aP - var28.aQ) * var1 + 180.0F, 0.0F, 1.0F, 0.0F);
         } else {
            buq.b(var2.x + (var2.v - var2.x) * var1 + 180.0F, 0.0F, 1.0F, 0.0F);
         }
      }

      buq.c(0.0F, -var3, 0.0F);
      var4 = var2.m + (var2.p - var2.m) * (double)var1;
      var6 = var2.n + (var2.q - var2.n) * (double)var1 + (double)var3;
      var8 = var2.o + (var2.r - var2.o) * (double)var1;
      this.B = this.h.g.a(var4, var6, var8, var1);
   }

   private void a(float var1, int var2) {
      this.k = (float)(this.h.t.e * 16);
      buq.n(5889);
      buq.F();
      float var3 = 0.07F;
      if (this.h.t.g) {
         buq.c((float)(-(var2 * 2 - 1)) * 0.07F, 0.0F, 0.0F);
      }

      if (this.Y != 1.0D) {
         buq.c((float)this.Z, (float)(-this.aa), 0.0F);
         buq.a(this.Y, this.Y, 1.0D);
      }

      Project.gluPerspective(this.a(var1, true), (float)this.h.d / (float)this.h.e, 0.05F, this.k * ri.a);
      buq.n(5888);
      buq.F();
      if (this.h.t.g) {
         buq.c((float)(var2 * 2 - 1) * 0.1F, 0.0F, 0.0F);
      }

      this.d(var1);
      if (this.h.t.f) {
         this.e(var1);
      }

      float var4 = this.h.h.ca + (this.h.h.bZ - this.h.h.ca) * var1;
      if (var4 > 0.0F) {
         int var5 = 20;
         if (this.h.h.a((ux)uz.i)) {
            var5 = 7;
         }

         float var6 = 5.0F / (var4 * var4 + 5.0F) - var4 * 0.04F;
         var6 *= var6;
         buq.b(((float)this.m + var1) * (float)var5, 0.0F, 1.0F, 1.0F);
         buq.b(1.0F / var6, 1.0F, 1.0F);
         buq.b(-((float)this.m + var1) * (float)var5, 0.0F, 1.0F, 1.0F);
      }

      this.f(var1);
      if (this.X) {
         switch(this.W) {
         case 0:
            buq.b(90.0F, 0.0F, 1.0F, 0.0F);
            break;
         case 1:
            buq.b(180.0F, 0.0F, 1.0F, 0.0F);
            break;
         case 2:
            buq.b(-90.0F, 0.0F, 1.0F, 0.0F);
            break;
         case 3:
            buq.b(90.0F, 1.0F, 0.0F, 0.0F);
            break;
         case 4:
            buq.b(-90.0F, 1.0F, 0.0F, 0.0F);
         }
      }

   }

   private void b(float var1, int var2) {
      if (!this.X) {
         buq.n(5889);
         buq.F();
         float var3 = 0.07F;
         if (this.h.t.g) {
            buq.c((float)(-(var2 * 2 - 1)) * 0.07F, 0.0F, 0.0F);
         }

         Project.gluPerspective(this.a(var1, false), (float)this.h.d / (float)this.h.e, 0.05F, this.k * 2.0F);
         buq.n(5888);
         buq.F();
         if (this.h.t.g) {
            buq.c((float)(var2 * 2 - 1) * 0.1F, 0.0F, 0.0F);
         }

         buq.G();
         this.d(var1);
         if (this.h.t.f) {
            this.e(var1);
         }

         boolean var4 = this.h.aa() instanceof vn && ((vn)this.h.aa()).cz();
         if (this.h.t.aw == 0 && !var4 && !this.h.t.av && !this.h.c.a()) {
            this.i();
            this.c.a(var1);
            this.h();
         }

         buq.H();
         if (this.h.t.aw == 0 && !var4) {
            this.c.b(var1);
            this.d(var1);
         }

         if (this.h.t.f) {
            this.e(var1);
         }

      }
   }

   public void h() {
      buq.g(cig.r);
      buq.z();
      buq.g(cig.q);
   }

   public void i() {
      buq.g(cig.r);
      buq.n(5890);
      buq.F();
      float var1 = 0.00390625F;
      buq.b(0.00390625F, 0.00390625F, 0.00390625F);
      buq.c(8.0F, 8.0F, 8.0F);
      buq.n(5888);
      this.h.N().a(this.J);
      buq.b(3553, 10241, 9729);
      buq.b(3553, 10240, 9729);
      buq.b(3553, 10242, 10496);
      buq.b(3553, 10243, 10496);
      buq.c(1.0F, 1.0F, 1.0F, 1.0F);
      buq.y();
      buq.g(cig.q);
   }

   private void n() {
      this.M = (float)((double)this.M + (Math.random() - Math.random()) * Math.random() * Math.random());
      this.M = (float)((double)this.M * 0.9D);
      this.L += this.M - this.L;
      this.K = true;
   }

   private void g(float var1) {
      if (this.K) {
         this.h.B.a("lightTex");
         ams var2 = this.h.f;
         if (var2 != null) {
            float var3 = var2.b(1.0F);
            float var4 = var3 * 0.95F + 0.05F;

            for(int var5 = 0; var5 < 256; ++var5) {
               float var6 = var2.s.o()[var5 / 16] * var4;
               float var7 = var2.s.o()[var5 % 16] * (this.L * 0.1F + 1.5F);
               if (var2.ai() > 0) {
                  var6 = var2.s.o()[var5 / 16];
               }

               float var8 = var6 * (var3 * 0.65F + 0.35F);
               float var9 = var6 * (var3 * 0.65F + 0.35F);
               float var12 = var7 * ((var7 * 0.6F + 0.4F) * 0.6F + 0.4F);
               float var13 = var7 * (var7 * var7 * 0.6F + 0.4F);
               float var14 = var8 + var7;
               float var15 = var9 + var12;
               float var16 = var6 + var13;
               var14 = var14 * 0.96F + 0.03F;
               var15 = var15 * 0.96F + 0.03F;
               var16 = var16 * 0.96F + 0.03F;
               float var17;
               if (this.z > 0.0F) {
                  var17 = this.A + (this.z - this.A) * var1;
                  var14 = var14 * (1.0F - var17) + var14 * 0.7F * var17;
                  var15 = var15 * (1.0F - var17) + var15 * 0.6F * var17;
                  var16 = var16 * (1.0F - var17) + var16 * 0.6F * var17;
               }

               if (var2.s.q().a() == 1) {
                  var14 = 0.22F + var7 * 0.75F;
                  var15 = 0.28F + var12 * 0.75F;
                  var16 = 0.25F + var13 * 0.75F;
               }

               float var18;
               if (this.h.h.a((ux)uz.p)) {
                  var17 = this.a(this.h.h, var1);
                  var18 = 1.0F / var14;
                  if (var18 > 1.0F / var15) {
                     var18 = 1.0F / var15;
                  }

                  if (var18 > 1.0F / var16) {
                     var18 = 1.0F / var16;
                  }

                  var14 = var14 * (1.0F - var17) + var14 * var18 * var17;
                  var15 = var15 * (1.0F - var17) + var15 * var18 * var17;
                  var16 = var16 * (1.0F - var17) + var16 * var18 * var17;
               }

               if (var14 > 1.0F) {
                  var14 = 1.0F;
               }

               if (var15 > 1.0F) {
                  var15 = 1.0F;
               }

               if (var16 > 1.0F) {
                  var16 = 1.0F;
               }

               var17 = this.h.t.aE;
               var18 = 1.0F - var14;
               float var19 = 1.0F - var15;
               float var20 = 1.0F - var16;
               var18 = 1.0F - var18 * var18 * var18 * var18;
               var19 = 1.0F - var19 * var19 * var19 * var19;
               var20 = 1.0F - var20 * var20 * var20 * var20;
               var14 = var14 * (1.0F - var17) + var18 * var17;
               var15 = var15 * (1.0F - var17) + var19 * var17;
               var16 = var16 * (1.0F - var17) + var20 * var17;
               var14 = var14 * 0.96F + 0.03F;
               var15 = var15 * 0.96F + 0.03F;
               var16 = var16 * 0.96F + 0.03F;
               if (var14 > 1.0F) {
                  var14 = 1.0F;
               }

               if (var15 > 1.0F) {
                  var15 = 1.0F;
               }

               if (var16 > 1.0F) {
                  var16 = 1.0F;
               }

               if (var14 < 0.0F) {
                  var14 = 0.0F;
               }

               if (var15 < 0.0F) {
                  var15 = 0.0F;
               }

               if (var16 < 0.0F) {
                  var16 = 0.0F;
               }

               int var21 = true;
               int var22 = (int)(var14 * 255.0F);
               int var23 = (int)(var15 * 255.0F);
               int var24 = (int)(var16 * 255.0F);
               this.I[var5] = -16777216 | var22 << 16 | var23 << 8 | var24;
            }

            this.H.d();
            this.K = false;
            this.h.B.b();
         }
      }
   }

   private float a(vn var1, float var2) {
      int var3 = var1.b(uz.p).b();
      return var3 > 200 ? 1.0F : 0.7F + ri.a(((float)var3 - var2) * 3.1415927F * 0.2F) * 0.3F;
   }

   public void a(float var1, long var2) {
      boolean var4 = Display.isActive();
      if (var4 || !this.h.t.A || this.h.t.B && Mouse.isButtonDown(1)) {
         this.F = bhz.I();
      } else if (bhz.I() - this.F > 500L) {
         this.h.q();
      }

      this.h.B.a("mouse");
      if (var4 && bhz.a && this.h.x && !Mouse.isInsideWindow()) {
         Mouse.setGrabbed(false);
         Mouse.setCursorPosition(Display.getWidth() / 2, Display.getHeight() / 2 - 20);
         Mouse.setGrabbed(true);
      }

      if (this.h.x && var4) {
         this.h.v.c();
         this.h.ap().a(this.h.v);
         float var5 = this.h.t.c * 0.6F + 0.2F;
         float var6 = var5 * var5 * var5 * 8.0F;
         float var7 = (float)this.h.v.a * var6;
         float var8 = (float)this.h.v.b * var6;
         int var9 = 1;
         if (this.h.t.d) {
            var9 = -1;
         }

         if (this.h.t.aB) {
            this.s += var7;
            this.t += var8;
            float var10 = var1 - this.w;
            this.w = var1;
            var7 = this.u * var10;
            var8 = this.v * var10;
            this.h.h.c(var7, var8 * (float)var9);
         } else {
            this.s = 0.0F;
            this.t = 0.0F;
            this.h.h.c(var7, var8 * (float)var9);
         }
      }

      this.h.B.b();
      if (!this.h.r) {
         a = this.h.t.g;
         final bir var17 = new bir(this.h);
         int var18 = var17.a();
         int var19 = var17.b();
         final int var20 = Mouse.getX() * var18 / this.h.d;
         final int var21 = var19 - Mouse.getY() * var19 / this.h.e - 1;
         int var22 = this.h.t.i;
         if (this.h.f != null) {
            this.h.B.a("level");
            int var11 = Math.min(bhz.af(), var22);
            var11 = Math.max(var11, 60);
            long var12 = System.nanoTime() - var2;
            long var14 = Math.max((long)(1000000000 / var11 / 4) - var12, 0L);
            this.b(var1, System.nanoTime() + var14);
            if (this.h.E() && this.E < bhz.I() - 1000L) {
               this.E = bhz.I();
               if (!this.h.F().y()) {
                  this.o();
               }
            }

            if (cig.O) {
               this.h.g.c();
               if (this.af != null && this.ai) {
                  buq.n(5890);
                  buq.G();
                  buq.F();
                  this.af.a(var1);
                  buq.H();
               }

               this.h.b().a(true);
            }

            this.G = System.nanoTime();
            this.h.B.c("gui");
            if (!this.h.t.av || this.h.m != null) {
               buq.a(516, 0.1F);
               this.j();
               this.a(var18, var19, var1);
               this.h.q.a(var1);
            }

            this.h.B.b();
         } else {
            buq.b(0, 0, this.h.d, this.h.e);
            buq.n(5889);
            buq.F();
            buq.n(5888);
            buq.F();
            this.j();
            this.G = System.nanoTime();
         }

         if (this.h.m != null) {
            buq.m(256);

            try {
               this.h.m.a(var20, var21, this.h.ak());
            } catch (Throwable var16) {
               b var23 = b.a(var16, "Rendering screen");
               c var13 = var23.a("Screen render details");
               var13.a("Screen name", new d<String>() {
                  public String a() throws Exception {
                     return buo.this.h.m.getClass().getCanonicalName();
                  }

                  // $FF: synthetic method
                  public Object call() throws Exception {
                     return this.a();
                  }
               });
               var13.a("Mouse location", new d<String>() {
                  public String a() throws Exception {
                     return String.format("Scaled: (%d, %d). Absolute: (%d, %d)", var20, var21, Mouse.getX(), Mouse.getY());
                  }

                  // $FF: synthetic method
                  public Object call() throws Exception {
                     return this.a();
                  }
               });
               var13.a("Screen size", new d<String>() {
                  public String a() throws Exception {
                     return String.format("Scaled: (%d, %d). Absolute: (%d, %d). Scale factor of %d", var17.a(), var17.b(), buo.this.h.d, buo.this.h.e, var17.e());
                  }

                  // $FF: synthetic method
                  public Object call() throws Exception {
                     return this.a();
                  }
               });
               throw new f(var23);
            }
         }

      }
   }

   private void o() {
      if (this.h.g.g() > 10 && this.h.g.n() && !this.h.F().y()) {
         BufferedImage var1 = bid.a(this.h.d, this.h.e, this.h.b());
         int var2 = var1.getWidth();
         int var3 = var1.getHeight();
         int var4 = 0;
         int var5 = 0;
         if (var2 > var3) {
            var4 = (var2 - var3) / 2;
            var2 = var3;
         } else {
            var5 = (var3 - var2) / 2;
         }

         try {
            BufferedImage var6 = new BufferedImage(64, 64, 1);
            Graphics var7 = var6.createGraphics();
            var7.drawImage(var1, 0, 0, 64, 64, var4, var5, var4 + var2, var5 + var2, (ImageObserver)null);
            var7.dispose();
            ImageIO.write(var6, "png", this.h.F().z());
         } catch (IOException var8) {
            e.warn("Couldn't save auto screenshot", var8);
         }
      }

   }

   public void b(float var1) {
      this.j();
   }

   private boolean p() {
      if (!this.D) {
         return false;
      } else {
         ve var1 = this.h.aa();
         boolean var2 = var1 instanceof aeb && !this.h.t.av;
         if (var2 && !((aeb)var1).bO.e) {
            ain var3 = ((aeb)var1).co();
            if (this.h.s != null && this.h.s.a == bha.a.b) {
               et var4 = this.h.s.a();
               aou var5 = this.h.f.o(var4).u();
               if (this.h.c.l() == amq.e) {
                  var2 = var5.l() && this.h.f.r(var4) instanceof tt;
               } else {
                  var2 = !var3.b() && (var3.a(var5) || var3.b(var5));
               }
            }
         }

         return var2;
      }
   }

   public void b(float var1, long var2) {
      this.g(var1);
      if (this.h.aa() == null) {
         this.h.a((ve)this.h.h);
      }

      this.a(var1);
      buq.k();
      buq.e();
      buq.a(516, 0.5F);
      this.h.B.a("center");
      if (this.h.t.g) {
         b = 0;
         buq.a(false, true, true, false);
         this.a(0, var1, var2);
         b = 1;
         buq.a(true, false, false, false);
         this.a(1, var1, var2);
         buq.a(true, true, true, false);
      } else {
         this.a(2, var1, var2);
      }

      this.h.B.b();
   }

   private void a(int var1, float var2, long var3) {
      buw var5 = this.h.g;
      bte var6 = this.h.j;
      boolean var7 = this.p();
      buq.q();
      this.h.B.c("clear");
      buq.b(0, 0, this.h.d, this.h.e);
      this.h(var2);
      buq.m(16640);
      this.h.B.c("camera");
      this.a(var2, var1);
      bht.a(this.h.h, this.h.t.aw == 2);
      this.h.B.c("frustum");
      bxx.a();
      this.h.B.c("culling");
      bxw var8 = new bxy();
      ve var9 = this.h.aa();
      double var10 = var9.M + (var9.p - var9.M) * (double)var2;
      double var12 = var9.N + (var9.q - var9.N) * (double)var2;
      double var14 = var9.O + (var9.r - var9.O) * (double)var2;
      var8.a(var10, var12, var14);
      if (this.h.t.e >= 4) {
         this.a(-1, var2);
         this.h.B.c("sky");
         buq.n(5889);
         buq.F();
         Project.gluPerspective(this.a(var2, true), (float)this.h.d / (float)this.h.e, 0.05F, this.k * 2.0F);
         buq.n(5888);
         var5.a(var2, var1);
         buq.n(5889);
         buq.F();
         Project.gluPerspective(this.a(var2, true), (float)this.h.d / (float)this.h.e, 0.05F, this.k * ri.a);
         buq.n(5888);
      }

      this.a(0, var2);
      buq.j(7425);
      if (var9.q + (double)var9.by() < 128.0D) {
         this.a(var5, var2, var1, var10, var12, var14);
      }

      this.h.B.c("prepareterrain");
      this.a(0, var2);
      this.h.N().a(cdn.g);
      bhx.a();
      this.h.B.c("terrain_setup");
      var5.a(var9, (double)var2, var8, this.aj++, this.h.h.y());
      if (var1 == 0 || var1 == 2) {
         this.h.B.c("updatechunks");
         this.h.g.a(var3);
      }

      this.h.B.c("terrain");
      buq.n(5888);
      buq.G();
      buq.d();
      var5.a(amk.a, (double)var2, var1, var9);
      buq.e();
      var5.a(amk.b, (double)var2, var1, var9);
      this.h.N().b(cdn.g).b(false, false);
      var5.a(amk.c, (double)var2, var1, var9);
      this.h.N().b(cdn.g).a();
      buq.j(7424);
      buq.a(516, 0.1F);
      if (!this.X) {
         buq.n(5888);
         buq.H();
         buq.G();
         bhx.b();
         this.h.B.c("entities");
         var5.a(var9, var8, var2);
         bhx.a();
         this.h();
      }

      buq.n(5888);
      buq.H();
      if (var7 && this.h.s != null && !var9.a(bcx.h)) {
         aeb var16 = (aeb)var9;
         buq.d();
         this.h.B.c("outline");
         var5.a(var16, this.h.s, 0, var2);
         buq.e();
      }

      if (this.h.p.a()) {
         this.h.p.a(var2, var3);
      }

      this.h.B.c("destroyProgress");
      buq.m();
      buq.a(buq.r.l, buq.l.e, buq.r.e, buq.l.n);
      this.h.N().b(cdn.g).b(false, false);
      var5.a(bvc.a(), bvc.a().c(), var9, var2);
      this.h.N().b(cdn.g).a();
      buq.l();
      if (!this.X) {
         this.i();
         this.h.B.c("litParticles");
         var6.b(var9, var2);
         bhx.a();
         this.a(0, var2);
         this.h.B.c("particles");
         var6.a(var9, var2);
         this.h();
      }

      buq.a(false);
      buq.q();
      this.h.B.c("weather");
      this.c(var2);
      buq.a(true);
      var5.a(var9, var2);
      buq.l();
      buq.q();
      buq.a(buq.r.l, buq.l.j, buq.r.e, buq.l.n);
      buq.a(516, 0.1F);
      this.a(0, var2);
      buq.m();
      buq.a(false);
      this.h.N().a(cdn.g);
      buq.j(7425);
      this.h.B.c("translucent");
      var5.a(amk.d, (double)var2, var1, var9);
      buq.j(7424);
      buq.a(true);
      buq.q();
      buq.l();
      buq.p();
      if (var9.q + (double)var9.by() >= 128.0D) {
         this.h.B.c("aboveClouds");
         this.a(var5, var2, var1, var10, var12, var14);
      }

      this.h.B.c("hand");
      if (this.C) {
         buq.m(256);
         this.b(var2, var1);
      }

   }

   private void a(buw var1, float var2, int var3, double var4, double var6, double var8) {
      if (this.h.t.e() != 0) {
         this.h.B.c("clouds");
         buq.n(5889);
         buq.F();
         Project.gluPerspective(this.a(var2, true), (float)this.h.d / (float)this.h.e, 0.05F, this.k * 4.0F);
         buq.n(5888);
         buq.G();
         this.a(0, var2);
         var1.a(var2, var3, var4, var6, var8);
         buq.p();
         buq.H();
         buq.n(5889);
         buq.F();
         Project.gluPerspective(this.a(var2, true), (float)this.h.d / (float)this.h.e, 0.05F, this.k * ri.a);
         buq.n(5888);
      }

   }

   private void q() {
      float var1 = this.h.f.j(1.0F);
      if (!this.h.t.k) {
         var1 /= 2.0F;
      }

      if (var1 != 0.0F) {
         this.j.setSeed((long)this.m * 312987231L);
         ve var2 = this.h.aa();
         ams var3 = this.h.f;
         et var4 = new et(var2);
         int var5 = true;
         double var6 = 0.0D;
         double var8 = 0.0D;
         double var10 = 0.0D;
         int var12 = 0;
         int var13 = (int)(100.0F * var1 * var1);
         if (this.h.t.aH == 1) {
            var13 >>= 1;
         } else if (this.h.t.aH == 2) {
            var13 = 0;
         }

         for(int var14 = 0; var14 < var13; ++var14) {
            et var15 = var3.p(var4.a(this.j.nextInt(10) - this.j.nextInt(10), 0, this.j.nextInt(10) - this.j.nextInt(10)));
            anf var16 = var3.b(var15);
            et var17 = var15.b();
            awr var18 = var3.o(var17);
            if (var15.q() <= var4.q() + 10 && var15.q() >= var4.q() - 10 && var16.d() && var16.a(var15) >= 0.15F) {
               double var19 = this.j.nextDouble();
               double var21 = this.j.nextDouble();
               bgz var23 = var18.e(var3, var17);
               if (var18.a() != bcx.i && var18.u() != aov.df) {
                  if (var18.a() != bcx.a) {
                     ++var12;
                     if (this.j.nextInt(var12) == 0) {
                        var6 = (double)var17.p() + var19;
                        var8 = (double)((float)var17.q() + 0.1F) + var23.e - 1.0D;
                        var10 = (double)var17.r() + var21;
                     }

                     this.h.f.a(fj.N, (double)var17.p() + var19, (double)((float)var17.q() + 0.1F) + var23.e, (double)var17.r() + var21, 0.0D, 0.0D, 0.0D, new int[0]);
                  }
               } else {
                  this.h.f.a(fj.l, (double)var15.p() + var19, (double)((float)var15.q() + 0.1F) - var23.b, (double)var15.r() + var21, 0.0D, 0.0D, 0.0D, new int[0]);
               }
            }
         }

         if (var12 > 0 && this.j.nextInt(3) < this.N++) {
            this.N = 0;
            if (var8 > (double)(var4.q() + 1) && var3.p(var4).q() > ri.d((float)var4.q())) {
               this.h.f.a(var6, var8, var10, qd.iw, qe.d, 0.1F, 0.5F, false);
            } else {
               this.h.f.a(var6, var8, var10, qd.iv, qe.d, 0.2F, 1.0F, false);
            }
         }

      }
   }

   protected void c(float var1) {
      float var2 = this.h.f.j(var1);
      if (!(var2 <= 0.0F)) {
         this.i();
         ve var3 = this.h.aa();
         ams var4 = this.h.f;
         int var5 = ri.c(var3.p);
         int var6 = ri.c(var3.q);
         int var7 = ri.c(var3.r);
         bvc var8 = bvc.a();
         bui var9 = var8.c();
         buq.r();
         buq.a(0.0F, 1.0F, 0.0F);
         buq.m();
         buq.a(buq.r.l, buq.l.j, buq.r.e, buq.l.n);
         buq.a(516, 0.1F);
         double var10 = var3.M + (var3.p - var3.M) * (double)var1;
         double var12 = var3.N + (var3.q - var3.N) * (double)var1;
         double var14 = var3.O + (var3.r - var3.O) * (double)var1;
         int var16 = ri.c(var12);
         int var17 = 5;
         if (this.h.t.k) {
            var17 = 10;
         }

         int var18 = -1;
         float var19 = (float)this.m + var1;
         var9.c(-var10, -var12, -var14);
         buq.c(1.0F, 1.0F, 1.0F, 1.0F);
         et.a var20 = new et.a();

         for(int var21 = var7 - var17; var21 <= var7 + var17; ++var21) {
            for(int var22 = var5 - var17; var22 <= var5 + var17; ++var22) {
               int var23 = (var21 - var7 + 16) * 32 + var22 - var5 + 16;
               double var24 = (double)this.O[var23] * 0.5D;
               double var26 = (double)this.P[var23] * 0.5D;
               var20.c(var22, 0, var21);
               anf var28 = var4.b((et)var20);
               if (var28.d() || var28.c()) {
                  int var29 = var4.p(var20).q();
                  int var30 = var6 - var17;
                  int var31 = var6 + var17;
                  if (var30 < var29) {
                     var30 = var29;
                  }

                  if (var31 < var29) {
                     var31 = var29;
                  }

                  int var32 = var29;
                  if (var29 < var16) {
                     var32 = var16;
                  }

                  if (var30 != var31) {
                     this.j.setSeed((long)(var22 * var22 * 3121 + var22 * 45238971 ^ var21 * var21 * 418711 + var21 * 13761));
                     var20.c(var22, var30, var21);
                     float var33 = var28.a((et)var20);
                     double var34;
                     double var36;
                     double var38;
                     if (var4.C().a(var33, var29) >= 0.15F) {
                        if (var18 != 0) {
                           if (var18 >= 0) {
                              var8.b();
                           }

                           var18 = 0;
                           this.h.N().a(f);
                           var9.a(7, cdw.d);
                        }

                        var34 = -((double)(this.m + var22 * var22 * 3121 + var22 * 45238971 + var21 * var21 * 418711 + var21 * 13761 & 31) + (double)var1) / 32.0D * (3.0D + this.j.nextDouble());
                        var36 = (double)((float)var22 + 0.5F) - var3.p;
                        var38 = (double)((float)var21 + 0.5F) - var3.r;
                        float var40 = ri.a(var36 * var36 + var38 * var38) / (float)var17;
                        float var41 = ((1.0F - var40 * var40) * 0.5F + 0.5F) * var2;
                        var20.c(var22, var32, var21);
                        int var42 = var4.b(var20, 0);
                        int var43 = var42 >> 16 & '\uffff';
                        int var44 = var42 & '\uffff';
                        var9.b((double)var22 - var24 + 0.5D, (double)var31, (double)var21 - var26 + 0.5D).a(0.0D, (double)var30 * 0.25D + var34).a(1.0F, 1.0F, 1.0F, var41).a(var43, var44).d();
                        var9.b((double)var22 + var24 + 0.5D, (double)var31, (double)var21 + var26 + 0.5D).a(1.0D, (double)var30 * 0.25D + var34).a(1.0F, 1.0F, 1.0F, var41).a(var43, var44).d();
                        var9.b((double)var22 + var24 + 0.5D, (double)var30, (double)var21 + var26 + 0.5D).a(1.0D, (double)var31 * 0.25D + var34).a(1.0F, 1.0F, 1.0F, var41).a(var43, var44).d();
                        var9.b((double)var22 - var24 + 0.5D, (double)var30, (double)var21 - var26 + 0.5D).a(0.0D, (double)var31 * 0.25D + var34).a(1.0F, 1.0F, 1.0F, var41).a(var43, var44).d();
                     } else {
                        if (var18 != 1) {
                           if (var18 >= 0) {
                              var8.b();
                           }

                           var18 = 1;
                           this.h.N().a(g);
                           var9.a(7, cdw.d);
                        }

                        var34 = (double)(-((float)(this.m & 511) + var1) / 512.0F);
                        var36 = this.j.nextDouble() + (double)var19 * 0.01D * (double)((float)this.j.nextGaussian());
                        var38 = this.j.nextDouble() + (double)(var19 * (float)this.j.nextGaussian()) * 0.001D;
                        double var51 = (double)((float)var22 + 0.5F) - var3.p;
                        double var49 = (double)((float)var21 + 0.5F) - var3.r;
                        float var50 = ri.a(var51 * var51 + var49 * var49) / (float)var17;
                        float var45 = ((1.0F - var50 * var50) * 0.3F + 0.5F) * var2;
                        var20.c(var22, var32, var21);
                        int var46 = (var4.b(var20, 0) * 3 + 15728880) / 4;
                        int var47 = var46 >> 16 & '\uffff';
                        int var48 = var46 & '\uffff';
                        var9.b((double)var22 - var24 + 0.5D, (double)var31, (double)var21 - var26 + 0.5D).a(0.0D + var36, (double)var30 * 0.25D + var34 + var38).a(1.0F, 1.0F, 1.0F, var45).a(var47, var48).d();
                        var9.b((double)var22 + var24 + 0.5D, (double)var31, (double)var21 + var26 + 0.5D).a(1.0D + var36, (double)var30 * 0.25D + var34 + var38).a(1.0F, 1.0F, 1.0F, var45).a(var47, var48).d();
                        var9.b((double)var22 + var24 + 0.5D, (double)var30, (double)var21 + var26 + 0.5D).a(1.0D + var36, (double)var31 * 0.25D + var34 + var38).a(1.0F, 1.0F, 1.0F, var45).a(var47, var48).d();
                        var9.b((double)var22 - var24 + 0.5D, (double)var30, (double)var21 - var26 + 0.5D).a(0.0D + var36, (double)var31 * 0.25D + var34 + var38).a(1.0F, 1.0F, 1.0F, var45).a(var47, var48).d();
                     }
                  }
               }
            }
         }

         if (var18 >= 0) {
            var8.b();
         }

         var9.c(0.0D, 0.0D, 0.0D);
         buq.q();
         buq.l();
         buq.a(516, 0.1F);
         this.h();
      }
   }

   public void j() {
      bir var1 = new bir(this.h);
      buq.m(256);
      buq.n(5889);
      buq.F();
      buq.a(0.0D, var1.c(), var1.d(), 0.0D, 1000.0D, 3000.0D);
      buq.n(5888);
      buq.F();
      buq.c(0.0F, 0.0F, -2000.0F);
   }

   private void h(float var1) {
      ams var2 = this.h.f;
      ve var3 = this.h.aa();
      float var4 = 0.25F + 0.75F * (float)this.h.t.e / 32.0F;
      var4 = 1.0F - (float)Math.pow((double)var4, 0.25D);
      bhc var5 = var2.a(this.h.aa(), var1);
      float var6 = (float)var5.b;
      float var7 = (float)var5.c;
      float var8 = (float)var5.d;
      bhc var9 = var2.f(var1);
      this.R = (float)var9.b;
      this.S = (float)var9.c;
      this.T = (float)var9.d;
      float var13;
      if (this.h.t.e >= 4) {
         double var10 = ri.a(var2.d(var1)) > 0.0F ? -1.0D : 1.0D;
         bhc var12 = new bhc(var10, 0.0D, 0.0D);
         var13 = (float)var3.e(var1).b(var12);
         if (var13 < 0.0F) {
            var13 = 0.0F;
         }

         if (var13 > 0.0F) {
            float[] var14 = var2.s.a(var2.c(var1), var1);
            if (var14 != null) {
               var13 *= var14[3];
               this.R = this.R * (1.0F - var13) + var14[0] * var13;
               this.S = this.S * (1.0F - var13) + var14[1] * var13;
               this.T = this.T * (1.0F - var13) + var14[2] * var13;
            }
         }
      }

      this.R += (var6 - this.R) * var4;
      this.S += (var7 - this.S) * var4;
      this.T += (var8 - this.T) * var4;
      float var19 = var2.j(var1);
      float var11;
      float var20;
      if (var19 > 0.0F) {
         var11 = 1.0F - var19 * 0.5F;
         var20 = 1.0F - var19 * 0.4F;
         this.R *= var11;
         this.S *= var11;
         this.T *= var20;
      }

      var11 = var2.h(var1);
      if (var11 > 0.0F) {
         var20 = 1.0F - var11 * 0.5F;
         this.R *= var20;
         this.S *= var20;
         this.T *= var20;
      }

      awr var21 = bht.a(this.h.f, var3, var1);
      if (this.B) {
         bhc var22 = var2.e(var1);
         this.R = (float)var22.b;
         this.S = (float)var22.c;
         this.T = (float)var22.d;
      } else if (var21.a() == bcx.h) {
         var13 = 0.0F;
         if (var3 instanceof vn) {
            var13 = (float)alk.d((vn)var3) * 0.2F;
            if (((vn)var3).a(uz.m)) {
               var13 = var13 * 0.3F + 0.6F;
            }
         }

         this.R = 0.02F + var13;
         this.S = 0.02F + var13;
         this.T = 0.2F + var13;
      } else if (var21.a() == bcx.i) {
         this.R = 0.6F;
         this.S = 0.1F;
         this.T = 0.0F;
      }

      var13 = this.U + (this.V - this.U) * var1;
      this.R *= var13;
      this.S *= var13;
      this.T *= var13;
      double var23 = (var3.N + (var3.q - var3.N) * (double)var1) * var2.s.j();
      if (var3 instanceof vn && ((vn)var3).a(uz.o)) {
         int var16 = ((vn)var3).b(uz.o).b();
         if (var16 < 20) {
            var23 *= (double)(1.0F - (float)var16 / 20.0F);
         } else {
            var23 = 0.0D;
         }
      }

      if (var23 < 1.0D) {
         if (var23 < 0.0D) {
            var23 = 0.0D;
         }

         var23 *= var23;
         this.R = (float)((double)this.R * var23);
         this.S = (float)((double)this.S * var23);
         this.T = (float)((double)this.T * var23);
      }

      float var24;
      if (this.z > 0.0F) {
         var24 = this.A + (this.z - this.A) * var1;
         this.R = this.R * (1.0F - var24) + this.R * 0.7F * var24;
         this.S = this.S * (1.0F - var24) + this.S * 0.6F * var24;
         this.T = this.T * (1.0F - var24) + this.T * 0.6F * var24;
      }

      float var17;
      if (var3 instanceof vn && ((vn)var3).a(uz.p)) {
         var24 = this.a((vn)var3, var1);
         var17 = 1.0F / this.R;
         if (var17 > 1.0F / this.S) {
            var17 = 1.0F / this.S;
         }

         if (var17 > 1.0F / this.T) {
            var17 = 1.0F / this.T;
         }

         this.R = this.R * (1.0F - var24) + this.R * var17 * var24;
         this.S = this.S * (1.0F - var24) + this.S * var17 * var24;
         this.T = this.T * (1.0F - var24) + this.T * var17 * var24;
      }

      if (this.h.t.g) {
         var24 = (this.R * 30.0F + this.S * 59.0F + this.T * 11.0F) / 100.0F;
         var17 = (this.R * 30.0F + this.S * 70.0F) / 100.0F;
         float var18 = (this.R * 30.0F + this.T * 70.0F) / 100.0F;
         this.R = var24;
         this.S = var17;
         this.T = var18;
      }

      buq.a(this.R, this.S, this.T, 0.0F);
   }

   private void a(int var1, float var2) {
      ve var3 = this.h.aa();
      this.d(false);
      buq.a(0.0F, -1.0F, 0.0F);
      buq.c(1.0F, 1.0F, 1.0F, 1.0F);
      awr var4 = bht.a(this.h.f, var3, var2);
      float var5;
      if (var3 instanceof vn && ((vn)var3).a(uz.o)) {
         var5 = 5.0F;
         int var6 = ((vn)var3).b(uz.o).b();
         if (var6 < 20) {
            var5 = 5.0F + (this.k - 5.0F) * (1.0F - (float)var6 / 20.0F);
         }

         buq.a(buq.m.a);
         if (var1 == -1) {
            buq.b(0.0F);
            buq.c(var5 * 0.8F);
         } else {
            buq.b(var5 * 0.25F);
            buq.c(var5);
         }

         if (GLContext.getCapabilities().GL_NV_fog_distance) {
            buq.c(34138, 34139);
         }
      } else if (this.B) {
         buq.a(buq.m.b);
         buq.a(0.1F);
      } else if (var4.a() == bcx.h) {
         buq.a(buq.m.b);
         if (var3 instanceof vn) {
            if (((vn)var3).a(uz.m)) {
               buq.a(0.01F);
            } else {
               buq.a(0.1F - (float)alk.d((vn)var3) * 0.03F);
            }
         } else {
            buq.a(0.1F);
         }
      } else if (var4.a() == bcx.i) {
         buq.a(buq.m.b);
         buq.a(2.0F);
      } else {
         var5 = this.k;
         buq.a(buq.m.a);
         if (var1 == -1) {
            buq.b(0.0F);
            buq.c(var5);
         } else {
            buq.b(var5 * 0.75F);
            buq.c(var5);
         }

         if (GLContext.getCapabilities().GL_NV_fog_distance) {
            buq.c(34138, 34139);
         }

         if (this.h.f.s.b((int)var3.p, (int)var3.r) || this.h.q.j().f()) {
            buq.b(var5 * 0.05F);
            buq.c(Math.min(var5, 192.0F) * 0.5F);
         }
      }

      buq.h();
      buq.o();
      buq.a(1028, 4608);
   }

   public void d(boolean var1) {
      if (var1) {
         buq.b(2918, this.a(0.0F, 0.0F, 0.0F, 1.0F));
      } else {
         buq.b(2918, this.a(this.R, this.S, this.T, 1.0F));
      }

   }

   private FloatBuffer a(float var1, float var2, float var3, float var4) {
      this.Q.clear();
      this.Q.put(var1).put(var2).put(var3).put(var4);
      this.Q.flip();
      return this.Q;
   }

   public void k() {
      this.ab = null;
      this.l.a();
   }

   public biq l() {
      return this.l;
   }

   public static void a(bin var0, String var1, float var2, float var3, float var4, int var5, float var6, float var7, boolean var8, boolean var9) {
      buq.G();
      buq.c(var2, var3, var4);
      buq.a(0.0F, 1.0F, 0.0F);
      buq.b(-var6, 0.0F, 1.0F, 0.0F);
      buq.b((float)(var8 ? -1 : 1) * var7, 1.0F, 0.0F, 0.0F);
      buq.b(-0.025F, -0.025F, 0.025F);
      buq.g();
      buq.a(false);
      if (!var9) {
         buq.j();
      }

      buq.m();
      buq.a(buq.r.l, buq.l.j, buq.r.e, buq.l.n);
      int var10 = var0.a(var1) / 2;
      buq.z();
      bvc var11 = bvc.a();
      bui var12 = var11.c();
      var12.a(7, cdw.f);
      var12.b((double)(-var10 - 1), (double)(-1 + var5), 0.0D).a(0.0F, 0.0F, 0.0F, 0.25F).d();
      var12.b((double)(-var10 - 1), (double)(8 + var5), 0.0D).a(0.0F, 0.0F, 0.0F, 0.25F).d();
      var12.b((double)(var10 + 1), (double)(8 + var5), 0.0D).a(0.0F, 0.0F, 0.0F, 0.25F).d();
      var12.b((double)(var10 + 1), (double)(-1 + var5), 0.0D).a(0.0F, 0.0F, 0.0F, 0.25F).d();
      var11.b();
      buq.y();
      if (!var9) {
         var0.a(var1, -var0.a(var1) / 2, var5, 553648127);
         buq.k();
      }

      buq.a(true);
      var0.a(var1, -var0.a(var1) / 2, var5, var9 ? 553648127 : -1);
      buq.f();
      buq.l();
      buq.c(1.0F, 1.0F, 1.0F, 1.0F);
      buq.H();
   }

   public void a(ain var1) {
      this.ab = var1;
      this.ac = 40;
      this.ad = this.j.nextFloat() * 2.0F - 1.0F;
      this.ae = this.j.nextFloat() * 2.0F - 1.0F;
   }

   private void a(int var1, int var2, float var3) {
      if (this.ab != null && this.ac > 0) {
         int var4 = 40 - this.ac;
         float var5 = ((float)var4 + var3) / 40.0F;
         float var6 = var5 * var5;
         float var7 = var5 * var6;
         float var8 = 10.25F * var7 * var6 + -24.95F * var6 * var6 + 25.5F * var7 + -13.8F * var6 + 4.0F * var5;
         float var9 = var8 * 3.1415927F;
         float var10 = this.ad * (float)(var1 / 4);
         float var11 = this.ae * (float)(var2 / 4);
         buq.e();
         buq.G();
         buq.a();
         buq.k();
         buq.r();
         bhx.b();
         buq.c((float)(var1 / 2) + var10 * ri.e(ri.a(var9 * 2.0F)), (float)(var2 / 2) + var11 * ri.e(ri.a(var9 * 2.0F)), -50.0F);
         float var12 = 50.0F + 175.0F * ri.a(var9);
         buq.b(var12, -var12, var12);
         buq.b(900.0F * ri.e(ri.a(var9)), 0.0F, 1.0F, 0.0F);
         buq.b(6.0F * ri.b(var5 * 8.0F), 1.0F, 0.0F, 0.0F);
         buq.b(6.0F * ri.b(var5 * 8.0F), 0.0F, 0.0F, 1.0F);
         this.h.ad().a(this.ab, bwa.b.i);
         buq.c();
         buq.H();
         bhx.a();
         buq.q();
         buq.j();
      }
   }

   static {
      d = ag.length;
   }
}
