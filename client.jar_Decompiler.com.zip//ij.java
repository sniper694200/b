import java.io.IOException;

public class ij implements ht<hw> {
   private et a;
   private awr b;

   public ij() {
   }

   public ij(ams var1, et var2) {
      this.a = var2;
      this.b = var1.o(var2);
   }

   public void a(gy var1) throws IOException {
      this.a = var1.e();
      this.b = (awr)aou.i.a(var1.g());
   }

   public void b(gy var1) throws IOException {
      var1.a(this.a);
      var1.d(aou.i.a(this.b));
   }

   public void a(hw var1) {
      var1.a(this);
   }

   public awr a() {
      return this.b;
   }

   public et b() {
      return this.a;
   }
}
