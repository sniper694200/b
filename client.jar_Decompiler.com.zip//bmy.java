public class bmy extends bme {
   private static final nd v = new nd("textures/gui/container/shulker_box.png");
   private final tt w;
   private final aea x;

   public bmy(aea var1, tt var2) {
      super(new agn(var1, var2, bhz.z().h));
      this.x = var1;
      this.w = var2;
      ++this.g;
   }

   public void a(int var1, int var2, float var3) {
      this.c();
      super.a(var1, var2, var3);
      this.b(var1, var2);
   }

   protected void c(int var1, int var2) {
      this.q.a(this.w.i_().c(), 8, 6, 4210752);
      this.q.a(this.x.i_().c(), 8, this.g - 96 + 2, 4210752);
   }

   protected void a(float var1, int var2, int var3) {
      buq.c(1.0F, 1.0F, 1.0F, 1.0F);
      this.j.N().a(v);
      int var4 = (this.l - this.f) / 2;
      int var5 = (this.m - this.g) / 2;
      this.b(var4, var5, 0, 0, this.f, this.g);
   }
}
