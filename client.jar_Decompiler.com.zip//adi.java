import javax.annotation.Nullable;

public class adi extends acn {
   public adi(ams var1) {
      super(var1);
   }

   public static void a(rw var0) {
      vo.a(var0, adi.class);
   }

   @Nullable
   protected nd J() {
      return bfl.ao;
   }

   protected qc F() {
      return qd.gQ;
   }

   protected qc d(up var1) {
      return qd.gV;
   }

   protected qc cf() {
      return qd.gR;
   }

   qc p() {
      return qd.gX;
   }

   public void a(up var1) {
      super.a((up)var1);
      if (var1.j() instanceof acq) {
         acq var2 = (acq)var1.j();
         if (var2.p() && var2.dp()) {
            var2.dq();
            this.a(new ain(aip.ci, 1, 0), 0.0F);
         }
      }

   }

   protected aef a(float var1) {
      ain var2 = this.b(vj.b);
      if (var2.c() == aip.i) {
         aes var4 = new aes(this.l, this);
         var4.a(this, var1);
         return var4;
      } else {
         aef var3 = super.a(var1);
         if (var2.c() == aip.j && var3 instanceof aey) {
            ((aey)var3).a(var2);
         }

         return var3;
      }
   }
}
