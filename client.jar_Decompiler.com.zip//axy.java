import javax.annotation.Nullable;

public interface axy {
   int a(awr var1);

   @Nullable
   awr a(int var1);

   void a(gy var1);

   void b(gy var1);

   int a();
}
