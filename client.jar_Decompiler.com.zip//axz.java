interface axz {
   int a(int var1, awr var2);
}
