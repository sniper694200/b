import io.netty.buffer.ByteBuf;
import net.minecraft.server.MinecraftServer;

public class afe extends afc {
   private static final mx<String> a;
   private static final mx<hh> b;
   private final amh c = new amh() {
      public void i() {
         afe.this.V().b(afe.a, this.m());
         afe.this.V().b(afe.b, this.l());
      }

      public int j() {
         return 1;
      }

      public void a(ByteBuf var1) {
         var1.writeInt(afe.this.S());
      }

      public et c() {
         return new et(afe.this.p, afe.this.q + 0.5D, afe.this.r);
      }

      public bhc d() {
         return new bhc(afe.this.p, afe.this.q, afe.this.r);
      }

      public ams e() {
         return afe.this.l;
      }

      public ve f() {
         return afe.this;
      }

      public MinecraftServer C_() {
         return afe.this.l.u();
      }
   };
   private int d;

   public afe(ams var1) {
      super(var1);
   }

   public afe(ams var1, double var2, double var4, double var6) {
      super(var1, var2, var4, var6);
   }

   public static void a(rw var0) {
      afc.a(var0, afe.class);
      var0.a(ru.e, new ry() {
         public fy a(rv var1, fy var2, int var3) {
            if (avh.a(avk.class).equals(new nd(var2.l("id")))) {
               var2.a("id", "Control");
               var1.a(ru.d, var2, var3);
               var2.a("id", "MinecartCommandBlock");
            }

            return var2;
         }
      });
   }

   protected void i() {
      super.i();
      this.V().a((mx)a, (Object)"");
      this.V().a((mx)b, (Object)(new ho("")));
   }

   protected void a(fy var1) {
      super.a(var1);
      this.c.b(var1);
      this.V().b(a, this.j().m());
      this.V().b(b, this.j().l());
   }

   protected void b(fy var1) {
      super.b(var1);
      this.c.a(var1);
   }

   public afc.a v() {
      return afc.a.g;
   }

   public awr x() {
      return aov.bX.t();
   }

   public amh j() {
      return this.c;
   }

   public void a(int var1, int var2, int var3, boolean var4) {
      if (var4 && this.T - this.d >= 4) {
         this.j().a(this.l);
         this.d = this.T;
      }

   }

   public boolean b(aeb var1, tz var2) {
      this.c.a(var1);
      return false;
   }

   public void a(mx<?> var1) {
      super.a((mx)var1);
      if (b.equals(var1)) {
         try {
            this.c.b((hh)this.V().a(b));
         } catch (Throwable var3) {
         }
      } else if (a.equals(var1)) {
         this.c.a((String)this.V().a(a));
      }

   }

   public boolean bC() {
      return true;
   }

   static {
      a = na.a(afe.class, mz.d);
      b = na.a(afe.class, mz.e);
   }
}
