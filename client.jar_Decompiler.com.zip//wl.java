public class wl extends wo {
   public wl(vo var1) {
      super(var1);
   }

   public void a() {
      if (this.h == wo.a.b) {
         this.h = wo.a.a;
         this.a.d(true);
         double var1 = this.b - this.a.p;
         double var3 = this.c - this.a.q;
         double var5 = this.d - this.a.r;
         double var7 = var1 * var1 + var3 * var3 + var5 * var5;
         if (var7 < 2.500000277905201E-7D) {
            this.a.o(0.0F);
            this.a.n(0.0F);
            return;
         }

         float var9 = (float)(ri.c(var5, var1) * 57.2957763671875D) - 90.0F;
         this.a.v = this.a(this.a.v, var9, 10.0F);
         float var10;
         if (this.a.z) {
            var10 = (float)(this.e * this.a.a((wa)adf.d).e());
         } else {
            var10 = (float)(this.e * this.a.a((wa)adf.e).e());
         }

         this.a.k(var10);
         double var11 = (double)ri.a(var1 * var1 + var5 * var5);
         float var13 = (float)(-(ri.c(var3, var11) * 57.2957763671875D));
         this.a.w = this.a(this.a.w, var13, 10.0F);
         this.a.o(var3 > 0.0D ? var10 : -var10);
      } else {
         this.a.d(false);
         this.a.o(0.0F);
         this.a.n(0.0F);
      }

   }
}
