import com.google.common.base.Predicate;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.common.util.concurrent.ListenableFuture;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class om extends ams implements tp {
   private static final Logger a = LogManager.getLogger();
   private final MinecraftServer K;
   private final oj L;
   private final os M;
   private final Set<and> N = Sets.newHashSet();
   private final TreeSet<and> O = new TreeSet();
   private final Map<UUID, ve> P = Maps.newHashMap();
   public boolean b;
   private boolean Q;
   private int R;
   private final ana S;
   private final amz T = new amz();
   protected final zn c = new zn(this);
   private final om.a[] U = new om.a[]{new om.a(), new om.a()};
   private int V;
   private final List<and> W = Lists.newArrayList();

   public om(MinecraftServer var1, bfc var2, bfb var3, int var4, rj var5) {
      super(var2, var3, ayl.a(var4).d(), var5, false);
      this.K = var1;
      this.L = new oj(this);
      this.M = new os(this);
      this.s.a((ams)this);
      this.v = this.n();
      this.S = new ana(this);
      this.J();
      this.K();
      this.al().a(var1.aE());
   }

   public ams b() {
      this.z = new bfk(this.w);
      String var1 = zo.a(this.s);
      zo var2 = (zo)this.z.a(zo.class, var1);
      if (var2 == null) {
         this.A = new zo(this);
         this.z.a((String)var1, (ber)this.A);
      } else {
         this.A = var2;
         this.A.a((ams)this);
      }

      this.F = new nt(this.K);
      bhj var3 = (bhj)this.z.a(bhj.class, "scoreboard");
      if (var3 == null) {
         var3 = new bhj();
         this.z.a((String)"scoreboard", (ber)var3);
      }

      var3.a(this.F);
      ((nt)this.F).a((Runnable)(new beq(var3)));
      this.B = new bft(new File(new File(this.w.b(), "data"), "loot_tables"));
      this.C = new nq(new File(new File(this.w.b(), "data"), "advancements"));
      this.D = new nr(new File(new File(this.w.b(), "data"), "functions"), this.K);
      this.al().c(this.x.B(), this.x.C());
      this.al().c(this.x.H());
      this.al().b(this.x.G());
      this.al().c(this.x.I());
      this.al().b(this.x.J());
      if (this.x.E() > 0L) {
         this.al().a(this.x.D(), this.x.F(), this.x.E());
      } else {
         this.al().a(this.x.D());
      }

      return this;
   }

   public void d() {
      super.d();
      if (this.V().s() && this.ag() != tx.d) {
         this.V().a(tx.d);
      }

      this.s.k().b();
      if (this.g()) {
         if (this.W().b("doDaylightCycle")) {
            long var1 = this.x.f() + 24000L;
            this.x.c(var1 - var1 % 24000L);
         }

         this.f();
      }

      this.E.a("mobSpawner");
      if (this.W().b("doMobSpawning") && this.x.t() != amx.g) {
         this.T.a(this, this.H, this.I, this.x.e() % 400L == 0L);
      }

      this.E.c("chunkSource");
      this.v.d();
      int var3 = this.a(1.0F);
      if (var3 != this.ah()) {
         this.c(var3);
      }

      this.x.b(this.x.e() + 1L);
      if (this.W().b("doDaylightCycle")) {
         this.x.c(this.x.f() + 1L);
      }

      this.E.c("tickPending");
      this.a(false);
      this.E.c("tickBlocks");
      this.j();
      this.E.c("chunkMap");
      this.M.c();
      this.E.c("village");
      this.A.a();
      this.c.a();
      this.E.c("portalForcer");
      this.S.a(this.R());
      this.E.b();
      this.aq();
   }

   @Nullable
   public anf.c a(vp var1, et var2) {
      List<anf.c> var3 = this.r().a(var1, var2);
      return var3 != null && !var3.isEmpty() ? (anf.c)rq.a(this.r, var3) : null;
   }

   public boolean a(vp var1, anf.c var2, et var3) {
      List<anf.c> var4 = this.r().a(var1, var3);
      return var4 != null && !var4.isEmpty() ? var4.contains(var2) : false;
   }

   public void e() {
      this.Q = false;
      if (!this.i.isEmpty()) {
         int var1 = 0;
         int var2 = 0;
         Iterator var3 = this.i.iterator();

         while(var3.hasNext()) {
            aeb var4 = (aeb)var3.next();
            if (var4.y()) {
               ++var1;
            } else if (var4.cz()) {
               ++var2;
            }
         }

         this.Q = var2 > 0 && var2 >= this.i.size() - var1;
      }

   }

   protected void f() {
      this.Q = false;
      Iterator var1 = this.i.iterator();

      while(var1.hasNext()) {
         aeb var2 = (aeb)var1.next();
         if (var2.cz()) {
            var2.a(false, false, true);
         }
      }

      if (this.W().b("doWeatherCycle")) {
         this.c();
      }

   }

   private void c() {
      this.x.g(0);
      this.x.b(false);
      this.x.f(0);
      this.x.a(false);
   }

   public boolean g() {
      if (this.Q && !this.G) {
         Iterator var1 = this.i.iterator();

         aeb var2;
         do {
            if (!var1.hasNext()) {
               return true;
            }

            var2 = (aeb)var1.next();
         } while(var2.y() || var2.dc());

         return false;
      } else {
         return false;
      }
   }

   public void h() {
      if (this.x.c() <= 0) {
         this.x.b(this.M() + 1);
      }

      int var1 = this.x.b();
      int var2 = this.x.d();
      int var3 = 0;

      while(this.c(new et(var1, 0, var2)).a() == bcx.a) {
         var1 += this.r.nextInt(8) - this.r.nextInt(8);
         var2 += this.r.nextInt(8) - this.r.nextInt(8);
         ++var3;
         if (var3 == 10000) {
            break;
         }
      }

      this.x.a(var1);
      this.x.c(var2);
   }

   protected boolean a(int var1, int var2, boolean var3) {
      return this.r().d(var1, var2);
   }

   protected void i() {
      this.E.a("playerCheckLight");
      if (!this.i.isEmpty()) {
         int var1 = this.r.nextInt(this.i.size());
         aeb var2 = (aeb)this.i.get(var1);
         int var3 = ri.c(var2.p) + this.r.nextInt(11) - 5;
         int var4 = ri.c(var2.q) + this.r.nextInt(11) - 5;
         int var5 = ri.c(var2.r) + this.r.nextInt(11) - 5;
         this.w(new et(var3, var4, var5));
      }

      this.E.b();
   }

   protected void j() {
      this.i();
      if (this.x.t() == amx.g) {
         Iterator var19 = this.M.b();

         while(var19.hasNext()) {
            ((axu)var19.next()).b(false);
         }

      } else {
         int var1 = this.W().c("randomTickSpeed");
         boolean var2 = this.Y();
         boolean var3 = this.X();
         this.E.a("pollingChunks");

         for(Iterator var4 = this.M.b(); var4.hasNext(); this.E.b()) {
            this.E.a("getChunk");
            axu var5 = (axu)var4.next();
            int var6 = var5.b * 16;
            int var7 = var5.c * 16;
            this.E.c("checkNextLight");
            var5.n();
            this.E.c("tickChunk");
            var5.b(false);
            this.E.c("thunder");
            int var8;
            et var9;
            if (var2 && var3 && this.r.nextInt(100000) == 0) {
               this.l = this.l * 3 + 1013904223;
               var8 = this.l >> 2;
               var9 = this.a(new et(var6 + (var8 & 15), 0, var7 + (var8 >> 8 & 15)));
               if (this.B(var9)) {
                  ty var10 = this.D(var9);
                  if (this.W().b("doMobSpawning") && this.r.nextDouble() < (double)var10.b() * 0.01D) {
                     aas var11 = new aas(this);
                     var11.p(true);
                     var11.c(0);
                     var11.b((double)var9.p(), (double)var9.q(), (double)var9.r());
                     this.a((ve)var11);
                     this.d(new acg(this, (double)var9.p(), (double)var9.q(), (double)var9.r(), true));
                  } else {
                     this.d(new acg(this, (double)var9.p(), (double)var9.q(), (double)var9.r(), false));
                  }
               }
            }

            this.E.c("iceandsnow");
            if (this.r.nextInt(16) == 0) {
               this.l = this.l * 3 + 1013904223;
               var8 = this.l >> 2;
               var9 = this.p(new et(var6 + (var8 & 15), 0, var7 + (var8 >> 8 & 15)));
               et var22 = var9.b();
               if (this.v(var22)) {
                  this.a((et)var22, (awr)aov.aI.t());
               }

               if (var2 && this.f(var9, true)) {
                  this.a((et)var9, (awr)aov.aH.t());
               }

               if (var2 && this.b((et)var22).d()) {
                  this.o(var22).u().h(this, var22);
               }
            }

            this.E.c("tickBlocks");
            if (var1 > 0) {
               axv[] var20 = var5.h();
               int var21 = var20.length;

               for(int var23 = 0; var23 < var21; ++var23) {
                  axv var24 = var20[var23];
                  if (var24 != axu.a && var24.b()) {
                     for(int var12 = 0; var12 < var1; ++var12) {
                        this.l = this.l * 3 + 1013904223;
                        int var13 = this.l >> 2;
                        int var14 = var13 & 15;
                        int var15 = var13 >> 8 & 15;
                        int var16 = var13 >> 16 & 15;
                        awr var17 = var24.a(var14, var16, var15);
                        aou var18 = var17.u();
                        this.E.a("randomTick");
                        if (var18.k()) {
                           var18.a((ams)this, (et)(new et(var14 + var6, var16 + var24.d(), var15 + var7)), (awr)var17, (Random)this.r);
                        }

                        this.E.b();
                     }
                  }
               }
            }
         }

         this.E.b();
      }
   }

   protected et a(et var1) {
      et var2 = this.p(var1);
      bgz var3 = (new bgz(var2, new et(var2.p(), this.aa(), var2.r()))).g(3.0D);
      List<vn> var4 = this.a(vn.class, var3, new Predicate<vn>() {
         public boolean a(@Nullable vn var1) {
            return var1 != null && var1.aC() && om.this.h(var1.c());
         }

         // $FF: synthetic method
         public boolean apply(@Nullable Object var1) {
            return this.a((vn)var1);
         }
      });
      if (!var4.isEmpty()) {
         return ((vn)var4.get(this.r.nextInt(var4.size()))).c();
      } else {
         if (var2.q() == -1) {
            var2 = var2.b(2);
         }

         return var2;
      }
   }

   public boolean a(et var1, aou var2) {
      and var3 = new and(var1, var2);
      return this.W.contains(var3);
   }

   public boolean b(et var1, aou var2) {
      and var3 = new and(var1, var2);
      return this.N.contains(var3);
   }

   public void a(et var1, aou var2, int var3) {
      this.a(var1, var2, var3, 0);
   }

   public void a(et var1, aou var2, int var3, int var4) {
      bcx var5 = var2.t().a();
      if (this.d && var5 != bcx.a) {
         if (var2.r()) {
            if (this.a((et)var1.a(-8, -8, -8), (et)var1.a(8, 8, 8))) {
               awr var7 = this.o(var1);
               if (var7.a() != bcx.a && var7.u() == var2) {
                  var7.u().b((ams)this, (et)var1, (awr)var7, (Random)this.r);
               }
            }

            return;
         }

         var3 = 1;
      }

      and var6 = new and(var1, var2);
      if (this.e(var1)) {
         if (var5 != bcx.a) {
            var6.a((long)var3 + this.x.e());
            var6.a(var4);
         }

         if (!this.N.contains(var6)) {
            this.N.add(var6);
            this.O.add(var6);
         }
      }

   }

   public void b(et var1, aou var2, int var3, int var4) {
      and var5 = new and(var1, var2);
      var5.a(var4);
      bcx var6 = var2.t().a();
      if (var6 != bcx.a) {
         var5.a((long)var3 + this.x.e());
      }

      if (!this.N.contains(var5)) {
         this.N.add(var5);
         this.O.add(var5);
      }

   }

   public void k() {
      if (this.i.isEmpty()) {
         if (this.R++ >= 300) {
            return;
         }
      } else {
         this.m();
      }

      this.s.s();
      super.k();
   }

   protected void l() {
      super.l();
      this.E.c("players");

      for(int var1 = 0; var1 < this.i.size(); ++var1) {
         ve var2 = (ve)this.i.get(var1);
         ve var3 = var2.bJ();
         if (var3 != null) {
            if (!var3.F && var3.w(var2)) {
               continue;
            }

            var2.o();
         }

         this.E.a("tick");
         if (!var2.F) {
            try {
               this.h(var2);
            } catch (Throwable var7) {
               b var5 = b.a(var7, "Ticking player");
               c var6 = var5.a("Player being ticked");
               var2.a(var6);
               throw new f(var5);
            }
         }

         this.E.b();
         this.E.a("remove");
         if (var2.F) {
            int var4 = var2.ab;
            int var8 = var2.ad;
            if (var2.aa && this.a(var4, var8, true)) {
               this.a(var4, var8).b(var2);
            }

            this.e.remove(var2);
            this.c(var2);
         }

         this.E.b();
      }

   }

   public void m() {
      this.R = 0;
   }

   public boolean a(boolean var1) {
      if (this.x.t() == amx.g) {
         return false;
      } else {
         int var2 = this.O.size();
         if (var2 != this.N.size()) {
            throw new IllegalStateException("TickNextTick list out of synch");
         } else {
            if (var2 > 65536) {
               var2 = 65536;
            }

            this.E.a("cleaning");

            and var4;
            for(int var3 = 0; var3 < var2; ++var3) {
               var4 = (and)this.O.first();
               if (!var1 && var4.b > this.x.e()) {
                  break;
               }

               this.O.remove(var4);
               this.N.remove(var4);
               this.W.add(var4);
            }

            this.E.b();
            this.E.a("ticking");
            Iterator var11 = this.W.iterator();

            while(var11.hasNext()) {
               var4 = (and)var11.next();
               var11.remove();
               int var5 = false;
               if (this.a((et)var4.a.a(0, 0, 0), (et)var4.a.a(0, 0, 0))) {
                  awr var6 = this.o(var4.a);
                  if (var6.a() != bcx.a && aou.a(var6.u(), var4.a())) {
                     try {
                        var6.u().b((ams)this, (et)var4.a, (awr)var6, (Random)this.r);
                     } catch (Throwable var10) {
                        b var8 = b.a(var10, "Exception while ticking a block");
                        c var9 = var8.a("Block being ticked");
                        c.a(var9, var4.a, var6);
                        throw new f(var8);
                     }
                  }
               } else {
                  this.a(var4.a, var4.a(), 0);
               }
            }

            this.E.b();
            this.W.clear();
            return !this.O.isEmpty();
         }
      }
   }

   @Nullable
   public List<and> a(axu var1, boolean var2) {
      aml var3 = var1.k();
      int var4 = (var3.a << 4) - 2;
      int var5 = var4 + 16 + 2;
      int var6 = (var3.b << 4) - 2;
      int var7 = var6 + 16 + 2;
      return this.a(new bbe(var4, 0, var6, var5, 256, var7), var2);
   }

   @Nullable
   public List<and> a(bbe var1, boolean var2) {
      List<and> var3 = null;

      for(int var4 = 0; var4 < 2; ++var4) {
         Iterator var5;
         if (var4 == 0) {
            var5 = this.O.iterator();
         } else {
            var5 = this.W.iterator();
         }

         while(var5.hasNext()) {
            and var6 = (and)var5.next();
            et var7 = var6.a;
            if (var7.p() >= var1.a && var7.p() < var1.d && var7.r() >= var1.c && var7.r() < var1.f) {
               if (var2) {
                  if (var4 == 0) {
                     this.N.remove(var6);
                  }

                  var5.remove();
               }

               if (var3 == null) {
                  var3 = Lists.newArrayList();
               }

               var3.add(var6);
            }
         }
      }

      return var3;
   }

   public void a(ve var1, boolean var2) {
      if (!this.ao() && (var1 instanceof zt || var1 instanceof aaj)) {
         var1.X();
      }

      if (!this.an() && var1 instanceof adv) {
         var1.X();
      }

      super.a(var1, var2);
   }

   private boolean an() {
      return this.K.ae();
   }

   private boolean ao() {
      return this.K.ad();
   }

   protected axp n() {
      ayd var1 = this.w.a(this.s);
      return new ol(this, var1, this.s.c());
   }

   public boolean a(aeb var1, et var2) {
      return !this.K.a(this, var2, var1) && this.al().a(var2);
   }

   public void a(amv var1) {
      if (!this.x.v()) {
         try {
            this.b(var1);
            if (this.x.t() == amx.g) {
               this.ap();
            }

            super.a(var1);
         } catch (Throwable var6) {
            b var3 = b.a(var6, "Exception initializing level");

            try {
               this.a((b)var3);
            } catch (Throwable var5) {
            }

            throw new f(var3);
         }

         this.x.d(true);
      }

   }

   private void ap() {
      this.x.f(false);
      this.x.c(true);
      this.x.b(false);
      this.x.a(false);
      this.x.i(1000000000);
      this.x.c(6000L);
      this.x.a(amq.e);
      this.x.g(false);
      this.x.a(tx.a);
      this.x.e(true);
      this.W().a("doDaylightCycle", "false");
   }

   private void b(amv var1) {
      if (!this.s.e()) {
         this.x.a(et.a.b(this.s.i()));
      } else if (this.x.t() == amx.g) {
         this.x.a(et.a.a());
      } else {
         this.y = true;
         anj var2 = this.s.k();
         List<anf> var3 = var2.a();
         Random var4 = new Random(this.Q());
         et var5 = var2.a(0, 0, 256, var3, var4);
         int var6 = 8;
         int var7 = this.s.i();
         int var8 = 8;
         if (var5 != null) {
            var6 = var5.p();
            var8 = var5.r();
         } else {
            a.warn("Unable to find spawn biome");
         }

         int var9 = 0;

         while(!this.s.a(var6, var8)) {
            var6 += var4.nextInt(64) - var4.nextInt(64);
            var8 += var4.nextInt(64) - var4.nextInt(64);
            ++var9;
            if (var9 == 1000) {
               break;
            }
         }

         this.x.a(new et(var6, var7, var8));
         this.y = false;
         if (var1.c()) {
            this.o();
         }

      }
   }

   protected void o() {
      azi var1 = new azi();

      for(int var2 = 0; var2 < 10; ++var2) {
         int var3 = this.x.b() + this.r.nextInt(6) - this.r.nextInt(6);
         int var4 = this.x.d() + this.r.nextInt(6) - this.r.nextInt(6);
         et var5 = this.q(new et(var3, 0, var4)).a();
         if (var1.b(this, this.r, var5)) {
            break;
         }
      }

   }

   @Nullable
   public et p() {
      return this.s.h();
   }

   public void a(boolean var1, @Nullable rk var2) throws amt {
      ol var3 = this.r();
      if (var3.e()) {
         if (var2 != null) {
            var2.a("Saving level");
         }

         this.a();
         if (var2 != null) {
            var2.c("Saving chunks");
         }

         var3.a(var1);
         List<axu> var4 = Lists.newArrayList(var3.a());
         Iterator var5 = var4.iterator();

         while(var5.hasNext()) {
            axu var6 = (axu)var5.next();
            if (var6 != null && !this.M.a(var6.b, var6.c)) {
               var3.a(var6);
            }
         }

      }
   }

   public void q() {
      ol var1 = this.r();
      if (var1.e()) {
         var1.c();
      }
   }

   protected void a() throws amt {
      this.P();
      om[] var1 = this.K.d;
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         om var4 = var1[var3];
         if (var4 instanceof oi) {
            ((oi)var4).c();
         }
      }

      this.x.a(this.al().h());
      this.x.d(this.al().f());
      this.x.c(this.al().g());
      this.x.e(this.al().m());
      this.x.f(this.al().n());
      this.x.j(this.al().q());
      this.x.k(this.al().p());
      this.x.b(this.al().j());
      this.x.e(this.al().i());
      this.w.a(this.x, this.K.am().t());
      this.z.a();
   }

   public boolean a(ve var1) {
      return this.j(var1) ? super.a(var1) : false;
   }

   public void a(Collection<ve> var1) {
      List<ve> var2 = Lists.newArrayList(var1);
      Iterator var3 = var2.iterator();

      while(var3.hasNext()) {
         ve var4 = (ve)var3.next();
         if (this.j(var4)) {
            this.e.add(var4);
            this.b(var4);
         }
      }

   }

   private boolean j(ve var1) {
      if (var1.F) {
         a.warn("Tried to add entity {} but it was marked as removed already", vg.a(var1));
         return false;
      } else {
         UUID var2 = var1.bm();
         if (this.P.containsKey(var2)) {
            ve var3 = (ve)this.P.get(var2);
            if (this.f.contains(var3)) {
               this.f.remove(var3);
            } else {
               if (!(var1 instanceof aeb)) {
                  a.warn("Keeping entity {} that already exists with UUID {}", vg.a(var3), var2.toString());
                  return false;
               }

               a.warn("Force-added player with duplicate UUID {}", var2.toString());
            }

            this.f(var3);
         }

         return true;
      }
   }

   protected void b(ve var1) {
      super.b(var1);
      this.k.a(var1.S(), var1);
      this.P.put(var1.bm(), var1);
      ve[] var2 = var1.bb();
      if (var2 != null) {
         ve[] var3 = var2;
         int var4 = var2.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            ve var6 = var3[var5];
            this.k.a(var6.S(), var6);
         }
      }

   }

   protected void c(ve var1) {
      super.c(var1);
      this.k.d(var1.S());
      this.P.remove(var1.bm());
      ve[] var2 = var1.bb();
      if (var2 != null) {
         ve[] var3 = var2;
         int var4 = var2.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            ve var6 = var3[var5];
            this.k.d(var6.S());
         }
      }

   }

   public boolean d(ve var1) {
      if (super.d(var1)) {
         this.K.am().a((aeb)null, var1.p, var1.q, var1.r, 512.0D, this.s.q().a(), new hz(var1));
         return true;
      } else {
         return false;
      }
   }

   public void a(ve var1, byte var2) {
      this.v().b(var1, new iz(var1, var2));
   }

   public ol r() {
      return (ol)super.B();
   }

   public amn a(@Nullable ve var1, double var2, double var4, double var6, float var8, boolean var9, boolean var10) {
      amn var11 = new amn(this, var1, var2, var4, var6, var8, var9, var10);
      var11.a();
      var11.a(false);
      if (!var10) {
         var11.d();
      }

      Iterator var12 = this.i.iterator();

      while(var12.hasNext()) {
         aeb var13 = (aeb)var12.next();
         if (var13.d(var2, var4, var6) < 4096.0D) {
            ((oo)var13).a.a((ht)(new ja(var2, var4, var6, var8, var11.e(), (bhc)var11.b().get(var13))));
         }
      }

      return var11;
   }

   public void c(et var1, aou var2, int var3, int var4) {
      amj var5 = new amj(var1, var2, var3, var4);
      Iterator var6 = this.U[this.V].iterator();

      amj var7;
      do {
         if (!var6.hasNext()) {
            this.U[this.V].add(var5);
            return;
         }

         var7 = (amj)var6.next();
      } while(!var7.equals(var5));

   }

   private void aq() {
      while(!this.U[this.V].isEmpty()) {
         int var1 = this.V;
         this.V ^= 1;
         Iterator var2 = this.U[var1].iterator();

         while(var2.hasNext()) {
            amj var3 = (amj)var2.next();
            if (this.a(var3)) {
               this.K.am().a((aeb)null, (double)var3.a().p(), (double)var3.a().q(), (double)var3.a().r(), 64.0D, this.s.q().a(), new ii(var3.a(), var3.d(), var3.b(), var3.c()));
            }
         }

         this.U[var1].clear();
      }

   }

   private boolean a(amj var1) {
      awr var2 = this.o(var1.a());
      return var2.u() == var1.d() ? var2.a(this, var1.a(), var1.b(), var1.c()) : false;
   }

   public void s() {
      this.w.a();
   }

   protected void t() {
      boolean var1 = this.Y();
      super.t();
      if (this.n != this.o) {
         this.K.am().a((ht)(new jc(7, this.o)), this.s.q().a());
      }

      if (this.p != this.q) {
         this.K.am().a((ht)(new jc(8, this.q)), this.s.q().a());
      }

      if (var1 != this.Y()) {
         if (var1) {
            this.K.am().a((ht)(new jc(2, 0.0F)));
         } else {
            this.K.am().a((ht)(new jc(1, 0.0F)));
         }

         this.K.am().a((ht)(new jc(7, this.o)));
         this.K.am().a((ht)(new jc(8, this.q)));
      }

   }

   @Nullable
   public MinecraftServer u() {
      return this.K;
   }

   public oj v() {
      return this.L;
   }

   public os w() {
      return this.M;
   }

   public ana x() {
      return this.S;
   }

   public bce y() {
      return this.w.h();
   }

   public void a(fj var1, double var2, double var4, double var6, int var8, double var9, double var11, double var13, double var15, int... var17) {
      this.a(var1, false, var2, var4, var6, var8, var9, var11, var13, var15, var17);
   }

   public void a(fj var1, boolean var2, double var3, double var5, double var7, int var9, double var10, double var12, double var14, double var16, int... var18) {
      jg var19 = new jg(var1, var2, (float)var3, (float)var5, (float)var7, (float)var10, (float)var12, (float)var14, (float)var16, var9, var18);

      for(int var20 = 0; var20 < this.i.size(); ++var20) {
         oo var21 = (oo)this.i.get(var20);
         this.a(var21, var2, var3, var5, var7, var19);
      }

   }

   public void a(oo var1, fj var2, boolean var3, double var4, double var6, double var8, int var10, double var11, double var13, double var15, double var17, int... var19) {
      ht<?> var20 = new jg(var2, var3, (float)var4, (float)var6, (float)var8, (float)var11, (float)var13, (float)var15, (float)var17, var10, var19);
      this.a(var1, var3, var4, var6, var8, var20);
   }

   private void a(oo var1, boolean var2, double var3, double var5, double var7, ht<?> var9) {
      et var10 = var1.c();
      double var11 = var10.f(var3, var5, var7);
      if (var11 <= 1024.0D || var2 && var11 <= 262144.0D) {
         var1.a.a(var9);
      }

   }

   @Nullable
   public ve a(UUID var1) {
      return (ve)this.P.get(var1);
   }

   public ListenableFuture<Object> a(Runnable var1) {
      return this.K.a(var1);
   }

   public boolean aF() {
      return this.K.aF();
   }

   @Nullable
   public et a(String var1, et var2, boolean var3) {
      return this.r().a(this, var1, var2, var3);
   }

   public nq z() {
      return this.C;
   }

   public nr A() {
      return this.D;
   }

   // $FF: synthetic method
   public axp B() {
      return this.r();
   }

   static class a extends ArrayList<amj> {
      private a() {
      }

      // $FF: synthetic method
      a(Object var1) {
         this();
      }
   }
}
