public class bzq extends cbl {
   private static final nd a = new nd("textures/entity/zombie/husk.png");

   public bzq(bzd var1) {
      super(var1);
   }

   protected void a(adr var1, float var2) {
      float var3 = 1.0625F;
      buq.b(1.0625F, 1.0625F, 1.0625F);
      super.a(var1, var2);
   }

   protected nd a(adr var1) {
      return a;
   }
}
