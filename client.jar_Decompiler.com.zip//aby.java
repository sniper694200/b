import com.google.common.base.Predicate;
import javax.annotation.Nullable;
import org.apache.commons.lang3.Validate;

public abstract class aby extends ve {
   private static final Predicate<ve> c = new Predicate<ve>() {
      public boolean a(@Nullable ve var1) {
         return var1 instanceof aby;
      }

      // $FF: synthetic method
      public boolean apply(@Nullable Object var1) {
         return this.a((ve)var1);
      }
   };
   private int d;
   protected et a;
   @Nullable
   public fa b;

   public aby(ams var1) {
      super(var1);
      this.a(0.5F, 0.5F);
   }

   public aby(ams var1, et var2) {
      this(var1);
      this.a = var2;
   }

   protected void i() {
   }

   protected void a(fa var1) {
      Validate.notNull(var1);
      Validate.isTrue(var1.k().c());
      this.b = var1;
      this.v = (float)(this.b.b() * 90);
      this.x = this.v;
      this.j();
   }

   protected void j() {
      if (this.b != null) {
         double var1 = (double)this.a.p() + 0.5D;
         double var3 = (double)this.a.q() + 0.5D;
         double var5 = (double)this.a.r() + 0.5D;
         double var7 = 0.46875D;
         double var9 = this.a(this.l());
         double var11 = this.a(this.n());
         var1 -= (double)this.b.g() * 0.46875D;
         var5 -= (double)this.b.i() * 0.46875D;
         var3 += var11;
         fa var13 = this.b.f();
         var1 += var9 * (double)var13.g();
         var5 += var9 * (double)var13.i();
         this.p = var1;
         this.q = var3;
         this.r = var5;
         double var14 = (double)this.l();
         double var16 = (double)this.n();
         double var18 = (double)this.l();
         if (this.b.k() == fa.a.c) {
            var18 = 1.0D;
         } else {
            var14 = 1.0D;
         }

         var14 /= 32.0D;
         var16 /= 32.0D;
         var18 /= 32.0D;
         this.a((bgz)(new bgz(var1 - var14, var3 - var16, var5 - var18, var1 + var14, var3 + var16, var5 + var18)));
      }
   }

   private double a(int var1) {
      return var1 % 32 == 0 ? 0.5D : 0.0D;
   }

   public void B_() {
      this.m = this.p;
      this.n = this.q;
      this.o = this.r;
      if (this.d++ == 100 && !this.l.G) {
         this.d = 0;
         if (!this.F && !this.k()) {
            this.X();
            this.a((ve)null);
         }
      }

   }

   public boolean k() {
      if (!this.l.a((ve)this, (bgz)this.bw()).isEmpty()) {
         return false;
      } else {
         int var1 = Math.max(1, this.l() / 16);
         int var2 = Math.max(1, this.n() / 16);
         et var3 = this.a.a(this.b.d());
         fa var4 = this.b.f();
         et.a var5 = new et.a();

         for(int var6 = 0; var6 < var1; ++var6) {
            for(int var7 = 0; var7 < var2; ++var7) {
               int var8 = (var1 - 1) / -2;
               int var9 = (var2 - 1) / -2;
               var5.g(var3).c(var4, var6 + var8).c(fa.b, var7 + var9);
               awr var10 = this.l.o(var5);
               if (!var10.a().a() && !apu.C(var10)) {
                  return false;
               }
            }
         }

         return this.l.a((ve)this, (bgz)this.bw(), (Predicate)c).isEmpty();
      }
   }

   public boolean ay() {
      return true;
   }

   public boolean t(ve var1) {
      return var1 instanceof aeb ? this.a(up.a((aeb)var1), 0.0F) : false;
   }

   public fa bt() {
      return this.b;
   }

   public boolean a(up var1, float var2) {
      if (this.b(var1)) {
         return false;
      } else {
         if (!this.F && !this.l.G) {
            this.X();
            this.ax();
            this.a(var1.j());
         }

         return true;
      }
   }

   public void a(vt var1, double var2, double var4, double var6) {
      if (!this.l.G && !this.F && var2 * var2 + var4 * var4 + var6 * var6 > 0.0D) {
         this.X();
         this.a((ve)null);
      }

   }

   public void f(double var1, double var3, double var5) {
      if (!this.l.G && !this.F && var1 * var1 + var3 * var3 + var5 * var5 > 0.0D) {
         this.X();
         this.a((ve)null);
      }

   }

   public void b(fy var1) {
      var1.a("Facing", (byte)this.b.b());
      et var2 = this.q();
      var1.a("TileX", var2.p());
      var1.a("TileY", var2.q());
      var1.a("TileZ", var2.r());
   }

   public void a(fy var1) {
      this.a = new et(var1.h("TileX"), var1.h("TileY"), var1.h("TileZ"));
      this.a(fa.b(var1.f("Facing")));
   }

   public abstract int l();

   public abstract int n();

   public abstract void a(@Nullable ve var1);

   public abstract void p();

   public acj a(ain var1, float var2) {
      acj var3 = new acj(this.l, this.p + (double)((float)this.b.g() * 0.15F), this.q + (double)var2, this.r + (double)((float)this.b.i() * 0.15F), var1);
      var3.q();
      this.l.a((ve)var3);
      return var3;
   }

   protected boolean aA() {
      return false;
   }

   public void b(double var1, double var3, double var5) {
      this.a = new et(var1, var3, var5);
      this.j();
      this.ai = true;
   }

   public et q() {
      return this.a;
   }

   public float a(atk var1) {
      if (this.b != null && this.b.k() != fa.a.b) {
         switch(var1) {
         case c:
            this.b = this.b.d();
            break;
         case d:
            this.b = this.b.f();
            break;
         case b:
            this.b = this.b.e();
         }
      }

      float var2 = ri.g(this.v);
      switch(var1) {
      case c:
         return var2 + 180.0F;
      case d:
         return var2 + 90.0F;
      case b:
         return var2 + 270.0F;
      default:
         return var2;
      }
   }

   public float a(arw var1) {
      return this.a(var1.a(this.b));
   }

   public void a(acg var1) {
   }
}
