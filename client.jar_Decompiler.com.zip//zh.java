import com.google.common.collect.Lists;
import java.util.List;

public class zh {
   vo a;
   List<ve> b = Lists.newArrayList();
   List<ve> c = Lists.newArrayList();

   public zh(vo var1) {
      this.a = var1;
   }

   public void a() {
      this.b.clear();
      this.c.clear();
   }

   public boolean a(ve var1) {
      if (this.b.contains(var1)) {
         return true;
      } else if (this.c.contains(var1)) {
         return false;
      } else {
         this.a.l.E.a("canSee");
         boolean var2 = this.a.D(var1);
         this.a.l.E.b();
         if (var2) {
            this.b.add(var1);
         } else {
            this.c.add(var1);
         }

         return var2;
      }
   }
}
