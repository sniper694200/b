import java.util.Random;

public abstract class apu extends ark {
   protected static final bgz c = new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.125D, 1.0D);
   protected final boolean d;

   protected apu(boolean var1) {
      super(bcx.q);
      this.d = var1;
   }

   public bgz b(awr var1, amw var2, et var3) {
      return c;
   }

   public boolean c(awr var1) {
      return false;
   }

   public boolean a(ams var1, et var2) {
      return var1.o(var2.b()).q() ? super.a(var1, var2) : false;
   }

   public boolean b(ams var1, et var2) {
      return var1.o(var2.b()).q();
   }

   public void a(ams var1, et var2, awr var3, Random var4) {
   }

   public void b(ams var1, et var2, awr var3, Random var4) {
      if (!this.b((amw)var1, (et)var2, (awr)var3)) {
         boolean var5 = this.e(var1, var2, var3);
         if (this.d && !var5) {
            var1.a((et)var2, (awr)this.z(var3), 2);
         } else if (!this.d) {
            var1.a((et)var2, (awr)this.y(var3), 2);
            if (!var5) {
               var1.a(var2, this.y(var3).u(), this.E(var3), -1);
            }
         }

      }
   }

   public boolean a(awr var1, amw var2, et var3, fa var4) {
      return var4.k() != fa.a.b;
   }

   protected boolean A(awr var1) {
      return this.d;
   }

   public int c(awr var1, amw var2, et var3, fa var4) {
      return var1.a(var2, var3, var4);
   }

   public int b(awr var1, amw var2, et var3, fa var4) {
      if (!this.A(var1)) {
         return 0;
      } else {
         return var1.c(D) == var4 ? this.a(var2, var3, var1) : 0;
      }
   }

   public void a(awr var1, ams var2, et var3, aou var4, et var5) {
      if (this.b(var2, var3)) {
         this.g(var2, var3, var1);
      } else {
         this.b(var2, var3, var1, 0);
         var2.g(var3);
         fa[] var6 = fa.values();
         int var7 = var6.length;

         for(int var8 = 0; var8 < var7; ++var8) {
            fa var9 = var6[var8];
            var2.b(var3.a(var9), this, false);
         }

      }
   }

   protected void g(ams var1, et var2, awr var3) {
      if (!this.b((amw)var1, (et)var2, (awr)var3)) {
         boolean var4 = this.e(var1, var2, var3);
         if (this.d != var4 && !var1.a((et)var2, (aou)this)) {
            int var5 = -1;
            if (this.i(var1, var2, var3)) {
               var5 = -3;
            } else if (this.d) {
               var5 = -2;
            }

            var1.a(var2, this, this.x(var3), var5);
         }

      }
   }

   public boolean b(amw var1, et var2, awr var3) {
      return false;
   }

   protected boolean e(ams var1, et var2, awr var3) {
      return this.f(var1, var2, var3) > 0;
   }

   protected int f(ams var1, et var2, awr var3) {
      fa var4 = (fa)var3.c(D);
      et var5 = var2.a(var4);
      int var6 = var1.c(var5, var4);
      if (var6 >= 15) {
         return var6;
      } else {
         awr var7 = var1.o(var5);
         return Math.max(var6, var7.u() == aov.af ? (Integer)var7.c(atd.e) : 0);
      }
   }

   protected int c(amw var1, et var2, awr var3) {
      fa var4 = (fa)var3.c(D);
      fa var5 = var4.e();
      fa var6 = var4.f();
      return Math.max(this.a(var1, var2.a(var5), var5), this.a(var1, var2.a(var6), var6));
   }

   protected int a(amw var1, et var2, fa var3) {
      awr var4 = var1.o(var2);
      aou var5 = var4.u();
      if (this.B(var4)) {
         if (var5 == aov.cn) {
            return 15;
         } else {
            return var5 == aov.af ? (Integer)var4.c(atd.e) : var1.a(var2, var3);
         }
      } else {
         return 0;
      }
   }

   public boolean g(awr var1) {
      return true;
   }

   public awr a(ams var1, et var2, fa var3, float var4, float var5, float var6, int var7, vn var8) {
      return this.t().a(D, var8.bt().d());
   }

   public void a(ams var1, et var2, awr var3, vn var4, ain var5) {
      if (this.e(var1, var2, var3)) {
         var1.a((et)var2, (aou)this, 1);
      }

   }

   public void c(ams var1, et var2, awr var3) {
      this.h(var1, var2, var3);
   }

   protected void h(ams var1, et var2, awr var3) {
      fa var4 = (fa)var3.c(D);
      et var5 = var2.a(var4.d());
      var1.a((et)var5, (aou)this, (et)var2);
      var1.a((et)var5, (aou)this, (fa)var4);
   }

   public void d(ams var1, et var2, awr var3) {
      if (this.d) {
         fa[] var4 = fa.values();
         int var5 = var4.length;

         for(int var6 = 0; var6 < var5; ++var6) {
            fa var7 = var4[var6];
            var1.b(var2.a(var7), this, false);
         }
      }

      super.d(var1, var2, var3);
   }

   public boolean b(awr var1) {
      return false;
   }

   protected boolean B(awr var1) {
      return var1.m();
   }

   protected int a(amw var1, et var2, awr var3) {
      return 15;
   }

   public static boolean C(awr var0) {
      return aov.bb.D(var0) || aov.cj.D(var0);
   }

   public boolean D(awr var1) {
      aou var2 = var1.u();
      return var2 == this.y(this.t()).u() || var2 == this.z(this.t()).u();
   }

   public boolean i(ams var1, et var2, awr var3) {
      fa var4 = ((fa)var3.c(D)).d();
      et var5 = var2.a(var4);
      if (C(var1.o(var5))) {
         return var1.o(var5).c(D) != var4;
      } else {
         return false;
      }
   }

   protected int E(awr var1) {
      return this.x(var1);
   }

   protected abstract int x(awr var1);

   protected abstract awr y(awr var1);

   protected abstract awr z(awr var1);

   public boolean d(aou var1) {
      return this.D(var1.t());
   }

   public amk f() {
      return amk.c;
   }

   public awp a(amw var1, awr var2, et var3, fa var4) {
      return var4 == fa.a ? awp.a : awp.i;
   }
}
