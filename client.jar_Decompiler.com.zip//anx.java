import java.util.Random;

public class anx extends aob {
   public anx(anf.a var1) {
      super(var1);
      this.s.z = 2;
      this.s.B = 2;
      this.s.C = 5;
   }

   public void a(ams var1, Random var2, ayu var3, int var4, int var5, double var6) {
      this.q = aov.c.t();
      this.r = aov.d.t();
      if (var6 > 1.75D) {
         this.q = aov.b.t();
         this.r = aov.b.t();
      } else if (var6 > -0.5D) {
         this.q = aov.d.t().a(apw.a, apw.a.b);
      }

      this.b(var1, var2, var3, var4, var5, var6);
   }

   public void a(ams var1, Random var2, et var3) {
      this.s.a(var1, var2, this, var3);
   }
}
