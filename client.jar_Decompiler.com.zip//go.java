public class go extends Exception {
   public go(String var1, String var2, int var3) {
      super(var1 + " at: " + a(var2, var3));
   }

   private static String a(String var0, int var1) {
      StringBuilder var2 = new StringBuilder();
      int var3 = Math.min(var0.length(), var1);
      if (var3 > 35) {
         var2.append("...");
      }

      var2.append(var0.substring(Math.max(0, var3 - 35), var3));
      var2.append("<--[HERE]");
      return var2.toString();
   }
}
