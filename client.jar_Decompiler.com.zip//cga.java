public class cga implements ceo {
   private fm<cgb, cfw> a;
   private final cdn b;
   private final bvj c;
   private cfw d;

   public cga(cdn var1) {
      this.b = var1;
      this.c = new bvj(this);
   }

   public void a(cen var1) {
      cfz var2 = new cfz(var1, this.b, this.c);
      this.a = var2.a();
      this.d = (cfw)this.a.c(cfz.a);
      this.c.c();
   }

   public cfw a(cgb var1) {
      if (var1 == null) {
         return this.d;
      } else {
         cfw var2 = (cfw)this.a.c(var1);
         return var2 == null ? this.d : var2;
      }
   }

   public cfw a() {
      return this.d;
   }

   public cdn b() {
      return this.b;
   }

   public bvj c() {
      return this.c;
   }
}
