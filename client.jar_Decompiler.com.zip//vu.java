import java.util.UUID;
import javax.annotation.Nullable;

public interface vu {
   @Nullable
   UUID b();

   @Nullable
   ve p_();
}
