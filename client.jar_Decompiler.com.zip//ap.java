import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ap implements p<ap.b> {
   private static final nd a = new nd("levitation");
   private final Map<nn, ap.a> b = Maps.newHashMap();

   public nd a() {
      return a;
   }

   public void a(nn var1, p.a<ap.b> var2) {
      ap.a var3 = (ap.a)this.b.get(var1);
      if (var3 == null) {
         var3 = new ap.a(var1);
         this.b.put(var1, var3);
      }

      var3.a(var2);
   }

   public void b(nn var1, p.a<ap.b> var2) {
      ap.a var3 = (ap.a)this.b.get(var1);
      if (var3 != null) {
         var3.b(var2);
         if (var3.a()) {
            this.b.remove(var1);
         }
      }

   }

   public void a(nn var1) {
      this.b.remove(var1);
   }

   public ap.b b(JsonObject var1, JsonDeserializationContext var2) {
      ad var3 = ad.a(var1.get("distance"));
      as var4 = as.a(var1.get("duration"));
      return new ap.b(var3, var4);
   }

   public void a(oo var1, bhc var2, int var3) {
      ap.a var4 = (ap.a)this.b.get(var1.P());
      if (var4 != null) {
         var4.a(var1, var2, var3);
      }

   }

   // $FF: synthetic method
   public q a(JsonObject var1, JsonDeserializationContext var2) {
      return this.b(var1, var2);
   }

   static class a {
      private final nn a;
      private final Set<p.a<ap.b>> b = Sets.newHashSet();

      public a(nn var1) {
         this.a = var1;
      }

      public boolean a() {
         return this.b.isEmpty();
      }

      public void a(p.a<ap.b> var1) {
         this.b.add(var1);
      }

      public void b(p.a<ap.b> var1) {
         this.b.remove(var1);
      }

      public void a(oo var1, bhc var2, int var3) {
         List<p.a<ap.b>> var4 = null;
         Iterator var5 = this.b.iterator();

         p.a var6;
         while(var5.hasNext()) {
            var6 = (p.a)var5.next();
            if (((ap.b)var6.a()).a(var1, var2, var3)) {
               if (var4 == null) {
                  var4 = Lists.newArrayList();
               }

               var4.add(var6);
            }
         }

         if (var4 != null) {
            var5 = var4.iterator();

            while(var5.hasNext()) {
               var6 = (p.a)var5.next();
               var6.a(this.a);
            }
         }

      }
   }

   public static class b extends u {
      private final ad a;
      private final as b;

      public b(ad var1, as var2) {
         super(ap.a);
         this.a = var1;
         this.b = var2;
      }

      public boolean a(oo var1, bhc var2, int var3) {
         if (!this.a.a(var2.b, var2.c, var2.d, var1.p, var1.q, var1.r)) {
            return false;
         } else {
            return this.b.a((float)var3);
         }
      }
   }
}
