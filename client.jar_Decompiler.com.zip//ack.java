import javax.annotation.Nullable;

public class ack extends ve {
   private static final mx<Integer> a;
   @Nullable
   private vn b;
   private int c;

   public ack(ams var1) {
      super(var1);
      this.c = 80;
      this.i = true;
      this.X = true;
      this.a(0.98F, 0.98F);
   }

   public ack(ams var1, double var2, double var4, double var6, vn var8) {
      this(var1);
      this.b(var2, var4, var6);
      float var9 = (float)(Math.random() * 6.2831854820251465D);
      this.s = (double)(-((float)Math.sin((double)var9)) * 0.02F);
      this.t = 0.20000000298023224D;
      this.u = (double)(-((float)Math.cos((double)var9)) * 0.02F);
      this.a(80);
      this.m = var2;
      this.n = var4;
      this.o = var6;
      this.b = var8;
   }

   protected void i() {
      this.Y.a((mx)a, (int)80);
   }

   protected boolean ak() {
      return false;
   }

   public boolean ay() {
      return !this.F;
   }

   public void B_() {
      this.m = this.p;
      this.n = this.q;
      this.o = this.r;
      if (!this.aj()) {
         this.t -= 0.03999999910593033D;
      }

      this.a(vt.a, this.s, this.t, this.u);
      this.s *= 0.9800000190734863D;
      this.t *= 0.9800000190734863D;
      this.u *= 0.9800000190734863D;
      if (this.z) {
         this.s *= 0.699999988079071D;
         this.u *= 0.699999988079071D;
         this.t *= -0.5D;
      }

      --this.c;
      if (this.c <= 0) {
         this.X();
         if (!this.l.G) {
            this.n();
         }
      } else {
         this.aq();
         this.l.a(fj.l, this.p, this.q + 0.5D, this.r, 0.0D, 0.0D, 0.0D);
      }

   }

   private void n() {
      float var1 = 4.0F;
      this.l.a(this, this.p, this.q + (double)(this.H / 16.0F), this.r, 4.0F, true);
   }

   protected void b(fy var1) {
      var1.a("Fuse", (short)this.l());
   }

   protected void a(fy var1) {
      this.a(var1.g("Fuse"));
   }

   @Nullable
   public vn j() {
      return this.b;
   }

   public float by() {
      return 0.0F;
   }

   public void a(int var1) {
      this.Y.b(a, var1);
      this.c = var1;
   }

   public void a(mx<?> var1) {
      if (a.equals(var1)) {
         this.c = this.k();
      }

   }

   public int k() {
      return (Integer)this.Y.a(a);
   }

   public int l() {
      return this.c;
   }

   static {
      a = na.a(ack.class, mz.b);
   }
}
