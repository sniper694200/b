import java.util.Random;

public class ato extends aou {
   public ato(bcx var1) {
      super(var1);
      this.a(ahn.b);
   }

   public int a(Random var1) {
      return 2 + var1.nextInt(2);
   }

   public int a(int var1, Random var2) {
      return ri.a(this.a(var2) + var2.nextInt(var1 + 1), 1, 5);
   }

   public ail a(awr var1, Random var2, int var3) {
      return aip.cO;
   }

   public bcy c(awr var1, amw var2, et var3) {
      return bcy.q;
   }

   protected boolean n() {
      return true;
   }
}
