public class so implements rs {
   public int a() {
      return 113;
   }

   public fy a(fy var1) {
      ge var2;
      if (var1.b("HandDropChances", 9)) {
         var2 = var1.c("HandDropChances", 5);
         if (var2.c() == 2 && var2.g(0) == 0.0F && var2.g(1) == 0.0F) {
            var1.r("HandDropChances");
         }
      }

      if (var1.b("ArmorDropChances", 9)) {
         var2 = var1.c("ArmorDropChances", 5);
         if (var2.c() == 4 && var2.g(0) == 0.0F && var2.g(1) == 0.0F && var2.g(2) == 0.0F && var2.g(3) == 0.0F) {
            var1.r("ArmorDropChances");
         }
      }

      return var1;
   }
}
