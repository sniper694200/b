import java.util.Iterator;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public class bkl extends bli implements bln {
   private static final Logger f = LogManager.getLogger();
   private String g = "";
   private int h = -1;
   private blo i;
   protected bjc a;
   private String s = "";

   public bkl() {
   }

   public bkl(String var1) {
      this.s = var1;
   }

   public void b() {
      Keyboard.enableRepeatEvents(true);
      this.h = this.j.q.d().b().size();
      this.a = new bjc(0, this.q, 4, this.m - 12, this.l - 4, 12);
      this.a.f(256);
      this.a.a(false);
      this.a.b(true);
      this.a.a(this.s);
      this.a.d(false);
      this.i = new bkl.a(this.a);
   }

   public void m() {
      Keyboard.enableRepeatEvents(false);
      this.j.q.d().c();
   }

   public void e() {
      this.a.a();
   }

   protected void a(char var1, int var2) {
      this.i.d();
      if (var2 == 15) {
         this.i.a();
      } else {
         this.i.c();
      }

      if (var2 == 1) {
         this.j.a((bli)null);
      } else if (var2 != 28 && var2 != 156) {
         if (var2 == 200) {
            this.b(-1);
         } else if (var2 == 208) {
            this.b(1);
         } else if (var2 == 201) {
            this.j.q.d().b(this.j.q.d().h() - 1);
         } else if (var2 == 209) {
            this.j.q.d().b(-this.j.q.d().h() + 1);
         } else {
            this.a.a(var1, var2);
         }
      } else {
         String var3 = this.a.b().trim();
         if (!var3.isEmpty()) {
            this.f(var3);
         }

         this.j.a((bli)null);
      }

   }

   public void k() {
      super.k();
      int var1 = Mouse.getEventDWheel();
      if (var1 != 0) {
         if (var1 > 1) {
            var1 = 1;
         }

         if (var1 < -1) {
            var1 = -1;
         }

         if (!s()) {
            var1 *= 7;
         }

         this.j.q.d().b(var1);
      }

   }

   protected void a(int var1, int var2, int var3) {
      if (var3 == 0) {
         hh var4 = this.j.q.d().a(Mouse.getX(), Mouse.getY());
         if (var4 != null && this.a(var4)) {
            return;
         }
      }

      this.a.a(var1, var2, var3);
      super.a(var1, var2, var3);
   }

   protected void a(String var1, boolean var2) {
      if (var2) {
         this.a.a(var1);
      } else {
         this.a.b(var1);
      }

   }

   public void b(int var1) {
      int var2 = this.h + var1;
      int var3 = this.j.q.d().b().size();
      var2 = ri.a(var2, 0, var3);
      if (var2 != this.h) {
         if (var2 == var3) {
            this.h = var3;
            this.a.a(this.g);
         } else {
            if (this.h == var3) {
               this.g = this.a.b();
            }

            this.a.a((String)this.j.q.d().b().get(var2));
            this.h = var2;
         }
      }
   }

   public void a(int var1, int var2, float var3) {
      a(2, this.m - 14, this.l - 2, this.m - 2, Integer.MIN_VALUE);
      this.a.g();
      hh var4 = this.j.q.d().a(Mouse.getX(), Mouse.getY());
      if (var4 != null && var4.b().i() != null) {
         this.a(var4, var1, var2);
      }

      super.a(var1, var2, var3);
   }

   public boolean d() {
      return false;
   }

   public void a(String... var1) {
      this.i.a(var1);
   }

   public static class a extends blo {
      private final bhz g = bhz.z();

      public a(bjc var1) {
         super(var1, false);
      }

      public void a() {
         super.a();
         if (this.f.size() > 1) {
            StringBuilder var1 = new StringBuilder();

            String var3;
            for(Iterator var2 = this.f.iterator(); var2.hasNext(); var1.append(var3)) {
               var3 = (String)var2.next();
               if (var1.length() > 0) {
                  var1.append(", ");
               }
            }

            this.g.q.d().a(new ho(var1.toString()), 1);
         }

      }

      @Nullable
      public et b() {
         et var1 = null;
         if (this.g.s != null && this.g.s.a == bha.a.b) {
            var1 = this.g.s.a();
         }

         return var1;
      }
   }
}
