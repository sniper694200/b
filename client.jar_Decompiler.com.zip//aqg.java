import com.google.common.base.Predicates;
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;

public class aqg extends aou {
   public static final axe a;
   public static final axd b;
   protected static final bgz c;
   protected static final bgz d;
   private static awv e;

   public aqg() {
      super(bcx.e, bcy.D);
      this.w(this.A.b().a(a, fa.c).a(b, false));
   }

   public boolean b(awr var1) {
      return false;
   }

   public bgz b(awr var1, amw var2, et var3) {
      return c;
   }

   public void a(awr var1, ams var2, et var3, bgz var4, List<bgz> var5, @Nullable ve var6, boolean var7) {
      a(var3, var4, var5, c);
      if ((Boolean)var2.o(var3).c(b)) {
         a(var3, var4, var5, d);
      }

   }

   public ail a(awr var1, Random var2, int var3) {
      return aip.a;
   }

   public awr a(ams var1, et var2, fa var3, float var4, float var5, float var6, int var7, vn var8) {
      return this.t().a(a, var8.bt().d()).a(b, false);
   }

   public boolean v(awr var1) {
      return true;
   }

   public int c(awr var1, ams var2, et var3) {
      return (Boolean)var1.c(b) ? 15 : 0;
   }

   public awr a(int var1) {
      return this.t().a(b, (var1 & 4) != 0).a(a, fa.b(var1 & 3));
   }

   public int e(awr var1) {
      int var2 = 0;
      int var3 = var2 | ((fa)var1.c(a)).b();
      if ((Boolean)var1.c(b)) {
         var3 |= 4;
      }

      return var3;
   }

   public awr a(awr var1, atk var2) {
      return var1.a(a, var2.a((fa)var1.c(a)));
   }

   public awr a(awr var1, arw var2) {
      return var1.a(var2.a((fa)var1.c(a)));
   }

   protected aws b() {
      return new aws(this, new axh[]{a, b});
   }

   public boolean c(awr var1) {
      return false;
   }

   public static awv e() {
      if (e == null) {
         e = aww.a().a("?vvv?", ">???<", ">???<", ">???<", "?^^^?").a('?', awu.a(axa.a)).a('^', awu.a(axa.a(aov.bG).a(b, Predicates.equalTo(true)).a(a, Predicates.equalTo(fa.d)))).a('>', awu.a(axa.a(aov.bG).a(b, Predicates.equalTo(true)).a(a, Predicates.equalTo(fa.e)))).a('v', awu.a(axa.a(aov.bG).a(b, Predicates.equalTo(true)).a(a, Predicates.equalTo(fa.c)))).a('<', awu.a(axa.a(aov.bG).a(b, Predicates.equalTo(true)).a(a, Predicates.equalTo(fa.f)))).b();
      }

      return e;
   }

   public awp a(amw var1, awr var2, et var3, fa var4) {
      return var4 == fa.a ? awp.a : awp.i;
   }

   static {
      a = ark.D;
      b = axd.a("eye");
      c = new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.8125D, 1.0D);
      d = new bgz(0.3125D, 0.8125D, 0.3125D, 0.6875D, 1.0D, 0.6875D);
   }
}
