import com.mojang.authlib.GameProfile;
import com.mojang.authlib.exceptions.AuthenticationUnavailableException;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.util.concurrent.Future;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.charset.StandardCharsets;
import java.security.PrivateKey;
import java.util.Arrays;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import javax.annotation.Nullable;
import javax.crypto.SecretKey;
import net.minecraft.server.MinecraftServer;
import org.apache.commons.lang3.Validate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class pa implements mk, nv {
   private static final AtomicInteger b = new AtomicInteger(0);
   private static final Logger c = LogManager.getLogger();
   private static final Random d = new Random();
   private final byte[] e = new byte[4];
   private final MinecraftServer f;
   public final gw a;
   private pa.a g;
   private int h;
   private GameProfile i;
   private final String j;
   private SecretKey k;
   private oo l;

   public pa(MinecraftServer var1, gw var2) {
      this.g = pa.a.a;
      this.j = "";
      this.f = var1;
      this.a = var2;
      d.nextBytes(this.e);
   }

   public void e() {
      if (this.g == pa.a.d) {
         this.b();
      } else if (this.g == pa.a.e) {
         oo var1 = this.f.am().a(this.i.getId());
         if (var1 == null) {
            this.g = pa.a.d;
            this.f.am().a(this.a, this.l);
            this.l = null;
         }
      }

      if (this.h++ == 600) {
         this.b((hh)(new hp("multiplayer.disconnect.slow_login", new Object[0])));
      }

   }

   public void b(hh var1) {
      try {
         c.info("Disconnecting {}: {}", this.c(), var1.c());
         this.a.a((ht)(new mj(var1)));
         this.a.a(var1);
      } catch (Exception var3) {
         c.error("Error whilst disconnecting player", var3);
      }

   }

   public void b() {
      if (!this.i.isComplete()) {
         this.i = this.a(this.i);
      }

      String var1 = this.f.am().a(this.a.b(), this.i);
      if (var1 != null) {
         this.b((hh)(new hp(var1, new Object[0])));
      } else {
         this.g = pa.a.f;
         if (this.f.aG() >= 0 && !this.a.c()) {
            this.a.a(new mi(this.f.aG()), new ChannelFutureListener() {
               public void a(ChannelFuture var1) throws Exception {
                  pa.this.a.a(pa.this.f.aG());
               }

               // $FF: synthetic method
               public void operationComplete(Future var1) throws Exception {
                  this.a((ChannelFuture)var1);
               }
            });
         }

         this.a.a((ht)(new mg(this.i)));
         oo var2 = this.f.am().a(this.i.getId());
         if (var2 != null) {
            this.g = pa.a.e;
            this.l = this.f.am().g(this.i);
         } else {
            this.f.am().a(this.a, this.f.am().g(this.i));
         }
      }

   }

   public void a(hh var1) {
      c.info("{} lost connection: {}", this.c(), var1.c());
   }

   public String c() {
      return this.i != null ? this.i + " (" + this.a.b() + ")" : String.valueOf(this.a.b());
   }

   public void a(ml var1) {
      Validate.validState(this.g == pa.a.a, "Unexpected hello packet", new Object[0]);
      this.i = var1.a();
      if (this.f.ab() && !this.a.c()) {
         this.g = pa.a.b;
         this.a.a((ht)(new mh("", this.f.O().getPublic(), this.e)));
      } else {
         this.g = pa.a.d;
      }

   }

   public void a(mm var1) {
      Validate.validState(this.g == pa.a.b, "Unexpected key packet", new Object[0]);
      PrivateKey var2 = this.f.O().getPrivate();
      if (!Arrays.equals(this.e, var1.b(var2))) {
         throw new IllegalStateException("Invalid nonce!");
      } else {
         this.k = var1.a(var2);
         this.g = pa.a.c;
         this.a.a(this.k);
         (new Thread("User Authenticator #" + b.incrementAndGet()) {
            public void run() {
               GameProfile var1 = pa.this.i;

               try {
                  String var2 = (new BigInteger(qy.a("", pa.this.f.O().getPublic(), pa.this.k))).toString(16);
                  pa.this.i = pa.this.f.az().hasJoinedServer(new GameProfile((UUID)null, var1.getName()), var2, this.a());
                  if (pa.this.i != null) {
                     pa.c.info("UUID of player {} is {}", pa.this.i.getName(), pa.this.i.getId());
                     pa.this.g = pa.a.d;
                  } else if (pa.this.f.R()) {
                     pa.c.warn("Failed to verify username but will let them in anyway!");
                     pa.this.i = pa.this.a(var1);
                     pa.this.g = pa.a.d;
                  } else {
                     pa.this.b((hh)(new hp("multiplayer.disconnect.unverified_username", new Object[0])));
                     pa.c.error("Username '{}' tried to join with an invalid session", var1.getName());
                  }
               } catch (AuthenticationUnavailableException var3) {
                  if (pa.this.f.R()) {
                     pa.c.warn("Authentication servers are down but will let them in anyway!");
                     pa.this.i = pa.this.a(var1);
                     pa.this.g = pa.a.d;
                  } else {
                     pa.this.b((hh)(new hp("multiplayer.disconnect.authservers_down", new Object[0])));
                     pa.c.error("Couldn't verify username because servers are unavailable");
                  }
               }

            }

            @Nullable
            private InetAddress a() {
               SocketAddress var1 = pa.this.a.b();
               return pa.this.f.ac() && var1 instanceof InetSocketAddress ? ((InetSocketAddress)var1).getAddress() : null;
            }
         }).start();
      }
   }

   protected GameProfile a(GameProfile var1) {
      UUID var2 = UUID.nameUUIDFromBytes(("OfflinePlayer:" + var1.getName()).getBytes(StandardCharsets.UTF_8));
      return new GameProfile(var2, var1.getName());
   }

   static enum a {
      a,
      b,
      c,
      d,
      e,
      f;
   }
}
