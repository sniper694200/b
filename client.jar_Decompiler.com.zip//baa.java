import java.util.Random;

public class baa extends azs {
   private final aou a;
   private final int b;

   public baa(int var1) {
      this.a = aov.cB;
      this.b = var1;
   }

   public boolean b(ams var1, Random var2, et var3) {
      while(var1.d(var3) && var3.q() > 2) {
         var3 = var3.b();
      }

      if (var1.o(var3).u() != aov.aJ) {
         return false;
      } else {
         int var4 = var2.nextInt(this.b - 2) + 2;
         int var5 = true;

         for(int var6 = var3.p() - var4; var6 <= var3.p() + var4; ++var6) {
            for(int var7 = var3.r() - var4; var7 <= var3.r() + var4; ++var7) {
               int var8 = var6 - var3.p();
               int var9 = var7 - var3.r();
               if (var8 * var8 + var9 * var9 <= var4 * var4) {
                  for(int var10 = var3.q() - 1; var10 <= var3.q() + 1; ++var10) {
                     et var11 = new et(var6, var10, var7);
                     aou var12 = var1.o(var11).u();
                     if (var12 == aov.d || var12 == aov.aJ || var12 == aov.aI) {
                        var1.a((et)var11, (awr)this.a.t(), 2);
                     }
                  }
               }
            }
         }

         return true;
      }
   }
}
