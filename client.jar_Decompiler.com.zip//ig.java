import java.io.IOException;

public class ig implements ht<hw> {
   private int a;
   private et b;
   private int c;

   public ig() {
   }

   public ig(int var1, et var2, int var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }

   public void a(gy var1) throws IOException {
      this.a = var1.g();
      this.b = var1.e();
      this.c = var1.readUnsignedByte();
   }

   public void b(gy var1) throws IOException {
      var1.d(this.a);
      var1.a(this.b);
      var1.writeByte(this.c);
   }

   public void a(hw var1) {
      var1.a(this);
   }

   public int a() {
      return this.a;
   }

   public et b() {
      return this.b;
   }

   public int c() {
      return this.c;
   }
}
