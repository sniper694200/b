import com.google.common.collect.ImmutableSet;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Set;
import javax.annotation.Nullable;

public class cee implements cep {
   public static final Set<String> a = ImmutableSet.of("minecraft", "realms");
   private final cec b;

   public cee(cec var1) {
      this.b = var1;
   }

   public InputStream a(nd var1) throws IOException {
      InputStream var2 = this.d(var1);
      if (var2 != null) {
         return var2;
      } else {
         InputStream var3 = this.c(var1);
         if (var3 != null) {
            return var3;
         } else {
            throw new FileNotFoundException(var1.a());
         }
      }
   }

   @Nullable
   public InputStream c(nd var1) throws FileNotFoundException {
      File var2 = this.b.a(var1);
      return var2 != null && var2.isFile() ? new FileInputStream(var2) : null;
   }

   @Nullable
   private InputStream d(nd var1) {
      String var2 = "/assets/" + var1.b() + "/" + var1.a();

      try {
         URL var3 = cee.class.getResource(var2);
         return var3 != null && cei.a(new File(var3.getFile()), var2) ? cee.class.getResourceAsStream(var2) : null;
      } catch (IOException var4) {
         return cee.class.getResourceAsStream(var2);
      }
   }

   public boolean b(nd var1) {
      return this.d(var1) != null || this.b.b(var1);
   }

   public Set<String> c() {
      return a;
   }

   @Nullable
   public <T extends cfc> T a(cfe var1, String var2) throws IOException {
      try {
         InputStream var3 = new FileInputStream(this.b.a());
         return ceb.a(var1, var3, var2);
      } catch (RuntimeException var4) {
         return null;
      } catch (FileNotFoundException var5) {
         return null;
      }
   }

   public BufferedImage a() throws IOException {
      return cdr.a(cee.class.getResourceAsStream("/" + (new nd("pack.png")).a()));
   }

   public String b() {
      return "Default";
   }
}
