import javax.annotation.Nullable;

public class adb extends adj {
   public adb(ams var1) {
      super(var1);
      this.X = true;
   }

   public static void a(rw var0) {
      vo.a(var0, adb.class);
   }

   protected void bM() {
      super.bM();
      this.a(adf.d).a(0.20000000298023224D);
   }

   public boolean P() {
      return this.l.ag() != tx.a;
   }

   public boolean Q() {
      return this.l.a((bgz)this.bw(), (ve)this) && this.l.a((ve)this, (bgz)this.bw()).isEmpty() && !this.l.d(this.bw());
   }

   protected void a(int var1, boolean var2) {
      super.a(var1, var2);
      this.a(adf.h).a((double)(var1 * 3));
   }

   public int av() {
      return 15728880;
   }

   public float aw() {
      return 1.0F;
   }

   protected fj p() {
      return fj.A;
   }

   protected adj de() {
      return new adb(this.l);
   }

   @Nullable
   protected nd J() {
      return this.dm() ? bfl.a : bfl.ai;
   }

   public boolean aR() {
      return false;
   }

   protected int df() {
      return super.df() * 4;
   }

   protected void dg() {
      this.a *= 0.9F;
   }

   protected void cu() {
      this.t = (double)(0.42F + (float)this.dl() * 0.1F);
      this.ai = true;
   }

   protected void cw() {
      this.t = (double)(0.22F + (float)this.dl() * 0.05F);
      this.ai = true;
   }

   public void e(float var1, float var2) {
   }

   protected boolean dh() {
      return true;
   }

   protected int di() {
      return super.di() + 2;
   }

   protected qc d(up var1) {
      return this.dm() ? qd.hj : qd.dW;
   }

   protected qc cf() {
      return this.dm() ? qd.hi : qd.dV;
   }

   protected qc dj() {
      return this.dm() ? qd.hk : qd.dY;
   }

   protected qc dk() {
      return qd.dX;
   }
}
