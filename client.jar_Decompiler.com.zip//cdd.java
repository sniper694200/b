public abstract class cdd implements cdq {
   protected int a = -1;
   protected boolean b;
   protected boolean c;
   protected boolean d;
   protected boolean e;

   public void a(boolean var1, boolean var2) {
      this.b = var1;
      this.c = var2;
      int var3;
      short var4;
      if (var1) {
         var3 = var2 ? 9987 : 9729;
         var4 = 9729;
      } else {
         var3 = var2 ? 9986 : 9728;
         var4 = 9728;
      }

      buq.b(3553, 10241, var3);
      buq.b(3553, 10240, var4);
   }

   public void b(boolean var1, boolean var2) {
      this.d = this.b;
      this.e = this.c;
      this.a(var1, var2);
   }

   public void a() {
      this.a(this.d, this.e);
   }

   public int b() {
      if (this.a == -1) {
         this.a = cdr.a();
      }

      return this.a;
   }

   public void c() {
      if (this.a != -1) {
         cdr.a(this.a);
         this.a = -1;
      }

   }
}
