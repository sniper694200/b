public class ccj implements cce<adm> {
   private static final nd a = new nd("textures/entity/skeleton/stray_overlay.png");
   private final bzy<?> b;
   private final bqu c = new bqu(0.25F, true);

   public ccj(bzy<?> var1) {
      this.b = var1;
   }

   public void a(adm var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8) {
      this.c.a(this.b.b());
      this.c.a(var1, var2, var3, var4);
      buq.c(1.0F, 1.0F, 1.0F, 1.0F);
      this.b.a((nd)a);
      this.c.a(var1, var2, var3, var5, var6, var7, var8);
   }

   public boolean a() {
      return true;
   }
}
