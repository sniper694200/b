import java.util.Iterator;
import java.util.List;

public class asu extends aop {
   public static final axd d = axd.a("powered");
   private final asu.a e;

   protected asu(bcx var1, asu.a var2) {
      super(var1);
      this.w(this.A.b().a(d, false));
      this.e = var2;
   }

   protected int i(awr var1) {
      return (Boolean)var1.c(d) ? 15 : 0;
   }

   protected awr a(awr var1, int var2) {
      return var1.a(d, var2 > 0);
   }

   protected void b(ams var1, et var2) {
      if (this.x == bcx.d) {
         var1.a((aeb)null, var2, qd.jg, qe.e, 0.3F, 0.8F);
      } else {
         var1.a((aeb)null, var2, qd.hP, qe.e, 0.3F, 0.6F);
      }

   }

   protected void c(ams var1, et var2) {
      if (this.x == bcx.d) {
         var1.a((aeb)null, var2, qd.jf, qe.e, 0.3F, 0.7F);
      } else {
         var1.a((aeb)null, var2, qd.hO, qe.e, 0.3F, 0.5F);
      }

   }

   protected int e(ams var1, et var2) {
      bgz var3 = c.a(var2);
      List var4;
      switch(this.e) {
      case a:
         var4 = var1.b((ve)null, (bgz)var3);
         break;
      case b:
         var4 = var1.a(vn.class, var3);
         break;
      default:
         return 0;
      }

      if (!var4.isEmpty()) {
         Iterator var5 = var4.iterator();

         while(var5.hasNext()) {
            ve var6 = (ve)var5.next();
            if (!var6.bk()) {
               return 15;
            }
         }
      }

      return 0;
   }

   public awr a(int var1) {
      return this.t().a(d, var1 == 1);
   }

   public int e(awr var1) {
      return (Boolean)var1.c(d) ? 1 : 0;
   }

   protected aws b() {
      return new aws(this, new axh[]{d});
   }

   public static enum a {
      a,
      b;
   }
}
