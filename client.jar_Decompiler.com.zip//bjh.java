public class bjh extends tr {
   protected float h;
   protected long i;

   public bjh(ik var1) {
      super(var1.a(), var1.c(), var1.e(), var1.f());
      this.h = var1.d();
      this.b = var1.d();
      this.i = bhz.I();
      this.a(var1.g());
      this.b(var1.h());
      this.c(var1.i());
   }

   public void a(float var1) {
      this.b = this.f();
      this.h = var1;
      this.i = bhz.I();
   }

   public float f() {
      long var1 = bhz.I() - this.i;
      float var3 = ri.a((float)var1 / 100.0F, 0.0F, 1.0F);
      return this.b + (this.h - this.b) * var3;
   }

   public void a(ik var1) {
      switch(var1.b()) {
      case d:
         this.a(var1.c());
         break;
      case c:
         this.a(var1.d());
         break;
      case e:
         this.a(var1.e());
         this.a(var1.f());
         break;
      case f:
         this.a(var1.g());
         this.b(var1.h());
      }

   }
}
