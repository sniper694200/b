import java.io.File;
import javax.annotation.Nullable;

public class bew extends bez {
   public bew(File var1, String var2, boolean var3, rw var4) {
      super(var1, var2, var3, var4);
   }

   public ayd a(ayk var1) {
      File var2 = this.b();
      File var3;
      if (var1 instanceof aym) {
         var3 = new File(var2, "DIM-1");
         var3.mkdirs();
         return new ayc(var3, this.a);
      } else if (var1 instanceof ayq) {
         var3 = new File(var2, "DIM1");
         var3.mkdirs();
         return new ayc(var3, this.a);
      } else {
         return new ayc(var2, this.a);
      }
   }

   public void a(bfb var1, @Nullable fy var2) {
      var1.e(19133);
      super.a(var1, var2);
   }

   public void a() {
      try {
         bgv.a().b();
      } catch (InterruptedException var2) {
         var2.printStackTrace();
      }

      ayi.a();
   }
}
