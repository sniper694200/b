import com.google.common.base.Predicate;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class aex extends aet {
   private static final mx<ain> e;
   private static final Logger f;
   public static final Predicate<vn> d;

   public aex(ams var1) {
      super(var1);
   }

   public aex(ams var1, vn var2, ain var3) {
      super(var1, var2);
      this.a(var3);
   }

   public aex(ams var1, double var2, double var4, double var6, ain var8) {
      super(var1, var2, var4, var6);
      if (!var8.b()) {
         this.a(var8);
      }

   }

   protected void i() {
      this.V().a((mx)e, (Object)ain.a);
   }

   public ain l() {
      ain var1 = (ain)this.V().a(e);
      if (var1.c() != aip.bI && var1.c() != aip.bJ) {
         if (this.l != null) {
            f.error("ThrownPotion entity {} has no item?!", this.S());
         }

         return new ain(aip.bI);
      } else {
         return var1;
      }
   }

   public void a(ain var1) {
      this.V().b(e, var1);
      this.V().b(e);
   }

   protected float j() {
      return 0.05F;
   }

   protected void a(bha var1) {
      if (!this.l.G) {
         ain var2 = this.l();
         ake var3 = akg.d(var2);
         List<uy> var4 = akg.a(var2);
         boolean var5 = var3 == akh.b && var4.isEmpty();
         if (var1.a == bha.a.b && var5) {
            et var6 = var1.a().a(var1.b);
            this.a(var6, var1.b);
            Iterator var7 = fa.c.a.iterator();

            while(var7.hasNext()) {
               fa var8 = (fa)var7.next();
               this.a(var6.a(var8), var8);
            }
         }

         if (var5) {
            this.n();
         } else if (!var4.isEmpty()) {
            if (this.p()) {
               this.a(var2, var3);
            } else {
               this.a(var1, var4);
            }
         }

         int var9 = var3.c() ? 2007 : 2002;
         this.l.b(var9, new et(this), akg.c(var2));
         this.X();
      }
   }

   private void n() {
      bgz var1 = this.bw().c(4.0D, 2.0D, 4.0D);
      List<vn> var2 = this.l.a(vn.class, var1, d);
      if (!var2.isEmpty()) {
         Iterator var3 = var2.iterator();

         while(var3.hasNext()) {
            vn var4 = (vn)var3.next();
            double var5 = this.h(var4);
            if (var5 < 16.0D && c(var4)) {
               var4.a(up.h, 1.0F);
            }
         }
      }

   }

   private void a(bha var1, List<uy> var2) {
      bgz var3 = this.bw().c(4.0D, 2.0D, 4.0D);
      List<vn> var4 = this.l.a(vn.class, var3);
      if (!var4.isEmpty()) {
         Iterator var5 = var4.iterator();

         while(true) {
            vn var6;
            double var7;
            do {
               do {
                  if (!var5.hasNext()) {
                     return;
                  }

                  var6 = (vn)var5.next();
               } while(!var6.cR());

               var7 = this.h(var6);
            } while(!(var7 < 16.0D));

            double var9 = 1.0D - Math.sqrt(var7) / 4.0D;
            if (var6 == var1.d) {
               var9 = 1.0D;
            }

            Iterator var11 = var2.iterator();

            while(var11.hasNext()) {
               uy var12 = (uy)var11.next();
               ux var13 = var12.a();
               if (var13.b()) {
                  var13.a(this, this.k(), var6, var12.c(), var9);
               } else {
                  int var14 = (int)(var9 * (double)var12.b() + 0.5D);
                  if (var14 > 20) {
                     var6.c(new uy(var13, var14, var12.c(), var12.d(), var12.e()));
                  }
               }
            }
         }
      }
   }

   private void a(ain var1, ake var2) {
      vc var3 = new vc(this.l, this.p, this.q, this.r);
      var3.a(this.k());
      var3.a(3.0F);
      var3.b(-0.5F);
      var3.g(10);
      var3.c(-var3.j() / (float)var3.r());
      var3.a(var2);
      Iterator var4 = akg.b(var1).iterator();

      while(var4.hasNext()) {
         uy var5 = (uy)var4.next();
         var3.a(new uy(var5));
      }

      fy var6 = var1.p();
      if (var6 != null && var6.b("CustomPotionColor", 99)) {
         var3.a(var6.h("CustomPotionColor"));
      }

      this.l.a((ve)var3);
   }

   private boolean p() {
      return this.l().c() == aip.bJ;
   }

   private void a(et var1, fa var2) {
      if (this.l.o(var1).u() == aov.ab) {
         this.l.a((aeb)null, (et)var1.a(var2), (fa)var2.d());
      }

   }

   public static void a(rw var0) {
      aet.a(var0, "ThrownPotion");
      var0.a((ru)ru.e, (ry)(new ti(aex.class, new String[]{"Potion"})));
   }

   public void a(fy var1) {
      super.a(var1);
      ain var2 = new ain(var1.p("Potion"));
      if (var2.b()) {
         this.X();
      } else {
         this.a(var2);
      }

   }

   public void b(fy var1) {
      super.b(var1);
      ain var2 = this.l();
      if (!var2.b()) {
         var1.a((String)"Potion", (gn)var2.a(new fy()));
      }

   }

   private static boolean c(vn var0) {
      return var0 instanceof acs || var0 instanceof aco;
   }

   static {
      e = na.a(aex.class, mz.f);
      f = LogManager.getLogger();
      d = new Predicate<vn>() {
         public boolean a(@Nullable vn var1) {
            return aex.c(var1);
         }

         // $FF: synthetic method
         public boolean apply(@Nullable Object var1) {
            return this.a((vn)var1);
         }
      };
   }
}
