public class bsu extends btd {
   private static final nd a = new nd("textures/particle/footprint.png");
   private int b;
   private final int L;
   private final cdp M;

   protected bsu(cdp var1, ams var2, double var3, double var5, double var7) {
      super(var2, var3, var5, var7, 0.0D, 0.0D, 0.0D);
      this.M = var1;
      this.j = 0.0D;
      this.k = 0.0D;
      this.l = 0.0D;
      this.L = 200;
   }

   public void a(bui var1, ve var2, float var3, float var4, float var5, float var6, float var7, float var8) {
      float var9 = ((float)this.b + var3) / (float)this.L;
      var9 *= var9;
      float var10 = 2.0F - var9 * 2.0F;
      if (var10 > 1.0F) {
         var10 = 1.0F;
      }

      var10 *= 0.2F;
      buq.g();
      float var11 = 0.125F;
      float var12 = (float)(this.g - H);
      float var13 = (float)(this.h - I);
      float var14 = (float)(this.i - J);
      float var15 = this.c.n(new et(this.g, this.h, this.i));
      this.M.a(a);
      buq.m();
      buq.a(buq.r.l, buq.l.j);
      var1.a(7, cdw.i);
      var1.b((double)(var12 - 0.125F), (double)var13, (double)(var14 + 0.125F)).a(0.0D, 1.0D).a(var15, var15, var15, var10).d();
      var1.b((double)(var12 + 0.125F), (double)var13, (double)(var14 + 0.125F)).a(1.0D, 1.0D).a(var15, var15, var15, var10).d();
      var1.b((double)(var12 + 0.125F), (double)var13, (double)(var14 - 0.125F)).a(1.0D, 0.0D).a(var15, var15, var15, var10).d();
      var1.b((double)(var12 - 0.125F), (double)var13, (double)(var14 - 0.125F)).a(0.0D, 0.0D).a(var15, var15, var15, var10).d();
      bvc.a().b();
      buq.l();
      buq.f();
   }

   public void a() {
      ++this.b;
      if (this.b == this.L) {
         this.i();
      }

   }

   public int b() {
      return 3;
   }

   public static class a implements btf {
      public btd a(int var1, ams var2, double var3, double var5, double var7, double var9, double var11, double var13, int... var15) {
         return new bsu(bhz.z().N(), var2, var3, var5, var7);
      }
   }
}
