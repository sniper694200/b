import java.io.IOException;

public class lo implements ht<kw> {
   private et a;
   private fa b;
   private lo.a c;

   public lo() {
   }

   public lo(lo.a var1, et var2, fa var3) {
      this.c = var1;
      this.a = var2;
      this.b = var3;
   }

   public void a(gy var1) throws IOException {
      this.c = (lo.a)var1.a(lo.a.class);
      this.a = var1.e();
      this.b = fa.a(var1.readUnsignedByte());
   }

   public void b(gy var1) throws IOException {
      var1.a((Enum)this.c);
      var1.a(this.a);
      var1.writeByte(this.b.a());
   }

   public void a(kw var1) {
      var1.a(this);
   }

   public et a() {
      return this.a;
   }

   public fa b() {
      return this.b;
   }

   public lo.a c() {
      return this.c;
   }

   public static enum a {
      a,
      b,
      c,
      d,
      e,
      f,
      g;
   }
}
