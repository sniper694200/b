public class yf extends xc {
   private final aam a;
   private final double b;
   private double c;
   private double d;
   private double e;

   public yf(aam var1, double var2) {
      this.a = var1;
      this.b = var2;
      this.a(1);
   }

   public boolean a() {
      if (!this.a.du() && this.a.aT()) {
         bhc var1 = zj.a(this.a, 5, 4);
         if (var1 == null) {
            return false;
         } else {
            this.c = var1.b;
            this.d = var1.c;
            this.e = var1.d;
            return true;
         }
      } else {
         return false;
      }
   }

   public void c() {
      this.a.x().a(this.c, this.d, this.e, this.b);
   }

   public boolean b() {
      return !this.a.du() && !this.a.x().o() && this.a.aT();
   }

   public void e() {
      if (!this.a.du() && this.a.bR().nextInt(50) == 0) {
         ve var1 = (ve)this.a.bF().get(0);
         if (var1 == null) {
            return;
         }

         if (var1 instanceof aeb) {
            int var2 = this.a.dB();
            int var3 = this.a.dH();
            if (var3 > 0 && this.a.bR().nextInt(var3) < var2) {
               this.a.h((aeb)var1);
               return;
            }

            this.a.n(5);
         }

         this.a.aH();
         this.a.dK();
         this.a.l.a((ve)this.a, (byte)6);
      }

   }
}
