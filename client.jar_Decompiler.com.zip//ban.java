import java.util.Random;

public class ban extends aze {
   private static final awr a;
   private static final awr b;

   public ban(boolean var1) {
      super(var1);
   }

   public boolean b(ams var1, Random var2, et var3) {
      int var4 = var2.nextInt(3) + var2.nextInt(2) + 6;
      int var5 = var3.p();
      int var6 = var3.q();
      int var7 = var3.r();
      if (var6 >= 1 && var6 + var4 + 1 < 256) {
         et var8 = var3.b();
         aou var9 = var1.o(var8).u();
         if (var9 != aov.c && var9 != aov.d) {
            return false;
         } else if (!this.a(var1, var3, var4)) {
            return false;
         } else {
            this.a(var1, var8);
            this.a(var1, var8.f());
            this.a(var1, var8.d());
            this.a(var1, var8.d().f());
            fa var10 = fa.c.a.a(var2);
            int var11 = var4 - var2.nextInt(4);
            int var12 = 2 - var2.nextInt(3);
            int var13 = var5;
            int var14 = var7;
            int var15 = var6 + var4 - 1;

            int var16;
            int var17;
            for(var16 = 0; var16 < var4; ++var16) {
               if (var16 >= var11 && var12 > 0) {
                  var13 += var10.g();
                  var14 += var10.i();
                  --var12;
               }

               var17 = var6 + var16;
               et var18 = new et(var13, var17, var14);
               bcx var19 = var1.o(var18).a();
               if (var19 == bcx.a || var19 == bcx.j) {
                  this.b(var1, var18);
                  this.b(var1, var18.f());
                  this.b(var1, var18.d());
                  this.b(var1, var18.f().d());
               }
            }

            for(var16 = -2; var16 <= 0; ++var16) {
               for(var17 = -2; var17 <= 0; ++var17) {
                  int var21 = -1;
                  this.a(var1, var13 + var16, var15 + var21, var14 + var17);
                  this.a(var1, 1 + var13 - var16, var15 + var21, var14 + var17);
                  this.a(var1, var13 + var16, var15 + var21, 1 + var14 - var17);
                  this.a(var1, 1 + var13 - var16, var15 + var21, 1 + var14 - var17);
                  if ((var16 > -2 || var17 > -1) && (var16 != -1 || var17 != -2)) {
                     int var22 = 1;
                     this.a(var1, var13 + var16, var15 + var22, var14 + var17);
                     this.a(var1, 1 + var13 - var16, var15 + var22, var14 + var17);
                     this.a(var1, var13 + var16, var15 + var22, 1 + var14 - var17);
                     this.a(var1, 1 + var13 - var16, var15 + var22, 1 + var14 - var17);
                  }
               }
            }

            if (var2.nextBoolean()) {
               this.a(var1, var13, var15 + 2, var14);
               this.a(var1, var13 + 1, var15 + 2, var14);
               this.a(var1, var13 + 1, var15 + 2, var14 + 1);
               this.a(var1, var13, var15 + 2, var14 + 1);
            }

            for(var16 = -3; var16 <= 4; ++var16) {
               for(var17 = -3; var17 <= 4; ++var17) {
                  if ((var16 != -3 || var17 != -3) && (var16 != -3 || var17 != 4) && (var16 != 4 || var17 != -3) && (var16 != 4 || var17 != 4) && (Math.abs(var16) < 3 || Math.abs(var17) < 3)) {
                     this.a(var1, var13 + var16, var15, var14 + var17);
                  }
               }
            }

            for(var16 = -1; var16 <= 2; ++var16) {
               for(var17 = -1; var17 <= 2; ++var17) {
                  if ((var16 < 0 || var16 > 1 || var17 < 0 || var17 > 1) && var2.nextInt(3) <= 0) {
                     int var23 = var2.nextInt(3) + 2;

                     int var24;
                     for(var24 = 0; var24 < var23; ++var24) {
                        this.b(var1, new et(var5 + var16, var15 - var24 - 1, var7 + var17));
                     }

                     int var20;
                     for(var24 = -1; var24 <= 1; ++var24) {
                        for(var20 = -1; var20 <= 1; ++var20) {
                           this.a(var1, var13 + var16 + var24, var15, var14 + var17 + var20);
                        }
                     }

                     for(var24 = -2; var24 <= 2; ++var24) {
                        for(var20 = -2; var20 <= 2; ++var20) {
                           if (Math.abs(var24) != 2 || Math.abs(var20) != 2) {
                              this.a(var1, var13 + var16 + var24, var15 - 1, var14 + var17 + var20);
                           }
                        }
                     }
                  }
               }
            }

            return true;
         }
      } else {
         return false;
      }
   }

   private boolean a(ams var1, et var2, int var3) {
      int var4 = var2.p();
      int var5 = var2.q();
      int var6 = var2.r();
      et.a var7 = new et.a();

      for(int var8 = 0; var8 <= var3 + 1; ++var8) {
         int var9 = 1;
         if (var8 == 0) {
            var9 = 0;
         }

         if (var8 >= var3 - 1) {
            var9 = 2;
         }

         for(int var10 = -var9; var10 <= var9; ++var10) {
            for(int var11 = -var9; var11 <= var9; ++var11) {
               if (!this.a(var1.o(var7.c(var4 + var10, var5 + var8, var6 + var11)).u())) {
                  return false;
               }
            }
         }
      }

      return true;
   }

   private void b(ams var1, et var2) {
      if (this.a(var1.o(var2).u())) {
         this.a(var1, var2, a);
      }

   }

   private void a(ams var1, int var2, int var3, int var4) {
      et var5 = new et(var2, var3, var4);
      bcx var6 = var1.o(var5).a();
      if (var6 == bcx.a) {
         this.a(var1, var5, b);
      }

   }

   static {
      a = aov.s.t().a(asf.b, asp.a.f);
      b = aov.u.t().a(ase.e, asp.a.f).a(arp.b, false);
   }
}
