import java.util.Random;

public class bau extends azs {
   private final awr a;

   public bau(aul.a var1) {
      this.a = aov.H.t().a(aul.a, var1);
   }

   public boolean b(ams var1, Random var2, et var3) {
      for(awr var4 = var1.o(var3); (var4.a() == bcx.a || var4.a() == bcx.j) && var3.q() > 0; var4 = var1.o(var3)) {
         var3 = var3.b();
      }

      for(int var5 = 0; var5 < 128; ++var5) {
         et var6 = var3.a(var2.nextInt(8) - var2.nextInt(8), var2.nextInt(4) - var2.nextInt(4), var2.nextInt(8) - var2.nextInt(8));
         if (var1.d(var6) && aov.H.f(var1, var6, this.a)) {
            var1.a((et)var6, (awr)this.a, 2);
         }
      }

      return true;
   }
}
