public class bje extends biy {
   private final nd o;
   private final int p;
   private final int q;
   private final int r;

   public bje(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, nd var9) {
      super(var1, var2, var3, var4, var5, "");
      this.p = var6;
      this.q = var7;
      this.r = var8;
      this.o = var9;
   }

   public void c(int var1, int var2) {
      this.h = var1;
      this.i = var2;
   }

   public void a(bhz var1, int var2, int var3, float var4) {
      if (this.m) {
         this.n = var2 >= this.h && var3 >= this.i && var2 < this.h + this.f && var3 < this.i + this.g;
         var1.N().a(this.o);
         buq.j();
         int var5 = this.p;
         int var6 = this.q;
         if (this.n) {
            var6 += this.r;
         }

         this.b(this.h, this.i, var5, var6, this.f, this.g);
         buq.k();
      }
   }
}
