public class aaz extends ve {
   public final aay a;
   public final String b;

   public aaz(aay var1, String var2, float var3, float var4) {
      super(var1.a());
      this.a(var3, var4);
      this.a = var1;
      this.b = var2;
   }

   protected void i() {
   }

   protected void a(fy var1) {
   }

   protected void b(fy var1) {
   }

   public boolean ay() {
      return true;
   }

   public boolean a(up var1, float var2) {
      return this.b(var1) ? false : this.a.a(this, var1, var2);
   }

   public boolean s(ve var1) {
      return this == var1 || this.a == var1;
   }
}
