import java.io.File;

public class cef extends cec {
   private final File a;

   public cef(File var1) {
      this.a = var1;
   }

   public File a(nd var1) {
      return new File(this.a, var1.toString().replace(':', '/'));
   }

   public File a() {
      return new File(this.a, "pack.mcmeta");
   }
}
