public class afx extends afp {
   public afw a = new afw(this, 3, 3);
   public agl f = new agl();
   private final ams g;
   private final et h;
   private final aeb i;

   public afx(aea var1, ams var2, et var3) {
      this.g = var2;
      this.h = var3;
      this.i = var1.e;
      this.a((agp)(new agm(var1.e, this.a, this.f, 0, 124, 35)));

      int var4;
      int var5;
      for(var4 = 0; var4 < 3; ++var4) {
         for(var5 = 0; var5 < 3; ++var5) {
            this.a((agp)(new agp(this.a, var5 + var4 * 3, 30 + var5 * 18, 17 + var4 * 18)));
         }
      }

      for(var4 = 0; var4 < 3; ++var4) {
         for(var5 = 0; var5 < 9; ++var5) {
            this.a((agp)(new agp(var1, var5 + var4 * 9 + 9, 8 + var5 * 18, 84 + var4 * 18)));
         }
      }

      for(var4 = 0; var4 < 9; ++var4) {
         this.a((agp)(new agp(var1, var4, 8 + var4 * 18, 142)));
      }

   }

   public void a(tt var1) {
      this.a(this.g, this.i, this.a, this.f);
   }

   public void b(aeb var1) {
      super.b(var1);
      if (!this.g.G) {
         this.a(var1, this.g, this.a);
      }
   }

   public boolean a(aeb var1) {
      if (this.g.o(this.h).u() != aov.ai) {
         return false;
      } else {
         return var1.d((double)this.h.p() + 0.5D, (double)this.h.q() + 0.5D, (double)this.h.r() + 0.5D) <= 64.0D;
      }
   }

   public ain b(aeb var1, int var2) {
      ain var3 = ain.a;
      agp var4 = (agp)this.c.get(var2);
      if (var4 != null && var4.e()) {
         ain var5 = var4.d();
         var3 = var5.l();
         if (var2 == 0) {
            var5.c().b(var5, this.g, var1);
            if (!this.a(var5, 10, 46, true)) {
               return ain.a;
            }

            var4.a(var5, var3);
         } else if (var2 >= 10 && var2 < 37) {
            if (!this.a(var5, 37, 46, false)) {
               return ain.a;
            }
         } else if (var2 >= 37 && var2 < 46) {
            if (!this.a(var5, 10, 37, false)) {
               return ain.a;
            }
         } else if (!this.a(var5, 10, 46, false)) {
            return ain.a;
         }

         if (var5.b()) {
            var4.d(ain.a);
         } else {
            var4.f();
         }

         if (var5.E() == var3.E()) {
            return ain.a;
         }

         ain var6 = var4.a(var1, var5);
         if (var2 == 0) {
            var1.a(var6, false);
         }
      }

      return var3;
   }

   public boolean a(ain var1, agp var2) {
      return var2.d != this.f && super.a(var1, var2);
   }
}
