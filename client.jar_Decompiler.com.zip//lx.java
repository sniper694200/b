import java.io.IOException;

public class lx implements ht<kw> {
   private tz a;

   public lx() {
   }

   public lx(tz var1) {
      this.a = var1;
   }

   public void a(gy var1) throws IOException {
      this.a = (tz)var1.a(tz.class);
   }

   public void b(gy var1) throws IOException {
      var1.a((Enum)this.a);
   }

   public void a(kw var1) {
      var1.a(this);
   }

   public tz a() {
      return this.a;
   }
}
