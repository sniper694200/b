import com.mojang.authlib.GameProfile;
import java.io.File;
import javax.annotation.Nullable;

public abstract class bty extends aeb {
   private bsa d;
   public float a;
   public float b;
   public float c;

   public bty(ams var1, GameProfile var2) {
      super(var1, var2);
   }

   public boolean y() {
      bsa var1 = bhz.z().v().a(this.da().getId());
      return var1 != null && var1.b() == amq.e;
   }

   public boolean z() {
      bsa var1 = bhz.z().v().a(this.da().getId());
      return var1 != null && var1.b() == amq.c;
   }

   public boolean a() {
      return this.b() != null;
   }

   @Nullable
   protected bsa b() {
      if (this.d == null) {
         this.d = bhz.z().v().a(this.bm());
      }

      return this.d;
   }

   public boolean h() {
      bsa var1 = this.b();
      return var1 != null && var1.e();
   }

   public nd m() {
      bsa var1 = this.b();
      return var1 == null ? ced.a(this.bm()) : var1.g();
   }

   @Nullable
   public nd q() {
      bsa var1 = this.b();
      return var1 == null ? null : var1.h();
   }

   public boolean r() {
      return this.b() != null;
   }

   @Nullable
   public nd s() {
      bsa var1 = this.b();
      return var1 == null ? null : var1.i();
   }

   public static cdf a(nd var0, String var1) {
      cdp var2 = bhz.z().N();
      cdq var3 = var2.b(var0);
      if (var3 == null) {
         var3 = new cdf((File)null, String.format("http://skins.minecraft.net/MinecraftSkins/%s.png", rn.a(var1)), ced.a(d(var1)), new bux());
         var2.a((nd)var0, (cdq)var3);
      }

      return (cdf)var3;
   }

   public static nd e(String var0) {
      return new nd("skins/" + rn.a(var0));
   }

   public String t() {
      bsa var1 = this.b();
      return var1 == null ? ced.b(this.bm()) : var1.f();
   }

   public float u() {
      float var1 = 1.0F;
      if (this.bO.b) {
         var1 *= 1.1F;
      }

      wb var2 = this.a(adf.d);
      var1 = (float)((double)var1 * ((var2.e() / (double)this.bO.b() + 1.0D) / 2.0D));
      if (this.bO.b() == 0.0F || Float.isNaN(var1) || Float.isInfinite(var1)) {
         var1 = 1.0F;
      }

      if (this.cG() && this.cJ().c() == aip.g) {
         int var3 = this.cL();
         float var4 = (float)var3 / 20.0F;
         if (var4 > 1.0F) {
            var4 = 1.0F;
         } else {
            var4 *= var4;
         }

         var1 *= 1.0F - var4 * 0.15F;
      }

      return var1;
   }
}
