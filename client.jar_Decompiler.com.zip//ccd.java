public class ccd implements cce<aab> {
   private static final nd a = new nd("textures/entity/pig/pig_saddle.png");
   private final cai b;
   private final bqg c = new bqg(0.5F);

   public ccd(cai var1) {
      this.b = var1;
   }

   public void a(aab var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8) {
      if (var1.dl()) {
         this.b.a((nd)a);
         this.c.a(this.b.b());
         this.c.a(var1, var2, var3, var5, var6, var7, var8);
      }
   }

   public boolean a() {
      return false;
   }
}
