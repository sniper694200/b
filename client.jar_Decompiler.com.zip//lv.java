import java.io.IOException;

public class lv implements ht<kw> {
   private int a;
   private ain b;

   public lv() {
      this.b = ain.a;
   }

   public lv(int var1, ain var2) {
      this.b = ain.a;
      this.a = var1;
      this.b = var2.l();
   }

   public void a(kw var1) {
      var1.a(this);
   }

   public void a(gy var1) throws IOException {
      this.a = var1.readShort();
      this.b = var1.k();
   }

   public void b(gy var1) throws IOException {
      var1.writeShort(this.a);
      var1.a(this.b);
   }

   public int a() {
      return this.a;
   }

   public ain b() {
      return this.b;
   }
}
