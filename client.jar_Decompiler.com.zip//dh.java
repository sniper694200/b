import java.util.Iterator;
import net.minecraft.server.MinecraftServer;

public class dh extends bj implements bh {
   private final MinecraftServer a;

   public dh(MinecraftServer var1) {
      this.a = var1;
      this.a(new dz());
      this.a(new ck());
      this.a(new cj());
      this.a(new ca());
      this.a(new cp());
      this.a(new eb());
      this.a(new ee());
      this.a(new cg());
      this.a(new ec());
      this.a(new dt());
      this.a(new cm());
      this.a(new db());
      this.a(new dp());
      this.a(new cb());
      this.a(new cd());
      this.a(new cw());
      this.a(new cc());
      this.a(new dm());
      this.a(new cn());
      this.a(new bz());
      this.a(new cs());
      this.a(new df());
      this.a(new dk());
      this.a(new dl());
      this.a(new cl());
      this.a(new bw());
      this.a(new dy());
      this.a(new dn());
      this.a(new cx());
      this.a(new dg());
      this.a(new cf());
      this.a(new ed());
      this.a(new br());
      this.a(new cz());
      this.a(new ds());
      this.a(new di());
      this.a(new ch());
      this.a(new bx());
      this.a(new dx());
      this.a(new bv());
      this.a(new dw());
      this.a(new du());
      this.a(new eg());
      this.a(new ea());
      this.a(new ce());
      this.a(new dr());
      this.a(new cr());
      this.a(new da());
      this.a(new ci());
      if (var1.aa()) {
         this.a(new ct());
         this.a(new by());
         this.a(new dq());
         this.a(new dc());
         this.a(new dd());
         this.a(new de());
         this.a(new bs());
         this.a(new cu());
         this.a(new bu());
         this.a(new bt());
         this.a(new cv());
         this.a(new co());
         this.a(new cq());
         this.a(new ef());
         this.a(new dj());
      } else {
         this.a(new cy());
      }

      bi.a((bh)this);
   }

   public void a(bn var1, bk var2, int var3, String var4, Object... var5) {
      boolean var6 = true;
      MinecraftServer var7 = this.a;
      if (!var1.g()) {
         var6 = false;
      }

      hh var8 = new hp("chat.type.admin", new Object[]{var1.h_(), new hp(var4, var5)});
      var8.b().a(a.h);
      var8.b().b(true);
      if (var6) {
         Iterator var9 = var7.am().v().iterator();

         label85:
         while(true) {
            aeb var10;
            boolean var11;
            boolean var12;
            do {
               do {
                  do {
                     do {
                        if (!var9.hasNext()) {
                           break label85;
                        }

                        var10 = (aeb)var9.next();
                     } while(var10 == var1);
                  } while(!var7.am().h(var10.da()));
               } while(!var2.a(this.a, var1));

               var11 = var1 instanceof MinecraftServer && this.a.s();
               var12 = var1 instanceof pv && this.a.r();
            } while(!var11 && !var12 && (var1 instanceof pv || var1 instanceof MinecraftServer));

            var10.a((hh)var8);
         }
      }

      if (var1 != var7 && var7.d[0].W().b("logAdminCommands")) {
         var7.a((hh)var8);
      }

      boolean var13 = var7.d[0].W().b("sendCommandFeedback");
      if (var1 instanceof amh) {
         var13 = ((amh)var1).n();
      }

      if ((var3 & 1) != 1 && var13 || var1 instanceof MinecraftServer) {
         var1.a(new hp(var4, var5));
      }

   }

   protected MinecraftServer a() {
      return this.a;
   }
}
