import java.io.Closeable;
import java.io.InputStream;
import javax.annotation.Nullable;

public interface cem extends Closeable {
   nd a();

   InputStream b();

   boolean c();

   @Nullable
   <T extends cfc> T a(String var1);

   String d();
}
