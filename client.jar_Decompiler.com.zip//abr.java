import java.lang.reflect.Constructor;
import java.util.Arrays;

public class abr<T extends abl> {
   private static abr<?>[] l = new abr[0];
   public static final abr<abh> a = a(abh.class, "HoldingPattern");
   public static final abr<abp> b = a(abp.class, "StrafePlayer");
   public static final abr<abj> c = a(abj.class, "LandingApproach");
   public static final abr<abk> d = a(abk.class, "Landing");
   public static final abr<abq> e = a(abq.class, "Takeoff");
   public static final abr<abn> f = a(abn.class, "SittingFlaming");
   public static final abr<abo> g = a(abo.class, "SittingScanning");
   public static final abr<abm> h = a(abm.class, "SittingAttacking");
   public static final abr<abf> i = a(abf.class, "ChargingPlayer");
   public static final abr<abg> j = a(abg.class, "Dying");
   public static final abr<abi> k = a(abi.class, "Hover");
   private final Class<? extends abl> m;
   private final int n;
   private final String o;

   private abr(int var1, Class<? extends abl> var2, String var3) {
      this.n = var1;
      this.m = var2;
      this.o = var3;
   }

   public abl a(abb var1) {
      try {
         Constructor<? extends abl> var2 = this.a();
         return (abl)var2.newInstance(var1);
      } catch (Exception var3) {
         throw new Error(var3);
      }
   }

   protected Constructor<? extends abl> a() throws NoSuchMethodException {
      return this.m.getConstructor(abb.class);
   }

   public int b() {
      return this.n;
   }

   public String toString() {
      return this.o + " (#" + this.n + ")";
   }

   public static abr<?> a(int var0) {
      return var0 >= 0 && var0 < l.length ? l[var0] : a;
   }

   public static int c() {
      return l.length;
   }

   private static <T extends abl> abr<T> a(Class<T> var0, String var1) {
      abr<T> var2 = new abr(l.length, var0, var1);
      l = (abr[])Arrays.copyOf(l, l.length + 1);
      l[var2.b()] = var2;
      return var2;
   }
}
