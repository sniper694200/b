import java.io.IOException;

public class mu implements ht<mt> {
   private long a;

   public mu() {
   }

   public mu(long var1) {
      this.a = var1;
   }

   public void a(gy var1) throws IOException {
      this.a = var1.readLong();
   }

   public void b(gy var1) throws IOException {
      var1.writeLong(this.a);
   }

   public void a(mt var1) {
      var1.a(this);
   }

   public long a() {
      return this.a;
   }
}
