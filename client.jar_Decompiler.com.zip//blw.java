enum blw {
   a(0, 0, 28, 32, 8),
   b(84, 0, 28, 32, 8),
   c(0, 64, 32, 28, 5),
   d(96, 64, 32, 28, 5);

   public static final int e;
   private final int f;
   private final int g;
   private final int h;
   private final int i;
   private final int j;

   private blw(int var3, int var4, int var5, int var6, int var7) {
      this.f = var3;
      this.g = var4;
      this.h = var5;
      this.i = var6;
      this.j = var7;
   }

   public int a() {
      return this.j;
   }

   public void a(bip var1, int var2, int var3, boolean var4, int var5) {
      int var6 = this.f;
      if (var5 > 0) {
         var6 += this.h;
      }

      if (var5 == this.j - 1) {
         var6 += this.h;
      }

      int var7 = var4 ? this.g + this.i : this.g;
      var1.b(var2 + this.a(var5), var3 + this.b(var5), var6, var7, this.h, this.i);
   }

   public void a(int var1, int var2, int var3, bzu var4, ain var5) {
      int var6 = var1 + this.a(var3);
      int var7 = var2 + this.b(var3);
      switch(this) {
      case a:
         var6 += 6;
         var7 += 9;
         break;
      case b:
         var6 += 6;
         var7 += 6;
         break;
      case c:
         var6 += 10;
         var7 += 5;
         break;
      case d:
         var6 += 6;
         var7 += 5;
      }

      var4.a((vn)null, var5, var6, var7);
   }

   public int a(int var1) {
      switch(this) {
      case a:
         return (this.h + 4) * var1;
      case b:
         return (this.h + 4) * var1;
      case c:
         return -this.h + 4;
      case d:
         return 248;
      default:
         throw new UnsupportedOperationException("Don't know what this tab type is!" + this);
      }
   }

   public int b(int var1) {
      switch(this) {
      case a:
         return -this.i + 4;
      case b:
         return 136;
      case c:
         return this.i * var1;
      case d:
         return this.i * var1;
      default:
         throw new UnsupportedOperationException("Don't know what this tab type is!" + this);
      }
   }

   public boolean a(int var1, int var2, int var3, int var4, int var5) {
      int var6 = var1 + this.a(var3);
      int var7 = var2 + this.b(var3);
      return var4 > var6 && var4 < var6 + this.h && var5 > var7 && var5 < var7 + this.i;
   }

   static {
      int var0 = 0;
      blw[] var1 = values();
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         blw var4 = var1[var3];
         var0 += var4.j;
      }

      e = var0;
   }
}
