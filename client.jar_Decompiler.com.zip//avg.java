public class avg extends avh {
   private ahq a;

   public avg() {
      this.a = ahq.o;
   }

   public void a(ain var1) {
      this.a(ahq.b(var1.j()));
   }

   public void a(fy var1) {
      super.a(var1);
      if (var1.e("color")) {
         this.a = ahq.b(var1.h("color"));
      }

   }

   public fy b(fy var1) {
      super.b(var1);
      var1.a("color", this.a.a());
      return var1;
   }

   public fy d() {
      return this.b(new fy());
   }

   public ih c() {
      return new ih(this.c, 11, this.d());
   }

   public ahq a() {
      return this.a;
   }

   public void a(ahq var1) {
      this.a = var1;
      this.y_();
   }

   public boolean e() {
      return aos.b(this.v());
   }

   public ain f() {
      return new ain(aip.bi, 1, this.a.a());
   }
}
