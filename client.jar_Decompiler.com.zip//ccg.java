public class ccg implements cce<adj> {
   private final car a;
   private final bqd b = new bqw(0);

   public ccg(car var1) {
      this.a = var1;
   }

   public void a(adj var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8) {
      if (!var1.aX()) {
         buq.c(1.0F, 1.0F, 1.0F, 1.0F);
         buq.B();
         buq.m();
         buq.a(buq.r.l, buq.l.j);
         this.b.a(this.a.b());
         this.b.a(var1, var2, var3, var5, var6, var7, var8);
         buq.l();
         buq.C();
      }
   }

   public boolean a() {
      return true;
   }
}
