import com.google.common.base.Predicate;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;

public class avu extends avy implements avt, nv {
   private fi<ain> a;
   private int f;
   private long g;

   public avu() {
      this.a = fi.a(5, ain.a);
      this.f = -1;
   }

   public static void a(rw var0) {
      var0.a((ru)ru.d, (ry)(new tl(avu.class, new String[]{"Items"})));
   }

   public void a(fy var1) {
      super.a((fy)var1);
      this.a = fi.a(this.w_(), ain.a);
      if (!this.c(var1)) {
         tu.b(var1, this.a);
      }

      if (var1.b("CustomName", 8)) {
         this.o = var1.l("CustomName");
      }

      this.f = var1.h("TransferCooldown");
   }

   public fy b(fy var1) {
      super.b(var1);
      if (!this.d(var1)) {
         tu.a(var1, this.a);
      }

      var1.a("TransferCooldown", this.f);
      if (this.n_()) {
         var1.a("CustomName", this.o);
      }

      return var1;
   }

   public int w_() {
      return this.a.size();
   }

   public ain a(int var1, int var2) {
      this.d((aeb)null);
      ain var3 = tu.a(this.q(), var1, var2);
      return var3;
   }

   public void a(int var1, ain var2) {
      this.d((aeb)null);
      this.q().set(var1, var2);
      if (var2.E() > this.z_()) {
         var2.e(this.z_());
      }

   }

   public String h_() {
      return this.n_() ? this.o : "container.hopper";
   }

   public int z_() {
      return 64;
   }

   public void e() {
      if (this.b != null && !this.b.G) {
         --this.f;
         this.g = this.b.R();
         if (!this.J()) {
            this.d(0);
            this.o();
         }

      }
   }

   private boolean o() {
      if (this.b != null && !this.b.G) {
         if (!this.J() && arj.f(this.v())) {
            boolean var1 = false;
            if (!this.p()) {
               var1 = this.s();
            }

            if (!this.r()) {
               var1 = a((avt)this) || var1;
            }

            if (var1) {
               this.d(8);
               this.y_();
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private boolean p() {
      Iterator var1 = this.a.iterator();

      ain var2;
      do {
         if (!var1.hasNext()) {
            return true;
         }

         var2 = (ain)var1.next();
      } while(var2.b());

      return false;
   }

   public boolean x_() {
      return this.p();
   }

   private boolean r() {
      Iterator var1 = this.a.iterator();

      ain var2;
      do {
         if (!var1.hasNext()) {
            return true;
         }

         var2 = (ain)var1.next();
      } while(!var2.b() && var2.E() == var2.d());

      return false;
   }

   private boolean s() {
      tt var1 = this.I();
      if (var1 == null) {
         return false;
      } else {
         fa var2 = arj.b(this.v()).d();
         if (this.a(var1, var2)) {
            return false;
         } else {
            for(int var3 = 0; var3 < this.w_(); ++var3) {
               if (!this.a(var3).b()) {
                  ain var4 = this.a(var3).l();
                  ain var5 = a(this, var1, this.a(var3, 1), var2);
                  if (var5.b()) {
                     var1.y_();
                     return true;
                  }

                  this.a(var3, var4);
               }
            }

            return false;
         }
      }
   }

   private boolean a(tt var1, fa var2) {
      if (var1 instanceof ul) {
         ul var10 = (ul)var1;
         int[] var11 = var10.a(var2);
         int[] var12 = var11;
         int var6 = var11.length;

         for(int var7 = 0; var7 < var6; ++var7) {
            int var8 = var12[var7];
            ain var9 = var10.a(var8);
            if (var9.b() || var9.E() != var9.d()) {
               return false;
            }
         }
      } else {
         int var3 = var1.w_();

         for(int var4 = 0; var4 < var3; ++var4) {
            ain var5 = var1.a(var4);
            if (var5.b() || var5.E() != var5.d()) {
               return false;
            }
         }
      }

      return true;
   }

   private static boolean b(tt var0, fa var1) {
      if (var0 instanceof ul) {
         ul var2 = (ul)var0;
         int[] var3 = var2.a(var1);
         int[] var4 = var3;
         int var5 = var3.length;

         for(int var6 = 0; var6 < var5; ++var6) {
            int var7 = var4[var6];
            if (!var2.a(var7).b()) {
               return false;
            }
         }
      } else {
         int var8 = var0.w_();

         for(int var9 = 0; var9 < var8; ++var9) {
            if (!var0.a(var9).b()) {
               return false;
            }
         }
      }

      return true;
   }

   public static boolean a(avt var0) {
      tt var1 = b(var0);
      if (var1 != null) {
         fa var2 = fa.a;
         if (b(var1, var2)) {
            return false;
         }

         if (var1 instanceof ul) {
            ul var3 = (ul)var1;
            int[] var4 = var3.a(var2);
            int[] var5 = var4;
            int var6 = var4.length;

            for(int var7 = 0; var7 < var6; ++var7) {
               int var8 = var5[var7];
               if (a(var0, var1, var8, var2)) {
                  return true;
               }
            }
         } else {
            int var10 = var1.w_();

            for(int var12 = 0; var12 < var10; ++var12) {
               if (a(var0, var1, var12, var2)) {
                  return true;
               }
            }
         }
      } else {
         Iterator var9 = a(var0.D(), var0.E(), var0.F(), var0.G()).iterator();

         while(var9.hasNext()) {
            acj var11 = (acj)var9.next();
            if (a((tt)null, var0, var11)) {
               return true;
            }
         }
      }

      return false;
   }

   private static boolean a(avt var0, tt var1, int var2, fa var3) {
      ain var4 = var1.a(var2);
      if (!var4.b() && b(var1, var4, var2, var3)) {
         ain var5 = var4.l();
         ain var6 = a(var1, var0, var1.a(var2, 1), (fa)null);
         if (var6.b()) {
            var1.y_();
            return true;
         }

         var1.a(var2, var5);
      }

      return false;
   }

   public static boolean a(tt var0, tt var1, acj var2) {
      boolean var3 = false;
      if (var2 == null) {
         return false;
      } else {
         ain var4 = var2.k().l();
         ain var5 = a(var0, var1, var4, (fa)null);
         if (var5.b()) {
            var3 = true;
            var2.X();
         } else {
            var2.a(var5);
         }

         return var3;
      }
   }

   public static ain a(tt var0, tt var1, ain var2, @Nullable fa var3) {
      if (var1 instanceof ul && var3 != null) {
         ul var7 = (ul)var1;
         int[] var8 = var7.a(var3);

         for(int var6 = 0; var6 < var8.length && !var2.b(); ++var6) {
            var2 = a(var0, var1, var2, var8[var6], var3);
         }
      } else {
         int var4 = var1.w_();

         for(int var5 = 0; var5 < var4 && !var2.b(); ++var5) {
            var2 = a(var0, var1, var2, var5, var3);
         }
      }

      return var2;
   }

   private static boolean a(tt var0, ain var1, int var2, fa var3) {
      if (!var0.b(var2, var1)) {
         return false;
      } else {
         return !(var0 instanceof ul) || ((ul)var0).a(var2, var1, var3);
      }
   }

   private static boolean b(tt var0, ain var1, int var2, fa var3) {
      return !(var0 instanceof ul) || ((ul)var0).b(var2, var1, var3);
   }

   private static ain a(tt var0, tt var1, ain var2, int var3, fa var4) {
      ain var5 = var1.a(var3);
      if (a(var1, var2, var3, var4)) {
         boolean var6 = false;
         boolean var7 = var1.x_();
         if (var5.b()) {
            var1.a(var3, var2);
            var2 = ain.a;
            var6 = true;
         } else if (a(var5, var2)) {
            int var8 = var2.d() - var5.E();
            int var9 = Math.min(var2.E(), var8);
            var2.g(var9);
            var5.f(var9);
            var6 = var9 > 0;
         }

         if (var6) {
            if (var7 && var1 instanceof avu) {
               avu var11 = (avu)var1;
               if (!var11.K()) {
                  int var12 = 0;
                  if (var0 != null && var0 instanceof avu) {
                     avu var10 = (avu)var0;
                     if (var11.g >= var10.g) {
                        var12 = 1;
                     }
                  }

                  var11.d(8 - var12);
               }
            }

            var1.y_();
         }
      }

      return var2;
   }

   private tt I() {
      fa var1 = arj.b(this.v());
      return b(this.D(), this.E() + (double)var1.g(), this.F() + (double)var1.h(), this.G() + (double)var1.i());
   }

   public static tt b(avt var0) {
      return b(var0.D(), var0.E(), var0.F() + 1.0D, var0.G());
   }

   public static List<acj> a(ams var0, double var1, double var3, double var5) {
      return var0.a(acj.class, new bgz(var1 - 0.5D, var3, var5 - 0.5D, var1 + 0.5D, var3 + 1.5D, var5 + 0.5D), vi.a);
   }

   public static tt b(ams var0, double var1, double var3, double var5) {
      tt var7 = null;
      int var8 = ri.c(var1);
      int var9 = ri.c(var3);
      int var10 = ri.c(var5);
      et var11 = new et(var8, var9, var10);
      aou var12 = var0.o(var11).u();
      if (var12.l()) {
         avh var13 = var0.r(var11);
         if (var13 instanceof tt) {
            var7 = (tt)var13;
            if (var7 instanceof avj && var12 instanceof apg) {
               var7 = ((apg)var12).a(var0, var11, true);
            }
         }
      }

      if (var7 == null) {
         List<ve> var14 = var0.a((ve)null, (bgz)(new bgz(var1 - 0.5D, var3 - 0.5D, var5 - 0.5D, var1 + 0.5D, var3 + 0.5D, var5 + 0.5D)), (Predicate)vi.c);
         if (!var14.isEmpty()) {
            var7 = (tt)var14.get(var0.r.nextInt(var14.size()));
         }
      }

      return (tt)var7;
   }

   private static boolean a(ain var0, ain var1) {
      if (var0.c() != var1.c()) {
         return false;
      } else if (var0.j() != var1.j()) {
         return false;
      } else if (var0.E() > var0.d()) {
         return false;
      } else {
         return ain.a(var0, var1);
      }
   }

   public double E() {
      return (double)this.c.p() + 0.5D;
   }

   public double F() {
      return (double)this.c.q() + 0.5D;
   }

   public double G() {
      return (double)this.c.r() + 0.5D;
   }

   private void d(int var1) {
      this.f = var1;
   }

   private boolean J() {
      return this.f > 0;
   }

   private boolean K() {
      return this.f > 8;
   }

   public String l() {
      return "minecraft:hopper";
   }

   public afp a(aea var1, aeb var2) {
      this.d(var2);
      return new agd(var1, this, var2);
   }

   protected fi<ain> q() {
      return this.a;
   }
}
