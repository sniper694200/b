import java.util.Random;

public class bad extends azs {
   public boolean b(ams var1, Random var2, et var3) {
      if (!var1.d(var3)) {
         return false;
      } else if (var1.o(var3.a()).u() != aov.aV) {
         return false;
      } else {
         var1.a((et)var3, (awr)aov.aX.t(), 2);

         for(int var4 = 0; var4 < 1500; ++var4) {
            et var5 = var3.a(var2.nextInt(8) - var2.nextInt(8), -var2.nextInt(12), var2.nextInt(8) - var2.nextInt(8));
            if (var1.o(var5).a() == bcx.a) {
               int var6 = 0;
               fa[] var7 = fa.values();
               int var8 = var7.length;

               for(int var9 = 0; var9 < var8; ++var9) {
                  fa var10 = var7[var9];
                  if (var1.o(var5.a(var10)).u() == aov.aX) {
                     ++var6;
                  }

                  if (var6 > 1) {
                     break;
                  }
               }

               if (var6 == 1) {
                  var1.a((et)var5, (awr)aov.aX.t(), 2);
               }
            }
         }

         return true;
      }
   }
}
