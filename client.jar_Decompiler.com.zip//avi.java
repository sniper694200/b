import java.util.Arrays;
import java.util.Iterator;

public class avi extends avv implements nv, ul {
   private static final int[] a = new int[]{3};
   private static final int[] f = new int[]{0, 1, 2, 3};
   private static final int[] g = new int[]{0, 1, 2, 4};
   private fi<ain> h;
   private int i;
   private boolean[] j;
   private ail k;
   private String l;
   private int m;

   public avi() {
      this.h = fi.a(5, ain.a);
   }

   public String h_() {
      return this.n_() ? this.l : "container.brewing";
   }

   public boolean n_() {
      return this.l != null && !this.l.isEmpty();
   }

   public void a(String var1) {
      this.l = var1;
   }

   public int w_() {
      return this.h.size();
   }

   public boolean x_() {
      Iterator var1 = this.h.iterator();

      ain var2;
      do {
         if (!var1.hasNext()) {
            return true;
         }

         var2 = (ain)var1.next();
      } while(var2.b());

      return false;
   }

   public void e() {
      ain var1 = (ain)this.h.get(4);
      if (this.m <= 0 && var1.c() == aip.bO) {
         this.m = 20;
         var1.g(1);
         this.y_();
      }

      boolean var2 = this.o();
      boolean var3 = this.i > 0;
      ain var4 = (ain)this.h.get(3);
      if (var3) {
         --this.i;
         boolean var5 = this.i == 0;
         if (var5 && var2) {
            this.p();
            this.y_();
         } else if (!var2) {
            this.i = 0;
            this.y_();
         } else if (this.k != var4.c()) {
            this.i = 0;
            this.y_();
         }
      } else if (var2 && this.m > 0) {
         --this.m;
         this.i = 400;
         this.k = var4.c();
         this.y_();
      }

      if (!this.b.G) {
         boolean[] var8 = this.n();
         if (!Arrays.equals(var8, this.j)) {
            this.j = var8;
            awr var6 = this.b.o(this.w());
            if (!(var6.u() instanceof aoz)) {
               return;
            }

            for(int var7 = 0; var7 < aoz.a.length; ++var7) {
               var6 = var6.a(aoz.a[var7], var8[var7]);
            }

            this.b.a((et)this.c, (awr)var6, 2);
         }
      }

   }

   public boolean[] n() {
      boolean[] var1 = new boolean[3];

      for(int var2 = 0; var2 < 3; ++var2) {
         if (!((ain)this.h.get(var2)).b()) {
            var1[var2] = true;
         }
      }

      return var1;
   }

   private boolean o() {
      ain var1 = (ain)this.h.get(3);
      if (var1.b()) {
         return false;
      } else if (!akf.a(var1)) {
         return false;
      } else {
         for(int var2 = 0; var2 < 3; ++var2) {
            ain var3 = (ain)this.h.get(var2);
            if (!var3.b() && akf.a(var3, var1)) {
               return true;
            }
         }

         return false;
      }
   }

   private void p() {
      ain var1 = (ain)this.h.get(3);

      for(int var2 = 0; var2 < 3; ++var2) {
         this.h.set(var2, akf.d(var1, (ain)this.h.get(var2)));
      }

      var1.g(1);
      et var4 = this.w();
      if (var1.c().r()) {
         ain var3 = new ain(var1.c().q());
         if (var1.b()) {
            var1 = var3;
         } else {
            tw.a(this.b, (double)var4.p(), (double)var4.q(), (double)var4.r(), var3);
         }
      }

      this.h.set(3, var1);
      this.b.b(1035, var4, 0);
   }

   public static void a(rw var0) {
      var0.a((ru)ru.d, (ry)(new tl(avi.class, new String[]{"Items"})));
   }

   public void a(fy var1) {
      super.a(var1);
      this.h = fi.a(this.w_(), ain.a);
      tu.b(var1, this.h);
      this.i = var1.g("BrewTime");
      if (var1.b("CustomName", 8)) {
         this.l = var1.l("CustomName");
      }

      this.m = var1.f("Fuel");
   }

   public fy b(fy var1) {
      super.b(var1);
      var1.a("BrewTime", (short)this.i);
      tu.a(var1, this.h);
      if (this.n_()) {
         var1.a("CustomName", this.l);
      }

      var1.a("Fuel", (byte)this.m);
      return var1;
   }

   public ain a(int var1) {
      return var1 >= 0 && var1 < this.h.size() ? (ain)this.h.get(var1) : ain.a;
   }

   public ain a(int var1, int var2) {
      return tu.a(this.h, var1, var2);
   }

   public ain c_(int var1) {
      return tu.a(this.h, var1);
   }

   public void a(int var1, ain var2) {
      if (var1 >= 0 && var1 < this.h.size()) {
         this.h.set(var1, var2);
      }

   }

   public int z_() {
      return 64;
   }

   public boolean a(aeb var1) {
      if (this.b.r(this.c) != this) {
         return false;
      } else {
         return !(var1.d((double)this.c.p() + 0.5D, (double)this.c.q() + 0.5D, (double)this.c.r() + 0.5D) > 64.0D);
      }
   }

   public void b(aeb var1) {
   }

   public void c(aeb var1) {
   }

   public boolean b(int var1, ain var2) {
      if (var1 == 3) {
         return akf.a(var2);
      } else {
         ail var3 = var2.c();
         if (var1 == 4) {
            return var3 == aip.bO;
         } else {
            return (var3 == aip.bH || var3 == aip.bI || var3 == aip.bJ || var3 == aip.bK) && this.a(var1).b();
         }
      }
   }

   public int[] a(fa var1) {
      if (var1 == fa.b) {
         return a;
      } else {
         return var1 == fa.a ? f : g;
      }
   }

   public boolean a(int var1, ain var2, fa var3) {
      return this.b(var1, var2);
   }

   public boolean b(int var1, ain var2, fa var3) {
      if (var1 == 3) {
         return var2.c() == aip.bK;
      } else {
         return true;
      }
   }

   public String l() {
      return "minecraft:brewing_stand";
   }

   public afp a(aea var1, aeb var2) {
      return new afs(var1, this);
   }

   public int c(int var1) {
      switch(var1) {
      case 0:
         return this.i;
      case 1:
         return this.m;
      default:
         return 0;
      }
   }

   public void b(int var1, int var2) {
      switch(var1) {
      case 0:
         this.i = var2;
         break;
      case 1:
         this.m = var2;
      }

   }

   public int h() {
      return 2;
   }

   public void m() {
      this.h.clear();
   }
}
