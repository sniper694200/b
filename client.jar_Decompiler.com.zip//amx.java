public class amx {
   public static final amx[] a = new amx[16];
   public static final amx b = (new amx(0, "default", 1)).i();
   public static final amx c = new amx(1, "flat");
   public static final amx d = new amx(2, "largeBiomes");
   public static final amx e = (new amx(3, "amplified")).j();
   public static final amx f = new amx(4, "customized");
   public static final amx g = new amx(5, "debug_all_block_states");
   public static final amx h = (new amx(8, "default_1_1", 0)).a(false);
   private final int i;
   private final String j;
   private final int k;
   private boolean l;
   private boolean m;
   private boolean n;

   private amx(int var1, String var2) {
      this(var1, var2, 0);
   }

   private amx(int var1, String var2, int var3) {
      this.j = var2;
      this.k = var3;
      this.l = true;
      this.i = var1;
      a[var1] = this;
   }

   public String a() {
      return this.j;
   }

   public String b() {
      return "generator." + this.j;
   }

   public String c() {
      return this.b() + ".info";
   }

   public int d() {
      return this.k;
   }

   public amx a(int var1) {
      return this == b && var1 == 0 ? h : this;
   }

   private amx a(boolean var1) {
      this.l = var1;
      return this;
   }

   public boolean e() {
      return this.l;
   }

   private amx i() {
      this.m = true;
      return this;
   }

   public boolean f() {
      return this.m;
   }

   public static amx a(String var0) {
      amx[] var1 = a;
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         amx var4 = var1[var3];
         if (var4 != null && var4.j.equalsIgnoreCase(var0)) {
            return var4;
         }
      }

      return null;
   }

   public int g() {
      return this.i;
   }

   public boolean h() {
      return this.n;
   }

   private amx j() {
      this.n = true;
      return this;
   }
}
