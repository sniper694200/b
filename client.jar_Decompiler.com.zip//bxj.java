import com.google.common.collect.Lists;
import com.google.common.primitives.Doubles;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

public class bxj implements Comparable<bxj> {
   private final bxp a;
   private final ReentrantLock b = new ReentrantLock();
   private final List<Runnable> c = Lists.newArrayList();
   private final bxj.b d;
   private final double e;
   private buk f;
   private bxm g;
   private bxj.a h;
   private boolean i;

   public bxj(bxp var1, bxj.b var2, double var3) {
      this.h = bxj.a.a;
      this.a = var1;
      this.d = var2;
      this.e = var3;
   }

   public bxj.a a() {
      return this.h;
   }

   public bxp b() {
      return this.a;
   }

   public bxm c() {
      return this.g;
   }

   public void a(bxm var1) {
      this.g = var1;
   }

   public buk d() {
      return this.f;
   }

   public void a(buk var1) {
      this.f = var1;
   }

   public void a(bxj.a var1) {
      this.b.lock();

      try {
         this.h = var1;
      } finally {
         this.b.unlock();
      }

   }

   public void e() {
      this.b.lock();

      try {
         if (this.d == bxj.b.a && this.h != bxj.a.d) {
            this.a.a(false);
         }

         this.i = true;
         this.h = bxj.a.d;
         Iterator var1 = this.c.iterator();

         while(var1.hasNext()) {
            Runnable var2 = (Runnable)var1.next();
            var2.run();
         }
      } finally {
         this.b.unlock();
      }

   }

   public void a(Runnable var1) {
      this.b.lock();

      try {
         this.c.add(var1);
         if (this.i) {
            var1.run();
         }
      } finally {
         this.b.unlock();
      }

   }

   public ReentrantLock f() {
      return this.b;
   }

   public bxj.b g() {
      return this.d;
   }

   public boolean h() {
      return this.i;
   }

   public int a(bxj var1) {
      return Doubles.compare(this.e, var1.e);
   }

   public double i() {
      return this.e;
   }

   // $FF: synthetic method
   public int compareTo(Object var1) {
      return this.a((bxj)var1);
   }

   public static enum a {
      a,
      b,
      c,
      d;
   }

   public static enum b {
      a,
      b;
   }
}
