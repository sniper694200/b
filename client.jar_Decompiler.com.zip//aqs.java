public class aqs extends asg {
   public boolean e() {
      return true;
   }
}
