public class aes extends aef {
   private int f = 200;

   public aes(ams var1) {
      super(var1);
   }

   public aes(ams var1, vn var2) {
      super(var1, var2);
   }

   public aes(ams var1, double var2, double var4, double var6) {
      super(var1, var2, var4, var6);
   }

   public void B_() {
      super.B_();
      if (this.l.G && !this.a) {
         this.l.a(fj.o, this.p, this.q, this.r, 0.0D, 0.0D, 0.0D);
      }

   }

   protected ain j() {
      return new ain(aip.i);
   }

   protected void a(vn var1) {
      super.a(var1);
      uy var2 = new uy(uz.x, this.f, 0);
      var1.c(var2);
   }

   public static void c(rw var0) {
      aef.a(var0, "SpectralArrow");
   }

   public void a(fy var1) {
      super.a(var1);
      if (var1.e("Duration")) {
         this.f = var1.h("Duration");
      }

   }

   public void b(fy var1) {
      super.b(var1);
      var1.a("Duration", this.f);
   }
}
