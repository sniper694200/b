public class bmo extends bme {
   private static final nd w = new nd("textures/gui/container/dispenser.png");
   private final aea x;
   public tt v;

   public bmo(aea var1, tt var2) {
      super(new afy(var1, var2));
      this.x = var1;
      this.v = var2;
   }

   public void a(int var1, int var2, float var3) {
      this.c();
      super.a(var1, var2, var3);
      this.b(var1, var2);
   }

   protected void c(int var1, int var2) {
      String var3 = this.v.i_().c();
      this.q.a(var3, this.f / 2 - this.q.a(var3) / 2, 6, 4210752);
      this.q.a(this.x.i_().c(), 8, this.g - 96 + 2, 4210752);
   }

   protected void a(float var1, int var2, int var3) {
      buq.c(1.0F, 1.0F, 1.0F, 1.0F);
      this.j.N().a(w);
      int var4 = (this.l - this.f) / 2;
      int var5 = (this.m - this.g) / 2;
      this.b(var4, var5, 0, 0, this.f, this.g);
   }
}
