import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import javax.annotation.Nullable;

public class gi {
   public static fy a(InputStream var0) throws IOException {
      DataInputStream var1 = new DataInputStream(new BufferedInputStream(new GZIPInputStream(var0)));

      fy var2;
      try {
         var2 = a((DataInput)var1, (gh)gh.a);
      } finally {
         var1.close();
      }

      return var2;
   }

   public static void a(fy var0, OutputStream var1) throws IOException {
      DataOutputStream var2 = new DataOutputStream(new BufferedOutputStream(new GZIPOutputStream(var1)));

      try {
         a((fy)var0, (DataOutput)var2);
      } finally {
         var2.close();
      }

   }

   public static void a(fy var0, File var1) throws IOException {
      File var2 = new File(var1.getAbsolutePath() + "_tmp");
      if (var2.exists()) {
         var2.delete();
      }

      b(var0, var2);
      if (var1.exists()) {
         var1.delete();
      }

      if (var1.exists()) {
         throw new IOException("Failed to delete " + var1);
      } else {
         var2.renameTo(var1);
      }
   }

   public static void b(fy var0, File var1) throws IOException {
      DataOutputStream var2 = new DataOutputStream(new FileOutputStream(var1));

      try {
         a((fy)var0, (DataOutput)var2);
      } finally {
         var2.close();
      }

   }

   @Nullable
   public static fy a(File var0) throws IOException {
      if (!var0.exists()) {
         return null;
      } else {
         DataInputStream var1 = new DataInputStream(new FileInputStream(var0));

         fy var2;
         try {
            var2 = a((DataInput)var1, (gh)gh.a);
         } finally {
            var1.close();
         }

         return var2;
      }
   }

   public static fy a(DataInputStream var0) throws IOException {
      return a((DataInput)var0, (gh)gh.a);
   }

   public static fy a(DataInput var0, gh var1) throws IOException {
      gn var2 = a(var0, 0, var1);
      if (var2 instanceof fy) {
         return (fy)var2;
      } else {
         throw new IOException("Root tag must be a named compound tag");
      }
   }

   public static void a(fy var0, DataOutput var1) throws IOException {
      a((gn)var0, (DataOutput)var1);
   }

   private static void a(gn var0, DataOutput var1) throws IOException {
      var1.writeByte(var0.a());
      if (var0.a() != 0) {
         var1.writeUTF("");
         var0.a(var1);
      }
   }

   private static gn a(DataInput var0, int var1, gh var2) throws IOException {
      byte var3 = var0.readByte();
      if (var3 == 0) {
         return new ga();
      } else {
         var0.readUTF();
         gn var4 = gn.a(var3);

         try {
            var4.a(var0, var1, var2);
            return var4;
         } catch (IOException var8) {
            b var6 = b.a(var8, "Loading NBT data");
            c var7 = var6.a("NBT Tag");
            var7.a((String)"Tag type", (Object)var3);
            throw new f(var6);
         }
      }
   }
}
