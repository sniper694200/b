import javax.annotation.Nullable;

public class bel extends bei {
   public beh b() {
      return this.a(ri.c(this.b.bw().a), ri.c(this.b.bw().b + 0.5D), ri.c(this.b.bw().c));
   }

   public beh a(double var1, double var3, double var5) {
      return this.a(ri.c(var1 - (double)(this.b.G / 2.0F)), ri.c(var3 + 0.5D), ri.c(var5 - (double)(this.b.G / 2.0F)));
   }

   public int a(beh[] var1, beh var2, beh var3, float var4) {
      int var5 = 0;
      fa[] var6 = fa.values();
      int var7 = var6.length;

      for(int var8 = 0; var8 < var7; ++var8) {
         fa var9 = var6[var8];
         beh var10 = this.b(var2.a + var9.g(), var2.b + var9.h(), var2.c + var9.i());
         if (var10 != null && !var10.i && var10.a(var3) < var4) {
            var1[var5++] = var10;
         }
      }

      return var5;
   }

   public bef a(amw var1, int var2, int var3, int var4, vo var5, int var6, int var7, int var8, boolean var9, boolean var10) {
      return bef.g;
   }

   public bef a(amw var1, int var2, int var3, int var4) {
      return bef.g;
   }

   @Nullable
   private beh b(int var1, int var2, int var3) {
      bef var4 = this.c(var1, var2, var3);
      return var4 == bef.g ? this.a(var1, var2, var3) : null;
   }

   private bef c(int var1, int var2, int var3) {
      et.a var4 = new et.a();

      for(int var5 = var1; var5 < var1 + this.d; ++var5) {
         for(int var6 = var2; var6 < var2 + this.e; ++var6) {
            for(int var7 = var3; var7 < var3 + this.f; ++var7) {
               awr var8 = this.a.o(var4.c(var5, var6, var7));
               if (var8.a() != bcx.h) {
                  return bef.a;
               }
            }
         }
      }

      return bef.g;
   }
}
