public class cam extends cad<aae> {
   private static final nd a = new nd("textures/entity/sheep/sheep.png");

   public cam(bzd var1) {
      super(var1, new bqn(), 0.7F);
      this.a((cce)(new ccf(this)));
   }

   protected nd a(aae var1) {
      return a;
   }
}
