import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class abb extends vo implements aay, acu {
   private static final Logger bJ = LogManager.getLogger();
   public static final mx<Integer> a;
   public double[][] b = new double[64][3];
   public int c = -1;
   public aaz[] bv;
   public aaz bw = new aaz(this, "head", 6.0F, 6.0F);
   public aaz bx = new aaz(this, "neck", 6.0F, 6.0F);
   public aaz by = new aaz(this, "body", 8.0F, 8.0F);
   public aaz bz = new aaz(this, "tail", 4.0F, 4.0F);
   public aaz bA = new aaz(this, "tail", 4.0F, 4.0F);
   public aaz bB = new aaz(this, "tail", 4.0F, 4.0F);
   public aaz bC = new aaz(this, "wing", 4.0F, 4.0F);
   public aaz bD = new aaz(this, "wing", 4.0F, 4.0F);
   public float bE;
   public float bF;
   public boolean bG;
   public int bH;
   public aba bI;
   private final ayp bK;
   private final abs bL;
   private int bM = 200;
   private int bN;
   private final beh[] bO = new beh[24];
   private final int[] bP = new int[24];
   private final bee bQ = new bee();

   public abb(ams var1) {
      super(var1);
      this.bv = new aaz[]{this.bw, this.bx, this.by, this.bz, this.bA, this.bB, this.bC, this.bD};
      this.c(this.cj());
      this.a(16.0F, 8.0F);
      this.Q = true;
      this.X = true;
      this.bM = 100;
      this.ah = true;
      if (!var1.G && var1.s instanceof ayq) {
         this.bK = ((ayq)var1.s).t();
      } else {
         this.bK = null;
      }

      this.bL = new abs(this);
   }

   protected void bM() {
      super.bM();
      this.a((wa)adf.a).a(200.0D);
   }

   protected void i() {
      super.i();
      this.V().a((mx)a, (Object)abr.k.b());
   }

   public double[] a(int var1, float var2) {
      if (this.cd() <= 0.0F) {
         var2 = 0.0F;
      }

      var2 = 1.0F - var2;
      int var3 = this.c - var1 & 63;
      int var4 = this.c - var1 - 1 & 63;
      double[] var5 = new double[3];
      double var6 = this.b[var3][0];
      double var8 = ri.g(this.b[var4][0] - var6);
      var5[0] = var6 + var8 * (double)var2;
      var6 = this.b[var3][1];
      var8 = this.b[var4][1] - var6;
      var5[1] = var6 + var8 * (double)var2;
      var5[2] = this.b[var3][2] + (this.b[var4][2] - this.b[var3][2]) * (double)var2;
      return var5;
   }

   public void n() {
      float var1;
      float var2;
      if (this.l.G) {
         this.c(this.cd());
         if (!this.ai()) {
            var1 = ri.b(this.bF * 6.2831855F);
            var2 = ri.b(this.bE * 6.2831855F);
            if (var2 <= -0.3F && var1 >= -0.3F) {
               this.l.a(this.p, this.q, this.r, qd.aX, this.bK(), 5.0F, 0.8F + this.S.nextFloat() * 0.3F, false);
            }

            if (!this.bL.a().a() && --this.bM < 0) {
               this.l.a(this.p, this.q, this.r, qd.aY, this.bK(), 2.5F, 0.8F + this.S.nextFloat() * 0.3F, false);
               this.bM = 200 + this.S.nextInt(200);
            }
         }
      }

      this.bE = this.bF;
      float var26;
      if (this.cd() <= 0.0F) {
         var1 = (this.S.nextFloat() - 0.5F) * 8.0F;
         var2 = (this.S.nextFloat() - 0.5F) * 4.0F;
         var26 = (this.S.nextFloat() - 0.5F) * 8.0F;
         this.l.a(fj.b, this.p + (double)var1, this.q + 2.0D + (double)var2, this.r + (double)var26, 0.0D, 0.0D, 0.0D);
      } else {
         this.dg();
         var1 = 0.2F / (ri.a(this.s * this.s + this.u * this.u) * 10.0F + 1.0F);
         var1 *= (float)Math.pow(2.0D, this.t);
         if (this.bL.a().a()) {
            this.bF += 0.1F;
         } else if (this.bG) {
            this.bF += var1 * 0.5F;
         } else {
            this.bF += var1;
         }

         this.v = ri.g(this.v);
         if (this.dc()) {
            this.bF = 0.5F;
         } else {
            if (this.c < 0) {
               for(int var22 = 0; var22 < this.b.length; ++var22) {
                  this.b[var22][0] = (double)this.v;
                  this.b[var22][1] = this.q;
               }
            }

            if (++this.c == this.b.length) {
               this.c = 0;
            }

            this.b[this.c][0] = (double)this.v;
            this.b[this.c][1] = this.q;
            double var4;
            double var6;
            double var8;
            float var12;
            float var17;
            if (this.l.G) {
               if (this.bi > 0) {
                  double var23 = this.p + (this.bj - this.p) / (double)this.bi;
                  var4 = this.q + (this.bk - this.q) / (double)this.bi;
                  var6 = this.r + (this.bl - this.r) / (double)this.bi;
                  var8 = ri.g(this.bm - (double)this.v);
                  this.v = (float)((double)this.v + var8 / (double)this.bi);
                  this.w = (float)((double)this.w + (this.bn - (double)this.w) / (double)this.bi);
                  --this.bi;
                  this.b(var23, var4, var6);
                  this.b(this.v, this.w);
               }

               this.bL.a().b();
            } else {
               abl var24 = this.bL.a();
               var24.c();
               if (this.bL.a() != var24) {
                  var24 = this.bL.a();
                  var24.c();
               }

               bhc var3 = var24.g();
               if (var3 != null) {
                  var4 = var3.b - this.p;
                  var6 = var3.c - this.q;
                  var8 = var3.d - this.r;
                  double var10 = var4 * var4 + var6 * var6 + var8 * var8;
                  var12 = var24.f();
                  var6 = ri.a(var6 / (double)ri.a(var4 * var4 + var8 * var8), (double)(-var12), (double)var12);
                  this.t += var6 * 0.10000000149011612D;
                  this.v = ri.g(this.v);
                  double var13 = ri.a(ri.g(180.0D - ri.c(var4, var8) * 57.2957763671875D - (double)this.v), -50.0D, 50.0D);
                  bhc var15 = (new bhc(var3.b - this.p, var3.c - this.q, var3.d - this.r)).a();
                  bhc var16 = (new bhc((double)ri.a(this.v * 0.017453292F), this.t, (double)(-ri.b(this.v * 0.017453292F)))).a();
                  var17 = Math.max(((float)var16.b(var15) + 0.5F) / 1.5F, 0.0F);
                  this.bh *= 0.8F;
                  this.bh = (float)((double)this.bh + var13 * (double)var24.h());
                  this.v += this.bh * 0.1F;
                  float var18 = (float)(2.0D / (var10 + 1.0D));
                  float var19 = 0.06F;
                  this.b(0.0F, 0.0F, -1.0F, 0.06F * (var17 * var18 + (1.0F - var18)));
                  if (this.bG) {
                     this.a(vt.a, this.s * 0.800000011920929D, this.t * 0.800000011920929D, this.u * 0.800000011920929D);
                  } else {
                     this.a(vt.a, this.s, this.t, this.u);
                  }

                  bhc var20 = (new bhc(this.s, this.t, this.u)).a();
                  float var21 = ((float)var20.b(var16) + 1.0F) / 2.0F;
                  var21 = 0.8F + 0.15F * var21;
                  this.s *= (double)var21;
                  this.u *= (double)var21;
                  this.t *= 0.9100000262260437D;
               }
            }

            this.aN = this.v;
            this.bw.G = 1.0F;
            this.bw.H = 1.0F;
            this.bx.G = 3.0F;
            this.bx.H = 3.0F;
            this.bz.G = 2.0F;
            this.bz.H = 2.0F;
            this.bA.G = 2.0F;
            this.bA.H = 2.0F;
            this.bB.G = 2.0F;
            this.bB.H = 2.0F;
            this.by.H = 3.0F;
            this.by.G = 5.0F;
            this.bC.H = 2.0F;
            this.bC.G = 4.0F;
            this.bD.H = 3.0F;
            this.bD.G = 4.0F;
            bhc[] var27 = new bhc[this.bv.length];

            for(int var25 = 0; var25 < this.bv.length; ++var25) {
               var27[var25] = new bhc(this.bv[var25].p, this.bv[var25].q, this.bv[var25].r);
            }

            var26 = (float)(this.a(5, 1.0F)[1] - this.a(10, 1.0F)[1]) * 10.0F * 0.017453292F;
            float var28 = ri.b(var26);
            float var5 = ri.a(var26);
            float var29 = this.v * 0.017453292F;
            float var7 = ri.a(var29);
            float var30 = ri.b(var29);
            this.by.B_();
            this.by.b(this.p + (double)(var7 * 0.5F), this.q, this.r - (double)(var30 * 0.5F), 0.0F, 0.0F);
            this.bC.B_();
            this.bC.b(this.p + (double)(var30 * 4.5F), this.q + 2.0D, this.r + (double)(var7 * 4.5F), 0.0F, 0.0F);
            this.bD.B_();
            this.bD.b(this.p - (double)(var30 * 4.5F), this.q + 2.0D, this.r - (double)(var7 * 4.5F), 0.0F, 0.0F);
            if (!this.l.G && this.ay == 0) {
               this.a(this.l.b((ve)this, (bgz)this.bC.bw().c(4.0D, 2.0D, 4.0D).d(0.0D, -2.0D, 0.0D)));
               this.a(this.l.b((ve)this, (bgz)this.bD.bw().c(4.0D, 2.0D, 4.0D).d(0.0D, -2.0D, 0.0D)));
               this.b(this.l.b((ve)this, (bgz)this.bw.bw().g(1.0D)));
               this.b(this.l.b((ve)this, (bgz)this.bx.bw().g(1.0D)));
            }

            double[] var9 = this.a(5, 1.0F);
            float var31 = ri.a(this.v * 0.017453292F - this.bh * 0.01F);
            float var11 = ri.b(this.v * 0.017453292F - this.bh * 0.01F);
            this.bw.B_();
            this.bx.B_();
            var12 = this.q(1.0F);
            this.bw.b(this.p + (double)(var31 * 6.5F * var28), this.q + (double)var12 + (double)(var5 * 6.5F), this.r - (double)(var11 * 6.5F * var28), 0.0F, 0.0F);
            this.bx.b(this.p + (double)(var31 * 5.5F * var28), this.q + (double)var12 + (double)(var5 * 5.5F), this.r - (double)(var11 * 5.5F * var28), 0.0F, 0.0F);

            int var32;
            for(var32 = 0; var32 < 3; ++var32) {
               aaz var33 = null;
               if (var32 == 0) {
                  var33 = this.bz;
               }

               if (var32 == 1) {
                  var33 = this.bA;
               }

               if (var32 == 2) {
                  var33 = this.bB;
               }

               double[] var34 = this.a(12 + var32 * 2, 1.0F);
               float var35 = this.v * 0.017453292F + this.c(var34[0] - var9[0]) * 0.017453292F;
               float var14 = ri.a(var35);
               float var36 = ri.b(var35);
               float var37 = 1.5F;
               var17 = (float)(var32 + 1) * 2.0F;
               var33.B_();
               var33.b(this.p - (double)((var7 * 1.5F + var14 * var17) * var28), this.q + (var34[1] - var9[1]) - (double)((var17 + 1.5F) * var5) + 1.5D, this.r + (double)((var30 * 1.5F + var36 * var17) * var28), 0.0F, 0.0F);
            }

            if (!this.l.G) {
               this.bG = this.b(this.bw.bw()) | this.b(this.bx.bw()) | this.b(this.by.bw());
               if (this.bK != null) {
                  this.bK.b(this);
               }
            }

            for(var32 = 0; var32 < this.bv.length; ++var32) {
               this.bv[var32].m = var27[var32].b;
               this.bv[var32].n = var27[var32].c;
               this.bv[var32].o = var27[var32].d;
            }

         }
      }
   }

   private float q(float var1) {
      double var2;
      if (this.bL.a().a()) {
         var2 = -1.0D;
      } else {
         double[] var4 = this.a(5, 1.0F);
         double[] var5 = this.a(0, 1.0F);
         var2 = var4[1] - var5[1];
      }

      return (float)var2;
   }

   private void dg() {
      if (this.bI != null) {
         if (this.bI.F) {
            this.bI = null;
         } else if (this.T % 10 == 0 && this.cd() < this.cj()) {
            this.c(this.cd() + 1.0F);
         }
      }

      if (this.S.nextInt(10) == 0) {
         List<aba> var1 = this.l.a(aba.class, this.bw().g(32.0D));
         aba var2 = null;
         double var3 = Double.MAX_VALUE;
         Iterator var5 = var1.iterator();

         while(var5.hasNext()) {
            aba var6 = (aba)var5.next();
            double var7 = var6.h(this);
            if (var7 < var3) {
               var3 = var7;
               var2 = var6;
            }
         }

         this.bI = var2;
      }

   }

   private void a(List<ve> var1) {
      double var2 = (this.by.bw().a + this.by.bw().d) / 2.0D;
      double var4 = (this.by.bw().c + this.by.bw().f) / 2.0D;
      Iterator var6 = var1.iterator();

      while(var6.hasNext()) {
         ve var7 = (ve)var6.next();
         if (var7 instanceof vn) {
            double var8 = var7.p - var2;
            double var10 = var7.r - var4;
            double var12 = var8 * var8 + var10 * var10;
            var7.f(var8 / var12 * 4.0D, 0.20000000298023224D, var10 / var12 * 4.0D);
            if (!this.bL.a().a() && ((vn)var7).bT() < var7.T - 2) {
               var7.a(up.a((vn)this), 5.0F);
               this.a(this, var7);
            }
         }
      }

   }

   private void b(List<ve> var1) {
      for(int var2 = 0; var2 < var1.size(); ++var2) {
         ve var3 = (ve)var1.get(var2);
         if (var3 instanceof vn) {
            var3.a(up.a((vn)this), 10.0F);
            this.a(this, var3);
         }
      }

   }

   private float c(double var1) {
      return (float)ri.g(var1);
   }

   private boolean b(bgz var1) {
      int var2 = ri.c(var1.a);
      int var3 = ri.c(var1.b);
      int var4 = ri.c(var1.c);
      int var5 = ri.c(var1.d);
      int var6 = ri.c(var1.e);
      int var7 = ri.c(var1.f);
      boolean var8 = false;
      boolean var9 = false;

      for(int var10 = var2; var10 <= var5; ++var10) {
         for(int var11 = var3; var11 <= var6; ++var11) {
            for(int var12 = var4; var12 <= var7; ++var12) {
               et var13 = new et(var10, var11, var12);
               awr var14 = this.l.o(var13);
               aou var15 = var14.u();
               if (var14.a() != bcx.a && var14.a() != bcx.o) {
                  if (!this.l.W().b("mobGriefing")) {
                     var8 = true;
                  } else if (var15 != aov.cv && var15 != aov.Z && var15 != aov.bH && var15 != aov.h && var15 != aov.bF && var15 != aov.bG) {
                     if (var15 != aov.bX && var15 != aov.dc && var15 != aov.dd && var15 != aov.bi && var15 != aov.db) {
                        var9 = this.l.g(var13) || var9;
                     } else {
                        var8 = true;
                     }
                  } else {
                     var8 = true;
                  }
               }
            }
         }
      }

      if (var9) {
         double var16 = var1.a + (var1.d - var1.a) * (double)this.S.nextFloat();
         double var17 = var1.b + (var1.e - var1.b) * (double)this.S.nextFloat();
         double var18 = var1.c + (var1.f - var1.c) * (double)this.S.nextFloat();
         this.l.a(fj.b, var16, var17, var18, 0.0D, 0.0D, 0.0D);
      }

      return var8;
   }

   public boolean a(aaz var1, up var2, float var3) {
      var3 = this.bL.a().a(var1, var2, var3);
      if (var1 != this.bw) {
         var3 = var3 / 4.0F + Math.min(var3, 1.0F);
      }

      if (var3 < 0.01F) {
         return false;
      } else {
         if (var2.j() instanceof aeb || var2.c()) {
            float var4 = this.cd();
            this.e(var2, var3);
            if (this.cd() <= 0.0F && !this.bL.a().a()) {
               this.c(1.0F);
               this.bL.a(abr.j);
            }

            if (this.bL.a().a()) {
               this.bN = (int)((float)this.bN + (var4 - this.cd()));
               if ((float)this.bN > 0.25F * this.cj()) {
                  this.bN = 0;
                  this.bL.a(abr.e);
               }
            }
         }

         return true;
      }
   }

   public boolean a(up var1, float var2) {
      if (var1 instanceof uq && ((uq)var1).x()) {
         this.a(this.by, var1, var2);
      }

      return false;
   }

   protected boolean e(up var1, float var2) {
      return super.a((up)var1, var2);
   }

   public void U() {
      this.X();
      if (this.bK != null) {
         this.bK.b(this);
         this.bK.a(this);
      }

   }

   protected void bO() {
      if (this.bK != null) {
         this.bK.b(this);
      }

      ++this.bH;
      if (this.bH >= 180 && this.bH <= 200) {
         float var1 = (this.S.nextFloat() - 0.5F) * 8.0F;
         float var2 = (this.S.nextFloat() - 0.5F) * 4.0F;
         float var3 = (this.S.nextFloat() - 0.5F) * 8.0F;
         this.l.a(fj.c, this.p + (double)var1, this.q + 2.0D + (double)var2, this.r + (double)var3, 0.0D, 0.0D, 0.0D);
      }

      boolean var4 = this.l.W().b("doMobLoot");
      int var5 = 500;
      if (this.bK != null && !this.bK.d()) {
         var5 = 12000;
      }

      if (!this.l.G) {
         if (this.bH > 150 && this.bH % 5 == 0 && var4) {
            this.a(ri.d((float)var5 * 0.08F));
         }

         if (this.bH == 1) {
            this.l.a(1028, new et(this), 0);
         }
      }

      this.a(vt.a, 0.0D, 0.10000000149011612D, 0.0D);
      this.v += 20.0F;
      this.aN = this.v;
      if (this.bH == 200 && !this.l.G) {
         if (var4) {
            this.a(ri.d((float)var5 * 0.2F));
         }

         if (this.bK != null) {
            this.bK.a(this);
         }

         this.X();
      }

   }

   private void a(int var1) {
      while(var1 > 0) {
         int var2 = vk.a(var1);
         var1 -= var2;
         this.l.a((ve)(new vk(this.l, this.p, this.q, this.r, var2)));
      }

   }

   public int p() {
      if (this.bO[0] == null) {
         for(int var1 = 0; var1 < 24; ++var1) {
            int var2 = 5;
            int var4;
            int var5;
            if (var1 < 12) {
               var4 = (int)(60.0F * ri.b(2.0F * (-3.1415927F + 0.2617994F * (float)var1)));
               var5 = (int)(60.0F * ri.a(2.0F * (-3.1415927F + 0.2617994F * (float)var1)));
            } else {
               int var3;
               if (var1 < 20) {
                  var3 = var1 - 12;
                  var4 = (int)(40.0F * ri.b(2.0F * (-3.1415927F + 0.3926991F * (float)var3)));
                  var5 = (int)(40.0F * ri.a(2.0F * (-3.1415927F + 0.3926991F * (float)var3)));
                  var2 += 10;
               } else {
                  var3 = var1 - 20;
                  var4 = (int)(20.0F * ri.b(2.0F * (-3.1415927F + 0.7853982F * (float)var3)));
                  var5 = (int)(20.0F * ri.a(2.0F * (-3.1415927F + 0.7853982F * (float)var3)));
               }
            }

            int var6 = Math.max(this.l.M() + 10, this.l.q(new et(var4, 0, var5)).q() + var2);
            this.bO[var1] = new beh(var4, var6, var5);
         }

         this.bP[0] = 6146;
         this.bP[1] = 8197;
         this.bP[2] = 8202;
         this.bP[3] = 16404;
         this.bP[4] = 32808;
         this.bP[5] = 32848;
         this.bP[6] = 65696;
         this.bP[7] = 131392;
         this.bP[8] = 131712;
         this.bP[9] = 263424;
         this.bP[10] = 526848;
         this.bP[11] = 525313;
         this.bP[12] = 1581057;
         this.bP[13] = 3166214;
         this.bP[14] = 2138120;
         this.bP[15] = 6373424;
         this.bP[16] = 4358208;
         this.bP[17] = 12910976;
         this.bP[18] = 9044480;
         this.bP[19] = 9706496;
         this.bP[20] = 15216640;
         this.bP[21] = 13688832;
         this.bP[22] = 11763712;
         this.bP[23] = 8257536;
      }

      return this.k(this.p, this.q, this.r);
   }

   public int k(double var1, double var3, double var5) {
      float var7 = 10000.0F;
      int var8 = 0;
      beh var9 = new beh(ri.c(var1), ri.c(var3), ri.c(var5));
      int var10 = 0;
      if (this.bK == null || this.bK.c() == 0) {
         var10 = 12;
      }

      for(int var11 = var10; var11 < 24; ++var11) {
         if (this.bO[var11] != null) {
            float var12 = this.bO[var11].b(var9);
            if (var12 < var7) {
               var7 = var12;
               var8 = var11;
            }
         }
      }

      return var8;
   }

   @Nullable
   public bej a(int var1, int var2, @Nullable beh var3) {
      beh var5;
      for(int var4 = 0; var4 < 24; ++var4) {
         var5 = this.bO[var4];
         var5.i = false;
         var5.g = 0.0F;
         var5.e = 0.0F;
         var5.f = 0.0F;
         var5.h = null;
         var5.d = -1;
      }

      beh var13 = this.bO[var1];
      var5 = this.bO[var2];
      var13.e = 0.0F;
      var13.f = var13.a(var5);
      var13.g = var13.f;
      this.bQ.a();
      this.bQ.a(var13);
      beh var6 = var13;
      int var7 = 0;
      if (this.bK == null || this.bK.c() == 0) {
         var7 = 12;
      }

      while(!this.bQ.e()) {
         beh var8 = this.bQ.c();
         if (var8.equals(var5)) {
            if (var3 != null) {
               var3.h = var5;
               var5 = var3;
            }

            return this.a(var13, var5);
         }

         if (var8.a(var5) < var6.a(var5)) {
            var6 = var8;
         }

         var8.i = true;
         int var9 = 0;

         int var10;
         for(var10 = 0; var10 < 24; ++var10) {
            if (this.bO[var10] == var8) {
               var9 = var10;
               break;
            }
         }

         for(var10 = var7; var10 < 24; ++var10) {
            if ((this.bP[var9] & 1 << var10) > 0) {
               beh var11 = this.bO[var10];
               if (!var11.i) {
                  float var12 = var8.e + var8.a(var11);
                  if (!var11.a() || var12 < var11.e) {
                     var11.h = var8;
                     var11.e = var12;
                     var11.f = var11.a(var5);
                     if (var11.a()) {
                        this.bQ.a(var11, var11.e + var11.f);
                     } else {
                        var11.g = var11.e + var11.f;
                        this.bQ.a(var11);
                     }
                  }
               }
            }
         }
      }

      if (var6 == var13) {
         return null;
      } else {
         bJ.debug("Failed to find path from {} to {}", var1, var2);
         if (var3 != null) {
            var3.h = var6;
            var6 = var3;
         }

         return this.a(var13, var6);
      }
   }

   private bej a(beh var1, beh var2) {
      int var3 = 1;

      beh var4;
      for(var4 = var2; var4.h != null; var4 = var4.h) {
         ++var3;
      }

      beh[] var5 = new beh[var3];
      var4 = var2;
      --var3;

      for(var5[var3] = var2; var4.h != null; var5[var3] = var4) {
         var4 = var4.h;
         --var3;
      }

      return new bej(var5);
   }

   public static void a(rw var0) {
      vo.a(var0, abb.class);
   }

   public void b(fy var1) {
      super.b(var1);
      var1.a("DragonPhase", this.bL.a().i().b());
   }

   public void a(fy var1) {
      super.a(var1);
      if (var1.e("DragonPhase")) {
         this.bL.a(abr.a(var1.h("DragonPhase")));
      }

   }

   protected void L() {
   }

   public ve[] bb() {
      return this.bv;
   }

   public boolean ay() {
      return false;
   }

   public ams a() {
      return this.l;
   }

   public qe bK() {
      return qe.f;
   }

   protected qc F() {
      return qd.aU;
   }

   protected qc d(up var1) {
      return qd.aZ;
   }

   protected float cq() {
      return 5.0F;
   }

   @Nullable
   protected nd J() {
      return bfl.az;
   }

   public float a(int var1, double[] var2, double[] var3) {
      abl var4 = this.bL.a();
      abr<? extends abl> var5 = var4.i();
      double var6;
      if (var5 != abr.d && var5 != abr.e) {
         if (var4.a()) {
            var6 = (double)var1;
         } else if (var1 == 6) {
            var6 = 0.0D;
         } else {
            var6 = var3[1] - var2[1];
         }
      } else {
         et var8 = this.l.q(azr.a);
         float var9 = Math.max(ri.a(this.d(var8)) / 4.0F, 1.0F);
         var6 = (double)((float)var1 / var9);
      }

      return (float)var6;
   }

   public bhc a(float var1) {
      abl var2 = this.bL.a();
      abr<? extends abl> var3 = var2.i();
      bhc var4;
      float var6;
      if (var3 != abr.d && var3 != abr.e) {
         if (var2.a()) {
            float var10 = this.w;
            var6 = 1.5F;
            this.w = -45.0F;
            var4 = this.e(var1);
            this.w = var10;
         } else {
            var4 = this.e(var1);
         }
      } else {
         et var5 = this.l.q(azr.a);
         var6 = Math.max(ri.a(this.d(var5)) / 4.0F, 1.0F);
         float var7 = 6.0F / var6;
         float var8 = this.w;
         float var9 = 1.5F;
         this.w = -var7 * 1.5F * 5.0F;
         var4 = this.e(var1);
         this.w = var8;
      }

      return var4;
   }

   public void a(aba var1, et var2, up var3) {
      aeb var4;
      if (var3.j() instanceof aeb) {
         var4 = (aeb)var3.j();
      } else {
         var4 = this.l.a(var2, 64.0D, 64.0D);
      }

      if (var1 == this.bI) {
         this.a(this.bw, up.b(var4), 10.0F);
      }

      this.bL.a().a(var1, var2, var3, var4);
   }

   public void a(mx<?> var1) {
      if (a.equals(var1) && this.l.G) {
         this.bL.a(abr.a((Integer)this.V().a(a)));
      }

      super.a((mx)var1);
   }

   public abs de() {
      return this.bL;
   }

   @Nullable
   public ayp df() {
      return this.bK;
   }

   public void c(uy var1) {
   }

   protected boolean n(ve var1) {
      return false;
   }

   public boolean bf() {
      return false;
   }

   static {
      a = na.a(abb.class, mz.b);
   }
}
