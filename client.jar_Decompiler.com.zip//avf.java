import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.annotation.Nullable;

public class avf extends avv implements nv, ul {
   public static final ux[][] a;
   private static final Set<ux> f;
   private final List<avf.a> g = Lists.newArrayList();
   private long h;
   private float i;
   private boolean j;
   private int k = -1;
   @Nullable
   private ux l;
   @Nullable
   private ux m;
   private ain n;
   private String o;

   public avf() {
      this.n = ain.a;
   }

   public void e() {
      if (this.b.R() % 80L == 0L) {
         this.n();
      }

   }

   public void n() {
      if (this.b != null) {
         this.F();
         this.E();
      }

   }

   private void E() {
      if (this.j && this.k > 0 && !this.b.G && this.l != null) {
         double var1 = (double)(this.k * 10 + 10);
         int var3 = 0;
         if (this.k >= 4 && this.l == this.m) {
            var3 = 1;
         }

         int var4 = (9 + this.k * 2) * 20;
         int var5 = this.c.p();
         int var6 = this.c.q();
         int var7 = this.c.r();
         bgz var8 = (new bgz((double)var5, (double)var6, (double)var7, (double)(var5 + 1), (double)(var6 + 1), (double)(var7 + 1))).g(var1).b(0.0D, (double)this.b.aa(), 0.0D);
         List<aeb> var9 = this.b.a(aeb.class, var8);
         Iterator var10 = var9.iterator();

         aeb var11;
         while(var10.hasNext()) {
            var11 = (aeb)var10.next();
            var11.c((uy)(new uy(this.l, var4, var3, true, true)));
         }

         if (this.k >= 4 && this.l != this.m && this.m != null) {
            var10 = var9.iterator();

            while(var10.hasNext()) {
               var11 = (aeb)var10.next();
               var11.c((uy)(new uy(this.m, var4, 0, true, true)));
            }
         }
      }

   }

   private void F() {
      int var1 = this.c.p();
      int var2 = this.c.q();
      int var3 = this.c.r();
      int var4 = this.k;
      this.k = 0;
      this.g.clear();
      this.j = true;
      avf.a var5 = new avf.a(ahq.a.f());
      this.g.add(var5);
      boolean var6 = true;
      et.a var7 = new et.a();

      int var8;
      for(var8 = var2 + 1; var8 < 256; ++var8) {
         awr var9 = this.b.o(var7.c(var1, var8, var3));
         float[] var10;
         if (var9.u() == aov.cG) {
            var10 = ((ahq)var9.c(aty.a)).f();
         } else {
            if (var9.u() != aov.cH) {
               if (var9.c() >= 15 && var9.u() != aov.h) {
                  this.j = false;
                  this.g.clear();
                  break;
               }

               var5.a();
               continue;
            }

            var10 = ((ahq)var9.c(atz.a)).f();
         }

         if (!var6) {
            var10 = new float[]{(var5.b()[0] + var10[0]) / 2.0F, (var5.b()[1] + var10[1]) / 2.0F, (var5.b()[2] + var10[2]) / 2.0F};
         }

         if (Arrays.equals(var10, var5.b())) {
            var5.a();
         } else {
            var5 = new avf.a(var10);
            this.g.add(var5);
         }

         var6 = false;
      }

      if (this.j) {
         for(var8 = 1; var8 <= 4; this.k = var8++) {
            int var15 = var2 - var8;
            if (var15 < 0) {
               break;
            }

            boolean var17 = true;

            for(int var11 = var1 - var8; var11 <= var1 + var8 && var17; ++var11) {
               for(int var12 = var3 - var8; var12 <= var3 + var8; ++var12) {
                  aou var13 = this.b.o(new et(var11, var15, var12)).u();
                  if (var13 != aov.bT && var13 != aov.R && var13 != aov.ah && var13 != aov.S) {
                     var17 = false;
                     break;
                  }
               }
            }

            if (!var17) {
               break;
            }
         }

         if (this.k == 0) {
            this.j = false;
         }
      }

      if (!this.b.G && var4 < this.k) {
         Iterator var14 = this.b.a(oo.class, (new bgz((double)var1, (double)var2, (double)var3, (double)var1, (double)(var2 - 4), (double)var3)).c(10.0D, 5.0D, 10.0D)).iterator();

         while(var14.hasNext()) {
            oo var16 = (oo)var14.next();
            m.k.a(var16, this);
         }
      }

   }

   public List<avf.a> o() {
      return this.g;
   }

   public float p() {
      if (!this.j) {
         return 0.0F;
      } else {
         int var1 = (int)(this.b.R() - this.h);
         this.h = this.b.R();
         if (var1 > 1) {
            this.i -= (float)var1 / 40.0F;
            if (this.i < 0.0F) {
               this.i = 0.0F;
            }
         }

         this.i += 0.025F;
         if (this.i > 1.0F) {
            this.i = 1.0F;
         }

         return this.i;
      }
   }

   public int s() {
      return this.k;
   }

   @Nullable
   public ih c() {
      return new ih(this.c, 3, this.d());
   }

   public fy d() {
      return this.b(new fy());
   }

   public double t() {
      return 65536.0D;
   }

   @Nullable
   private static ux f(int var0) {
      ux var1 = ux.a(var0);
      return f.contains(var1) ? var1 : null;
   }

   public void a(fy var1) {
      super.a(var1);
      this.l = f(var1.h("Primary"));
      this.m = f(var1.h("Secondary"));
      this.k = var1.h("Levels");
   }

   public fy b(fy var1) {
      super.b(var1);
      var1.a("Primary", ux.a(this.l));
      var1.a("Secondary", ux.a(this.m));
      var1.a("Levels", this.k);
      return var1;
   }

   public int w_() {
      return 1;
   }

   public boolean x_() {
      return this.n.b();
   }

   public ain a(int var1) {
      return var1 == 0 ? this.n : ain.a;
   }

   public ain a(int var1, int var2) {
      if (var1 == 0 && !this.n.b()) {
         if (var2 >= this.n.E()) {
            ain var3 = this.n;
            this.n = ain.a;
            return var3;
         } else {
            return this.n.a(var2);
         }
      } else {
         return ain.a;
      }
   }

   public ain c_(int var1) {
      if (var1 == 0) {
         ain var2 = this.n;
         this.n = ain.a;
         return var2;
      } else {
         return ain.a;
      }
   }

   public void a(int var1, ain var2) {
      if (var1 == 0) {
         this.n = var2;
      }

   }

   public String h_() {
      return this.n_() ? this.o : "container.beacon";
   }

   public boolean n_() {
      return this.o != null && !this.o.isEmpty();
   }

   public void a(String var1) {
      this.o = var1;
   }

   public int z_() {
      return 1;
   }

   public boolean a(aeb var1) {
      if (this.b.r(this.c) != this) {
         return false;
      } else {
         return !(var1.d((double)this.c.p() + 0.5D, (double)this.c.q() + 0.5D, (double)this.c.r() + 0.5D) > 64.0D);
      }
   }

   public void b(aeb var1) {
   }

   public void c(aeb var1) {
   }

   public boolean b(int var1, ain var2) {
      return var2.c() == aip.bZ || var2.c() == aip.l || var2.c() == aip.n || var2.c() == aip.m;
   }

   public String l() {
      return "minecraft:beacon";
   }

   public afp a(aea var1, aeb var2) {
      return new afr(var1, this);
   }

   public int c(int var1) {
      switch(var1) {
      case 0:
         return this.k;
      case 1:
         return ux.a(this.l);
      case 2:
         return ux.a(this.m);
      default:
         return 0;
      }
   }

   public void b(int var1, int var2) {
      switch(var1) {
      case 0:
         this.k = var2;
         break;
      case 1:
         this.l = f(var2);
         break;
      case 2:
         this.m = f(var2);
      }

   }

   public int h() {
      return 3;
   }

   public void m() {
      this.n = ain.a;
   }

   public boolean c(int var1, int var2) {
      if (var1 == 1) {
         this.n();
         return true;
      } else {
         return super.c(var1, var2);
      }
   }

   public int[] a(fa var1) {
      return new int[0];
   }

   public boolean a(int var1, ain var2, fa var3) {
      return false;
   }

   public boolean b(int var1, ain var2, fa var3) {
      return false;
   }

   static {
      a = new ux[][]{{uz.a, uz.c}, {uz.k, uz.h}, {uz.e}, {uz.j}};
      f = Sets.newHashSet();
      ux[][] var0 = a;
      int var1 = var0.length;

      for(int var2 = 0; var2 < var1; ++var2) {
         ux[] var3 = var0[var2];
         Collections.addAll(f, var3);
      }

   }

   public static class a {
      private final float[] a;
      private int b;

      public a(float[] var1) {
         this.a = var1;
         this.b = 1;
      }

      protected void a() {
         ++this.b;
      }

      public float[] b() {
         return this.a;
      }

      public int c() {
         return this.b;
      }
   }
}
