import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public class agz extends ail {
   protected final aou a;

   public agz(aou var1) {
      this.a = var1;
   }

   public ub a(aeb var1, ams var2, et var3, tz var4, fa var5, float var6, float var7, float var8) {
      awr var9 = var2.o(var3);
      aou var10 = var9.u();
      if (!var10.a((amw)var2, (et)var3)) {
         var3 = var3.a(var5);
      }

      ain var11 = var1.b((tz)var4);
      if (!var11.b() && var1.a(var3, var5, var11) && var2.a(this.a, var3, false, var5, (ve)null)) {
         int var12 = this.a(var11.j());
         awr var13 = this.a.a(var2, var3, var5, var6, var7, var8, var12, var1);
         if (var2.a((et)var3, (awr)var13, 11)) {
            var13 = var2.o(var3);
            if (var13.u() == this.a) {
               a(var2, var1, var3, var11);
               this.a.a((ams)var2, (et)var3, (awr)var13, (vn)var1, (ain)var11);
               if (var1 instanceof oo) {
                  m.x.a((oo)var1, var3, var11);
               }
            }

            atw var14 = this.a.v();
            var2.a(var1, var3, var14.e(), qe.e, (var14.a() + 1.0F) / 2.0F, var14.b() * 0.8F);
            var11.g(1);
         }

         return ub.a;
      } else {
         return ub.c;
      }
   }

   public static boolean a(ams var0, @Nullable aeb var1, et var2, ain var3) {
      MinecraftServer var4 = var0.u();
      if (var4 == null) {
         return false;
      } else {
         fy var5 = var3.d("BlockEntityTag");
         if (var5 != null) {
            avh var6 = var0.r(var2);
            if (var6 != null) {
               if (!var0.G && var6.C() && (var1 == null || !var1.dv())) {
                  return false;
               }

               fy var7 = var6.b(new fy());
               fy var8 = var7.g();
               var7.a(var5);
               var7.a("x", var2.p());
               var7.a("y", var2.q());
               var7.a("z", var2.r());
               if (!var7.equals(var8)) {
                  var6.a(var7);
                  var6.y_();
                  return true;
               }
            }
         }

         return false;
      }
   }

   public boolean a(ams var1, et var2, fa var3, aeb var4, ain var5) {
      aou var6 = var1.o(var2).u();
      if (var6 == aov.aH) {
         var3 = fa.b;
      } else if (!var6.a((amw)var1, (et)var2)) {
         var2 = var2.a(var3);
      }

      return var1.a(this.a, var2, false, var3, (ve)null);
   }

   public String a(ain var1) {
      return this.a.a();
   }

   public String a() {
      return this.a.a();
   }

   public ahn b() {
      return this.a.q();
   }

   public void a(ahn var1, fi<ain> var2) {
      if (this.a(var1)) {
         this.a.a(var1, var2);
      }

   }

   public void a(ain var1, @Nullable ams var2, List<String> var3, ajz var4) {
      super.a(var1, var2, var3, var4);
      this.a.a(var1, var2, var3, var4);
   }

   public aou d() {
      return this.a;
   }
}
