import javax.annotation.Nullable;

public class ahj extends ail {
   public ahj() {
      this.a(new nd("time"), new aio() {
         double a;
         double b;
         long c;

         public float a(ain var1, @Nullable ams var2, @Nullable vn var3) {
            boolean var4 = var3 != null;
            ve var5 = var4 ? var3 : var1.A();
            if (var2 == null && var5 != null) {
               var2 = ((ve)var5).l;
            }

            if (var2 == null) {
               return 0.0F;
            } else {
               double var6;
               if (var2.s.d()) {
                  var6 = (double)var2.c(1.0F);
               } else {
                  var6 = Math.random();
               }

               var6 = this.a(var2, var6);
               return (float)var6;
            }
         }

         private double a(ams var1, double var2) {
            if (var1.R() != this.c) {
               this.c = var1.R();
               double var4 = var2 - this.a;
               var4 = ri.b(var4 + 0.5D, 1.0D) - 0.5D;
               this.b += var4 * 0.1D;
               this.b *= 0.9D;
               this.a = ri.b(this.a + this.b, 1.0D);
            }

            return this.a;
         }
      });
   }
}
