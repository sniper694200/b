import java.io.IOException;

public class mj implements ht<mf> {
   private hh a;

   public mj() {
   }

   public mj(hh var1) {
      this.a = var1;
   }

   public void a(gy var1) throws IOException {
      this.a = hh.a.b(var1.e(32767));
   }

   public void b(gy var1) throws IOException {
      var1.a(this.a);
   }

   public void a(mf var1) {
      var1.a(this);
   }

   public hh a() {
      return this.a;
   }
}
