import java.io.IOException;

public class ju implements ht<hw> {
   private String a;
   private String b;

   public ju() {
   }

   public ju(String var1, String var2) {
      this.a = var1;
      this.b = var2;
      if (var2.length() > 40) {
         throw new IllegalArgumentException("Hash is too long (max 40, was " + var2.length() + ")");
      }
   }

   public void a(gy var1) throws IOException {
      this.a = var1.e(32767);
      this.b = var1.e(40);
   }

   public void b(gy var1) throws IOException {
      var1.a(this.a);
      var1.a(this.b);
   }

   public void a(hw var1) {
      var1.a(this);
   }

   public String a() {
      return this.a;
   }

   public String b() {
      return this.b;
   }
}
