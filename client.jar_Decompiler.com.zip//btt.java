public class btt extends btj {
   public btt(ams var1, double var2, double var4, double var6, double var8, double var10, double var12) {
      super(var1, var2, var4, var6, 176, 8, -0.05F);
      this.j = var8;
      this.k = var10;
      this.l = var12;
      this.y *= 0.75F;
      this.x = 60 + this.r.nextInt(12);
      if (this.r.nextInt(4) == 0) {
         this.a(0.6F + this.r.nextFloat() * 0.2F, 0.6F + this.r.nextFloat() * 0.3F, this.r.nextFloat() * 0.2F);
      } else {
         this.a(0.1F + this.r.nextFloat() * 0.2F, 0.4F + this.r.nextFloat() * 0.3F, this.r.nextFloat() * 0.2F);
      }

      this.f(0.6F);
   }

   public static class a implements btf {
      public btd a(int var1, ams var2, double var3, double var5, double var7, double var9, double var11, double var13, int... var15) {
         return new btt(var2, var3, var5, var7, var9, var11, var13);
      }
   }
}
