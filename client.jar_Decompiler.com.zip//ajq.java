public class ajq extends agz {
   private final ard b;
   private final ard c;

   public ajq(aou var1, ard var2, ard var3) {
      super(var1);
      this.b = var2;
      this.c = var3;
      this.e(0);
      this.a(true);
   }

   public int a(int var1) {
      return var1;
   }

   public String a(ain var1) {
      return this.b.b(var1.j());
   }

   public ub a(aeb var1, ams var2, et var3, tz var4, fa var5, float var6, float var7, float var8) {
      ain var9 = var1.b((tz)var4);
      if (!var9.b() && var1.a(var3.a(var5), var5, var9)) {
         Comparable<?> var10 = this.b.a(var9);
         awr var11 = var2.o(var3);
         if (var11.u() == this.b) {
            axh<?> var12 = this.b.g();
            Comparable<?> var13 = var11.c(var12);
            ard.a var14 = (ard.a)var11.c(ard.a);
            if ((var5 == fa.b && var14 == ard.a.b || var5 == fa.a && var14 == ard.a.a) && var13 == var10) {
               awr var15 = this.a(var12, var13);
               bgz var16 = var15.d(var2, var3);
               if (var16 != aou.k && var2.b(var16.a(var3)) && var2.a((et)var3, (awr)var15, 11)) {
                  atw var17 = this.c.v();
                  var2.a(var1, var3, var17.e(), qe.e, (var17.a() + 1.0F) / 2.0F, var17.b() * 0.8F);
                  var9.g(1);
                  if (var1 instanceof oo) {
                     m.x.a((oo)var1, var3, var9);
                  }
               }

               return ub.a;
            }
         }

         return this.a((aeb)var1, (ain)var9, (ams)var2, (et)var3.a(var5), (Object)var10) ? ub.a : super.a(var1, var2, var3, var4, var5, var6, var7, var8);
      } else {
         return ub.c;
      }
   }

   public boolean a(ams var1, et var2, fa var3, aeb var4, ain var5) {
      et var6 = var2;
      axh<?> var7 = this.b.g();
      Comparable<?> var8 = this.b.a(var5);
      awr var9 = var1.o(var2);
      if (var9.u() == this.b) {
         boolean var10 = var9.c(ard.a) == ard.a.a;
         if ((var3 == fa.b && !var10 || var3 == fa.a && var10) && var8 == var9.c(var7)) {
            return true;
         }
      }

      var2 = var2.a(var3);
      awr var11 = var1.o(var2);
      return var11.u() == this.b && var8 == var11.c(var7) ? true : super.a(var1, var6, var3, var4, var5);
   }

   private boolean a(aeb var1, ain var2, ams var3, et var4, Object var5) {
      awr var6 = var3.o(var4);
      if (var6.u() == this.b) {
         Comparable<?> var7 = var6.c(this.b.g());
         if (var7 == var5) {
            awr var8 = this.a(this.b.g(), var7);
            bgz var9 = var8.d(var3, var4);
            if (var9 != aou.k && var3.b(var9.a(var4)) && var3.a((et)var4, (awr)var8, 11)) {
               atw var10 = this.c.v();
               var3.a(var1, var4, var10.e(), qe.e, (var10.a() + 1.0F) / 2.0F, var10.b() * 0.8F);
               var2.g(1);
            }

            return true;
         }
      }

      return false;
   }

   protected <T extends Comparable<T>> awr a(axh<T> var1, Comparable<?> var2) {
      return this.c.t().a(var1, var2);
   }
}
