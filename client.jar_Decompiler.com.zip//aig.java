public class aig extends ail {
   public aig() {
      this.k = 1;
      this.e(64);
      this.b(ahn.i);
   }

   public ub a(aeb var1, ams var2, et var3, tz var4, fa var5, float var6, float var7, float var8) {
      var3 = var3.a(var5);
      ain var9 = var1.b((tz)var4);
      if (!var1.a(var3, var5, var9)) {
         return ub.c;
      } else {
         if (var2.o(var3).a() == bcx.a) {
            var2.a(var1, var3, qd.bO, qe.e, 1.0F, j.nextFloat() * 0.4F + 0.8F);
            var2.a((et)var3, (awr)aov.ab.t(), 11);
         }

         if (var1 instanceof oo) {
            m.x.a((oo)var1, var3, var9);
         }

         var9.a(1, var1);
         return ub.a;
      }
   }
}
