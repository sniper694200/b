import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;

public interface bl {
   int a(bn var1, String var2);

   List<String> a(bn var1, String var2, @Nullable et var3);

   List<bk> a(bn var1);

   Map<String, bk> b();
}
