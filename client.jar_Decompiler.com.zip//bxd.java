import java.util.List;

public class bxd extends bww<awa> {
   private static final nd a = new nd("textures/entity/sign.png");
   private final bqr d = new bqr();

   public void a(awa var1, double var2, double var4, double var6, float var8, int var9, float var10) {
      aou var11 = var1.x();
      buq.G();
      float var12 = 0.6666667F;
      float var14;
      if (var11 == aov.an) {
         buq.c((float)var2 + 0.5F, (float)var4 + 0.5F, (float)var6 + 0.5F);
         float var13 = (float)(var1.v() * 360) / 16.0F;
         buq.b(-var13, 0.0F, 1.0F, 0.0F);
         this.d.b.j = true;
      } else {
         int var20 = var1.v();
         var14 = 0.0F;
         if (var20 == 2) {
            var14 = 180.0F;
         }

         if (var20 == 4) {
            var14 = 90.0F;
         }

         if (var20 == 5) {
            var14 = -90.0F;
         }

         buq.c((float)var2 + 0.5F, (float)var4 + 0.5F, (float)var6 + 0.5F);
         buq.b(-var14, 0.0F, 1.0F, 0.0F);
         buq.c(0.0F, -0.3125F, -0.4375F);
         this.d.b.j = false;
      }

      if (var9 >= 0) {
         this.a(b[var9]);
         buq.n(5890);
         buq.G();
         buq.b(4.0F, 2.0F, 1.0F);
         buq.c(0.0625F, 0.0625F, 0.0625F);
         buq.n(5888);
      } else {
         this.a(a);
      }

      buq.D();
      buq.G();
      buq.b(0.6666667F, -0.6666667F, -0.6666667F);
      this.d.a();
      buq.H();
      bin var21 = this.b();
      var14 = 0.010416667F;
      buq.c(0.0F, 0.33333334F, 0.046666667F);
      buq.b(0.010416667F, -0.010416667F, 0.010416667F);
      buq.a(0.0F, 0.0F, -0.010416667F);
      buq.a(false);
      int var15 = false;
      if (var9 < 0) {
         for(int var16 = 0; var16 < var1.a.length; ++var16) {
            if (var1.a[var16] != null) {
               hh var17 = var1.a[var16];
               List<hh> var18 = bja.a(var17, 90, var21, false, true);
               String var19 = var18 != null && !var18.isEmpty() ? ((hh)var18.get(0)).d() : "";
               if (var16 == var1.f) {
                  var19 = "> " + var19 + " <";
                  var21.a(var19, -var21.a(var19) / 2, var16 * 10 - var1.a.length * 5, 0);
               } else {
                  var21.a(var19, -var21.a(var19) / 2, var16 * 10 - var1.a.length * 5, 0);
               }
            }
         }
      }

      buq.a(true);
      buq.c(1.0F, 1.0F, 1.0F, 1.0F);
      buq.H();
      if (var9 >= 0) {
         buq.n(5890);
         buq.H();
         buq.n(5888);
      }

   }
}
