import com.google.common.collect.Sets;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.Set;
import javax.annotation.Nullable;

public class bem extends bei {
   protected float j;

   public void a(amw var1, vo var2) {
      super.a(var1, var2);
      this.j = var2.a(bef.g);
   }

   public void a() {
      this.b.a(bef.g, this.j);
      super.a();
   }

   public beh b() {
      int var1;
      et var2;
      if (this.e() && this.b.ao()) {
         var1 = (int)this.b.bw().b;
         et.a var8 = new et.a(ri.c(this.b.p), var1, ri.c(this.b.r));

         for(aou var3 = this.a.o(var8).u(); var3 == aov.i || var3 == aov.j; var3 = this.a.o(var8).u()) {
            ++var1;
            var8.c(ri.c(this.b.p), var1, ri.c(this.b.r));
         }
      } else if (this.b.z) {
         var1 = ri.c(this.b.bw().b + 0.5D);
      } else {
         for(var2 = new et(this.b); (this.a.o(var2).a() == bcx.a || this.a.o(var2).u().b(this.a, var2)) && var2.q() > 0; var2 = var2.b()) {
         }

         var1 = var2.a().q();
      }

      var2 = new et(this.b);
      bef var9 = this.a(this.b, var2.p(), var1, var2.r());
      if (this.b.a(var9) < 0.0F) {
         Set<et> var4 = Sets.newHashSet();
         var4.add(new et(this.b.bw().a, (double)var1, this.b.bw().c));
         var4.add(new et(this.b.bw().a, (double)var1, this.b.bw().f));
         var4.add(new et(this.b.bw().d, (double)var1, this.b.bw().c));
         var4.add(new et(this.b.bw().d, (double)var1, this.b.bw().f));
         Iterator var5 = var4.iterator();

         while(var5.hasNext()) {
            et var6 = (et)var5.next();
            bef var7 = this.a(this.b, var6);
            if (this.b.a(var7) >= 0.0F) {
               return this.a(var6.p(), var6.q(), var6.r());
            }
         }
      }

      return this.a(var2.p(), var1, var2.r());
   }

   public beh a(double var1, double var3, double var5) {
      return this.a(ri.c(var1), ri.c(var3), ri.c(var5));
   }

   public int a(beh[] var1, beh var2, beh var3, float var4) {
      int var5 = 0;
      int var6 = 0;
      bef var7 = this.a(this.b, var2.a, var2.b + 1, var2.c);
      if (this.b.a(var7) >= 0.0F) {
         var6 = ri.d(Math.max(1.0F, this.b.P));
      }

      et var8 = (new et(var2.a, var2.b, var2.c)).b();
      double var9 = (double)var2.b - (1.0D - this.a.o(var8).e(this.a, var8).e);
      beh var11 = this.a(var2.a, var2.b, var2.c + 1, var6, var9, fa.d);
      beh var12 = this.a(var2.a - 1, var2.b, var2.c, var6, var9, fa.e);
      beh var13 = this.a(var2.a + 1, var2.b, var2.c, var6, var9, fa.f);
      beh var14 = this.a(var2.a, var2.b, var2.c - 1, var6, var9, fa.c);
      if (var11 != null && !var11.i && var11.a(var3) < var4) {
         var1[var5++] = var11;
      }

      if (var12 != null && !var12.i && var12.a(var3) < var4) {
         var1[var5++] = var12;
      }

      if (var13 != null && !var13.i && var13.a(var3) < var4) {
         var1[var5++] = var13;
      }

      if (var14 != null && !var14.i && var14.a(var3) < var4) {
         var1[var5++] = var14;
      }

      boolean var15 = var14 == null || var14.m == bef.b || var14.l != 0.0F;
      boolean var16 = var11 == null || var11.m == bef.b || var11.l != 0.0F;
      boolean var17 = var13 == null || var13.m == bef.b || var13.l != 0.0F;
      boolean var18 = var12 == null || var12.m == bef.b || var12.l != 0.0F;
      beh var19;
      if (var15 && var18) {
         var19 = this.a(var2.a - 1, var2.b, var2.c - 1, var6, var9, fa.c);
         if (var19 != null && !var19.i && var19.a(var3) < var4) {
            var1[var5++] = var19;
         }
      }

      if (var15 && var17) {
         var19 = this.a(var2.a + 1, var2.b, var2.c - 1, var6, var9, fa.c);
         if (var19 != null && !var19.i && var19.a(var3) < var4) {
            var1[var5++] = var19;
         }
      }

      if (var16 && var18) {
         var19 = this.a(var2.a - 1, var2.b, var2.c + 1, var6, var9, fa.d);
         if (var19 != null && !var19.i && var19.a(var3) < var4) {
            var1[var5++] = var19;
         }
      }

      if (var16 && var17) {
         var19 = this.a(var2.a + 1, var2.b, var2.c + 1, var6, var9, fa.d);
         if (var19 != null && !var19.i && var19.a(var3) < var4) {
            var1[var5++] = var19;
         }
      }

      return var5;
   }

   @Nullable
   private beh a(int var1, int var2, int var3, int var4, double var5, fa var7) {
      beh var8 = null;
      et var9 = new et(var1, var2, var3);
      et var10 = var9.b();
      double var11 = (double)var2 - (1.0D - this.a.o(var10).e(this.a, var10).e);
      if (var11 - var5 > 1.125D) {
         return null;
      } else {
         bef var13 = this.a(this.b, var1, var2, var3);
         float var14 = this.b.a(var13);
         double var15 = (double)this.b.G / 2.0D;
         if (var14 >= 0.0F) {
            var8 = this.a(var1, var2, var3);
            var8.m = var13;
            var8.l = Math.max(var8.l, var14);
         }

         if (var13 == bef.c) {
            return var8;
         } else {
            if (var8 == null && var4 > 0 && var13 != bef.e && var13 != bef.d) {
               var8 = this.a(var1, var2 + 1, var3, var4 - 1, var5, var7);
               if (var8 != null && (var8.m == bef.b || var8.m == bef.c) && this.b.G < 1.0F) {
                  double var17 = (double)(var1 - var7.g()) + 0.5D;
                  double var19 = (double)(var3 - var7.i()) + 0.5D;
                  bgz var21 = new bgz(var17 - var15, (double)var2 + 0.001D, var19 - var15, var17 + var15, (double)((float)var2 + this.b.H), var19 + var15);
                  bgz var22 = this.a.o(var9).e(this.a, var9);
                  bgz var23 = var21.b(0.0D, var22.e - 0.002D, 0.0D);
                  if (this.b.l.a(var23)) {
                     var8 = null;
                  }
               }
            }

            if (var13 == bef.b) {
               bgz var24 = new bgz((double)var1 - var15 + 0.5D, (double)var2 + 0.001D, (double)var3 - var15 + 0.5D, (double)var1 + var15 + 0.5D, (double)((float)var2 + this.b.H), (double)var3 + var15 + 0.5D);
               if (this.b.l.a(var24)) {
                  return null;
               }

               if (this.b.G >= 1.0F) {
                  bef var18 = this.a(this.b, var1, var2 - 1, var3);
                  if (var18 == bef.a) {
                     var8 = this.a(var1, var2, var3);
                     var8.m = bef.c;
                     var8.l = Math.max(var8.l, var14);
                     return var8;
                  }
               }

               int var25 = 0;

               while(var2 > 0 && var13 == bef.b) {
                  --var2;
                  if (var25++ >= this.b.bg()) {
                     return null;
                  }

                  var13 = this.a(this.b, var1, var2, var3);
                  var14 = this.b.a(var13);
                  if (var13 != bef.b && var14 >= 0.0F) {
                     var8 = this.a(var1, var2, var3);
                     var8.m = var13;
                     var8.l = Math.max(var8.l, var14);
                     break;
                  }

                  if (var14 < 0.0F) {
                     return null;
                  }
               }
            }

            return var8;
         }
      }
   }

   public bef a(amw var1, int var2, int var3, int var4, vo var5, int var6, int var7, int var8, boolean var9, boolean var10) {
      EnumSet<bef> var11 = EnumSet.noneOf(bef.class);
      bef var12 = bef.a;
      double var13 = (double)var5.G / 2.0D;
      et var15 = new et(var5);
      var12 = this.a(var1, var2, var3, var4, var6, var7, var8, var9, var10, var11, var12, var15);
      if (var11.contains(bef.e)) {
         return bef.e;
      } else {
         bef var16 = bef.a;
         Iterator var17 = var11.iterator();

         while(var17.hasNext()) {
            bef var18 = (bef)var17.next();
            if (var5.a(var18) < 0.0F) {
               return var18;
            }

            if (var5.a(var18) >= var5.a(var16)) {
               var16 = var18;
            }
         }

         if (var12 == bef.b && var5.a(var16) == 0.0F) {
            return bef.b;
         } else {
            return var16;
         }
      }
   }

   public bef a(amw var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean var8, boolean var9, EnumSet<bef> var10, bef var11, et var12) {
      for(int var13 = 0; var13 < var5; ++var13) {
         for(int var14 = 0; var14 < var6; ++var14) {
            for(int var15 = 0; var15 < var7; ++var15) {
               int var16 = var13 + var2;
               int var17 = var14 + var3;
               int var18 = var15 + var4;
               bef var19 = this.a(var1, var16, var17, var18);
               if (var19 == bef.p && var8 && var9) {
                  var19 = bef.c;
               }

               if (var19 == bef.o && !var9) {
                  var19 = bef.a;
               }

               if (var19 == bef.h && !(var1.o(var12).u() instanceof aoq) && !(var1.o(var12.b()).u() instanceof aoq)) {
                  var19 = bef.e;
               }

               if (var13 == 0 && var14 == 0 && var15 == 0) {
                  var11 = var19;
               }

               var10.add(var19);
            }
         }
      }

      return var11;
   }

   private bef a(vo var1, et var2) {
      return this.a(var1, var2.p(), var2.q(), var2.r());
   }

   private bef a(vo var1, int var2, int var3, int var4) {
      return this.a(this.a, var2, var3, var4, var1, this.d, this.e, this.f, this.d(), this.c());
   }

   public bef a(amw var1, int var2, int var3, int var4) {
      bef var5 = this.b(var1, var2, var3, var4);
      if (var5 == bef.b && var3 >= 1) {
         aou var6 = var1.o(new et(var2, var3 - 1, var4)).u();
         bef var7 = this.b(var1, var2, var3 - 1, var4);
         var5 = var7 != bef.c && var7 != bef.b && var7 != bef.g && var7 != bef.f ? bef.c : bef.b;
         if (var7 == bef.j || var6 == aov.df) {
            var5 = bef.j;
         }

         if (var7 == bef.l) {
            var5 = bef.l;
         }
      }

      var5 = this.a(var1, var2, var3, var4, var5);
      return var5;
   }

   public bef a(amw var1, int var2, int var3, int var4, bef var5) {
      et.b var6 = et.b.s();
      if (var5 == bef.c) {
         for(int var7 = -1; var7 <= 1; ++var7) {
            for(int var8 = -1; var8 <= 1; ++var8) {
               if (var7 != 0 || var8 != 0) {
                  aou var9 = var1.o(var6.f(var7 + var2, var3, var8 + var4)).u();
                  if (var9 == aov.aK) {
                     var5 = bef.k;
                  } else if (var9 == aov.ab) {
                     var5 = bef.i;
                  }
               }
            }
         }
      }

      var6.t();
      return var5;
   }

   protected bef b(amw var1, int var2, int var3, int var4) {
      et var5 = new et(var2, var3, var4);
      awr var6 = var1.o(var5);
      aou var7 = var6.u();
      bcx var8 = var6.a();
      if (var8 == bcx.a) {
         return bef.b;
      } else if (var7 != aov.bd && var7 != aov.cw && var7 != aov.bx) {
         if (var7 == aov.ab) {
            return bef.j;
         } else if (var7 == aov.aK) {
            return bef.l;
         } else if (var7 instanceof apy && var8 == bcx.d && !(Boolean)var6.c(apy.b)) {
            return bef.p;
         } else if (var7 instanceof apy && var8 == bcx.f && !(Boolean)var6.c(apy.b)) {
            return bef.q;
         } else if (var7 instanceof apy && (Boolean)var6.c(apy.b)) {
            return bef.o;
         } else if (var7 instanceof aoq) {
            return bef.h;
         } else if (!(var7 instanceof aqm) && !(var7 instanceof aut) && (!(var7 instanceof aqn) || (Boolean)var6.c(aqn.a))) {
            if (var8 == bcx.h) {
               return bef.g;
            } else if (var8 == bcx.i) {
               return bef.f;
            } else {
               return var7.b(var1, var5) ? bef.b : bef.a;
            }
         } else {
            return bef.e;
         }
      } else {
         return bef.d;
      }
   }
}
