public class btw extends btd {
   protected btw(ams var1, double var2, double var4, double var6) {
      super(var1, var2, var4, var6, 0.0D, 0.0D, 0.0D);
      this.j *= 0.30000001192092896D;
      this.k = Math.random() * 0.20000000298023224D + 0.10000000149011612D;
      this.l *= 0.30000001192092896D;
      this.A = 1.0F;
      this.B = 1.0F;
      this.C = 1.0F;
      this.b(19 + this.r.nextInt(4));
      this.a(0.01F, 0.01F);
      this.z = 0.06F;
      this.x = (int)(8.0D / (Math.random() * 0.8D + 0.2D));
   }

   public void a() {
      this.d = this.g;
      this.e = this.h;
      this.f = this.i;
      this.k -= (double)this.z;
      this.a(this.j, this.k, this.l);
      this.j *= 0.9800000190734863D;
      this.k *= 0.9800000190734863D;
      this.l *= 0.9800000190734863D;
      if (this.x-- <= 0) {
         this.i();
      }

      if (this.m) {
         if (Math.random() < 0.5D) {
            this.i();
         }

         this.j *= 0.699999988079071D;
         this.l *= 0.699999988079071D;
      }

      et var1 = new et(this.g, this.h, this.i);
      awr var2 = this.c.o(var1);
      bcx var3 = var2.a();
      if (var3.d() || var3.a()) {
         double var4;
         if (var2.u() instanceof ars) {
            var4 = (double)(1.0F - ars.b((Integer)var2.c(ars.b)));
         } else {
            var4 = var2.e(this.c, var1).e;
         }

         double var6 = (double)ri.c(this.h) + var4;
         if (this.h < var6) {
            this.i();
         }
      }

   }

   public static class a implements btf {
      public btd a(int var1, ams var2, double var3, double var5, double var7, double var9, double var11, double var13, int... var15) {
         return new btw(var2, var3, var5, var7);
      }
   }
}
