public class cah extends cad<aaa> {
   public static final nd[] a = new nd[]{new nd("textures/entity/parrot/parrot_red_blue.png"), new nd("textures/entity/parrot/parrot_blue.png"), new nd("textures/entity/parrot/parrot_green.png"), new nd("textures/entity/parrot/parrot_yellow_blue.png"), new nd("textures/entity/parrot/parrot_grey.png")};

   public cah(bzd var1) {
      super(var1, new bqf(), 0.3F);
   }

   protected nd a(aaa var1) {
      return a[var1.du()];
   }

   public float a(aaa var1, float var2) {
      return this.b(var1, var2);
   }

   private float b(aaa var1, float var2) {
      float var3 = var1.bE + (var1.bB - var1.bE) * var2;
      float var4 = var1.bD + (var1.bC - var1.bD) * var2;
      return (ri.a(var3) + 1.0F) * var4;
   }

   // $FF: synthetic method
   public float b(vn var1, float var2) {
      return this.a((aaa)var1, var2);
   }
}
