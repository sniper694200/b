import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public class ajt extends ail {
   public ajt() {
      this.b(ahn.f);
   }

   public String b(ain var1) {
      String var2 = ("" + ft.a(this.a() + ".name")).trim();
      String var3 = vg.a(h(var1));
      if (var3 != null) {
         var2 = var2 + " " + ft.a("entity." + var3 + ".name");
      }

      return var2;
   }

   public ub a(aeb var1, ams var2, et var3, tz var4, fa var5, float var6, float var7, float var8) {
      ain var9 = var1.b((tz)var4);
      if (var2.G) {
         return ub.a;
      } else if (!var1.a(var3.a(var5), var5, var9)) {
         return ub.c;
      } else {
         awr var10 = var2.o(var3);
         aou var11 = var10.u();
         if (var11 == aov.ac) {
            avh var12 = var2.r(var3);
            if (var12 instanceof avw) {
               ami var17 = ((avw)var12).a();
               var17.a(h(var9));
               var12.y_();
               var2.a(var3, var10, var10, 3);
               if (!var1.bO.d) {
                  var9.g(1);
               }

               return ub.a;
            }
         }

         et var16 = var3.a(var5);
         double var13 = this.a(var2, var16);
         ve var15 = a(var2, h(var9), (double)var16.p() + 0.5D, (double)var16.q() + var13, (double)var16.r() + 0.5D);
         if (var15 != null) {
            if (var15 instanceof vn && var9.t()) {
               var15.c(var9.r());
            }

            a(var2, var1, var9, var15);
            if (!var1.bO.d) {
               var9.g(1);
            }
         }

         return ub.a;
      }
   }

   protected double a(ams var1, et var2) {
      bgz var3 = (new bgz(var2)).b(0.0D, -1.0D, 0.0D);
      List<bgz> var4 = var1.a((ve)null, (bgz)var3);
      if (var4.isEmpty()) {
         return 0.0D;
      } else {
         double var5 = var3.b;

         bgz var8;
         for(Iterator var7 = var4.iterator(); var7.hasNext(); var5 = Math.max(var8.e, var5)) {
            var8 = (bgz)var7.next();
         }

         return var5 - (double)var2.q();
      }
   }

   public static void a(ams var0, @Nullable aeb var1, ain var2, @Nullable ve var3) {
      MinecraftServer var4 = var0.u();
      if (var4 != null && var3 != null) {
         fy var5 = var2.p();
         if (var5 != null && var5.b("EntityTag", 10)) {
            if (!var0.G && var3.bC() && (var1 == null || !var4.am().h(var1.da()))) {
               return;
            }

            fy var6 = var3.e(new fy());
            UUID var7 = var3.bm();
            var6.a(var5.p("EntityTag"));
            var3.a(var7);
            var3.f(var6);
         }

      }
   }

   public uc<ain> a(ams var1, aeb var2, tz var3) {
      ain var4 = var2.b((tz)var3);
      if (var1.G) {
         return new uc(ub.b, var4);
      } else {
         bha var5 = this.a(var1, var2, true);
         if (var5 != null && var5.a == bha.a.b) {
            et var6 = var5.a();
            if (!(var1.o(var6).u() instanceof ars)) {
               return new uc(ub.b, var4);
            } else if (var1.a(var2, var6) && var2.a(var6, var5.b, var4)) {
               ve var7 = a(var1, h(var4), (double)var6.p() + 0.5D, (double)var6.q() + 0.5D, (double)var6.r() + 0.5D);
               if (var7 == null) {
                  return new uc(ub.b, var4);
               } else {
                  if (var7 instanceof vn && var4.t()) {
                     var7.c(var4.r());
                  }

                  a(var1, var2, var4, var7);
                  if (!var2.bO.d) {
                     var4.g(1);
                  }

                  var2.b(qq.b((ail)this));
                  return new uc(ub.a, var4);
               }
            } else {
               return new uc(ub.c, var4);
            }
         } else {
            return new uc(ub.b, var4);
         }
      }
   }

   @Nullable
   public static ve a(ams var0, @Nullable nd var1, double var2, double var4, double var6) {
      if (var1 != null && vg.c.containsKey(var1)) {
         ve var8 = null;

         for(int var9 = 0; var9 < 1; ++var9) {
            var8 = vg.a(var1, var0);
            if (var8 instanceof vo) {
               vo var10 = (vo)var8;
               var8.b(var2, var4, var6, ri.g(var0.r.nextFloat() * 360.0F), 0.0F);
               var10.aP = var10.v;
               var10.aN = var10.v;
               var10.a((ty)var0.D(new et(var10)), (vq)null);
               var0.a(var8);
               var10.D();
            }
         }

         return var8;
      } else {
         return null;
      }
   }

   public void a(ahn var1, fi<ain> var2) {
      if (this.a(var1)) {
         Iterator var3 = vg.c.values().iterator();

         while(var3.hasNext()) {
            vg.a var4 = (vg.a)var3.next();
            ain var5 = new ain(this, 1);
            a(var5, var4.a);
            var2.add(var5);
         }
      }

   }

   public static void a(ain var0, nd var1) {
      fy var2 = var0.o() ? var0.p() : new fy();
      fy var3 = new fy();
      var3.a("id", var1.toString());
      var2.a((String)"EntityTag", (gn)var3);
      var0.b(var2);
   }

   @Nullable
   public static nd h(ain var0) {
      fy var1 = var0.p();
      if (var1 == null) {
         return null;
      } else if (!var1.b("EntityTag", 10)) {
         return null;
      } else {
         fy var2 = var1.p("EntityTag");
         if (!var2.b("id", 8)) {
            return null;
         } else {
            String var3 = var2.l("id");
            nd var4 = new nd(var3);
            if (!var3.contains(":")) {
               var2.a("id", var4.toString());
            }

            return var4;
         }
      }
   }
}
