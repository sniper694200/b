import java.util.Iterator;
import java.util.Random;

public class anm extends anf {
   public anm(anf.a var1) {
      super(var1);
      this.u.clear();
      this.q = aov.m.t();
      this.r = aov.m.t();
      this.s.z = -999;
      this.s.D = 2;
      this.s.F = 50;
      this.s.G = 10;
      this.u.clear();
      this.u.add(new anf.c(aad.class, 4, 2, 3));
      Iterator var2 = this.t.iterator();

      while(true) {
         anf.c var3;
         do {
            if (!var2.hasNext()) {
               this.t.add(new anf.c(adr.class, 19, 4, 4));
               this.t.add(new anf.c(ads.class, 1, 1, 1));
               this.t.add(new anf.c(acz.class, 80, 4, 4));
               return;
            }

            var3 = (anf.c)var2.next();
         } while(var3.b != adr.class && var3.b != ads.class);

         var2.remove();
      }
   }

   public void a(ams var1, Random var2, et var3) {
      super.a(var1, var2, var3);
      if (var2.nextInt(1000) == 0) {
         int var4 = var2.nextInt(16) + 8;
         int var5 = var2.nextInt(16) + 8;
         et var6 = var1.l(var3.a(var4, 0, var5)).a();
         (new azn()).b(var1, var2, var6);
      }

      if (var2.nextInt(64) == 0) {
         (new azu()).b(var1, var2, var3);
      }

   }
}
