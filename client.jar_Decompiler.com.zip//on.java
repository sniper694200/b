import java.util.Iterator;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public class on implements amu {
   private final MinecraftServer a;
   private final om b;

   public on(MinecraftServer var1, om var2) {
      this.a = var1;
      this.b = var2;
   }

   public void a(int var1, boolean var2, double var3, double var5, double var7, double var9, double var11, double var13, int... var15) {
   }

   public void a(int var1, boolean var2, boolean var3, double var4, double var6, double var8, double var10, double var12, double var14, int... var16) {
   }

   public void a(ve var1) {
      this.b.v().a(var1);
      if (var1 instanceof oo) {
         this.b.s.a((oo)var1);
      }

   }

   public void b(ve var1) {
      this.b.v().b(var1);
      this.b.af().a(var1);
      if (var1 instanceof oo) {
         this.b.s.b((oo)var1);
      }

   }

   public void a(@Nullable aeb var1, qc var2, qe var3, double var4, double var6, double var8, float var10, float var11) {
      this.a.am().a(var1, var4, var6, var8, var10 > 1.0F ? (double)(16.0F * var10) : 16.0D, this.b.s.q().a(), new kp(var2, var3, var4, var6, var8, var10, var11));
   }

   public void a(int var1, int var2, int var3, int var4, int var5, int var6) {
   }

   public void a(ams var1, et var2, awr var3, awr var4, int var5) {
      this.b.w().a(var2);
   }

   public void a(et var1) {
   }

   public void a(qc var1, et var2) {
   }

   public void a(aeb var1, int var2, et var3, int var4) {
      this.a.am().a(var1, (double)var3.p(), (double)var3.q(), (double)var3.r(), 64.0D, this.b.s.q().a(), new jf(var2, var3, var4, false));
   }

   public void a(int var1, et var2, int var3) {
      this.a.am().a((ht)(new jf(var1, var2, var3, true)));
   }

   public void b(int var1, et var2, int var3) {
      Iterator var4 = this.a.am().v().iterator();

      while(var4.hasNext()) {
         oo var5 = (oo)var4.next();
         if (var5 != null && var5.l == this.b && var5.S() != var1) {
            double var6 = (double)var2.p() - var5.p;
            double var8 = (double)var2.q() - var5.q;
            double var10 = (double)var2.r() - var5.r;
            if (var6 * var6 + var8 * var8 + var10 * var10 < 1024.0D) {
               var5.a.a((ht)(new ig(var1, var2, var3)));
            }
         }
      }

   }
}
