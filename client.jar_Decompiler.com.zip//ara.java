import java.util.Random;

public class ara extends aou {
   protected static final bgz a = new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.9375D, 1.0D);

   protected ara() {
      super(bcx.c);
      this.e(255);
   }

   public boolean a(awr var1, amw var2, et var3, fa var4) {
      switch(var4) {
      case b:
         return true;
      case c:
      case d:
      case e:
      case f:
         awr var5 = var2.o(var3.a(var4));
         aou var6 = var5.u();
         return !var5.p() && var6 != aov.ak && var6 != aov.da;
      default:
         return super.a(var1, var2, var3, var4);
      }
   }

   public void c(ams var1, et var2, awr var3) {
      super.c(var1, var2, var3);
      this.b(var1, var2);
   }

   private void b(ams var1, et var2) {
      if (var1.o(var2.a()).a().a()) {
         var1.a(var2, aov.d.t());
      }

   }

   public bgz b(awr var1, amw var2, et var3) {
      return a;
   }

   public boolean b(awr var1) {
      return false;
   }

   public boolean c(awr var1) {
      return false;
   }

   public ail a(awr var1, Random var2, int var3) {
      return aov.d.a(aov.d.t().a(apw.a, apw.a.a), var2, var3);
   }

   public ain a(ams var1, et var2, awr var3) {
      return new ain(this);
   }

   public void a(awr var1, ams var2, et var3, aou var4, et var5) {
      super.a(var1, var2, var3, var4, var5);
      this.b(var2, var3);
   }

   public awp a(amw var1, awr var2, et var3, fa var4) {
      return var4 == fa.a ? awp.a : awp.i;
   }
}
