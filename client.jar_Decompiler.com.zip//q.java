public interface q {
   nd a();
}
