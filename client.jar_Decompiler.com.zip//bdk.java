public class bdk extends beb {
   public bdk(long var1, bdo var3) {
      super(var1, var3);
   }

   protected int b(int var1, int var2, int var3, int var4) {
      return this.a(new int[]{var1, var2, var3, var4});
   }
}
