public class ep extends em {
   public ep(String var1, Object... var2) {
      super(var1, var2);
   }

   public synchronized Throwable fillInStackTrace() {
      return this;
   }
}
