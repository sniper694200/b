import java.io.IOException;

public class mc implements ht<md> {
   private int a;
   private String b;
   private int c;
   private gx d;

   public mc() {
   }

   public mc(int var1, String var2, int var3, gx var4) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
   }

   public void a(gy var1) throws IOException {
      this.a = var1.g();
      this.b = var1.e(255);
      this.c = var1.readUnsignedShort();
      this.d = gx.a(var1.g());
   }

   public void b(gy var1) throws IOException {
      var1.d(this.a);
      var1.a(this.b);
      var1.writeShort(this.c);
      var1.d(this.d.a());
   }

   public void a(md var1) {
      var1.a(this);
   }

   public gx a() {
      return this.d;
   }

   public int b() {
      return this.a;
   }
}
