import java.util.Iterator;
import java.util.Random;

public class ans extends anf {
   private final boolean x;
   private final bab y = new bab();
   private final baa z = new baa(4);

   public ans(boolean var1, anf.a var2) {
      super(var2);
      this.x = var1;
      if (var1) {
         this.q = aov.aJ.t();
      }

      this.u.clear();
      this.u.add(new anf.c(aad.class, 10, 2, 3));
      this.u.add(new anf.c(aac.class, 1, 1, 2));
      Iterator var3 = this.t.iterator();

      while(var3.hasNext()) {
         anf.c var4 = (anf.c)var3.next();
         if (var4.b == adi.class) {
            var3.remove();
         }
      }

      this.t.add(new anf.c(adi.class, 20, 4, 4));
      this.t.add(new anf.c(adm.class, 80, 4, 4));
   }

   public float f() {
      return 0.07F;
   }

   public void a(ams var1, Random var2, et var3) {
      if (this.x) {
         int var4;
         int var5;
         int var6;
         for(var4 = 0; var4 < 3; ++var4) {
            var5 = var2.nextInt(16) + 8;
            var6 = var2.nextInt(16) + 8;
            this.y.b(var1, var2, var1.l(var3.a(var5, 0, var6)));
         }

         for(var4 = 0; var4 < 2; ++var4) {
            var5 = var2.nextInt(16) + 8;
            var6 = var2.nextInt(16) + 8;
            this.z.b(var1, var2, var1.l(var3.a(var5, 0, var6)));
         }
      }

      super.a(var1, var2, var3);
   }

   public aze a(Random var1) {
      return new bas(false);
   }
}
