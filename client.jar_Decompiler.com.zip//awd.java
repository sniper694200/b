import java.util.Iterator;
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class awd extends awe implements nv {
   private static final Logger a = LogManager.getLogger();
   private long f;
   private int g;
   private et h;
   private boolean i;

   public fy b(fy var1) {
      super.b(var1);
      var1.a("Age", this.f);
      if (this.h != null) {
         var1.a((String)"ExitPortal", (gn)gj.a(this.h));
      }

      if (this.i) {
         var1.a("ExactTeleport", this.i);
      }

      return var1;
   }

   public void a(fy var1) {
      super.a(var1);
      this.f = var1.i("Age");
      if (var1.b("ExitPortal", 10)) {
         this.h = gj.c(var1.p("ExitPortal"));
      }

      this.i = var1.q("ExactTeleport");
   }

   public double t() {
      return 65536.0D;
   }

   public void e() {
      boolean var1 = this.a();
      boolean var2 = this.f();
      ++this.f;
      if (var2) {
         --this.g;
      } else if (!this.b.G) {
         List<ve> var3 = this.b.a(ve.class, new bgz(this.w()));
         if (!var3.isEmpty()) {
            this.a((ve)var3.get(0));
         }

         if (this.f % 2400L == 0L) {
            this.h();
         }
      }

      if (var1 != this.a() || var2 != this.f()) {
         this.y_();
      }

   }

   public boolean a() {
      return this.f < 200L;
   }

   public boolean f() {
      return this.g > 0;
   }

   public float a(float var1) {
      return ri.a(((float)this.f + var1) / 200.0F, 0.0F, 1.0F);
   }

   public float b(float var1) {
      return 1.0F - ri.a(((float)this.g - var1) / 40.0F, 0.0F, 1.0F);
   }

   @Nullable
   public ih c() {
      return new ih(this.c, 8, this.d());
   }

   public fy d() {
      return this.b(new fy());
   }

   public void h() {
      if (!this.b.G) {
         this.g = 40;
         this.b.c(this.w(), this.x(), 1, 0);
         this.y_();
      }

   }

   public boolean c(int var1, int var2) {
      if (var1 == 1) {
         this.g = 40;
         return true;
      } else {
         return super.c(var1, var2);
      }
   }

   public void a(ve var1) {
      if (!this.b.G && !this.f()) {
         this.g = 100;
         if (this.h == null && this.b.s instanceof ayq) {
            this.k();
         }

         if (this.h != null) {
            et var2 = this.i ? this.h : this.j();
            var1.a((double)var2.p() + 0.5D, (double)var2.q() + 0.5D, (double)var2.r() + 0.5D);
         }

         this.h();
      }
   }

   private et j() {
      et var1 = a(this.b, this.h, 5, false);
      a.debug("Best exit position for portal at {} is {}", this.h, var1);
      return var1.a();
   }

   private void k() {
      bhc var1 = (new bhc((double)this.w().p(), 0.0D, (double)this.w().r())).a();
      bhc var2 = var1.a(1024.0D);

      int var3;
      for(var3 = 16; a(this.b, var2).g() > 0 && var3-- > 0; var2 = var2.e(var1.a(-16.0D))) {
         a.debug("Skipping backwards past nonempty chunk at {}", var2);
      }

      for(var3 = 16; a(this.b, var2).g() == 0 && var3-- > 0; var2 = var2.e(var1.a(16.0D))) {
         a.debug("Skipping forward past empty chunk at {}", var2);
      }

      a.debug("Found chunk at {}", var2);
      axu var4 = a(this.b, var2);
      this.h = a(var4);
      if (this.h == null) {
         this.h = new et(var2.b + 0.5D, 75.0D, var2.d + 0.5D);
         a.debug("Failed to find suitable block, settling on {}", this.h);
         (new azq()).b(this.b, new Random(this.h.g()), this.h);
      } else {
         a.debug("Found block at {}", this.h);
      }

      this.h = a(this.b, this.h, 16, true);
      a.debug("Creating portal at {}", this.h);
      this.h = this.h.b(10);
      this.c(this.h);
      this.y_();
   }

   private static et a(ams var0, et var1, int var2, boolean var3) {
      et var4 = null;

      for(int var5 = -var2; var5 <= var2; ++var5) {
         for(int var6 = -var2; var6 <= var2; ++var6) {
            if (var5 != 0 || var6 != 0 || var3) {
               for(int var7 = 255; var7 > (var4 == null ? 0 : var4.q()); --var7) {
                  et var8 = new et(var1.p() + var5, var7, var1.r() + var6);
                  awr var9 = var0.o(var8);
                  if (var9.k() && (var3 || var9.u() != aov.h)) {
                     var4 = var8;
                     break;
                  }
               }
            }
         }
      }

      return var4 == null ? var1 : var4;
   }

   private static axu a(ams var0, bhc var1) {
      return var0.a(ri.c(var1.b / 16.0D), ri.c(var1.d / 16.0D));
   }

   @Nullable
   private static et a(axu var0) {
      et var1 = new et(var0.b * 16, 30, var0.c * 16);
      int var2 = var0.g() + 16 - 1;
      et var3 = new et(var0.b * 16 + 16 - 1, var2, var0.c * 16 + 16 - 1);
      et var4 = null;
      double var5 = 0.0D;
      Iterator var7 = et.a(var1, var3).iterator();

      while(true) {
         et var8;
         double var10;
         do {
            do {
               awr var9;
               do {
                  do {
                     if (!var7.hasNext()) {
                        return var4;
                     }

                     var8 = (et)var7.next();
                     var9 = var0.a(var8);
                  } while(var9.u() != aov.bH);
               } while(var0.a(var8.b(1)).k());
            } while(var0.a(var8.b(2)).k());

            var10 = var8.g(0.0D, 0.0D, 0.0D);
         } while(var4 != null && !(var10 < var5));

         var4 = var8;
         var5 = var10;
      }
   }

   private void c(et var1) {
      (new azp()).b(this.b, new Random(), var1);
      avh var2 = this.b.r(var1);
      if (var2 instanceof awd) {
         awd var3 = (awd)var2;
         var3.h = new et(this.w());
         var3.y_();
      } else {
         a.warn("Couldn't save exit portal at {}", var1);
      }

   }

   public boolean a(fa var1) {
      return this.x().t().c(this.b, this.w(), var1);
   }

   public int i() {
      int var1 = 0;
      fa[] var2 = fa.values();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         fa var5 = var2[var4];
         var1 += this.a(var5) ? 1 : 0;
      }

      return var1;
   }

   public void b(et var1) {
      this.i = true;
      this.h = var1;
   }
}
