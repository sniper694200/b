import io.netty.buffer.ByteBuf;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public abstract class amh implements bn {
   private static final SimpleDateFormat a = new SimpleDateFormat("HH:mm:ss");
   private long b = -1L;
   private boolean c = true;
   private int d;
   private boolean e = true;
   private hh f;
   private String g = "";
   private String h = "@";
   private final bp i = new bp();

   public int k() {
      return this.d;
   }

   public void a(int var1) {
      this.d = var1;
   }

   public hh l() {
      return (hh)(this.f == null ? new ho("") : this.f);
   }

   public fy a(fy var1) {
      var1.a("Command", this.g);
      var1.a("SuccessCount", this.d);
      var1.a("CustomName", this.h);
      var1.a("TrackOutput", this.e);
      if (this.f != null && this.e) {
         var1.a("LastOutput", hh.a.a(this.f));
      }

      var1.a("UpdateLastExecution", this.c);
      if (this.c && this.b > 0L) {
         var1.a("LastExecution", this.b);
      }

      this.i.b(var1);
      return var1;
   }

   public void b(fy var1) {
      this.g = var1.l("Command");
      this.d = var1.h("SuccessCount");
      if (var1.b("CustomName", 8)) {
         this.h = var1.l("CustomName");
      }

      if (var1.b("TrackOutput", 1)) {
         this.e = var1.q("TrackOutput");
      }

      if (var1.b("LastOutput", 8) && this.e) {
         try {
            this.f = hh.a.a(var1.l("LastOutput"));
         } catch (Throwable var3) {
            this.f = new ho(var3.getMessage());
         }
      } else {
         this.f = null;
      }

      if (var1.e("UpdateLastExecution")) {
         this.c = var1.q("UpdateLastExecution");
      }

      if (this.c && var1.e("LastExecution")) {
         this.b = var1.i("LastExecution");
      } else {
         this.b = -1L;
      }

      this.i.a(var1);
   }

   public boolean a(int var1, String var2) {
      return var1 <= 2;
   }

   public void a(String var1) {
      this.g = var1;
      this.d = 0;
   }

   public String m() {
      return this.g;
   }

   public boolean a(ams var1) {
      if (!var1.G && var1.R() != this.b) {
         if ("Searge".equalsIgnoreCase(this.g)) {
            this.f = new ho("#itzlipofutzli");
            this.d = 1;
            return true;
         } else {
            MinecraftServer var2 = this.C_();
            if (var2 != null && var2.M() && var2.ai()) {
               try {
                  this.f = null;
                  this.d = var2.N().a(this, this.g);
               } catch (Throwable var6) {
                  b var4 = b.a(var6, "Executing command block");
                  c var5 = var4.a("Command to be executed");
                  var5.a("Command", new d<String>() {
                     public String a() throws Exception {
                        return amh.this.m();
                     }

                     // $FF: synthetic method
                     public Object call() throws Exception {
                        return this.a();
                     }
                  });
                  var5.a("Name", new d<String>() {
                     public String a() throws Exception {
                        return amh.this.h_();
                     }

                     // $FF: synthetic method
                     public Object call() throws Exception {
                        return this.a();
                     }
                  });
                  throw new f(var4);
               }
            } else {
               this.d = 0;
            }

            if (this.c) {
               this.b = var1.R();
            } else {
               this.b = -1L;
            }

            return true;
         }
      } else {
         return false;
      }
   }

   public String h_() {
      return this.h;
   }

   public void b(String var1) {
      this.h = var1;
   }

   public void a(hh var1) {
      if (this.e && this.e() != null && !this.e().G) {
         this.f = (new ho("[" + a.format(new Date()) + "] ")).a(var1);
         this.i();
      }

   }

   public boolean g() {
      MinecraftServer var1 = this.C_();
      return var1 == null || !var1.M() || var1.d[0].W().b("commandBlockOutput");
   }

   public void a(bp.a var1, int var2) {
      this.i.a(this.C_(), this, var1, var2);
   }

   public abstract void i();

   public abstract int j();

   public abstract void a(ByteBuf var1);

   public void b(@Nullable hh var1) {
      this.f = var1;
   }

   public void a(boolean var1) {
      this.e = var1;
   }

   public boolean n() {
      return this.e;
   }

   public boolean a(aeb var1) {
      if (!var1.dv()) {
         return false;
      } else {
         if (var1.e().G) {
            var1.a(this);
         }

         return true;
      }
   }

   public bp o() {
      return this.i;
   }
}
