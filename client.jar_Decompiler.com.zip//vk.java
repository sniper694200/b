public class vk extends ve {
   public int a;
   public int b;
   public int c;
   private int d = 5;
   private int e;
   private aeb f;
   private int g;

   public vk(ams var1, double var2, double var4, double var6, int var8) {
      super(var1);
      this.a(0.5F, 0.5F);
      this.b(var2, var4, var6);
      this.v = (float)(Math.random() * 360.0D);
      this.s = (double)((float)(Math.random() * 0.20000000298023224D - 0.10000000149011612D) * 2.0F);
      this.t = (double)((float)(Math.random() * 0.2D) * 2.0F);
      this.u = (double)((float)(Math.random() * 0.20000000298023224D - 0.10000000149011612D) * 2.0F);
      this.e = var8;
   }

   protected boolean ak() {
      return false;
   }

   public vk(ams var1) {
      super(var1);
      this.a(0.25F, 0.25F);
   }

   protected void i() {
   }

   public int av() {
      float var1 = 0.5F;
      var1 = ri.a(var1, 0.0F, 1.0F);
      int var2 = super.av();
      int var3 = var2 & 255;
      int var4 = var2 >> 16 & 255;
      var3 += (int)(var1 * 15.0F * 16.0F);
      if (var3 > 240) {
         var3 = 240;
      }

      return var3 | var4 << 16;
   }

   public void B_() {
      super.B_();
      if (this.c > 0) {
         --this.c;
      }

      this.m = this.p;
      this.n = this.q;
      this.o = this.r;
      if (!this.aj()) {
         this.t -= 0.029999999329447746D;
      }

      if (this.l.o(new et(this)).a() == bcx.i) {
         this.t = 0.20000000298023224D;
         this.s = (double)((this.S.nextFloat() - this.S.nextFloat()) * 0.2F);
         this.u = (double)((this.S.nextFloat() - this.S.nextFloat()) * 0.2F);
         this.a(qd.bR, 0.4F, 2.0F + this.S.nextFloat() * 0.4F);
      }

      this.i(this.p, (this.bw().b + this.bw().e) / 2.0D, this.r);
      double var1 = 8.0D;
      if (this.g < this.a - 20 + this.S() % 100) {
         if (this.f == null || this.f.h(this) > 64.0D) {
            this.f = this.l.a(this, 8.0D);
         }

         this.g = this.a;
      }

      if (this.f != null && this.f.y()) {
         this.f = null;
      }

      if (this.f != null) {
         double var3 = (this.f.p - this.p) / 8.0D;
         double var5 = (this.f.q + (double)this.f.by() / 2.0D - this.q) / 8.0D;
         double var7 = (this.f.r - this.r) / 8.0D;
         double var9 = Math.sqrt(var3 * var3 + var5 * var5 + var7 * var7);
         double var11 = 1.0D - var9;
         if (var11 > 0.0D) {
            var11 *= var11;
            this.s += var3 / var9 * var11 * 0.1D;
            this.t += var5 / var9 * var11 * 0.1D;
            this.u += var7 / var9 * var11 * 0.1D;
         }
      }

      this.a(vt.a, this.s, this.t, this.u);
      float var13 = 0.98F;
      if (this.z) {
         var13 = this.l.o(new et(ri.c(this.p), ri.c(this.bw().b) - 1, ri.c(this.r))).u().z * 0.98F;
      }

      this.s *= (double)var13;
      this.t *= 0.9800000190734863D;
      this.u *= (double)var13;
      if (this.z) {
         this.t *= -0.8999999761581421D;
      }

      ++this.a;
      ++this.b;
      if (this.b >= 6000) {
         this.X();
      }

   }

   public boolean aq() {
      return this.l.a((bgz)this.bw(), (bcx)bcx.h, (ve)this);
   }

   protected void j(int var1) {
      this.a(up.a, (float)var1);
   }

   public boolean a(up var1, float var2) {
      if (this.b(var1)) {
         return false;
      } else {
         this.ax();
         this.d = (int)((float)this.d - var2);
         if (this.d <= 0) {
            this.X();
         }

         return false;
      }
   }

   public void b(fy var1) {
      var1.a("Health", (short)this.d);
      var1.a("Age", (short)this.b);
      var1.a("Value", (short)this.e);
   }

   public void a(fy var1) {
      this.d = var1.g("Health");
      this.b = var1.g("Age");
      this.e = var1.g("Value");
   }

   public void d(aeb var1) {
      if (!this.l.G) {
         if (this.c == 0 && var1.bD == 0) {
            var1.bD = 2;
            var1.a((ve)this, 1);
            ain var2 = alk.b((ali)alm.C, (vn)var1);
            if (!var2.b() && var2.h()) {
               int var3 = Math.min(this.d(this.e), var2.i());
               this.e -= this.c(var3);
               var2.b(var2.i() - var3);
            }

            if (this.e > 0) {
               var1.m(this.e);
            }

            this.X();
         }

      }
   }

   private int c(int var1) {
      return var1 / 2;
   }

   private int d(int var1) {
      return var1 * 2;
   }

   public int j() {
      return this.e;
   }

   public int k() {
      if (this.e >= 2477) {
         return 10;
      } else if (this.e >= 1237) {
         return 9;
      } else if (this.e >= 617) {
         return 8;
      } else if (this.e >= 307) {
         return 7;
      } else if (this.e >= 149) {
         return 6;
      } else if (this.e >= 73) {
         return 5;
      } else if (this.e >= 37) {
         return 4;
      } else if (this.e >= 17) {
         return 3;
      } else if (this.e >= 7) {
         return 2;
      } else {
         return this.e >= 3 ? 1 : 0;
      }
   }

   public static int a(int var0) {
      if (var0 >= 2477) {
         return 2477;
      } else if (var0 >= 1237) {
         return 1237;
      } else if (var0 >= 617) {
         return 617;
      } else if (var0 >= 307) {
         return 307;
      } else if (var0 >= 149) {
         return 149;
      } else if (var0 >= 73) {
         return 73;
      } else if (var0 >= 37) {
         return 37;
      } else if (var0 >= 17) {
         return 17;
      } else if (var0 >= 7) {
         return 7;
      } else {
         return var0 >= 3 ? 3 : 1;
      }
   }

   public boolean bd() {
      return false;
   }
}
