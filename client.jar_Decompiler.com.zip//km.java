import java.io.IOException;

public class km implements ht<hw> {
   private et a;

   public km() {
   }

   public km(et var1) {
      this.a = var1;
   }

   public void a(gy var1) throws IOException {
      this.a = var1.e();
   }

   public void b(gy var1) throws IOException {
      var1.a(this.a);
   }

   public void a(hw var1) {
      var1.a(this);
   }

   public et a() {
      return this.a;
   }
}
