import com.google.common.collect.Maps;
import java.util.Map;

public class qr {
   protected final Map<qm, qo> a = Maps.newConcurrentMap();

   public void b(aeb var1, qm var2, int var3) {
      this.a(var1, var2, this.a(var2) + var3);
   }

   public void a(aeb var1, qm var2, int var3) {
      qo var4 = (qo)this.a.get(var2);
      if (var4 == null) {
         var4 = new qo();
         this.a.put(var2, var4);
      }

      var4.a(var3);
   }

   public int a(qm var1) {
      qo var2 = (qo)this.a.get(var1);
      return var2 == null ? 0 : var2.a();
   }
}
