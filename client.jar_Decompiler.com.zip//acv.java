import com.google.common.base.Predicate;
import java.util.List;
import javax.annotation.Nullable;

public class acv extends adk {
   private aae c;

   public acv(ams var1) {
      super(var1);
      this.a(0.6F, 1.95F);
      this.b_ = 10;
   }

   protected void r() {
      super.r();
      this.br.a(0, new wx(this));
      this.br.a(1, new acv.b());
      this.br.a(2, new wq(this, aeb.class, 8.0F, 0.6D, 1.0D));
      this.br.a(4, new acv.c());
      this.br.a(5, new acv.a());
      this.br.a(6, new acv.d());
      this.br.a(8, new ya(this, 0.6D));
      this.br.a(9, new xj(this, aeb.class, 3.0F, 1.0F));
      this.br.a(10, new xj(this, vo.class, 8.0F));
      this.bs.a(1, new yr(this, true, new Class[]{acv.class}));
      this.bs.a(2, (new yu(this, aeb.class, true)).b(300));
      this.bs.a(3, (new yu(this, adw.class, false)).b(300));
      this.bs.a(3, new yu(this, aai.class, false));
   }

   protected void bM() {
      super.bM();
      this.a((wa)adf.d).a(0.5D);
      this.a((wa)adf.b).a(12.0D);
      this.a((wa)adf.a).a(24.0D);
   }

   protected void i() {
      super.i();
   }

   public static void a(rw var0) {
      vo.a(var0, acv.class);
   }

   public void a(fy var1) {
      super.a(var1);
   }

   public void b(fy var1) {
      super.b(var1);
   }

   protected nd J() {
      return bfl.au;
   }

   protected void M() {
      super.M();
   }

   public void B_() {
      super.B_();
   }

   public boolean r(ve var1) {
      if (var1 == null) {
         return false;
      } else if (var1 == this) {
         return true;
      } else if (super.r(var1)) {
         return true;
      } else if (var1 instanceof adn) {
         return this.r(((adn)var1).p());
      } else if (var1 instanceof vn && ((vn)var1).cn() == vs.d) {
         return this.aY() == null && var1.aY() == null;
      } else {
         return false;
      }
   }

   protected qc F() {
      return qd.bs;
   }

   protected qc cf() {
      return qd.bu;
   }

   protected qc d(up var1) {
      return qd.bv;
   }

   private void a(@Nullable aae var1) {
      this.c = var1;
   }

   @Nullable
   private aae dq() {
      return this.c;
   }

   protected qc dm() {
      return qd.bt;
   }

   public class d extends adk.c {
      final Predicate<aae> a = new Predicate<aae>() {
         public boolean a(aae var1) {
            return var1.dl() == ahq.l;
         }

         // $FF: synthetic method
         public boolean apply(Object var1) {
            return this.a((aae)var1);
         }
      };

      public d() {
         super();
      }

      public boolean a() {
         if (acv.this.z() != null) {
            return false;
         } else if (acv.this.dn()) {
            return false;
         } else if (acv.this.T < this.d) {
            return false;
         } else if (!acv.this.l.W().b("mobGriefing")) {
            return false;
         } else {
            List<aae> var1 = acv.this.l.a(aae.class, acv.this.bw().c(16.0D, 4.0D, 16.0D), this.a);
            if (var1.isEmpty()) {
               return false;
            } else {
               acv.this.a((aae)var1.get(acv.this.S.nextInt(var1.size())));
               return true;
            }
         }
      }

      public boolean b() {
         return acv.this.dq() != null && this.c > 0;
      }

      public void d() {
         super.d();
         acv.this.a((aae)null);
      }

      protected void j() {
         aae var1 = acv.this.dq();
         if (var1 != null && var1.aC()) {
            var1.b(ahq.o);
         }

      }

      protected int m() {
         return 40;
      }

      protected int f() {
         return 60;
      }

      protected int i() {
         return 140;
      }

      protected qc k() {
         return qd.by;
      }

      protected adk.a l() {
         return adk.a.d;
      }
   }

   class c extends adk.c {
      private c() {
         super();
      }

      public boolean a() {
         if (!super.a()) {
            return false;
         } else {
            int var1 = acv.this.l.a(adn.class, acv.this.bw().g(16.0D)).size();
            return acv.this.S.nextInt(8) + 1 > var1;
         }
      }

      protected int f() {
         return 100;
      }

      protected int i() {
         return 340;
      }

      protected void j() {
         for(int var1 = 0; var1 < 3; ++var1) {
            et var2 = (new et(acv.this)).a(-2 + acv.this.S.nextInt(5), 1, -2 + acv.this.S.nextInt(5));
            adn var3 = new adn(acv.this.l);
            var3.a(var2, 0.0F, 0.0F);
            var3.a(acv.this.l.D(var2), (vq)null);
            var3.a((vo)acv.this);
            var3.g(var2);
            var3.a(20 * (30 + acv.this.S.nextInt(90)));
            acv.this.l.a((ve)var3);
         }

      }

      protected qc k() {
         return qd.bx;
      }

      protected adk.a l() {
         return adk.a.b;
      }

      // $FF: synthetic method
      c(Object var2) {
         this();
      }
   }

   class a extends adk.c {
      private a() {
         super();
      }

      protected int f() {
         return 40;
      }

      protected int i() {
         return 100;
      }

      protected void j() {
         vn var1 = acv.this.z();
         double var2 = Math.min(var1.q, acv.this.q);
         double var4 = Math.max(var1.q, acv.this.q) + 1.0D;
         float var6 = (float)ri.c(var1.r - acv.this.r, var1.p - acv.this.p);
         int var7;
         if (acv.this.h(var1) < 9.0D) {
            float var8;
            for(var7 = 0; var7 < 5; ++var7) {
               var8 = var6 + (float)var7 * 3.1415927F * 0.4F;
               this.a(acv.this.p + (double)ri.b(var8) * 1.5D, acv.this.r + (double)ri.a(var8) * 1.5D, var2, var4, var8, 0);
            }

            for(var7 = 0; var7 < 8; ++var7) {
               var8 = var6 + (float)var7 * 3.1415927F * 2.0F / 8.0F + 1.2566371F;
               this.a(acv.this.p + (double)ri.b(var8) * 2.5D, acv.this.r + (double)ri.a(var8) * 2.5D, var2, var4, var8, 3);
            }
         } else {
            for(var7 = 0; var7 < 16; ++var7) {
               double var11 = 1.25D * (double)(var7 + 1);
               int var10 = 1 * var7;
               this.a(acv.this.p + (double)ri.b(var6) * var11, acv.this.r + (double)ri.a(var6) * var11, var2, var4, var6, var10);
            }
         }

      }

      private void a(double var1, double var3, double var5, double var7, float var9, int var10) {
         et var11 = new et(var1, var7, var3);
         boolean var12 = false;
         double var13 = 0.0D;

         do {
            if (!acv.this.l.d(var11, true) && acv.this.l.d(var11.b(), true)) {
               if (!acv.this.l.d(var11)) {
                  awr var15 = acv.this.l.o(var11);
                  bgz var16 = var15.d(acv.this.l, var11);
                  if (var16 != null) {
                     var13 = var16.e;
                  }
               }

               var12 = true;
               break;
            }

            var11 = var11.b();
         } while(var11.q() >= ri.c(var5) - 1);

         if (var12) {
            aeh var17 = new aeh(acv.this.l, var1, (double)var11.q() + var13, var3, var9, var10, acv.this);
            acv.this.l.a((ve)var17);
         }

      }

      protected qc k() {
         return qd.bw;
      }

      protected adk.a l() {
         return adk.a.c;
      }

      // $FF: synthetic method
      a(Object var2) {
         this();
      }
   }

   class b extends adk.b {
      private b() {
         super();
      }

      public void e() {
         if (acv.this.z() != null) {
            acv.this.t().a(acv.this.z(), (float)acv.this.O(), (float)acv.this.N());
         } else if (acv.this.dq() != null) {
            acv.this.t().a(acv.this.dq(), (float)acv.this.O(), (float)acv.this.N());
         }

      }

      // $FF: synthetic method
      b(Object var2) {
         this();
      }
   }
}
