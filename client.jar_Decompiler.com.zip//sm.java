import com.google.common.collect.Lists;
import java.util.List;

public class sm implements rs {
   private static final List<String> a = Lists.newArrayList(new String[]{"MinecartRideable", "MinecartChest", "MinecartFurnace", "MinecartTNT", "MinecartSpawner", "MinecartHopper", "MinecartCommandBlock"});

   public int a() {
      return 106;
   }

   public fy a(fy var1) {
      if ("Minecart".equals(var1.l("id"))) {
         String var2 = "MinecartRideable";
         int var3 = var1.h("Type");
         if (var3 > 0 && var3 < a.size()) {
            var2 = (String)a.get(var3);
         }

         var1.a("id", var2);
         var1.r("Type");
      }

      return var1;
   }
}
