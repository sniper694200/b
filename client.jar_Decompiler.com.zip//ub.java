public enum ub {
   a,
   b,
   c;
}
