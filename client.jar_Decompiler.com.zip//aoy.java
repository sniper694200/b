import java.util.Random;

public class aoy extends aou {
   public aoy() {
      super(bcx.d);
      this.a(ahn.b);
   }

   public int a(Random var1) {
      return 3;
   }

   public ail a(awr var1, Random var2, int var3) {
      return aip.aT;
   }
}
