public class ala extends ali {
   public ala(ali.a var1, vj... var2) {
      super(var1, alj.k, var2);
      this.c("arrowDamage");
   }

   public int a(int var1) {
      return 1 + (var1 - 1) * 10;
   }

   public int b(int var1) {
      return this.a(var1) + 15;
   }

   public int b() {
      return 5;
   }
}
