import com.google.common.collect.Sets;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class wg extends we {
   private final Set<wb> e = Sets.newHashSet();
   protected final Map<String, wb> d = new rc();

   public wf e(wa var1) {
      return (wf)super.a(var1);
   }

   public wf b(String var1) {
      wb var2 = super.a(var1);
      if (var2 == null) {
         var2 = (wb)this.d.get(var1);
      }

      return (wf)var2;
   }

   public wb b(wa var1) {
      wb var2 = super.b(var1);
      if (var1 instanceof wh && ((wh)var1).g() != null) {
         this.d.put(((wh)var1).g(), var2);
      }

      return var2;
   }

   protected wb c(wa var1) {
      return new wf(this, var1);
   }

   public void a(wb var1) {
      if (var1.a().c()) {
         this.e.add(var1);
      }

      Iterator var2 = this.c.get(var1.a()).iterator();

      while(var2.hasNext()) {
         wa var3 = (wa)var2.next();
         wf var4 = this.e(var3);
         if (var4 != null) {
            var4.f();
         }
      }

   }

   public Set<wb> b() {
      return this.e;
   }

   public Collection<wb> c() {
      Set<wb> var1 = Sets.newHashSet();
      Iterator var2 = this.a().iterator();

      while(var2.hasNext()) {
         wb var3 = (wb)var2.next();
         if (var3.a().c()) {
            var1.add(var3);
         }
      }

      return var1;
   }

   // $FF: synthetic method
   public wb a(String var1) {
      return this.b(var1);
   }

   // $FF: synthetic method
   public wb a(wa var1) {
      return this.e(var1);
   }
}
