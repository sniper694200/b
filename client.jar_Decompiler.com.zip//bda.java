public enum bda {
   a,
   b,
   c,
   d,
   e;
}
