import javax.annotation.Nullable;

public interface aqj {
   @Nullable
   avh a(ams var1, int var2);
}
