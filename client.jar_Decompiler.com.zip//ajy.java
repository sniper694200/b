import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;

public class ajy extends agv {
   public ain u() {
      return akg.a(super.u(), akh.z);
   }

   public aef a(ams var1, ain var2, vn var3) {
      aey var4 = new aey(var1, var3);
      var4.a(var2);
      return var4;
   }

   public void a(ahn var1, fi<ain> var2) {
      if (this.a(var1)) {
         Iterator var3 = ake.a.iterator();

         while(var3.hasNext()) {
            ake var4 = (ake)var3.next();
            if (!var4.a().isEmpty()) {
               var2.add(akg.a(new ain(this), var4));
            }
         }
      }

   }

   public void a(ain var1, @Nullable ams var2, List<String> var3, ajz var4) {
      akg.a(var1, var3, 0.125F);
   }

   public String b(ain var1) {
      return ft.a(akg.d(var1).b("tipped_arrow.effect."));
   }
}
