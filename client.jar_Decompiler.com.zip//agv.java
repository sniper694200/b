public class agv extends ail {
   public agv() {
      this.b(ahn.j);
   }

   public aef a(ams var1, ain var2, vn var3) {
      aey var4 = new aey(var1, var3);
      var4.a(var2);
      return var4;
   }
}
