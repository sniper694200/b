import javax.annotation.Nullable;

public class up {
   public static final up a = (new up("inFire")).n();
   public static final up b = new up("lightningBolt");
   public static final up c = (new up("onFire")).k().n();
   public static final up d = (new up("lava")).n();
   public static final up e = (new up("hotFloor")).n();
   public static final up f = (new up("inWall")).k();
   public static final up g = (new up("cramming")).k();
   public static final up h = (new up("drown")).k();
   public static final up i = (new up("starve")).k().m();
   public static final up j = new up("cactus");
   public static final up k = (new up("fall")).k();
   public static final up l = (new up("flyIntoWall")).k();
   public static final up m = (new up("outOfWorld")).k().l();
   public static final up n = (new up("generic")).k();
   public static final up o = (new up("magic")).k().t();
   public static final up p = (new up("wither")).k();
   public static final up q = new up("anvil");
   public static final up r = new up("fallingBlock");
   public static final up s = (new up("dragonBreath")).k();
   public static final up t = (new up("fireworks")).d();
   private boolean v;
   private boolean w;
   private boolean x;
   private float y = 0.1F;
   private boolean z;
   private boolean A;
   private boolean B;
   private boolean C;
   private boolean D;
   public String u;

   public static up a(vn var0) {
      return new uq("mob", var0);
   }

   public static up a(ve var0, vn var1) {
      return new ur("mob", var0, var1);
   }

   public static up a(aeb var0) {
      return new uq("player", var0);
   }

   public static up a(aef var0, @Nullable ve var1) {
      return (new ur("arrow", var0, var1)).b();
   }

   public static up a(aej var0, @Nullable ve var1) {
      return var1 == null ? (new ur("onFire", var0, var0)).n().b() : (new ur("fireball", var0, var1)).n().b();
   }

   public static up a(ve var0, @Nullable ve var1) {
      return (new ur("thrown", var0, var1)).b();
   }

   public static up b(ve var0, @Nullable ve var1) {
      return (new ur("indirectMagic", var0, var1)).k().t();
   }

   public static up a(ve var0) {
      return (new uq("thorns", var0)).w().t();
   }

   public static up a(@Nullable amn var0) {
      return var0 != null && var0.c() != null ? (new uq("explosion.player", var0.c())).q().d() : (new up("explosion")).q().d();
   }

   public static up b(@Nullable vn var0) {
      return var0 != null ? (new uq("explosion.player", var0)).q().d() : (new up("explosion")).q().d();
   }

   public boolean a() {
      return this.A;
   }

   public up b() {
      this.A = true;
      return this;
   }

   public boolean c() {
      return this.D;
   }

   public up d() {
      this.D = true;
      return this;
   }

   public boolean e() {
      return this.v;
   }

   public float f() {
      return this.y;
   }

   public boolean g() {
      return this.w;
   }

   public boolean h() {
      return this.x;
   }

   protected up(String var1) {
      this.u = var1;
   }

   @Nullable
   public ve i() {
      return this.j();
   }

   @Nullable
   public ve j() {
      return null;
   }

   protected up k() {
      this.v = true;
      this.y = 0.0F;
      return this;
   }

   protected up l() {
      this.w = true;
      return this;
   }

   protected up m() {
      this.x = true;
      this.y = 0.0F;
      return this;
   }

   protected up n() {
      this.z = true;
      return this;
   }

   public hh c(vn var1) {
      vn var2 = var1.ci();
      String var3 = "death.attack." + this.u;
      String var4 = var3 + ".player";
      return var2 != null && ft.c(var4) ? new hp(var4, new Object[]{var1.i_(), var2.i_()}) : new hp(var3, new Object[]{var1.i_()});
   }

   public boolean o() {
      return this.z;
   }

   public String p() {
      return this.u;
   }

   public up q() {
      this.B = true;
      return this;
   }

   public boolean r() {
      return this.B;
   }

   public boolean s() {
      return this.C;
   }

   public up t() {
      this.C = true;
      return this;
   }

   public boolean u() {
      ve var1 = this.j();
      return var1 instanceof aeb && ((aeb)var1).bO.d;
   }

   @Nullable
   public bhc v() {
      return null;
   }
}
