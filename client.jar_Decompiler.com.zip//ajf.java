public class ajf extends ail {
   public ajf() {
      this.k = 1;
      this.b(ahn.e);
   }

   public boolean a(ain var1, aeb var2, vn var3, tz var4) {
      if (var3 instanceof aab) {
         aab var5 = (aab)var3;
         if (!var5.dl() && !var5.l_()) {
            var5.p(true);
            var5.l.a(var2, var5.p, var5.q, var5.r, qd.fr, qe.g, 0.5F, 1.0F);
            var1.g(1);
         }

         return true;
      } else {
         return false;
      }
   }
}
