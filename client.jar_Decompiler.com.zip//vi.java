import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import javax.annotation.Nullable;

public final class vi {
   public static final Predicate<ve> a = new Predicate<ve>() {
      public boolean a(@Nullable ve var1) {
         return var1.aC();
      }

      // $FF: synthetic method
      public boolean apply(@Nullable Object var1) {
         return this.a((ve)var1);
      }
   };
   public static final Predicate<ve> b = new Predicate<ve>() {
      public boolean a(@Nullable ve var1) {
         return var1.aC() && !var1.aT() && !var1.aS();
      }

      // $FF: synthetic method
      public boolean apply(@Nullable Object var1) {
         return this.a((ve)var1);
      }
   };
   public static final Predicate<ve> c = new Predicate<ve>() {
      public boolean a(@Nullable ve var1) {
         return var1 instanceof tt && var1.aC();
      }

      // $FF: synthetic method
      public boolean apply(@Nullable Object var1) {
         return this.a((ve)var1);
      }
   };
   public static final Predicate<ve> d = new Predicate<ve>() {
      public boolean a(@Nullable ve var1) {
         return !(var1 instanceof aeb) || !((aeb)var1).y() && !((aeb)var1).z();
      }

      // $FF: synthetic method
      public boolean apply(@Nullable Object var1) {
         return this.a((ve)var1);
      }
   };
   public static final Predicate<ve> e = new Predicate<ve>() {
      public boolean a(@Nullable ve var1) {
         return !(var1 instanceof aeb) || !((aeb)var1).y();
      }

      // $FF: synthetic method
      public boolean apply(@Nullable Object var1) {
         return this.a((ve)var1);
      }
   };

   public static <T extends ve> Predicate<T> a(final double var0, final double var2, final double var4, double var6) {
      final double var8 = var6 * var6;
      return new Predicate<T>() {
         public boolean a(@Nullable T var1) {
            return var1 != null && var1.d(var0, var2, var4) <= var8;
         }

         // $FF: synthetic method
         public boolean apply(@Nullable Object var1) {
            return this.a((ve)var1);
         }
      };
   }

   public static <T extends ve> Predicate<T> a(final ve var0) {
      final bhk var1 = var0.aY();
      final bhk.a var2 = var1 == null ? bhk.a.a : var1.k();
      return var2 == bhk.a.b ? Predicates.alwaysFalse() : Predicates.and(e, new Predicate<ve>() {
         public boolean a(@Nullable ve var1x) {
            if (!var1x.az()) {
               return false;
            } else if (var0.l.G && (!(var1x instanceof aeb) || !((aeb)var1x).cZ())) {
               return false;
            } else {
               bhk var2x = var1x.aY();
               bhk.a var3 = var2x == null ? bhk.a.a : var2x.k();
               if (var3 == bhk.a.b) {
                  return false;
               } else {
                  boolean var4 = var1 != null && var1.a(var2x);
                  if ((var2 == bhk.a.d || var3 == bhk.a.d) && var4) {
                     return false;
                  } else {
                     return var2 != bhk.a.c && var3 != bhk.a.c || var4;
                  }
               }
            }
         }

         // $FF: synthetic method
         public boolean apply(@Nullable Object var1x) {
            return this.a((ve)var1x);
         }
      });
   }

   public static Predicate<ve> b(final ve var0) {
      return new Predicate<ve>() {
         public boolean a(@Nullable ve var1) {
            while(true) {
               if (var1.aS()) {
                  var1 = var1.bJ();
                  if (var1 != var0) {
                     continue;
                  }

                  return false;
               }

               return true;
            }
         }

         // $FF: synthetic method
         public boolean apply(@Nullable Object var1) {
            return this.a((ve)var1);
         }
      };
   }

   public static class a implements Predicate<ve> {
      private final ain a;

      public a(ain var1) {
         this.a = var1;
      }

      public boolean a(@Nullable ve var1) {
         if (!var1.aC()) {
            return false;
         } else if (!(var1 instanceof vn)) {
            return false;
         } else {
            vn var2 = (vn)var1;
            if (!var2.b(vo.d(this.a)).b()) {
               return false;
            } else if (var2 instanceof vo) {
               return ((vo)var2).cX();
            } else if (var2 instanceof abx) {
               return true;
            } else {
               return var2 instanceof aeb;
            }
         }
      }

      // $FF: synthetic method
      public boolean apply(@Nullable Object var1) {
         return this.a((ve)var1);
      }
   }
}
