import java.util.Random;
import javax.annotation.Nullable;

public class aqe extends aoo {
   protected aqe(bcx var1) {
      super(var1);
      this.a(1.0F);
   }

   public avh a(ams var1, int var2) {
      return new awd();
   }

   public boolean a(awr var1, amw var2, et var3, fa var4) {
      awr var5 = var2.o(var3.a(var4));
      aou var6 = var5.u();
      return !var5.p() && var6 != aov.db;
   }

   @Nullable
   public bgz a(awr var1, amw var2, et var3) {
      return k;
   }

   public boolean b(awr var1) {
      return false;
   }

   public boolean c(awr var1) {
      return false;
   }

   public int a(Random var1) {
      return 0;
   }

   public void a(awr var1, ams var2, et var3, Random var4) {
      avh var5 = var2.r(var3);
      if (var5 instanceof awd) {
         int var6 = ((awd)var5).i();

         for(int var7 = 0; var7 < var6; ++var7) {
            double var8 = (double)((float)var3.p() + var4.nextFloat());
            double var10 = (double)((float)var3.q() + var4.nextFloat());
            double var12 = (double)((float)var3.r() + var4.nextFloat());
            double var14 = ((double)var4.nextFloat() - 0.5D) * 0.5D;
            double var16 = ((double)var4.nextFloat() - 0.5D) * 0.5D;
            double var18 = ((double)var4.nextFloat() - 0.5D) * 0.5D;
            int var20 = var4.nextInt(2) * 2 - 1;
            if (var4.nextBoolean()) {
               var12 = (double)var3.r() + 0.5D + 0.25D * (double)var20;
               var18 = (double)(var4.nextFloat() * 2.0F * (float)var20);
            } else {
               var8 = (double)var3.p() + 0.5D + 0.25D * (double)var20;
               var14 = (double)(var4.nextFloat() * 2.0F * (float)var20);
            }

            var2.a(fj.y, var8, var10, var12, var14, var16, var18);
         }

      }
   }

   public ain a(ams var1, et var2, awr var3) {
      return ain.a;
   }

   public bcy c(awr var1, amw var2, et var3) {
      return bcy.F;
   }

   public awp a(amw var1, awr var2, et var3, fa var4) {
      return awp.i;
   }
}
