import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.IntBuffer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.annotation.Nullable;
import javax.imageio.ImageIO;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.BufferUtils;

public class bid {
   private static final Logger a = LogManager.getLogger();
   private static final DateFormat b = new SimpleDateFormat("yyyy-MM-dd_HH.mm.ss");
   private static IntBuffer c;
   private static int[] d;

   public static hh a(File var0, int var1, int var2, bvb var3) {
      return a(var0, (String)null, var1, var2, var3);
   }

   public static hh a(File var0, @Nullable String var1, int var2, int var3, bvb var4) {
      try {
         File var5 = new File(var0, "screenshots");
         var5.mkdir();
         BufferedImage var6 = a(var2, var3, var4);
         File var7;
         if (var1 == null) {
            var7 = a(var5);
         } else {
            var7 = new File(var5, var1);
         }

         ImageIO.write(var6, "png", var7);
         hh var8 = new ho(var7.getName());
         var8.b().a(new hg(hg.a.b, var7.getAbsolutePath()));
         var8.b().d(true);
         return new hp("screenshot.success", new Object[]{var8});
      } catch (Exception var9) {
         a.warn("Couldn't save screenshot", var9);
         return new hp("screenshot.failure", new Object[]{var9.getMessage()});
      }
   }

   public static BufferedImage a(int var0, int var1, bvb var2) {
      if (cig.j()) {
         var0 = var2.a;
         var1 = var2.b;
      }

      int var3 = var0 * var1;
      if (c == null || c.capacity() < var3) {
         c = BufferUtils.createIntBuffer(var3);
         d = new int[var3];
      }

      buq.g(3333, 1);
      buq.g(3317, 1);
      c.clear();
      if (cig.j()) {
         buq.i(var2.g);
         buq.a(3553, 0, 32993, 33639, c);
      } else {
         buq.a(0, 0, var0, var1, 32993, 33639, c);
      }

      c.get(d);
      cdr.a(d, var0, var1);
      BufferedImage var4 = new BufferedImage(var0, var1, 1);
      var4.setRGB(0, 0, var0, var1, d, 0, var0);
      return var4;
   }

   private static File a(File var0) {
      String var2 = b.format(new Date()).toString();
      int var3 = 1;

      while(true) {
         File var1 = new File(var0, var2 + (var3 == 1 ? "" : "_" + var3) + ".png");
         if (!var1.exists()) {
            return var1;
         }

         ++var3;
      }
   }
}
