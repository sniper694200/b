public class cba extends cab<afk> {
   public cba(bzd var1) {
      super(var1);
   }

   protected void a(afk var1, float var2, awr var3) {
      int var4 = var1.k();
      if (var4 > -1 && (float)var4 - var2 + 1.0F < 10.0F) {
         float var5 = 1.0F - ((float)var4 - var2 + 1.0F) / 10.0F;
         var5 = ri.a(var5, 0.0F, 1.0F);
         var5 *= var5;
         var5 *= var5;
         float var6 = 1.0F + var5 * 0.3F;
         buq.b(var6, var6, var6);
      }

      super.a(var1, var2, var3);
      if (var4 > -1 && var4 / 5 % 2 == 0) {
         bvk var7 = bhz.z().ab();
         buq.z();
         buq.g();
         buq.m();
         buq.a(buq.r.l, buq.l.c);
         buq.c(1.0F, 1.0F, 1.0F, (1.0F - ((float)var4 - var2 + 1.0F) / 100.0F) * 0.8F);
         buq.G();
         var7.a(aov.W.t(), 1.0F);
         buq.H();
         buq.c(1.0F, 1.0F, 1.0F, 1.0F);
         buq.l();
         buq.f();
         buq.y();
      }

   }
}
