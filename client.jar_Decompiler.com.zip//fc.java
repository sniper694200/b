public interface fc extends Iterable {
}
