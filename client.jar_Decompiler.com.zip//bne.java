public class bne implements bjk.a {
   private final bhz a = bhz.z();

   public void a(int var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean var8, float var9) {
      int var10 = var3 + var5 / 2 - this.a.k.a / 2;
      this.a.k.a(cew.a("lanServer.scanning"), this.a.m.l / 2 - this.a.k.a(cew.a("lanServer.scanning")) / 2, var10, 16777215);
      String var11;
      switch((int)(bhz.I() / 300L % 4L)) {
      case 0:
      default:
         var11 = "O o o";
         break;
      case 1:
      case 3:
         var11 = "o O o";
         break;
      case 2:
         var11 = "o o O";
      }

      this.a.k.a(var11, this.a.m.l / 2 - this.a.k.a(var11) / 2, var10 + this.a.k.a, 8421504);
   }

   public void a(int var1, int var2, int var3, float var4) {
   }

   public boolean a(int var1, int var2, int var3, int var4, int var5, int var6) {
      return false;
   }

   public void b(int var1, int var2, int var3, int var4, int var5, int var6) {
   }
}
