import com.google.common.base.Predicates;
import java.util.Iterator;
import java.util.Random;

public class azn extends azs {
   private static final axa a;
   private final awr b;
   private final awr c;
   private final awr d;

   public azn() {
      this.b = aov.U.t().a(aui.e, aui.a.b).a(ard.a, ard.a.b);
      this.c = aov.A.t();
      this.d = aov.i.t();
   }

   public boolean b(ams var1, Random var2, et var3) {
      while(var1.d(var3) && var3.q() > 2) {
         var3 = var3.b();
      }

      if (!a.a(var1.o(var3))) {
         return false;
      } else {
         int var4;
         int var5;
         for(var4 = -2; var4 <= 2; ++var4) {
            for(var5 = -2; var5 <= 2; ++var5) {
               if (var1.d(var3.a(var4, -1, var5)) && var1.d(var3.a(var4, -2, var5))) {
                  return false;
               }
            }
         }

         for(var4 = -1; var4 <= 0; ++var4) {
            for(var5 = -2; var5 <= 2; ++var5) {
               for(int var6 = -2; var6 <= 2; ++var6) {
                  var1.a((et)var3.a(var5, var4, var6), (awr)this.c, 2);
               }
            }
         }

         var1.a((et)var3, (awr)this.d, 2);
         Iterator var7 = fa.c.a.iterator();

         while(var7.hasNext()) {
            fa var8 = (fa)var7.next();
            var1.a((et)var3.a(var8), (awr)this.d, 2);
         }

         for(var4 = -2; var4 <= 2; ++var4) {
            for(var5 = -2; var5 <= 2; ++var5) {
               if (var4 == -2 || var4 == 2 || var5 == -2 || var5 == 2) {
                  var1.a((et)var3.a(var4, 1, var5), (awr)this.c, 2);
               }
            }
         }

         var1.a((et)var3.a(2, 1, 0), (awr)this.b, 2);
         var1.a((et)var3.a(-2, 1, 0), (awr)this.b, 2);
         var1.a((et)var3.a(0, 1, 2), (awr)this.b, 2);
         var1.a((et)var3.a(0, 1, -2), (awr)this.b, 2);

         for(var4 = -1; var4 <= 1; ++var4) {
            for(var5 = -1; var5 <= 1; ++var5) {
               if (var4 == 0 && var5 == 0) {
                  var1.a((et)var3.a(var4, 4, var5), (awr)this.c, 2);
               } else {
                  var1.a((et)var3.a(var4, 4, var5), (awr)this.b, 2);
               }
            }
         }

         for(var4 = 1; var4 <= 3; ++var4) {
            var1.a((et)var3.a(-1, var4, -1), (awr)this.c, 2);
            var1.a((et)var3.a(-1, var4, 1), (awr)this.c, 2);
            var1.a((et)var3.a(1, var4, -1), (awr)this.c, 2);
            var1.a((et)var3.a(1, var4, 1), (awr)this.c, 2);
         }

         return true;
      }
   }

   static {
      a = axa.a((aou)aov.m).a(atl.a, Predicates.equalTo(atl.a.a));
   }
}
