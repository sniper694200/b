import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public class cd extends bi {
   public String c() {
      return "enchant";
   }

   public int a() {
      return 2;
   }

   public String b(bn var1) {
      return "commands.enchant.usage";
   }

   public void a(MinecraftServer var1, bn var2, String[] var3) throws ei {
      if (var3.length < 2) {
         throw new ep("commands.enchant.usage", new Object[0]);
      } else {
         vn var4 = (vn)a(var1, var2, var3[0], vn.class);
         var2.a(bp.a.d, 0);

         ali var5;
         try {
            var5 = ali.c(a(var3[1], 0));
         } catch (el var12) {
            var5 = ali.b(var3[1]);
         }

         if (var5 == null) {
            throw new el("commands.enchant.notFound", new Object[]{var3[1]});
         } else {
            int var6 = 1;
            ain var7 = var4.co();
            if (var7.b()) {
               throw new ei("commands.enchant.noItem", new Object[0]);
            } else if (!var5.a(var7)) {
               throw new ei("commands.enchant.cantEnchant", new Object[0]);
            } else {
               if (var3.length >= 3) {
                  var6 = a(var3[2], var5.f(), var5.b());
               }

               if (var7.o()) {
                  ge var8 = var7.q();

                  for(int var9 = 0; var9 < var8.c(); ++var9) {
                     int var10 = var8.b(var9).g("id");
                     if (ali.c(var10) != null) {
                        ali var11 = ali.c(var10);
                        if (!var5.c(var11)) {
                           throw new ei("commands.enchant.cantCombine", new Object[]{var5.d(var6), var11.d(var8.b(var9).g("lvl"))});
                        }
                     }
                  }
               }

               var7.a(var5, var6);
               a(var2, this, "commands.enchant.success", new Object[0]);
               var2.a(bp.a.d, 1);
            }
         }
      }
   }

   public List<String> a(MinecraftServer var1, bn var2, String[] var3, @Nullable et var4) {
      if (var3.length == 1) {
         return a(var3, var1.J());
      } else {
         return var3.length == 2 ? a(var3, ali.b.c()) : Collections.emptyList();
      }
   }

   public boolean b(String[] var1, int var2) {
      return var2 == 0;
   }
}
