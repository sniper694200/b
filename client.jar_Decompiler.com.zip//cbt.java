public class cbt implements cce<bty> {
   private final ccr a;

   public cbt(ccr var1) {
      this.a = var1;
   }

   public void a(bty var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8) {
      if ("deadmau5".equals(var1.h_()) && var1.h() && !var1.aX()) {
         this.a.a((nd)var1.m());

         for(int var9 = 0; var9 < 2; ++var9) {
            float var10 = var1.x + (var1.v - var1.x) * var4 - (var1.aO + (var1.aN - var1.aO) * var4);
            float var11 = var1.y + (var1.w - var1.y) * var4;
            buq.G();
            buq.b(var10, 0.0F, 1.0F, 0.0F);
            buq.b(var11, 1.0F, 0.0F, 0.0F);
            buq.c(0.375F * (float)(var9 * 2 - 1), 0.0F, 0.0F);
            buq.c(0.0F, -0.375F, 0.0F);
            buq.b(-var11, 1.0F, 0.0F, 0.0F);
            buq.b(-var10, 0.0F, 1.0F, 0.0F);
            float var12 = 1.3333334F;
            buq.b(1.3333334F, 1.3333334F, 1.3333334F);
            this.a.h().a(0.0625F);
            buq.H();
         }

      }
   }

   public boolean a() {
      return true;
   }
}
