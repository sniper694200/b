import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;

public class zo extends ber {
   private ams b;
   private final List<et> c = Lists.newArrayList();
   private final List<zl> d = Lists.newArrayList();
   private final List<zm> e = Lists.newArrayList();
   private int f;

   public zo(String var1) {
      super(var1);
   }

   public zo(ams var1) {
      super(a(var1.s));
      this.b = var1;
      this.c();
   }

   public void a(ams var1) {
      this.b = var1;
      Iterator var2 = this.e.iterator();

      while(var2.hasNext()) {
         zm var3 = (zm)var2.next();
         var3.a(var1);
      }

   }

   public void a(et var1) {
      if (this.c.size() <= 64) {
         if (!this.e(var1)) {
            this.c.add(var1);
         }

      }
   }

   public void a() {
      ++this.f;
      Iterator var1 = this.e.iterator();

      while(var1.hasNext()) {
         zm var2 = (zm)var1.next();
         var2.a(this.f);
      }

      this.e();
      this.f();
      this.g();
      if (this.f % 400 == 0) {
         this.c();
      }

   }

   private void e() {
      Iterator var1 = this.e.iterator();

      while(var1.hasNext()) {
         zm var2 = (zm)var1.next();
         if (var2.g()) {
            var1.remove();
            this.c();
         }
      }

   }

   public List<zm> b() {
      return this.e;
   }

   public zm a(et var1, int var2) {
      zm var3 = null;
      double var4 = 3.4028234663852886E38D;
      Iterator var6 = this.e.iterator();

      while(var6.hasNext()) {
         zm var7 = (zm)var6.next();
         double var8 = var7.a().n(var1);
         if (!(var8 >= var4)) {
            float var10 = (float)(var2 + var7.b());
            if (!(var8 > (double)(var10 * var10))) {
               var3 = var7;
               var4 = var8;
            }
         }
      }

      return var3;
   }

   private void f() {
      if (!this.c.isEmpty()) {
         this.b((et)this.c.remove(0));
      }
   }

   private void g() {
      for(int var1 = 0; var1 < this.d.size(); ++var1) {
         zl var2 = (zl)this.d.get(var1);
         zm var3 = this.a(var2.d(), 32);
         if (var3 == null) {
            var3 = new zm(this.b);
            this.e.add(var3);
            this.c();
         }

         var3.a(var2);
      }

      this.d.clear();
   }

   private void b(et var1) {
      int var2 = true;
      int var3 = true;
      int var4 = true;

      for(int var5 = -16; var5 < 16; ++var5) {
         for(int var6 = -4; var6 < 4; ++var6) {
            for(int var7 = -16; var7 < 16; ++var7) {
               et var8 = var1.a(var5, var6, var7);
               if (this.f(var8)) {
                  zl var9 = this.c(var8);
                  if (var9 == null) {
                     this.d(var8);
                  } else {
                     var9.a(this.f);
                  }
               }
            }
         }
      }

   }

   @Nullable
   private zl c(et var1) {
      Iterator var2 = this.d.iterator();

      zl var3;
      do {
         if (!var2.hasNext()) {
            var2 = this.e.iterator();

            zl var4;
            do {
               if (!var2.hasNext()) {
                  return null;
               }

               zm var5 = (zm)var2.next();
               var4 = var5.e(var1);
            } while(var4 == null);

            return var4;
         }

         var3 = (zl)var2.next();
      } while(var3.d().p() != var1.p() || var3.d().r() != var1.r() || Math.abs(var3.d().q() - var1.q()) > 1);

      return var3;
   }

   private void d(et var1) {
      fa var2 = apy.f(this.b, var1);
      fa var3 = var2.d();
      int var4 = this.a(var1, var2, 5);
      int var5 = this.a(var1, var3, var4 + 1);
      if (var4 != var5) {
         this.d.add(new zl(var1, var4 < var5 ? var2 : var3, this.f));
      }

   }

   private int a(et var1, fa var2, int var3) {
      int var4 = 0;

      for(int var5 = 1; var5 <= 5; ++var5) {
         if (this.b.h(var1.a(var2, var5))) {
            ++var4;
            if (var4 >= var3) {
               return var4;
            }
         }
      }

      return var4;
   }

   private boolean e(et var1) {
      Iterator var2 = this.c.iterator();

      et var3;
      do {
         if (!var2.hasNext()) {
            return false;
         }

         var3 = (et)var2.next();
      } while(!var3.equals(var1));

      return true;
   }

   private boolean f(et var1) {
      awr var2 = this.b.o(var1);
      aou var3 = var2.u();
      if (var3 instanceof apy) {
         return var2.a() == bcx.d;
      } else {
         return false;
      }
   }

   public void a(fy var1) {
      this.f = var1.h("Tick");
      ge var2 = var1.c("Villages", 10);

      for(int var3 = 0; var3 < var2.c(); ++var3) {
         fy var4 = var2.b(var3);
         zm var5 = new zm();
         var5.a(var4);
         this.e.add(var5);
      }

   }

   public fy b(fy var1) {
      var1.a("Tick", this.f);
      ge var2 = new ge();
      Iterator var3 = this.e.iterator();

      while(var3.hasNext()) {
         zm var4 = (zm)var3.next();
         fy var5 = new fy();
         var4.b(var5);
         var2.a((gn)var5);
      }

      var1.a((String)"Villages", (gn)var2);
      return var1;
   }

   public static String a(ayk var0) {
      return "villages" + var0.q().c();
   }
}
