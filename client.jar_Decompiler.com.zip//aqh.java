import java.util.Random;

public class aqh extends apv {
   protected static final bgz a = new bgz(0.375D, 0.0D, 0.375D, 0.625D, 1.0D, 0.625D);
   protected static final bgz b = new bgz(0.375D, 0.375D, 0.0D, 0.625D, 0.625D, 1.0D);
   protected static final bgz c = new bgz(0.0D, 0.375D, 0.375D, 1.0D, 0.625D, 0.625D);

   protected aqh() {
      super(bcx.q);
      this.w(this.A.b().a(H, fa.b));
      this.a(ahn.c);
   }

   public awr a(awr var1, atk var2) {
      return var1.a(H, var2.a((fa)var1.c(H)));
   }

   public awr a(awr var1, arw var2) {
      return var1.a(H, var2.b((fa)var1.c(H)));
   }

   public bgz b(awr var1, amw var2, et var3) {
      switch(((fa)var1.c(H)).k()) {
      case a:
      default:
         return c;
      case c:
         return b;
      case b:
         return a;
      }
   }

   public boolean b(awr var1) {
      return false;
   }

   public boolean c(awr var1) {
      return false;
   }

   public boolean a(ams var1, et var2) {
      return true;
   }

   public awr a(ams var1, et var2, fa var3, float var4, float var5, float var6, int var7, vn var8) {
      awr var9 = var1.o(var2.a(var3.d()));
      if (var9.u() == aov.cQ) {
         fa var10 = (fa)var9.c(H);
         if (var10 == var3) {
            return this.t().a(H, var3.d());
         }
      }

      return this.t().a(H, var3);
   }

   public void a(awr var1, ams var2, et var3, Random var4) {
      fa var5 = (fa)var1.c(H);
      double var6 = (double)var3.p() + 0.55D - (double)(var4.nextFloat() * 0.1F);
      double var8 = (double)var3.q() + 0.55D - (double)(var4.nextFloat() * 0.1F);
      double var10 = (double)var3.r() + 0.55D - (double)(var4.nextFloat() * 0.1F);
      double var12 = (double)(0.4F - (var4.nextFloat() + var4.nextFloat()) * 0.4F);
      if (var4.nextInt(5) == 0) {
         var2.a(fj.R, var6 + (double)var5.g() * var12, var8 + (double)var5.h() * var12, var10 + (double)var5.i() * var12, var4.nextGaussian() * 0.005D, var4.nextGaussian() * 0.005D, var4.nextGaussian() * 0.005D);
      }

   }

   public amk f() {
      return amk.c;
   }

   public awr a(int var1) {
      awr var2 = this.t();
      var2 = var2.a(H, fa.a(var1));
      return var2;
   }

   public int e(awr var1) {
      return ((fa)var1.c(H)).a();
   }

   protected aws b() {
      return new aws(this, new axh[]{H});
   }

   public bda h(awr var1) {
      return bda.a;
   }

   public awp a(amw var1, awr var2, et var3, fa var4) {
      return awp.i;
   }
}
