import com.mojang.authlib.GameProfile;
import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public class ef extends bi {
   public String c() {
      return "whitelist";
   }

   public int a() {
      return 3;
   }

   public String b(bn var1) {
      return "commands.whitelist.usage";
   }

   public void a(MinecraftServer var1, bn var2, String[] var3) throws ei {
      if (var3.length < 1) {
         throw new ep("commands.whitelist.usage", new Object[0]);
      } else {
         if ("on".equals(var3[0])) {
            var1.am().a(true);
            a(var2, this, "commands.whitelist.enabled", new Object[0]);
         } else if ("off".equals(var3[0])) {
            var1.am().a(false);
            a(var2, this, "commands.whitelist.disabled", new Object[0]);
         } else if ("list".equals(var3[0])) {
            var2.a(new hp("commands.whitelist.list", new Object[]{var1.am().l().length, var1.am().q().length}));
            String[] var4 = var1.am().l();
            var2.a(new ho(a(var4)));
         } else {
            GameProfile var5;
            if ("add".equals(var3[0])) {
               if (var3.length < 2) {
                  throw new ep("commands.whitelist.add.usage", new Object[0]);
               }

               var5 = var1.aB().a(var3[1]);
               if (var5 == null) {
                  throw new ei("commands.whitelist.add.failed", new Object[]{var3[1]});
               }

               var1.am().d(var5);
               a(var2, this, "commands.whitelist.add.success", new Object[]{var3[1]});
            } else if ("remove".equals(var3[0])) {
               if (var3.length < 2) {
                  throw new ep("commands.whitelist.remove.usage", new Object[0]);
               }

               var5 = var1.am().k().a(var3[1]);
               if (var5 == null) {
                  throw new ei("commands.whitelist.remove.failed", new Object[]{var3[1]});
               }

               var1.am().c(var5);
               a(var2, this, "commands.whitelist.remove.success", new Object[]{var3[1]});
            } else if ("reload".equals(var3[0])) {
               var1.am().a();
               a(var2, this, "commands.whitelist.reloaded", new Object[0]);
            }
         }

      }
   }

   public List<String> a(MinecraftServer var1, bn var2, String[] var3, @Nullable et var4) {
      if (var3.length == 1) {
         return a(var3, new String[]{"on", "off", "list", "add", "remove", "reload"});
      } else {
         if (var3.length == 2) {
            if ("remove".equals(var3[0])) {
               return a(var3, var1.am().l());
            }

            if ("add".equals(var3[0])) {
               return a(var3, var1.aB().a());
            }
         }

         return Collections.emptyList();
      }
   }
}
