public class cgo implements chp<cgo> {
   private final nd a;
   private final float b;
   private final float c;
   private final int d;
   private final cgo.a e;
   private final boolean f;

   public cgo(String var1, float var2, float var3, int var4, cgo.a var5, boolean var6) {
      this.a = new nd(var1);
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = var5;
      this.f = var6;
   }

   public nd a() {
      return this.a;
   }

   public nd b() {
      return new nd(this.a.b(), "sounds/" + this.a.a() + ".ogg");
   }

   public float c() {
      return this.b;
   }

   public float d() {
      return this.c;
   }

   public int e() {
      return this.d;
   }

   public cgo f() {
      return this;
   }

   public cgo.a g() {
      return this.e;
   }

   public boolean h() {
      return this.f;
   }

   // $FF: synthetic method
   public Object i() {
      return this.f();
   }

   public static enum a {
      a("file"),
      b("event");

      private final String c;

      private a(String var3) {
         this.c = var3;
      }

      public static cgo.a a(String var0) {
         cgo.a[] var1 = values();
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            cgo.a var4 = var1[var3];
            if (var4.c.equals(var0)) {
               return var4;
            }
         }

         return null;
      }
   }
}
