import com.google.common.collect.Lists;
import java.util.List;
import javax.annotation.Nullable;
import org.apache.commons.lang3.StringUtils;

public abstract class blo {
   protected final bjc a;
   protected final boolean b;
   protected boolean c;
   protected boolean d;
   protected int e;
   protected List<String> f = Lists.newArrayList();

   public blo(bjc var1, boolean var2) {
      this.a = var1;
      this.b = var2;
   }

   public void a() {
      if (this.c) {
         this.a.b(0);
         this.a.b(this.a.a(-1, this.a.i(), false) - this.a.i());
         if (this.e >= this.f.size()) {
            this.e = 0;
         }
      } else {
         int var1 = this.a.a(-1, this.a.i(), false);
         this.f.clear();
         this.e = 0;
         String var2 = this.a.b().substring(0, this.a.i());
         this.a(var2);
         if (this.f.isEmpty()) {
            return;
         }

         this.c = true;
         this.a.b(var1 - this.a.i());
      }

      this.a.b((String)this.f.get(this.e++));
   }

   private void a(String var1) {
      if (var1.length() >= 1) {
         bhz.z().h.d.a((ht)(new kz(var1, this.b(), this.b)));
         this.d = true;
      }
   }

   @Nullable
   public abstract et b();

   public void a(String... var1) {
      if (this.d) {
         this.c = false;
         this.f.clear();
         String[] var2 = var1;
         int var3 = var1.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            String var5 = var2[var4];
            if (!var5.isEmpty()) {
               this.f.add(var5);
            }
         }

         String var6 = this.a.b().substring(this.a.a(-1, this.a.i(), false));
         String var7 = StringUtils.getCommonPrefix(var1);
         if (!var7.isEmpty() && !var6.equalsIgnoreCase(var7)) {
            this.a.b(0);
            this.a.b(this.a.a(-1, this.a.i(), false) - this.a.i());
            this.a.b(var7);
         } else if (!this.f.isEmpty()) {
            this.c = true;
            this.a();
         }

      }
   }

   public void c() {
      this.c = false;
   }

   public void d() {
      this.d = false;
   }
}
