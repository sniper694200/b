import javax.annotation.Nullable;

public class xw extends xc {
   protected final vv a;
   protected double b;
   protected double c;
   protected double d;
   protected double e;

   public xw(vv var1, double var2) {
      this.a = var1;
      this.b = var2;
      this.a(1);
   }

   public boolean a() {
      if (this.a.bS() == null && !this.a.aR()) {
         return false;
      } else {
         if (this.a.aR()) {
            et var1 = this.a(this.a.l, this.a, 5, 4);
            if (var1 != null) {
               this.c = (double)var1.p();
               this.d = (double)var1.q();
               this.e = (double)var1.r();
               return true;
            }
         }

         return this.f();
      }
   }

   protected boolean f() {
      bhc var1 = zj.a(this.a, 5, 4);
      if (var1 == null) {
         return false;
      } else {
         this.c = var1.b;
         this.d = var1.c;
         this.e = var1.d;
         return true;
      }
   }

   public void c() {
      this.a.x().a(this.c, this.d, this.e, this.b);
   }

   public boolean b() {
      return !this.a.x().o();
   }

   @Nullable
   private et a(ams var1, ve var2, int var3, int var4) {
      et var5 = new et(var2);
      int var6 = var5.p();
      int var7 = var5.q();
      int var8 = var5.r();
      float var9 = (float)(var3 * var3 * var4 * 2);
      et var10 = null;
      et.a var11 = new et.a();

      for(int var12 = var6 - var3; var12 <= var6 + var3; ++var12) {
         for(int var13 = var7 - var4; var13 <= var7 + var4; ++var13) {
            for(int var14 = var8 - var3; var14 <= var8 + var3; ++var14) {
               var11.c(var12, var13, var14);
               awr var15 = var1.o(var11);
               if (var15.a() == bcx.h) {
                  float var16 = (float)((var12 - var6) * (var12 - var6) + (var13 - var7) * (var13 - var7) + (var14 - var8) * (var14 - var8));
                  if (var16 < var9) {
                     var9 = var16;
                     var10 = new et(var11);
                  }
               }
            }
         }
      }

      return var10;
   }
}
