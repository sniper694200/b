import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public class bp {
   private static final int a = bp.a.values().length;
   private static final String[] b;
   private String[] c;
   private String[] d;

   public bp() {
      this.c = b;
      this.d = b;
   }

   public void a(MinecraftServer var1, final bn var2, bp.a var3, int var4) {
      String var5 = this.c[var3.a()];
      if (var5 != null) {
         bn var6 = new bn() {
            public String h_() {
               return var2.h_();
            }

            public hh i_() {
               return var2.i_();
            }

            public void a(hh var1) {
               var2.a(var1);
            }

            public boolean a(int var1, String var2x) {
               return true;
            }

            public et c() {
               return var2.c();
            }

            public bhc d() {
               return var2.d();
            }

            public ams e() {
               return var2.e();
            }

            public ve f() {
               return var2.f();
            }

            public boolean g() {
               return var2.g();
            }

            public void a(bp.a var1, int var2x) {
               var2.a(var1, var2x);
            }

            public MinecraftServer C_() {
               return var2.C_();
            }
         };

         String var7;
         try {
            var7 = bi.f(var1, var6, var5);
         } catch (ei var12) {
            return;
         }

         String var8 = this.d[var3.a()];
         if (var8 != null) {
            bhi var9 = var2.e().af();
            bhe var10 = var9.b(var8);
            if (var10 != null) {
               if (var9.b(var7, var10)) {
                  bhg var11 = var9.c(var7, var10);
                  var11.c(var4);
               }
            }
         }
      }
   }

   public void a(fy var1) {
      if (var1.b("CommandStats", 10)) {
         fy var2 = var1.p("CommandStats");
         bp.a[] var3 = bp.a.values();
         int var4 = var3.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            bp.a var6 = var3[var5];
            String var7 = var6.b() + "Name";
            String var8 = var6.b() + "Objective";
            if (var2.b(var7, 8) && var2.b(var8, 8)) {
               String var9 = var2.l(var7);
               String var10 = var2.l(var8);
               a(this, var6, var9, var10);
            }
         }

      }
   }

   public void b(fy var1) {
      fy var2 = new fy();
      bp.a[] var3 = bp.a.values();
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         bp.a var6 = var3[var5];
         String var7 = this.c[var6.a()];
         String var8 = this.d[var6.a()];
         if (var7 != null && var8 != null) {
            var2.a(var6.b() + "Name", var7);
            var2.a(var6.b() + "Objective", var8);
         }
      }

      if (!var2.b_()) {
         var1.a((String)"CommandStats", (gn)var2);
      }

   }

   public static void a(bp var0, bp.a var1, @Nullable String var2, @Nullable String var3) {
      if (var2 != null && !var2.isEmpty() && var3 != null && !var3.isEmpty()) {
         if (var0.c == b || var0.d == b) {
            var0.c = new String[a];
            var0.d = new String[a];
         }

         var0.c[var1.a()] = var2;
         var0.d[var1.a()] = var3;
      } else {
         a(var0, var1);
      }
   }

   private static void a(bp var0, bp.a var1) {
      if (var0.c != b && var0.d != b) {
         var0.c[var1.a()] = null;
         var0.d[var1.a()] = null;
         boolean var2 = true;
         bp.a[] var3 = bp.a.values();
         int var4 = var3.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            bp.a var6 = var3[var5];
            if (var0.c[var6.a()] != null && var0.d[var6.a()] != null) {
               var2 = false;
               break;
            }
         }

         if (var2) {
            var0.c = b;
            var0.d = b;
         }

      }
   }

   public void a(bp var1) {
      bp.a[] var2 = bp.a.values();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         bp.a var5 = var2[var4];
         a(this, var5, var1.c[var5.a()], var1.d[var5.a()]);
      }

   }

   static {
      b = new String[a];
   }

   public static enum a {
      a(0, "SuccessCount"),
      b(1, "AffectedBlocks"),
      c(2, "AffectedEntities"),
      d(3, "AffectedItems"),
      e(4, "QueryResult");

      final int f;
      final String g;

      private a(int var3, String var4) {
         this.f = var3;
         this.g = var4;
      }

      public int a() {
         return this.f;
      }

      public String b() {
         return this.g;
      }

      public static String[] c() {
         String[] var0 = new String[values().length];
         int var1 = 0;
         bp.a[] var2 = values();
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            bp.a var5 = var2[var4];
            var0[var1++] = var5.b();
         }

         return var0;
      }

      @Nullable
      public static bp.a a(String var0) {
         bp.a[] var1 = values();
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            bp.a var4 = var1[var3];
            if (var4.b().equals(var0)) {
               return var4;
            }
         }

         return null;
      }
   }
}
