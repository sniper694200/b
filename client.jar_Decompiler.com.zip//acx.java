import javax.annotation.Nullable;

public class acx extends adc {
   public acx(ams var1) {
      super(var1);
      this.a(this.G * 6.0F, this.H * 6.0F);
   }

   public static void a(rw var0) {
      vo.a(var0, acx.class);
   }

   public float by() {
      return 10.440001F;
   }

   protected void bM() {
      super.bM();
      this.a((wa)adf.a).a(100.0D);
      this.a((wa)adf.d).a(0.5D);
      this.a((wa)adf.f).a(50.0D);
   }

   public float a(et var1) {
      return this.l.n(var1) - 0.5F;
   }

   @Nullable
   protected nd J() {
      return bfl.u;
   }
}
