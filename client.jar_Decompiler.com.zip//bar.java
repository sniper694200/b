import java.util.Random;

public class bar extends azs {
   private final aou a;

   public bar(aou var1) {
      this.a = var1;
   }

   public boolean b(ams var1, Random var2, et var3) {
      if (var1.o(var3.a()).u() != aov.b) {
         return false;
      } else if (var1.o(var3.b()).u() != aov.b) {
         return false;
      } else {
         awr var4 = var1.o(var3);
         if (var4.a() != bcx.a && var4.u() != aov.b) {
            return false;
         } else {
            int var5 = 0;
            if (var1.o(var3.e()).u() == aov.b) {
               ++var5;
            }

            if (var1.o(var3.f()).u() == aov.b) {
               ++var5;
            }

            if (var1.o(var3.c()).u() == aov.b) {
               ++var5;
            }

            if (var1.o(var3.d()).u() == aov.b) {
               ++var5;
            }

            int var6 = 0;
            if (var1.d(var3.e())) {
               ++var6;
            }

            if (var1.d(var3.f())) {
               ++var6;
            }

            if (var1.d(var3.c())) {
               ++var6;
            }

            if (var1.d(var3.d())) {
               ++var6;
            }

            if (var5 == 3 && var6 == 1) {
               awr var7 = this.a.t();
               var1.a((et)var3, (awr)var7, 2);
               var1.a(var3, var7, var2);
            }

            return true;
         }
      }
   }
}
