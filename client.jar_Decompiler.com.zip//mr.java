import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;

public class mr implements ht<mp> {
   private static final Gson a = (new GsonBuilder()).registerTypeAdapter(ms.c.class, new ms.c.a()).registerTypeAdapter(ms.a.class, new ms.a.a()).registerTypeAdapter(ms.class, new ms.b()).registerTypeHierarchyAdapter(hh.class, new hh.a()).registerTypeHierarchyAdapter(hn.class, new hn.a()).registerTypeAdapterFactory(new rh()).create();
   private ms b;

   public mr() {
   }

   public mr(ms var1) {
      this.b = var1;
   }

   public void a(gy var1) throws IOException {
      this.b = (ms)ra.a(a, var1.e(32767), ms.class);
   }

   public void b(gy var1) throws IOException {
      var1.a(a.toJson(this.b));
   }

   public void a(mp var1) {
      var1.a(this);
   }

   public ms a() {
      return this.b;
   }
}
