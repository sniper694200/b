import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public class dz extends bi {
   public String c() {
      return "time";
   }

   public int a() {
      return 2;
   }

   public String b(bn var1) {
      return "commands.time.usage";
   }

   public void a(MinecraftServer var1, bn var2, String[] var3) throws ei {
      if (var3.length > 1) {
         int var4;
         if ("set".equals(var3[0])) {
            if ("day".equals(var3[1])) {
               var4 = 1000;
            } else if ("night".equals(var3[1])) {
               var4 = 13000;
            } else {
               var4 = a(var3[1], 0);
            }

            this.a(var1, var4);
            a(var2, this, "commands.time.set", new Object[]{var4});
            return;
         }

         if ("add".equals(var3[0])) {
            var4 = a(var3[1], 0);
            this.b(var1, var4);
            a(var2, this, "commands.time.added", new Object[]{var4});
            return;
         }

         if ("query".equals(var3[0])) {
            if ("daytime".equals(var3[1])) {
               var4 = (int)(var2.e().S() % 24000L);
               var2.a(bp.a.e, var4);
               a(var2, this, "commands.time.query", new Object[]{var4});
               return;
            }

            if ("day".equals(var3[1])) {
               var4 = (int)(var2.e().S() / 24000L % 2147483647L);
               var2.a(bp.a.e, var4);
               a(var2, this, "commands.time.query", new Object[]{var4});
               return;
            }

            if ("gametime".equals(var3[1])) {
               var4 = (int)(var2.e().R() % 2147483647L);
               var2.a(bp.a.e, var4);
               a(var2, this, "commands.time.query", new Object[]{var4});
               return;
            }
         }
      }

      throw new ep("commands.time.usage", new Object[0]);
   }

   public List<String> a(MinecraftServer var1, bn var2, String[] var3, @Nullable et var4) {
      if (var3.length == 1) {
         return a(var3, new String[]{"set", "add", "query"});
      } else if (var3.length == 2 && "set".equals(var3[0])) {
         return a(var3, new String[]{"day", "night"});
      } else {
         return var3.length == 2 && "query".equals(var3[0]) ? a(var3, new String[]{"daytime", "gametime", "day"}) : Collections.emptyList();
      }
   }

   protected void a(MinecraftServer var1, int var2) {
      for(int var3 = 0; var3 < var1.d.length; ++var3) {
         var1.d[var3].b((long)var2);
      }

   }

   protected void b(MinecraftServer var1, int var2) {
      for(int var3 = 0; var3 < var1.d.length; ++var3) {
         om var4 = var1.d[var3];
         var4.b(var4.S() + (long)var2);
      }

   }
}
