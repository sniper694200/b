import com.google.common.collect.Maps;
import java.util.Map;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector3f;

public enum cfx {
   a(0, 0),
   b(0, 90),
   c(0, 180),
   d(0, 270),
   e(90, 0),
   f(90, 90),
   g(90, 180),
   h(90, 270),
   i(180, 0),
   j(180, 90),
   k(180, 180),
   l(180, 270),
   m(270, 0),
   n(270, 90),
   o(270, 180),
   p(270, 270);

   private static final Map<Integer, cfx> q = Maps.newHashMap();
   private final int r;
   private final Matrix4f s;
   private final int t;
   private final int u;

   private static int b(int var0, int var1) {
      return var0 * 360 + var1;
   }

   private cfx(int var3, int var4) {
      this.r = b(var3, var4);
      this.s = new Matrix4f();
      Matrix4f var5 = new Matrix4f();
      var5.setIdentity();
      Matrix4f.rotate((float)(-var3) * 0.017453292F, new Vector3f(1.0F, 0.0F, 0.0F), var5, var5);
      this.t = ri.a(var3 / 90);
      Matrix4f var6 = new Matrix4f();
      var6.setIdentity();
      Matrix4f.rotate((float)(-var4) * 0.017453292F, new Vector3f(0.0F, 1.0F, 0.0F), var6, var6);
      this.u = ri.a(var4 / 90);
      Matrix4f.mul(var6, var5, this.s);
   }

   public Matrix4f a() {
      return this.s;
   }

   public fa a(fa var1) {
      fa var2 = var1;

      int var3;
      for(var3 = 0; var3 < this.t; ++var3) {
         var2 = var2.a(fa.a.a);
      }

      if (var2.k() != fa.a.b) {
         for(var3 = 0; var3 < this.u; ++var3) {
            var2 = var2.a(fa.a.b);
         }
      }

      return var2;
   }

   public int a(fa var1, int var2) {
      int var3 = var2;
      if (var1.k() == fa.a.a) {
         var3 = (var2 + this.t) % 4;
      }

      fa var4 = var1;

      for(int var5 = 0; var5 < this.t; ++var5) {
         var4 = var4.a(fa.a.a);
      }

      if (var4.k() == fa.a.b) {
         var3 = (var3 + this.u) % 4;
      }

      return var3;
   }

   public static cfx a(int var0, int var1) {
      return (cfx)q.get(b(ri.b(var0, 360), ri.b(var1, 360)));
   }

   static {
      cfx[] var0 = values();
      int var1 = var0.length;

      for(int var2 = 0; var2 < var1; ++var2) {
         cfx var3 = var0[var2];
         q.put(var3.r, var3);
      }

   }
}
