import javax.annotation.Nullable;

public class axw implements axy {
   private final awr[] a;
   private final axz b;
   private final int c;
   private int d;

   public axw(int var1, axz var2) {
      this.a = new awr[1 << var1];
      this.c = var1;
      this.b = var2;
   }

   public int a(awr var1) {
      int var2;
      for(var2 = 0; var2 < this.d; ++var2) {
         if (this.a[var2] == var1) {
            return var2;
         }
      }

      var2 = this.d;
      if (var2 < this.a.length) {
         this.a[var2] = var1;
         ++this.d;
         return var2;
      } else {
         return this.b.a(this.c + 1, var1);
      }
   }

   @Nullable
   public awr a(int var1) {
      return var1 >= 0 && var1 < this.d ? this.a[var1] : null;
   }

   public void a(gy var1) {
      this.d = var1.g();

      for(int var2 = 0; var2 < this.d; ++var2) {
         this.a[var2] = (awr)aou.i.a(var1.g());
      }

   }

   public void b(gy var1) {
      var1.d(this.d);

      for(int var2 = 0; var2 < this.d; ++var2) {
         var1.d(aou.i.a(this.a[var2]));
      }

   }

   public int a() {
      int var1 = gy.a(this.d);

      for(int var2 = 0; var2 < this.d; ++var2) {
         var1 += gy.a(aou.i.a(this.a[var2]));
      }

      return var1;
   }
}
