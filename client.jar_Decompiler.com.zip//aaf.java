public abstract class aaf extends vz {
   private int bB;

   public aaf(ams var1) {
      super(var1);
   }

   public boolean g(aeb var1) {
      fy var2 = new fy();
      var2.a("id", this.aB());
      this.e(var2);
      if (var1.g(var2)) {
         this.l.e((ve)this);
         return true;
      } else {
         return false;
      }
   }

   public void B_() {
      ++this.bB;
      super.B_();
   }

   public boolean dw() {
      return this.bB > 100;
   }
}
