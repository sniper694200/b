import io.netty.buffer.Unpooled;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class bmw extends bme {
   private static final Logger v = LogManager.getLogger();
   private static final nd w = new nd("textures/gui/container/villager.png");
   private final amd x;
   private bmw.a y;
   private bmw.a z;
   private int A;
   private final hh B;

   public bmw(aea var1, amd var2, ams var3) {
      super(new agi(var1, var2, var3));
      this.x = var2;
      this.B = var2.i_();
   }

   public void b() {
      super.b();
      int var1 = (this.l - this.f) / 2;
      int var2 = (this.m - this.g) / 2;
      this.y = (bmw.a)this.b(new bmw.a(1, var1 + 120 + 27, var2 + 24 - 1, true));
      this.z = (bmw.a)this.b(new bmw.a(2, var1 + 36 - 19, var2 + 24 - 1, false));
      this.y.l = false;
      this.z.l = false;
   }

   protected void c(int var1, int var2) {
      String var3 = this.B.c();
      this.q.a(var3, this.f / 2 - this.q.a(var3) / 2, 6, 4210752);
      this.q.a(cew.a("container.inventory"), 8, this.g - 96 + 2, 4210752);
   }

   public void e() {
      super.e();
      amf var1 = this.x.b_(this.j.h);
      if (var1 != null) {
         this.y.l = this.A < var1.size() - 1;
         this.z.l = this.A > 0;
      }

   }

   protected void a(biy var1) {
      boolean var2 = false;
      if (var1 == this.y) {
         ++this.A;
         amf var3 = this.x.b_(this.j.h);
         if (var3 != null && this.A >= var3.size()) {
            this.A = var3.size() - 1;
         }

         var2 = true;
      } else if (var1 == this.z) {
         --this.A;
         if (this.A < 0) {
            this.A = 0;
         }

         var2 = true;
      }

      if (var2) {
         ((agi)this.h).d(this.A);
         gy var4 = new gy(Unpooled.buffer());
         var4.writeInt(this.A);
         this.j.v().a((ht)(new lh("MC|TrSel", var4)));
      }

   }

   protected void a(float var1, int var2, int var3) {
      buq.c(1.0F, 1.0F, 1.0F, 1.0F);
      this.j.N().a(w);
      int var4 = (this.l - this.f) / 2;
      int var5 = (this.m - this.g) / 2;
      this.b(var4, var5, 0, 0, this.f, this.g);
      amf var6 = this.x.b_(this.j.h);
      if (var6 != null && !var6.isEmpty()) {
         int var7 = this.A;
         if (var7 < 0 || var7 >= var6.size()) {
            return;
         }

         ame var8 = (ame)var6.get(var7);
         if (var8.h()) {
            this.j.N().a(w);
            buq.c(1.0F, 1.0F, 1.0F, 1.0F);
            buq.g();
            this.b(this.i + 83, this.s + 21, 212, 0, 28, 21);
            this.b(this.i + 83, this.s + 51, 212, 0, 28, 21);
         }
      }

   }

   public void a(int var1, int var2, float var3) {
      this.c();
      super.a(var1, var2, var3);
      amf var4 = this.x.b_(this.j.h);
      if (var4 != null && !var4.isEmpty()) {
         int var5 = (this.l - this.f) / 2;
         int var6 = (this.m - this.g) / 2;
         int var7 = this.A;
         ame var8 = (ame)var4.get(var7);
         ain var9 = var8.a();
         ain var10 = var8.b();
         ain var11 = var8.d();
         buq.G();
         bhx.c();
         buq.g();
         buq.D();
         buq.h();
         buq.f();
         this.k.a = 100.0F;
         this.k.b(var9, var5 + 36, var6 + 24);
         this.k.a(this.q, var9, var5 + 36, var6 + 24);
         if (!var10.b()) {
            this.k.b(var10, var5 + 62, var6 + 24);
            this.k.a(this.q, var10, var5 + 62, var6 + 24);
         }

         this.k.b(var11, var5 + 120, var6 + 24);
         this.k.a(this.q, var11, var5 + 120, var6 + 24);
         this.k.a = 0.0F;
         buq.g();
         if (this.c(36, 24, 16, 16, var1, var2) && !var9.b()) {
            this.a(var9, var1, var2);
         } else if (!var10.b() && this.c(62, 24, 16, 16, var1, var2) && !var10.b()) {
            this.a(var10, var1, var2);
         } else if (!var11.b() && this.c(120, 24, 16, 16, var1, var2) && !var11.b()) {
            this.a(var11, var1, var2);
         } else if (var8.h() && (this.c(83, 21, 28, 21, var1, var2) || this.c(83, 51, 28, 21, var1, var2))) {
            this.a(cew.a("merchant.deprecated"), var1, var2);
         }

         buq.H();
         buq.f();
         buq.k();
         bhx.b();
      }

      this.b(var1, var2);
   }

   public amd a() {
      return this.x;
   }

   static class a extends biy {
      private final boolean o;

      public a(int var1, int var2, int var3, boolean var4) {
         super(var1, var2, var3, 12, 19, "");
         this.o = var4;
      }

      public void a(bhz var1, int var2, int var3, float var4) {
         if (this.m) {
            var1.N().a(bmw.w);
            buq.c(1.0F, 1.0F, 1.0F, 1.0F);
            boolean var5 = var2 >= this.h && var3 >= this.i && var2 < this.h + this.f && var3 < this.i + this.g;
            int var6 = 0;
            int var7 = 176;
            if (!this.l) {
               var7 += this.f * 2;
            } else if (var5) {
               var7 += this.f;
            }

            if (!this.o) {
               var6 += this.g;
            }

            this.b(this.h, this.i, var7, var6, this.f, this.g);
         }
      }
   }
}
