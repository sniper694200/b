import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import java.util.Collection;
import java.util.Random;

public class bfm extends bfp {
   public bfm(int var1, int var2, bgj[] var3) {
      super(var1, var2, var3);
   }

   public void a(Collection<ain> var1, Random var2, bfr var3) {
   }

   protected void a(JsonObject var1, JsonSerializationContext var2) {
   }

   public static bfm a(JsonObject var0, JsonDeserializationContext var1, int var2, int var3, bgj[] var4) {
      return new bfm(var2, var3, var4);
   }
}
