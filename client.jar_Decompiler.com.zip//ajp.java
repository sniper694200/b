import com.mojang.authlib.GameProfile;
import java.util.UUID;
import org.apache.commons.lang3.StringUtils;

public class ajp extends ail {
   private static final String[] a = new String[]{"skeleton", "wither", "zombie", "char", "creeper", "dragon"};

   public ajp() {
      this.b(ahn.c);
      this.e(0);
      this.a(true);
   }

   public ub a(aeb var1, ams var2, et var3, tz var4, fa var5, float var6, float var7, float var8) {
      if (var5 == fa.a) {
         return ub.c;
      } else {
         awr var9 = var2.o(var3);
         aou var10 = var9.u();
         boolean var11 = var10.a((amw)var2, (et)var3);
         if (!var11) {
            if (!var2.o(var3).a().a()) {
               return ub.c;
            }

            var3 = var3.a(var5);
         }

         ain var12 = var1.b((tz)var4);
         if (var1.a(var3, var5, var12) && aov.ce.a((ams)var2, (et)var3)) {
            if (var2.G) {
               return ub.a;
            } else {
               var2.a((et)var3, (awr)aov.ce.t().a(atr.a, var5), 11);
               int var13 = 0;
               if (var5 == fa.b) {
                  var13 = ri.c((double)(var1.v * 16.0F / 360.0F) + 0.5D) & 15;
               }

               avh var14 = var2.r(var3);
               if (var14 instanceof awb) {
                  awb var15 = (awb)var14;
                  if (var12.j() == 3) {
                     GameProfile var16 = null;
                     if (var12.o()) {
                        fy var17 = var12.p();
                        if (var17.b("SkullOwner", 10)) {
                           var16 = gj.a(var17.p("SkullOwner"));
                        } else if (var17.b("SkullOwner", 8) && !StringUtils.isBlank(var17.l("SkullOwner"))) {
                           var16 = new GameProfile((UUID)null, var17.l("SkullOwner"));
                        }
                     }

                     var15.a(var16);
                  } else {
                     var15.a(var12.j());
                  }

                  var15.b(var13);
                  aov.ce.a(var2, var3, var15);
               }

               if (var1 instanceof oo) {
                  m.x.a((oo)var1, var3, var12);
               }

               var12.g(1);
               return ub.a;
            }
         } else {
            return ub.c;
         }
      }
   }

   public void a(ahn var1, fi<ain> var2) {
      if (this.a((ahn)var1)) {
         for(int var3 = 0; var3 < a.length; ++var3) {
            var2.add(new ain(this, 1, var3));
         }
      }

   }

   public int a(int var1) {
      return var1;
   }

   public String a(ain var1) {
      int var2 = var1.j();
      if (var2 < 0 || var2 >= a.length) {
         var2 = 0;
      }

      return super.a() + "." + a[var2];
   }

   public String b(ain var1) {
      if (var1.j() == 3 && var1.o()) {
         if (var1.p().b("SkullOwner", 8)) {
            return ft.a("item.skull.player.name", var1.p().l("SkullOwner"));
         }

         if (var1.p().b("SkullOwner", 10)) {
            fy var2 = var1.p().p("SkullOwner");
            if (var2.b("Name", 8)) {
               return ft.a("item.skull.player.name", var2.l("Name"));
            }
         }
      }

      return super.b(var1);
   }

   public boolean a(fy var1) {
      super.a(var1);
      if (var1.b("SkullOwner", 8) && !StringUtils.isBlank(var1.l("SkullOwner"))) {
         GameProfile var2 = new GameProfile((UUID)null, var1.l("SkullOwner"));
         var2 = awb.b(var2);
         var1.a((String)"SkullOwner", (gn)gj.a(new fy(), var2));
         return true;
      } else {
         return false;
      }
   }
}
