import com.google.common.collect.Sets;
import java.util.Set;
import javax.annotation.Nullable;

public class aab extends zt {
   private static final mx<Boolean> bx;
   private static final mx<Integer> by;
   private static final Set<ail> bz;
   private boolean bB;
   private int bC;
   private int bD;

   public aab(ams var1) {
      super(var1);
      this.a(0.9F, 0.9F);
   }

   protected void r() {
      this.br.a(0, new wx(this));
      this.br.a(1, new xw(this, 1.25D));
      this.br.a(3, new wt(this, 1.0D));
      this.br.a(4, new yj(this, 1.2D, aip.cj, false));
      this.br.a(4, new yj(this, 1.2D, false, bz));
      this.br.a(5, new xb(this, 1.1D));
      this.br.a(6, new yn(this, 1.0D));
      this.br.a(7, new xj(this, aeb.class, 6.0F));
      this.br.a(8, new xz(this));
   }

   protected void bM() {
      super.bM();
      this.a((wa)adf.a).a(10.0D);
      this.a((wa)adf.d).a(0.25D);
   }

   @Nullable
   public ve bE() {
      return this.bF().isEmpty() ? null : (ve)this.bF().get(0);
   }

   public boolean cV() {
      ve var1 = this.bE();
      if (!(var1 instanceof aeb)) {
         return false;
      } else {
         aeb var2 = (aeb)var1;
         return var2.co().c() == aip.cj || var2.cp().c() == aip.cj;
      }
   }

   public void a(mx<?> var1) {
      if (by.equals(var1) && this.l.G) {
         this.bB = true;
         this.bC = 0;
         this.bD = (Integer)this.Y.a(by);
      }

      super.a((mx)var1);
   }

   protected void i() {
      super.i();
      this.Y.a((mx)bx, (Object)false);
      this.Y.a((mx)by, (int)0);
   }

   public static void a(rw var0) {
      vo.a(var0, aab.class);
   }

   public void b(fy var1) {
      super.b(var1);
      var1.a("Saddle", this.dl());
   }

   public void a(fy var1) {
      super.a(var1);
      this.p(var1.q("Saddle"));
   }

   protected qc F() {
      return qd.fo;
   }

   protected qc d(up var1) {
      return qd.fq;
   }

   protected qc cf() {
      return qd.fp;
   }

   protected void a(et var1, aou var2) {
      this.a(qd.fs, 0.15F, 1.0F);
   }

   public boolean a(aeb var1, tz var2) {
      if (!super.a(var1, var2)) {
         ain var3 = var1.b((tz)var2);
         if (var3.c() == aip.cz) {
            var3.a((aeb)var1, (vn)this, (tz)var2);
            return true;
         } else if (this.dl() && !this.aT()) {
            if (!this.l.G) {
               var1.m(this);
            }

            return true;
         } else if (var3.c() == aip.aD) {
            var3.a((aeb)var1, (vn)this, (tz)var2);
            return true;
         } else {
            return false;
         }
      } else {
         return true;
      }
   }

   public void a(up var1) {
      super.a((up)var1);
      if (!this.l.G) {
         if (this.dl()) {
            this.a(aip.aD, 1);
         }

      }
   }

   @Nullable
   protected nd J() {
      return bfl.E;
   }

   public boolean dl() {
      return (Boolean)this.Y.a(bx);
   }

   public void p(boolean var1) {
      if (var1) {
         this.Y.b(bx, true);
      } else {
         this.Y.b(bx, false);
      }

   }

   public void a(acg var1) {
      if (!this.l.G && !this.F) {
         add var2 = new add(this.l);
         var2.a((vj)vj.a, (ain)(new ain(aip.E)));
         var2.b(this.p, this.q, this.r, this.v, this.w);
         var2.n(this.dc());
         if (this.n_()) {
            var2.c(this.bq());
            var2.j(this.br());
         }

         this.l.a((ve)var2);
         this.X();
      }
   }

   public void a(float var1, float var2, float var3) {
      ve var4 = this.bF().isEmpty() ? null : (ve)this.bF().get(0);
      if (this.aT() && this.cV()) {
         this.v = var4.v;
         this.x = this.v;
         this.w = var4.w * 0.5F;
         this.b(this.v, this.w);
         this.aN = this.v;
         this.aP = this.v;
         this.P = 1.0F;
         this.aR = this.cy() * 0.1F;
         if (this.bB && this.bC++ > this.bD) {
            this.bB = false;
         }

         if (this.bI()) {
            float var5 = (float)this.a((wa)adf.d).e() * 0.225F;
            if (this.bB) {
               var5 += var5 * 1.15F * ri.a((float)this.bC / (float)this.bD * 3.1415927F);
            }

            this.k(var5);
            super.a(0.0F, 0.0F, 1.0F);
         } else {
            this.s = 0.0D;
            this.t = 0.0D;
            this.u = 0.0D;
         }

         this.aF = this.aG;
         double var10 = this.p - this.m;
         double var7 = this.r - this.o;
         float var9 = ri.a(var10 * var10 + var7 * var7) * 4.0F;
         if (var9 > 1.0F) {
            var9 = 1.0F;
         }

         this.aG += (var9 - this.aG) * 0.4F;
         this.aH += this.aG;
      } else {
         this.P = 0.5F;
         this.aR = 0.02F;
         super.a(var1, var2, var3);
      }
   }

   public boolean dm() {
      if (this.bB) {
         return false;
      } else {
         this.bB = true;
         this.bC = 0;
         this.bD = this.bR().nextInt(841) + 140;
         this.V().b(by, this.bD);
         return true;
      }
   }

   public aab b(vb var1) {
      return new aab(this.l);
   }

   public boolean e(ain var1) {
      return bz.contains(var1.c());
   }

   // $FF: synthetic method
   public vb a(vb var1) {
      return this.b(var1);
   }

   static {
      bx = na.a(aab.class, mz.h);
      by = na.a(aab.class, mz.b);
      bz = Sets.newHashSet(new ail[]{aip.cc, aip.cd, aip.cW});
   }
}
