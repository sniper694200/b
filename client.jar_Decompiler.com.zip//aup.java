import javax.annotation.Nullable;

public class aup extends aou {
   public static final axe a;
   public static final axd b;
   public static final axf<aup.a> c;
   protected static final bgz d;
   protected static final bgz e;
   protected static final bgz f;
   protected static final bgz g;
   protected static final bgz B;
   protected static final bgz C;

   protected aup(bcx var1) {
      super(var1);
      this.w(this.A.b().a(a, fa.c).a(b, false).a(c, aup.a.b));
      this.a(ahn.d);
   }

   public bgz b(awr var1, amw var2, et var3) {
      bgz var4;
      if ((Boolean)var1.c(b)) {
         switch((fa)var1.c(a)) {
         case c:
         default:
            var4 = g;
            break;
         case d:
            var4 = f;
            break;
         case e:
            var4 = e;
            break;
         case f:
            var4 = d;
         }
      } else if (var1.c(c) == aup.a.a) {
         var4 = C;
      } else {
         var4 = B;
      }

      return var4;
   }

   public boolean b(awr var1) {
      return false;
   }

   public boolean c(awr var1) {
      return false;
   }

   public boolean b(amw var1, et var2) {
      return !(Boolean)var1.o(var2).c(b);
   }

   public boolean a(ams var1, et var2, awr var3, aeb var4, tz var5, fa var6, float var7, float var8, float var9) {
      if (this.x == bcx.f) {
         return false;
      } else {
         var3 = var3.a(b);
         var1.a((et)var2, (awr)var3, 2);
         this.a(var4, var1, var2, (Boolean)var3.c(b));
         return true;
      }
   }

   protected void a(@Nullable aeb var1, ams var2, et var3, boolean var4) {
      int var5;
      if (var4) {
         var5 = this.x == bcx.f ? 1037 : 1007;
         var2.a(var1, var5, var3, 0);
      } else {
         var5 = this.x == bcx.f ? 1036 : 1013;
         var2.a(var1, var5, var3, 0);
      }

   }

   public void a(awr var1, ams var2, et var3, aou var4, et var5) {
      if (!var2.G) {
         boolean var6 = var2.y(var3);
         if (var6 || var4.t().m()) {
            boolean var7 = (Boolean)var1.c(b);
            if (var7 != var6) {
               var2.a((et)var3, (awr)var1.a(b, var6), 2);
               this.a((aeb)null, var2, var3, var6);
            }
         }

      }
   }

   public awr a(ams var1, et var2, fa var3, float var4, float var5, float var6, int var7, vn var8) {
      awr var9 = this.t();
      if (var3.k().c()) {
         var9 = var9.a(a, var3).a(b, false);
         var9 = var9.a(c, var5 > 0.5F ? aup.a.a : aup.a.b);
      } else {
         var9 = var9.a(a, var8.bt().d()).a(b, false);
         var9 = var9.a(c, var3 == fa.b ? aup.a.b : aup.a.a);
      }

      if (var1.y(var2)) {
         var9 = var9.a(b, true);
      }

      return var9;
   }

   public boolean b(ams var1, et var2, fa var3) {
      return true;
   }

   protected static fa b(int var0) {
      switch(var0 & 3) {
      case 0:
         return fa.c;
      case 1:
         return fa.d;
      case 2:
         return fa.e;
      case 3:
      default:
         return fa.f;
      }
   }

   protected static int a(fa var0) {
      switch(var0) {
      case c:
         return 0;
      case d:
         return 1;
      case e:
         return 2;
      case f:
      default:
         return 3;
      }
   }

   public amk f() {
      return amk.c;
   }

   public awr a(int var1) {
      return this.t().a(a, b(var1)).a(b, (var1 & 4) != 0).a(c, (var1 & 8) == 0 ? aup.a.b : aup.a.a);
   }

   public int e(awr var1) {
      int var2 = 0;
      int var3 = var2 | a((fa)var1.c(a));
      if ((Boolean)var1.c(b)) {
         var3 |= 4;
      }

      if (var1.c(c) == aup.a.a) {
         var3 |= 8;
      }

      return var3;
   }

   public awr a(awr var1, atk var2) {
      return var1.a(a, var2.a((fa)var1.c(a)));
   }

   public awr a(awr var1, arw var2) {
      return var1.a(var2.a((fa)var1.c(a)));
   }

   protected aws b() {
      return new aws(this, new axh[]{a, b, c});
   }

   public awp a(amw var1, awr var2, et var3, fa var4) {
      return (var4 == fa.b && var2.c(c) == aup.a.a || var4 == fa.a && var2.c(c) == aup.a.b) && !(Boolean)var2.c(b) ? awp.a : awp.i;
   }

   static {
      a = ark.D;
      b = axd.a("open");
      c = axf.a("half", aup.a.class);
      d = new bgz(0.0D, 0.0D, 0.0D, 0.1875D, 1.0D, 1.0D);
      e = new bgz(0.8125D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
      f = new bgz(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 0.1875D);
      g = new bgz(0.0D, 0.0D, 0.8125D, 1.0D, 1.0D, 1.0D);
      B = new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.1875D, 1.0D);
      C = new bgz(0.0D, 0.8125D, 0.0D, 1.0D, 1.0D, 1.0D);
   }

   public static enum a implements rm {
      a("top"),
      b("bottom");

      private final String c;

      private a(String var3) {
         this.c = var3;
      }

      public String toString() {
         return this.c;
      }

      public String m() {
         return this.c;
      }
   }
}
