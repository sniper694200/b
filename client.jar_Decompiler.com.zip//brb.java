public class brb {
   public bhc a;
   public float b;
   public float c;

   public brb(float var1, float var2, float var3, float var4, float var5) {
      this(new bhc((double)var1, (double)var2, (double)var3), var4, var5);
   }

   public brb a(float var1, float var2) {
      return new brb(this, var1, var2);
   }

   public brb(brb var1, float var2, float var3) {
      this.a = var1.a;
      this.b = var2;
      this.c = var3;
   }

   public brb(bhc var1, float var2, float var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }
}
