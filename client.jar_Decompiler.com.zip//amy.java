public enum amy {
   a(15),
   b(0);

   public final int c;

   private amy(int var3) {
      this.c = var3;
   }
}
