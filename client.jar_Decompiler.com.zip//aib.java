public class aib extends ail {
   public aib() {
      this.b(ahn.f);
   }

   public ub a(aeb var1, ams var2, et var3, tz var4, fa var5, float var6, float var7, float var8) {
      if (var2.G) {
         return ub.a;
      } else {
         var3 = var3.a(var5);
         ain var9 = var1.b((tz)var4);
         if (!var1.a(var3, var5, var9)) {
            return ub.c;
         } else {
            if (var2.o(var3).a() == bcx.a) {
               var2.a((aeb)null, var3, qd.bD, qe.e, 1.0F, (j.nextFloat() - j.nextFloat()) * 0.2F + 1.0F);
               var2.a(var3, aov.ab.t());
            }

            if (!var1.bO.d) {
               var9.g(1);
            }

            return ub.a;
         }
      }
   }
}
