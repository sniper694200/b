import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class bbj extends bbw {
   private bbh.a c;

   public bbj() {
   }

   public bbj(ams var1, Random var2, int var3, int var4, bbh.a var5) {
      super(var3, var4);
      this.c = var5;
      bbi.d var6 = new bbi.d(0, var2, (var3 << 4) + 2, (var4 << 4) + 2, this.c);
      this.a.add(var6);
      var6.a((bbv)var6, (List)this.a, (Random)var2);
      this.d();
      if (var5 == bbh.a.b) {
         int var7 = true;
         int var8 = var1.M() - this.b.e + this.b.d() / 2 - -5;
         this.b.a(0, var8, 0);
         Iterator var9 = this.a.iterator();

         while(var9.hasNext()) {
            bbv var10 = (bbv)var9.next();
            var10.a(0, var8, 0);
         }
      } else {
         this.a(var1, var2, 10);
      }

   }
}
