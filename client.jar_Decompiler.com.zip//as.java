import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import javax.annotation.Nullable;

public class as {
   public static final as a = new as((Float)null, (Float)null);
   private final Float b;
   private final Float c;

   public as(@Nullable Float var1, @Nullable Float var2) {
      this.b = var1;
      this.c = var2;
   }

   public boolean a(float var1) {
      if (this.b != null && this.b > var1) {
         return false;
      } else {
         return this.c == null || !(this.c < var1);
      }
   }

   public boolean a(double var1) {
      if (this.b != null && (double)(this.b * this.b) > var1) {
         return false;
      } else {
         return this.c == null || !((double)(this.c * this.c) < var1);
      }
   }

   public static as a(@Nullable JsonElement var0) {
      if (var0 != null && !var0.isJsonNull()) {
         if (ra.b(var0)) {
            float var4 = ra.e(var0, "value");
            return new as(var4, var4);
         } else {
            JsonObject var1 = ra.m(var0, "value");
            Float var2 = var1.has("min") ? ra.l(var1, "min") : null;
            Float var3 = var1.has("max") ? ra.l(var1, "max") : null;
            return new as(var2, var3);
         }
      } else {
         return a;
      }
   }
}
