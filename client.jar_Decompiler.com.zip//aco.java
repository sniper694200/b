import javax.annotation.Nullable;

public class aco extends adc {
   private float a = 0.5F;
   private int b;
   private static final mx<Byte> c;

   public aco(ams var1) {
      super(var1);
      this.a(bef.g, -1.0F);
      this.a(bef.f, 8.0F);
      this.a(bef.i, 0.0F);
      this.a(bef.j, 0.0F);
      this.X = true;
      this.b_ = 10;
   }

   public static void a(rw var0) {
      vo.a(var0, aco.class);
   }

   protected void r() {
      this.br.a(4, new aco.a(this));
      this.br.a(5, new xq(this, 1.0D));
      this.br.a(7, new yn(this, 1.0D, 0.0F));
      this.br.a(8, new xj(this, aeb.class, 8.0F));
      this.br.a(8, new xz(this));
      this.bs.a(1, new yr(this, true, new Class[0]));
      this.bs.a(2, new yu(this, aeb.class, true));
   }

   protected void bM() {
      super.bM();
      this.a(adf.f).a(6.0D);
      this.a(adf.d).a(0.23000000417232513D);
      this.a(adf.b).a(48.0D);
   }

   protected void i() {
      super.i();
      this.Y.a((mx)c, (byte)0);
   }

   protected qc F() {
      return qd.C;
   }

   protected qc d(up var1) {
      return qd.F;
   }

   protected qc cf() {
      return qd.E;
   }

   public int av() {
      return 15728880;
   }

   public float aw() {
      return 1.0F;
   }

   public void n() {
      if (!this.z && this.t < 0.0D) {
         this.t *= 0.6D;
      }

      if (this.l.G) {
         if (this.S.nextInt(24) == 0 && !this.ai()) {
            this.l.a(this.p + 0.5D, this.q + 0.5D, this.r + 0.5D, qd.D, this.bK(), 1.0F + this.S.nextFloat(), this.S.nextFloat() * 0.7F + 0.3F, false);
         }

         for(int var1 = 0; var1 < 2; ++var1) {
            this.l.a(fj.m, this.p + (this.S.nextDouble() - 0.5D) * (double)this.G, this.q + this.S.nextDouble() * (double)this.H, this.r + (this.S.nextDouble() - 0.5D) * (double)this.G, 0.0D, 0.0D, 0.0D);
         }
      }

      super.n();
   }

   protected void M() {
      if (this.an()) {
         this.a(up.h, 1.0F);
      }

      --this.b;
      if (this.b <= 0) {
         this.b = 100;
         this.a = 0.5F + (float)this.S.nextGaussian() * 3.0F;
      }

      vn var1 = this.z();
      if (var1 != null && var1.q + (double)var1.by() > this.q + (double)this.by() + (double)this.a) {
         this.t += (0.30000001192092896D - this.t) * 0.30000001192092896D;
         this.ai = true;
      }

      super.M();
   }

   public void e(float var1, float var2) {
   }

   public boolean aR() {
      return this.p();
   }

   @Nullable
   protected nd J() {
      return bfl.q;
   }

   public boolean p() {
      return ((Byte)this.Y.a(c) & 1) != 0;
   }

   public void a(boolean var1) {
      byte var2 = (Byte)this.Y.a(c);
      if (var1) {
         var2 = (byte)(var2 | 1);
      } else {
         var2 &= -2;
      }

      this.Y.b(c, var2);
   }

   protected boolean s_() {
      return true;
   }

   static {
      c = na.a(aco.class, mz.a);
   }

   static class a extends xc {
      private final aco a;
      private int b;
      private int c;

      public a(aco var1) {
         this.a = var1;
         this.a(3);
      }

      public boolean a() {
         vn var1 = this.a.z();
         return var1 != null && var1.aC();
      }

      public void c() {
         this.b = 0;
      }

      public void d() {
         this.a.a(false);
      }

      public void e() {
         --this.c;
         vn var1 = this.a.z();
         double var2 = this.a.h(var1);
         if (var2 < 4.0D) {
            if (this.c <= 0) {
               this.c = 20;
               this.a.B(var1);
            }

            this.a.u().a(var1.p, var1.q, var1.r, 1.0D);
         } else if (var2 < this.f() * this.f()) {
            double var4 = var1.p - this.a.p;
            double var6 = var1.bw().b + (double)(var1.H / 2.0F) - (this.a.q + (double)(this.a.H / 2.0F));
            double var8 = var1.r - this.a.r;
            if (this.c <= 0) {
               ++this.b;
               if (this.b == 1) {
                  this.c = 60;
                  this.a.a(true);
               } else if (this.b <= 4) {
                  this.c = 6;
               } else {
                  this.c = 100;
                  this.b = 0;
                  this.a.a(false);
               }

               if (this.b > 1) {
                  float var10 = ri.c(ri.a(var2)) * 0.5F;
                  this.a.l.a((aeb)null, 1018, new et((int)this.a.p, (int)this.a.q, (int)this.a.r), 0);

                  for(int var11 = 0; var11 < 1; ++var11) {
                     aeq var12 = new aeq(this.a.l, this.a, var4 + this.a.bR().nextGaussian() * (double)var10, var6, var8 + this.a.bR().nextGaussian() * (double)var10);
                     var12.q = this.a.q + (double)(this.a.H / 2.0F) + 0.5D;
                     this.a.l.a((ve)var12);
                  }
               }
            }

            this.a.t().a(var1, 10.0F, 10.0F);
         } else {
            this.a.x().p();
            this.a.u().a(var1.p, var1.q, var1.r, 1.0D);
         }

         super.e();
      }

      private double f() {
         wb var1 = this.a.a(adf.b);
         return var1 == null ? 16.0D : var1.e();
      }
   }
}
