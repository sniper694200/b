public class cfp implements cfc {
   private final hh a;
   private final int b;

   public cfp(hh var1, int var2) {
      this.a = var1;
      this.b = var2;
   }

   public hh a() {
      return this.a;
   }

   public int b() {
      return this.b;
   }
}
