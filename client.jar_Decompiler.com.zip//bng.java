import com.google.common.util.concurrent.ThreadFactoryBuilder;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufInputStream;
import io.netty.buffer.Unpooled;
import io.netty.handler.codec.base64.Base64;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadPoolExecutor;
import org.apache.commons.lang3.Validate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class bng implements bjk.a {
   private static final Logger a = LogManager.getLogger();
   private static final ThreadPoolExecutor b = new ScheduledThreadPoolExecutor(5, (new ThreadFactoryBuilder()).setNameFormat("Server Pinger #%d").setDaemon(true).build());
   private static final nd c = new nd("textures/misc/unknown_server.png");
   private static final nd d = new nd("textures/gui/server_selection.png");
   private final bnd e;
   private final bhz f;
   private final bsc g;
   private final nd h;
   private String i;
   private cde j;
   private long k;

   protected bng(bnd var1, bsc var2) {
      this.e = var1;
      this.g = var2;
      this.f = bhz.z();
      this.h = new nd("servers/" + var2.b + "/icon");
      this.j = (cde)this.f.N().b(this.h);
   }

   public void a(int var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean var8, float var9) {
      if (!this.g.h) {
         this.g.h = true;
         this.g.e = -2L;
         this.g.d = "";
         this.g.c = "";
         b.submit(new Runnable() {
            public void run() {
               try {
                  bng.this.e.g().a(bng.this.g);
               } catch (UnknownHostException var2) {
                  bng.this.g.e = -1L;
                  bng.this.g.d = a.e + cew.a("multiplayer.status.cannot_resolve");
               } catch (Exception var3) {
                  bng.this.g.e = -1L;
                  bng.this.g.d = a.e + cew.a("multiplayer.status.cannot_connect");
               }

            }
         });
      }

      boolean var10 = this.g.f > 335;
      boolean var11 = this.g.f < 335;
      boolean var12 = var10 || var11;
      this.f.k.a(this.g.a, var2 + 32 + 3, var3 + 1, 16777215);
      List<String> var13 = this.f.k.c(this.g.d, var4 - 32 - 2);

      for(int var14 = 0; var14 < Math.min(var13.size(), 2); ++var14) {
         this.f.k.a((String)var13.get(var14), var2 + 32 + 3, var3 + 12 + this.f.k.a * var14, 8421504);
      }

      String var24 = var12 ? a.e + this.g.g : this.g.c;
      int var15 = this.f.k.a(var24);
      this.f.k.a(var24, var2 + var4 - var15 - 15 - 2, var3 + 1, 8421504);
      int var16 = 0;
      String var18 = null;
      int var17;
      String var19;
      if (var12) {
         var17 = 5;
         var19 = cew.a(var10 ? "multiplayer.status.client_out_of_date" : "multiplayer.status.server_out_of_date");
         var18 = this.g.i;
      } else if (this.g.h && this.g.e != -2L) {
         if (this.g.e < 0L) {
            var17 = 5;
         } else if (this.g.e < 150L) {
            var17 = 0;
         } else if (this.g.e < 300L) {
            var17 = 1;
         } else if (this.g.e < 600L) {
            var17 = 2;
         } else if (this.g.e < 1000L) {
            var17 = 3;
         } else {
            var17 = 4;
         }

         if (this.g.e < 0L) {
            var19 = cew.a("multiplayer.status.no_connection");
         } else {
            var19 = this.g.e + "ms";
            var18 = this.g.i;
         }
      } else {
         var16 = 1;
         var17 = (int)(bhz.I() / 100L + (long)(var1 * 2) & 7L);
         if (var17 > 4) {
            var17 = 8 - var17;
         }

         var19 = cew.a("multiplayer.status.pinging");
      }

      buq.c(1.0F, 1.0F, 1.0F, 1.0F);
      this.f.N().a(bip.d);
      bip.a(var2 + var4 - 15, var3, (float)(var16 * 10), (float)(176 + var17 * 8), 10, 8, 256.0F, 256.0F);
      if (this.g.c() != null && !this.g.c().equals(this.i)) {
         this.i = this.g.c();
         this.c();
         this.e.h().b();
      }

      if (this.j != null) {
         this.a(var2, var3, this.h);
      } else {
         this.a(var2, var3, c);
      }

      int var20 = var6 - var2;
      int var21 = var7 - var3;
      if (var20 >= var4 - 15 && var20 <= var4 - 5 && var21 >= 0 && var21 <= 8) {
         this.e.a(var19);
      } else if (var20 >= var4 - var15 - 15 - 2 && var20 <= var4 - 15 - 2 && var21 >= 0 && var21 <= 8) {
         this.e.a(var18);
      }

      if (this.f.t.B || var8) {
         this.f.N().a(d);
         bip.a(var2, var3, var2 + 32, var3 + 32, -1601138544);
         buq.c(1.0F, 1.0F, 1.0F, 1.0F);
         int var22 = var6 - var2;
         int var23 = var7 - var3;
         if (this.b()) {
            if (var22 < 32 && var22 > 16) {
               bip.a(var2, var3, 0.0F, 32.0F, 32, 32, 256.0F, 256.0F);
            } else {
               bip.a(var2, var3, 0.0F, 0.0F, 32, 32, 256.0F, 256.0F);
            }
         }

         if (this.e.a(this, var1)) {
            if (var22 < 16 && var23 < 16) {
               bip.a(var2, var3, 96.0F, 32.0F, 32, 32, 256.0F, 256.0F);
            } else {
               bip.a(var2, var3, 96.0F, 0.0F, 32, 32, 256.0F, 256.0F);
            }
         }

         if (this.e.b(this, var1)) {
            if (var22 < 16 && var23 > 16) {
               bip.a(var2, var3, 64.0F, 32.0F, 32, 32, 256.0F, 256.0F);
            } else {
               bip.a(var2, var3, 64.0F, 0.0F, 32, 32, 256.0F, 256.0F);
            }
         }
      }

   }

   protected void a(int var1, int var2, nd var3) {
      this.f.N().a(var3);
      buq.m();
      bip.a(var1, var2, 0.0F, 0.0F, 32, 32, 32.0F, 32.0F);
      buq.l();
   }

   private boolean b() {
      return true;
   }

   private void c() {
      if (this.g.c() == null) {
         this.f.N().c(this.h);
         this.j = null;
      } else {
         ByteBuf var2 = Unpooled.copiedBuffer(this.g.c(), StandardCharsets.UTF_8);
         ByteBuf var3 = null;

         BufferedImage var1;
         label99: {
            try {
               var3 = Base64.decode(var2);
               var1 = cdr.a((InputStream)(new ByteBufInputStream(var3)));
               Validate.validState(var1.getWidth() == 64, "Must be 64 pixels wide", new Object[0]);
               Validate.validState(var1.getHeight() == 64, "Must be 64 pixels high", new Object[0]);
               break label99;
            } catch (Throwable var8) {
               a.error("Invalid icon for server {} ({})", this.g.a, this.g.b, var8);
               this.g.a((String)null);
            } finally {
               var2.release();
               if (var3 != null) {
                  var3.release();
               }

            }

            return;
         }

         if (this.j == null) {
            this.j = new cde(var1.getWidth(), var1.getHeight());
            this.f.N().a((nd)this.h, (cdq)this.j);
         }

         var1.getRGB(0, 0, var1.getWidth(), var1.getHeight(), this.j.e(), 0, var1.getWidth());
         this.j.d();
      }

   }

   public boolean a(int var1, int var2, int var3, int var4, int var5, int var6) {
      if (var5 <= 32) {
         if (var5 < 32 && var5 > 16 && this.b()) {
            this.e.b(var1);
            this.e.f();
            return true;
         }

         if (var5 < 16 && var6 < 16 && this.e.a(this, var1)) {
            this.e.a(this, var1, bli.s());
            return true;
         }

         if (var5 < 16 && var6 > 16 && this.e.b(this, var1)) {
            this.e.b(this, var1, bli.s());
            return true;
         }
      }

      this.e.b(var1);
      if (bhz.I() - this.k < 250L) {
         this.e.f();
      }

      this.k = bhz.I();
      return false;
   }

   public void a(int var1, int var2, int var3, float var4) {
   }

   public void b(int var1, int var2, int var3, int var4, int var5, int var6) {
   }

   public bsc a() {
      return this.g;
   }
}
