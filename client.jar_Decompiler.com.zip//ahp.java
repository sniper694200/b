public class ahp extends ail {
   private final aou a;

   public ahp(aou var1) {
      this.a = var1;
      this.b(ahn.d);
   }

   public ub a(aeb var1, ams var2, et var3, tz var4, fa var5, float var6, float var7, float var8) {
      if (var5 != fa.b) {
         return ub.c;
      } else {
         awr var9 = var2.o(var3);
         aou var10 = var9.u();
         if (!var10.a((amw)var2, (et)var3)) {
            var3 = var3.a(var5);
         }

         ain var11 = var1.b((tz)var4);
         if (var1.a(var3, var5, var11) && this.a.a(var2, var3)) {
            fa var12 = fa.a((double)var1.v);
            int var13 = var12.g();
            int var14 = var12.i();
            boolean var15 = var13 < 0 && var8 < 0.5F || var13 > 0 && var8 > 0.5F || var14 < 0 && var6 > 0.5F || var14 > 0 && var6 < 0.5F;
            a(var2, var3, var12, this.a, var15);
            atw var16 = this.a.v();
            var2.a(var1, var3, var16.e(), qe.e, (var16.a() + 1.0F) / 2.0F, var16.b() * 0.8F);
            var11.g(1);
            return ub.a;
         } else {
            return ub.c;
         }
      }
   }

   public static void a(ams var0, et var1, fa var2, aou var3, boolean var4) {
      et var5 = var1.a(var2.e());
      et var6 = var1.a(var2.f());
      int var7 = (var0.o(var6).l() ? 1 : 0) + (var0.o(var6.a()).l() ? 1 : 0);
      int var8 = (var0.o(var5).l() ? 1 : 0) + (var0.o(var5.a()).l() ? 1 : 0);
      boolean var9 = var0.o(var6).u() == var3 || var0.o(var6.a()).u() == var3;
      boolean var10 = var0.o(var5).u() == var3 || var0.o(var5.a()).u() == var3;
      if ((!var9 || var10) && var8 <= var7) {
         if (var10 && !var9 || var8 < var7) {
            var4 = false;
         }
      } else {
         var4 = true;
      }

      et var11 = var1.a();
      boolean var12 = var0.y(var1) || var0.y(var11);
      awr var13 = var3.t().a(apy.a, var2).a(apy.c, var4 ? apy.b.b : apy.b.a).a(apy.d, var12).a(apy.b, var12);
      var0.a((et)var1, (awr)var13.a(apy.e, apy.a.b), 2);
      var0.a((et)var11, (awr)var13.a(apy.e, apy.a.a), 2);
      var0.b(var1, var3, false);
      var0.b(var11, var3, false);
   }
}
