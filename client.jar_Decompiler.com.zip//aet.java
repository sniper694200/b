import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;

public abstract class aet extends ve implements aen {
   private int d;
   private int e;
   private int f;
   private aou g;
   protected boolean a;
   public int b;
   private vn h;
   private String at;
   private int au;
   private int av;
   public ve c;
   private int aw;

   public aet(ams var1) {
      super(var1);
      this.d = -1;
      this.e = -1;
      this.f = -1;
      this.a(0.25F, 0.25F);
   }

   public aet(ams var1, double var2, double var4, double var6) {
      this(var1);
      this.b(var2, var4, var6);
   }

   public aet(ams var1, vn var2) {
      this(var1, var2.p, var2.q + (double)var2.by() - 0.10000000149011612D, var2.r);
      this.h = var2;
   }

   protected void i() {
   }

   public boolean a(double var1) {
      double var3 = this.bw().a() * 4.0D;
      if (Double.isNaN(var3)) {
         var3 = 4.0D;
      }

      var3 *= 64.0D;
      return var1 < var3 * var3;
   }

   public void a(ve var1, float var2, float var3, float var4, float var5, float var6) {
      float var7 = -ri.a(var3 * 0.017453292F) * ri.b(var2 * 0.017453292F);
      float var8 = -ri.a((var2 + var4) * 0.017453292F);
      float var9 = ri.b(var3 * 0.017453292F) * ri.b(var2 * 0.017453292F);
      this.c((double)var7, (double)var8, (double)var9, var5, var6);
      this.s += var1.s;
      this.u += var1.u;
      if (!var1.z) {
         this.t += var1.t;
      }

   }

   public void c(double var1, double var3, double var5, float var7, float var8) {
      float var9 = ri.a(var1 * var1 + var3 * var3 + var5 * var5);
      var1 /= (double)var9;
      var3 /= (double)var9;
      var5 /= (double)var9;
      var1 += this.S.nextGaussian() * 0.007499999832361937D * (double)var8;
      var3 += this.S.nextGaussian() * 0.007499999832361937D * (double)var8;
      var5 += this.S.nextGaussian() * 0.007499999832361937D * (double)var8;
      var1 *= (double)var7;
      var3 *= (double)var7;
      var5 *= (double)var7;
      this.s = var1;
      this.t = var3;
      this.u = var5;
      float var10 = ri.a(var1 * var1 + var5 * var5);
      this.v = (float)(ri.c(var1, var5) * 57.2957763671875D);
      this.w = (float)(ri.c(var3, (double)var10) * 57.2957763671875D);
      this.x = this.v;
      this.y = this.w;
      this.au = 0;
   }

   public void h(double var1, double var3, double var5) {
      this.s = var1;
      this.t = var3;
      this.u = var5;
      if (this.y == 0.0F && this.x == 0.0F) {
         float var7 = ri.a(var1 * var1 + var5 * var5);
         this.v = (float)(ri.c(var1, var5) * 57.2957763671875D);
         this.w = (float)(ri.c(var3, (double)var7) * 57.2957763671875D);
         this.x = this.v;
         this.y = this.w;
      }

   }

   public void B_() {
      this.M = this.p;
      this.N = this.q;
      this.O = this.r;
      super.B_();
      if (this.b > 0) {
         --this.b;
      }

      if (this.a) {
         if (this.l.o(new et(this.d, this.e, this.f)).u() == this.g) {
            ++this.au;
            if (this.au == 1200) {
               this.X();
            }

            return;
         }

         this.a = false;
         this.s *= (double)(this.S.nextFloat() * 0.2F);
         this.t *= (double)(this.S.nextFloat() * 0.2F);
         this.u *= (double)(this.S.nextFloat() * 0.2F);
         this.au = 0;
         this.av = 0;
      } else {
         ++this.av;
      }

      bhc var1 = new bhc(this.p, this.q, this.r);
      bhc var2 = new bhc(this.p + this.s, this.q + this.t, this.r + this.u);
      bha var3 = this.l.a(var1, var2);
      var1 = new bhc(this.p, this.q, this.r);
      var2 = new bhc(this.p + this.s, this.q + this.t, this.r + this.u);
      if (var3 != null) {
         var2 = new bhc(var3.c.b, var3.c.c, var3.c.d);
      }

      ve var4 = null;
      List<ve> var5 = this.l.b((ve)this, (bgz)this.bw().b(this.s, this.t, this.u).g(1.0D));
      double var6 = 0.0D;
      boolean var8 = false;

      for(int var9 = 0; var9 < var5.size(); ++var9) {
         ve var10 = (ve)var5.get(var9);
         if (var10.ay()) {
            if (var10 == this.c) {
               var8 = true;
            } else if (this.h != null && this.T < 2 && this.c == null) {
               this.c = var10;
               var8 = true;
            } else {
               var8 = false;
               bgz var11 = var10.bw().g(0.30000001192092896D);
               bha var12 = var11.b(var1, var2);
               if (var12 != null) {
                  double var13 = var1.g(var12.c);
                  if (var13 < var6 || var6 == 0.0D) {
                     var4 = var10;
                     var6 = var13;
                  }
               }
            }
         }
      }

      if (this.c != null) {
         if (var8) {
            this.aw = 2;
         } else if (this.aw-- <= 0) {
            this.c = null;
         }
      }

      if (var4 != null) {
         var3 = new bha(var4);
      }

      if (var3 != null) {
         if (var3.a == bha.a.b && this.l.o(var3.a()).u() == aov.aY) {
            this.e(var3.a());
         } else {
            this.a(var3);
         }
      }

      this.p += this.s;
      this.q += this.t;
      this.r += this.u;
      float var15 = ri.a(this.s * this.s + this.u * this.u);
      this.v = (float)(ri.c(this.s, this.u) * 57.2957763671875D);

      for(this.w = (float)(ri.c(this.t, (double)var15) * 57.2957763671875D); this.w - this.y < -180.0F; this.y -= 360.0F) {
      }

      while(this.w - this.y >= 180.0F) {
         this.y += 360.0F;
      }

      while(this.v - this.x < -180.0F) {
         this.x -= 360.0F;
      }

      while(this.v - this.x >= 180.0F) {
         this.x += 360.0F;
      }

      this.w = this.y + (this.w - this.y) * 0.2F;
      this.v = this.x + (this.v - this.x) * 0.2F;
      float var16 = 0.99F;
      float var17 = this.j();
      if (this.ao()) {
         for(int var18 = 0; var18 < 4; ++var18) {
            float var19 = 0.25F;
            this.l.a(fj.e, this.p - this.s * 0.25D, this.q - this.t * 0.25D, this.r - this.u * 0.25D, this.s, this.t, this.u);
         }

         var16 = 0.8F;
      }

      this.s *= (double)var16;
      this.t *= (double)var16;
      this.u *= (double)var16;
      if (!this.aj()) {
         this.t -= (double)var17;
      }

      this.b(this.p, this.q, this.r);
   }

   protected float j() {
      return 0.03F;
   }

   protected abstract void a(bha var1);

   public static void a(rw var0, String var1) {
   }

   public void b(fy var1) {
      var1.a("xTile", this.d);
      var1.a("yTile", this.e);
      var1.a("zTile", this.f);
      nd var2 = (nd)aou.h.b(this.g);
      var1.a("inTile", var2 == null ? "" : var2.toString());
      var1.a("shake", (byte)this.b);
      var1.a("inGround", (byte)(this.a ? 1 : 0));
      if ((this.at == null || this.at.isEmpty()) && this.h instanceof aeb) {
         this.at = this.h.h_();
      }

      var1.a("ownerName", this.at == null ? "" : this.at);
   }

   public void a(fy var1) {
      this.d = var1.h("xTile");
      this.e = var1.h("yTile");
      this.f = var1.h("zTile");
      if (var1.b("inTile", 8)) {
         this.g = aou.b(var1.l("inTile"));
      } else {
         this.g = aou.c(var1.f("inTile") & 255);
      }

      this.b = var1.f("shake") & 255;
      this.a = var1.f("inGround") == 1;
      this.h = null;
      this.at = var1.l("ownerName");
      if (this.at != null && this.at.isEmpty()) {
         this.at = null;
      }

      this.h = this.k();
   }

   @Nullable
   public vn k() {
      if (this.h == null && this.at != null && !this.at.isEmpty()) {
         this.h = this.l.a(this.at);
         if (this.h == null && this.l instanceof om) {
            try {
               ve var1 = ((om)this.l).a(UUID.fromString(this.at));
               if (var1 instanceof vn) {
                  this.h = (vn)var1;
               }
            } catch (Throwable var2) {
               this.h = null;
            }
         }
      }

      return this.h;
   }
}
