import javax.annotation.Nullable;

public class bey extends bfb {
   private final bfb b;

   public bey(bfb var1) {
      this.b = var1;
   }

   public fy a(@Nullable fy var1) {
      return this.b.a(var1);
   }

   public long a() {
      return this.b.a();
   }

   public int b() {
      return this.b.b();
   }

   public int c() {
      return this.b.c();
   }

   public int d() {
      return this.b.d();
   }

   public long e() {
      return this.b.e();
   }

   public long f() {
      return this.b.f();
   }

   public long g() {
      return this.b.g();
   }

   public fy h() {
      return this.b.h();
   }

   public String j() {
      return this.b.j();
   }

   public int k() {
      return this.b.k();
   }

   public long l() {
      return this.b.l();
   }

   public boolean m() {
      return this.b.m();
   }

   public int n() {
      return this.b.n();
   }

   public boolean o() {
      return this.b.o();
   }

   public int p() {
      return this.b.p();
   }

   public amq q() {
      return this.b.q();
   }

   public void a(int var1) {
   }

   public void b(int var1) {
   }

   public void c(int var1) {
   }

   public void b(long var1) {
   }

   public void c(long var1) {
   }

   public void a(et var1) {
   }

   public void a(String var1) {
   }

   public void e(int var1) {
   }

   public void a(boolean var1) {
   }

   public void f(int var1) {
   }

   public void b(boolean var1) {
   }

   public void g(int var1) {
   }

   public boolean r() {
      return this.b.r();
   }

   public boolean s() {
      return this.b.s();
   }

   public amx t() {
      return this.b.t();
   }

   public void a(amx var1) {
   }

   public boolean u() {
      return this.b.u();
   }

   public void c(boolean var1) {
   }

   public boolean v() {
      return this.b.v();
   }

   public void d(boolean var1) {
   }

   public amp w() {
      return this.b.w();
   }

   public tx x() {
      return this.b.x();
   }

   public void a(tx var1) {
   }

   public boolean y() {
      return this.b.y();
   }

   public void e(boolean var1) {
   }

   public void a(ayl var1, fy var2) {
      this.b.a(var1, var2);
   }

   public fy a(ayl var1) {
      return this.b.a(var1);
   }
}
