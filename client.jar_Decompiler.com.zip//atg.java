import java.util.Iterator;
import java.util.Random;
import javax.annotation.Nullable;

public class atg extends aou {
   public static final axg a = axg.a("age", 0, 15);
   protected static final bgz b = new bgz(0.125D, 0.0D, 0.125D, 0.875D, 1.0D, 0.875D);

   protected atg() {
      super(bcx.k);
      this.w(this.A.b().a(a, 0));
      this.a(true);
   }

   public bgz b(awr var1, amw var2, et var3) {
      return b;
   }

   public void b(ams var1, et var2, awr var3, Random var4) {
      if (var1.o(var2.b()).u() == aov.aM || this.e(var1, var2, var3)) {
         if (var1.d(var2.a())) {
            int var5;
            for(var5 = 1; var1.o(var2.c(var5)).u() == this; ++var5) {
            }

            if (var5 < 3) {
               int var6 = (Integer)var3.c(a);
               if (var6 == 15) {
                  var1.a(var2.a(), this.t());
                  var1.a((et)var2, (awr)var3.a(a, 0), 4);
               } else {
                  var1.a((et)var2, (awr)var3.a(a, var6 + 1), 4);
               }
            }
         }

      }
   }

   public boolean a(ams var1, et var2) {
      aou var3 = var1.o(var2.b()).u();
      if (var3 == this) {
         return true;
      } else if (var3 != aov.c && var3 != aov.d && var3 != aov.m) {
         return false;
      } else {
         et var4 = var2.b();
         Iterator var5 = fa.c.a.iterator();

         awr var7;
         do {
            if (!var5.hasNext()) {
               return false;
            }

            fa var6 = (fa)var5.next();
            var7 = var1.o(var4.a(var6));
         } while(var7.a() != bcx.h && var7.u() != aov.de);

         return true;
      }
   }

   public void a(awr var1, ams var2, et var3, aou var4, et var5) {
      this.e(var2, var3, var1);
   }

   protected final boolean e(ams var1, et var2, awr var3) {
      if (this.b(var1, var2)) {
         return true;
      } else {
         this.b(var1, var2, var3, 0);
         var1.g(var2);
         return false;
      }
   }

   public boolean b(ams var1, et var2) {
      return this.a(var1, var2);
   }

   @Nullable
   public bgz a(awr var1, amw var2, et var3) {
      return k;
   }

   public ail a(awr var1, Random var2, int var3) {
      return aip.aR;
   }

   public boolean b(awr var1) {
      return false;
   }

   public boolean c(awr var1) {
      return false;
   }

   public ain a(ams var1, et var2, awr var3) {
      return new ain(aip.aR);
   }

   public amk f() {
      return amk.c;
   }

   public awr a(int var1) {
      return this.t().a(a, var1);
   }

   public int e(awr var1) {
      return (Integer)var1.c(a);
   }

   protected aws b() {
      return new aws(this, new axh[]{a});
   }

   public awp a(amw var1, awr var2, et var3, fa var4) {
      return awp.i;
   }
}
