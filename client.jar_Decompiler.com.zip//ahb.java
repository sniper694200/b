import java.util.List;

public class ahb extends ail {
   private final afb.b a;

   public ahb(afb.b var1) {
      this.a = var1;
      this.k = 1;
      this.b(ahn.e);
      this.c("boat." + var1.a());
   }

   public uc<ain> a(ams var1, aeb var2, tz var3) {
      ain var4 = var2.b((tz)var3);
      float var5 = 1.0F;
      float var6 = var2.y + (var2.w - var2.y) * 1.0F;
      float var7 = var2.x + (var2.v - var2.x) * 1.0F;
      double var8 = var2.m + (var2.p - var2.m) * 1.0D;
      double var10 = var2.n + (var2.q - var2.n) * 1.0D + (double)var2.by();
      double var12 = var2.o + (var2.r - var2.o) * 1.0D;
      bhc var14 = new bhc(var8, var10, var12);
      float var15 = ri.b(-var7 * 0.017453292F - 3.1415927F);
      float var16 = ri.a(-var7 * 0.017453292F - 3.1415927F);
      float var17 = -ri.b(-var6 * 0.017453292F);
      float var18 = ri.a(-var6 * 0.017453292F);
      float var19 = var16 * var17;
      float var21 = var15 * var17;
      double var22 = 5.0D;
      bhc var24 = var14.b((double)var19 * 5.0D, (double)var18 * 5.0D, (double)var21 * 5.0D);
      bha var25 = var1.a(var14, var24, true);
      if (var25 == null) {
         return new uc(ub.b, var4);
      } else {
         bhc var26 = var2.e(1.0F);
         boolean var27 = false;
         List<ve> var28 = var1.b((ve)var2, (bgz)var2.bw().b(var26.b * 5.0D, var26.c * 5.0D, var26.d * 5.0D).g(1.0D));

         for(int var29 = 0; var29 < var28.size(); ++var29) {
            ve var30 = (ve)var28.get(var29);
            if (var30.ay()) {
               bgz var31 = var30.bw().g((double)var30.aI());
               if (var31.b(var14)) {
                  var27 = true;
               }
            }
         }

         if (var27) {
            return new uc(ub.b, var4);
         } else if (var25.a != bha.a.b) {
            return new uc(ub.b, var4);
         } else {
            aou var32 = var1.o(var25.a()).u();
            boolean var33 = var32 == aov.j || var32 == aov.i;
            afb var34 = new afb(var1, var25.c.b, var33 ? var25.c.c - 0.12D : var25.c.c, var25.c.d);
            var34.a(this.a);
            var34.v = var2.v;
            if (!var1.a((ve)var34, (bgz)var34.bw().g(-0.1D)).isEmpty()) {
               return new uc(ub.c, var4);
            } else {
               if (!var1.G) {
                  var1.a((ve)var34);
               }

               if (!var2.bO.d) {
                  var4.g(1);
               }

               var2.b(qq.b((ail)this));
               return new uc(ub.a, var4);
            }
         }
      }
   }
}
