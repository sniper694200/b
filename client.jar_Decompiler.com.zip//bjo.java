import com.google.common.collect.ComparisonChain;
import com.google.common.collect.Ordering;
import com.mojang.authlib.GameProfile;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;

public class bjo extends bip {
   private static final Ordering<bsa> a = Ordering.from(new bjo.a());
   private final bhz f;
   private final bio g;
   private hh h;
   private hh i;
   private long j;
   private boolean k;

   public bjo(bhz var1, bio var2) {
      this.f = var1;
      this.g = var2;
   }

   public String a(bsa var1) {
      return var1.l() != null ? var1.l().d() : bhf.a(var1.j(), var1.a().getName());
   }

   public void a(boolean var1) {
      if (var1 && !this.k) {
         this.j = bhz.I();
      }

      this.k = var1;
   }

   public void a(int var1, bhi var2, @Nullable bhe var3) {
      brx var4 = this.f.h.d;
      List<bsa> var5 = a.sortedCopy(var4.d());
      int var6 = 0;
      int var7 = 0;
      Iterator var8 = var5.iterator();

      int var10;
      while(var8.hasNext()) {
         bsa var9 = (bsa)var8.next();
         var10 = this.f.k.a(this.a(var9));
         var6 = Math.max(var6, var10);
         if (var3 != null && var3.e() != bho.a.b) {
            var10 = this.f.k.a(" " + var2.c(var9.a().getName(), var3).c());
            var7 = Math.max(var7, var10);
         }
      }

      var5 = var5.subList(0, Math.min(var5.size(), 80));
      int var32 = var5.size();
      int var33 = var32;

      for(var10 = 1; var33 > 20; var33 = (var32 + var10 - 1) / var10) {
         ++var10;
      }

      boolean var11 = this.f.D() || this.f.v().a().f();
      int var12;
      if (var3 != null) {
         if (var3.e() == bho.a.b) {
            var12 = 90;
         } else {
            var12 = var7;
         }
      } else {
         var12 = 0;
      }

      int var13 = Math.min(var10 * ((var11 ? 9 : 0) + var6 + var12 + 13), var1 - 50) / var10;
      int var14 = var1 / 2 - (var13 * var10 + (var10 - 1) * 5) / 2;
      int var15 = 10;
      int var16 = var13 * var10 + (var10 - 1) * 5;
      List<String> var17 = null;
      if (this.i != null) {
         var17 = this.f.k.c(this.i.d(), var1 - 50);

         String var19;
         for(Iterator var18 = var17.iterator(); var18.hasNext(); var16 = Math.max(var16, this.f.k.a(var19))) {
            var19 = (String)var18.next();
         }
      }

      List<String> var34 = null;
      String var20;
      Iterator var35;
      if (this.h != null) {
         var34 = this.f.k.c(this.h.d(), var1 - 50);

         for(var35 = var34.iterator(); var35.hasNext(); var16 = Math.max(var16, this.f.k.a(var20))) {
            var20 = (String)var35.next();
         }
      }

      int var21;
      if (var17 != null) {
         a(var1 / 2 - var16 / 2 - 1, var15 - 1, var1 / 2 + var16 / 2 + 1, var15 + var17.size() * this.f.k.a, Integer.MIN_VALUE);

         for(var35 = var17.iterator(); var35.hasNext(); var15 += this.f.k.a) {
            var20 = (String)var35.next();
            var21 = this.f.k.a(var20);
            this.f.k.a(var20, (float)(var1 / 2 - var21 / 2), (float)var15, -1);
         }

         ++var15;
      }

      a(var1 / 2 - var16 / 2 - 1, var15 - 1, var1 / 2 + var16 / 2 + 1, var15 + var33 * 9, Integer.MIN_VALUE);

      for(int var36 = 0; var36 < var32; ++var36) {
         int var37 = var36 / var33;
         var21 = var36 % var33;
         int var22 = var14 + var37 * var13 + var37 * 5;
         int var23 = var15 + var21 * 9;
         a(var22, var23, var22 + var13, var23 + 8, 553648127);
         buq.c(1.0F, 1.0F, 1.0F, 1.0F);
         buq.e();
         buq.m();
         buq.a(buq.r.l, buq.l.j, buq.r.e, buq.l.n);
         if (var36 < var5.size()) {
            bsa var24 = (bsa)var5.get(var36);
            GameProfile var25 = var24.a();
            int var28;
            if (var11) {
               aeb var26 = this.f.f.b((UUID)var25.getId());
               boolean var27 = var26 != null && var26.a(aec.a) && ("Dinnerbone".equals(var25.getName()) || "Grumm".equals(var25.getName()));
               this.f.N().a(var24.g());
               var28 = 8 + (var27 ? 8 : 0);
               int var29 = 8 * (var27 ? -1 : 1);
               bip.a(var22, var23, 8.0F, (float)var28, 8, var29, 8, 8, 64.0F, 64.0F);
               if (var26 != null && var26.a(aec.g)) {
                  int var30 = 8 + (var27 ? 8 : 0);
                  int var31 = 8 * (var27 ? -1 : 1);
                  bip.a(var22, var23, 40.0F, (float)var30, 8, var31, 8, 8, 64.0F, 64.0F);
               }

               var22 += 9;
            }

            String var38 = this.a(var24);
            if (var24.b() == amq.e) {
               this.f.k.a(.a.u + var38, (float)var22, (float)var23, -1862270977);
            } else {
               this.f.k.a(var38, (float)var22, (float)var23, -1);
            }

            if (var3 != null && var24.b() != amq.e) {
               int var39 = var22 + var6 + 1;
               var28 = var39 + var12;
               if (var28 - var39 > 5) {
                  this.a(var3, var23, var25.getName(), var39, var28, var24);
               }
            }

            this.a(var13, var22 - (var11 ? 9 : 0), var23, var24);
         }
      }

      if (var34 != null) {
         var15 += var33 * 9 + 1;
         a(var1 / 2 - var16 / 2 - 1, var15 - 1, var1 / 2 + var16 / 2 + 1, var15 + var34.size() * this.f.k.a, Integer.MIN_VALUE);

         for(var35 = var34.iterator(); var35.hasNext(); var15 += this.f.k.a) {
            var20 = (String)var35.next();
            var21 = this.f.k.a(var20);
            this.f.k.a(var20, (float)(var1 / 2 - var21 / 2), (float)var15, -1);
         }
      }

   }

   protected void a(int var1, int var2, int var3, bsa var4) {
      buq.c(1.0F, 1.0F, 1.0F, 1.0F);
      this.f.N().a(d);
      int var5 = false;
      byte var6;
      if (var4.c() < 0) {
         var6 = 5;
      } else if (var4.c() < 150) {
         var6 = 0;
      } else if (var4.c() < 300) {
         var6 = 1;
      } else if (var4.c() < 600) {
         var6 = 2;
      } else if (var4.c() < 1000) {
         var6 = 3;
      } else {
         var6 = 4;
      }

      this.e += 100.0F;
      this.b(var2 + var1 - 11, var3, 0, 176 + var6 * 8, 10, 8);
      this.e -= 100.0F;
   }

   private void a(bhe var1, int var2, String var3, int var4, int var5, bsa var6) {
      int var7 = var1.a().c(var3, var1).c();
      if (var1.e() == bho.a.b) {
         this.f.N().a(d);
         if (this.j == var6.q()) {
            if (var7 < var6.m()) {
               var6.a(bhz.I());
               var6.b((long)(this.g.e() + 20));
            } else if (var7 > var6.m()) {
               var6.a(bhz.I());
               var6.b((long)(this.g.e() + 10));
            }
         }

         if (bhz.I() - var6.o() > 1000L || this.j != var6.q()) {
            var6.b(var7);
            var6.c(var7);
            var6.a(bhz.I());
         }

         var6.c(this.j);
         var6.b(var7);
         int var8 = ri.f((float)Math.max(var7, var6.n()) / 2.0F);
         int var9 = Math.max(ri.f((float)(var7 / 2)), Math.max(ri.f((float)(var6.n() / 2)), 10));
         boolean var10 = var6.p() > (long)this.g.e() && (var6.p() - (long)this.g.e()) / 3L % 2L == 1L;
         if (var8 > 0) {
            float var11 = Math.min((float)(var5 - var4 - 4) / (float)var9, 9.0F);
            if (var11 > 3.0F) {
               int var12;
               for(var12 = var8; var12 < var9; ++var12) {
                  this.a((float)var4 + (float)var12 * var11, (float)var2, var10 ? 25 : 16, 0, 9, 9);
               }

               for(var12 = 0; var12 < var8; ++var12) {
                  this.a((float)var4 + (float)var12 * var11, (float)var2, var10 ? 25 : 16, 0, 9, 9);
                  if (var10) {
                     if (var12 * 2 + 1 < var6.n()) {
                        this.a((float)var4 + (float)var12 * var11, (float)var2, 70, 0, 9, 9);
                     }

                     if (var12 * 2 + 1 == var6.n()) {
                        this.a((float)var4 + (float)var12 * var11, (float)var2, 79, 0, 9, 9);
                     }
                  }

                  if (var12 * 2 + 1 < var7) {
                     this.a((float)var4 + (float)var12 * var11, (float)var2, var12 >= 10 ? 160 : 52, 0, 9, 9);
                  }

                  if (var12 * 2 + 1 == var7) {
                     this.a((float)var4 + (float)var12 * var11, (float)var2, var12 >= 10 ? 169 : 61, 0, 9, 9);
                  }
               }
            } else {
               float var16 = ri.a((float)var7 / 20.0F, 0.0F, 1.0F);
               int var13 = (int)((1.0F - var16) * 255.0F) << 16 | (int)(var16 * 255.0F) << 8;
               String var14 = "" + (float)var7 / 2.0F;
               if (var5 - this.f.k.a(var14 + "hp") >= var4) {
                  var14 = var14 + "hp";
               }

               this.f.k.a(var14, (float)((var5 + var4) / 2 - this.f.k.a(var14) / 2), (float)var2, var13);
            }
         }
      } else {
         String var15 = .a.o + "" + var7;
         this.f.k.a(var15, (float)(var5 - this.f.k.a(var15)), (float)var2, 16777215);
      }

   }

   public void a(@Nullable hh var1) {
      this.h = var1;
   }

   public void b(@Nullable hh var1) {
      this.i = var1;
   }

   public void a() {
      this.i = null;
      this.h = null;
   }

   static class a implements Comparator<bsa> {
      private a() {
      }

      public int a(bsa var1, bsa var2) {
         bhf var3 = var1.j();
         bhf var4 = var2.j();
         return ComparisonChain.start().compareTrueFirst(var1.b() != amq.e, var2.b() != amq.e).compare(var3 != null ? var3.b() : "", var4 != null ? var4.b() : "").compare(var1.a().getName(), var2.a().getName()).result();
      }

      // $FF: synthetic method
      public int compare(Object var1, Object var2) {
         return this.a((bsa)var1, (bsa)var2);
      }

      // $FF: synthetic method
      a(Object var1) {
         this();
      }
   }
}
