public class alc extends ali {
   public alc(ali.a var1, vj... var2) {
      super(var1, alj.k, var2);
      this.c("arrowInfinite");
   }

   public int a(int var1) {
      return 20;
   }

   public int b(int var1) {
      return 50;
   }

   public int b() {
      return 1;
   }

   public boolean a(ali var1) {
      return var1 instanceof als ? false : super.a(var1);
   }
}
