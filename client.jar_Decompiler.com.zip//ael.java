public class ael extends aej {
   public int e = 1;

   public ael(ams var1) {
      super(var1);
   }

   public ael(ams var1, double var2, double var4, double var6, double var8, double var10, double var12) {
      super(var1, var2, var4, var6, var8, var10, var12);
   }

   public ael(ams var1, vn var2, double var3, double var5, double var7) {
      super(var1, var2, var3, var5, var7);
   }

   protected void a(bha var1) {
      if (!this.l.G) {
         if (var1.d != null) {
            var1.d.a(up.a((aej)this, (ve)this.a), 6.0F);
            this.a(this.a, var1.d);
         }

         boolean var2 = this.l.W().b("mobGriefing");
         this.l.a((ve)null, this.p, this.q, this.r, (float)this.e, var2, var2);
         this.X();
      }

   }

   public static void a(rw var0) {
      aej.a(var0, "Fireball");
   }

   public void b(fy var1) {
      super.b(var1);
      var1.a("ExplosionPower", this.e);
   }

   public void a(fy var1) {
      super.a(var1);
      if (var1.b("ExplosionPower", 99)) {
         this.e = var1.h("ExplosionPower");
      }

   }
}
