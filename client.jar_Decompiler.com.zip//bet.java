import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;

public class bet extends ber {
   public int b;
   public int c;
   public byte d;
   public boolean e;
   public boolean f;
   public byte g;
   public byte[] h = new byte[16384];
   public List<bet.a> i = Lists.newArrayList();
   private final Map<aeb, bet.a> k = Maps.newHashMap();
   public Map<String, bes> j = Maps.newLinkedHashMap();

   public bet(String var1) {
      super(var1);
   }

   public void a(double var1, double var3, int var5) {
      int var6 = 128 * (1 << var5);
      int var7 = ri.c((var1 + 64.0D) / (double)var6);
      int var8 = ri.c((var3 + 64.0D) / (double)var6);
      this.b = var7 * var6 + var6 / 2 - 64;
      this.c = var8 * var6 + var6 / 2 - 64;
   }

   public void a(fy var1) {
      this.d = var1.f("dimension");
      this.b = var1.h("xCenter");
      this.c = var1.h("zCenter");
      this.g = var1.f("scale");
      this.g = (byte)ri.a(this.g, 0, 4);
      if (var1.b("trackingPosition", 1)) {
         this.e = var1.q("trackingPosition");
      } else {
         this.e = true;
      }

      this.f = var1.q("unlimitedTracking");
      int var2 = var1.g("width");
      int var3 = var1.g("height");
      if (var2 == 128 && var3 == 128) {
         this.h = var1.m("colors");
      } else {
         byte[] var4 = var1.m("colors");
         this.h = new byte[16384];
         int var5 = (128 - var2) / 2;
         int var6 = (128 - var3) / 2;

         for(int var7 = 0; var7 < var3; ++var7) {
            int var8 = var7 + var6;
            if (var8 >= 0 || var8 < 128) {
               for(int var9 = 0; var9 < var2; ++var9) {
                  int var10 = var9 + var5;
                  if (var10 >= 0 || var10 < 128) {
                     this.h[var10 + var8 * 128] = var4[var9 + var7 * var2];
                  }
               }
            }
         }
      }

   }

   public fy b(fy var1) {
      var1.a("dimension", this.d);
      var1.a("xCenter", this.b);
      var1.a("zCenter", this.c);
      var1.a("scale", this.g);
      var1.a("width", (short)128);
      var1.a("height", (short)128);
      var1.a("colors", this.h);
      var1.a("trackingPosition", this.e);
      var1.a("unlimitedTracking", this.f);
      return var1;
   }

   public void a(aeb var1, ain var2) {
      if (!this.k.containsKey(var1)) {
         bet.a var3 = new bet.a(var1);
         this.k.put(var1, var3);
         this.i.add(var3);
      }

      if (!var1.bv.h(var2)) {
         this.j.remove(var1.h_());
      }

      for(int var6 = 0; var6 < this.i.size(); ++var6) {
         bet.a var4 = (bet.a)this.i.get(var6);
         if (var4.a.F || !var4.a.bv.h(var2) && !var2.z()) {
            this.k.remove(var4.a);
            this.i.remove(var4);
         } else if (!var2.z() && var4.a.am == this.d && this.e) {
            this.a(bes.a.a, var4.a.l, var4.a.h_(), var4.a.p, var4.a.r, (double)var4.a.v);
         }
      }

      if (var2.z() && this.e) {
         abz var7 = var2.A();
         et var8 = var7.q();
         this.a(bes.a.b, var1.l, "frame-" + var7.S(), (double)var8.p(), (double)var8.r(), (double)(var7.b.b() * 90));
      }

      if (var2.o() && var2.p().b("Decorations", 9)) {
         ge var9 = var2.p().c("Decorations", 10);

         for(int var10 = 0; var10 < var9.c(); ++var10) {
            fy var5 = var9.b(var10);
            if (!this.j.containsKey(var5.l("id"))) {
               this.a(bes.a.a(var5.f("type")), var1.l, var5.l("id"), var5.k("x"), var5.k("z"), var5.k("rot"));
            }
         }
      }

   }

   public static void a(ain var0, et var1, String var2, bes.a var3) {
      ge var4;
      if (var0.o() && var0.p().b("Decorations", 9)) {
         var4 = var0.p().c("Decorations", 10);
      } else {
         var4 = new ge();
         var0.a((String)"Decorations", (gn)var4);
      }

      fy var5 = new fy();
      var5.a("type", var3.a());
      var5.a("id", var2);
      var5.a("x", (double)var1.p());
      var5.a("z", (double)var1.r());
      var5.a("rot", 180.0D);
      var4.a((gn)var5);
      if (var3.c()) {
         fy var6 = var0.c("display");
         var6.a("MapColor", var3.d());
      }

   }

   private void a(bes.a var1, ams var2, String var3, double var4, double var6, double var8) {
      int var10 = 1 << this.g;
      float var11 = (float)(var4 - (double)this.b) / (float)var10;
      float var12 = (float)(var6 - (double)this.c) / (float)var10;
      byte var13 = (byte)((int)((double)(var11 * 2.0F) + 0.5D));
      byte var14 = (byte)((int)((double)(var12 * 2.0F) + 0.5D));
      int var16 = true;
      byte var15;
      if (var11 >= -63.0F && var12 >= -63.0F && var11 <= 63.0F && var12 <= 63.0F) {
         var8 += var8 < 0.0D ? -8.0D : 8.0D;
         var15 = (byte)((int)(var8 * 16.0D / 360.0D));
         if (this.d < 0) {
            int var18 = (int)(var2.V().f() / 10L);
            var15 = (byte)(var18 * var18 * 34187121 + var18 * 121 >> 15 & 15);
         }
      } else {
         if (var1 != bes.a.a) {
            this.j.remove(var3);
            return;
         }

         int var17 = true;
         if (Math.abs(var11) < 320.0F && Math.abs(var12) < 320.0F) {
            var1 = bes.a.g;
         } else {
            if (!this.f) {
               this.j.remove(var3);
               return;
            }

            var1 = bes.a.h;
         }

         var15 = 0;
         if (var11 <= -63.0F) {
            var13 = -128;
         }

         if (var12 <= -63.0F) {
            var14 = -128;
         }

         if (var11 >= 63.0F) {
            var13 = 127;
         }

         if (var12 >= 63.0F) {
            var14 = 127;
         }
      }

      this.j.put(var3, new bes(var1, var13, var14, var15));
   }

   @Nullable
   public ht<?> a(ain var1, ams var2, aeb var3) {
      bet.a var4 = (bet.a)this.k.get(var3);
      return var4 == null ? null : var4.a(var1);
   }

   public void a(int var1, int var2) {
      super.c();
      Iterator var3 = this.i.iterator();

      while(var3.hasNext()) {
         bet.a var4 = (bet.a)var3.next();
         var4.a(var1, var2);
      }

   }

   public bet.a a(aeb var1) {
      bet.a var2 = (bet.a)this.k.get(var1);
      if (var2 == null) {
         var2 = new bet.a(var1);
         this.k.put(var1, var2);
         this.i.add(var2);
      }

      return var2;
   }

   public class a {
      public final aeb a;
      private boolean d = true;
      private int e;
      private int f;
      private int g = 127;
      private int h = 127;
      private int i;
      public int b;

      public a(aeb var2) {
         this.a = var2;
      }

      @Nullable
      public ht<?> a(ain var1) {
         if (this.d) {
            this.d = false;
            return new ji(var1.j(), bet.this.g, bet.this.e, bet.this.j.values(), bet.this.h, this.e, this.f, this.g + 1 - this.e, this.h + 1 - this.f);
         } else {
            return this.i++ % 5 == 0 ? new ji(var1.j(), bet.this.g, bet.this.e, bet.this.j.values(), bet.this.h, 0, 0, 0, 0) : null;
         }
      }

      public void a(int var1, int var2) {
         if (this.d) {
            this.e = Math.min(this.e, var1);
            this.f = Math.min(this.f, var2);
            this.g = Math.max(this.g, var1);
            this.h = Math.max(this.h, var2);
         } else {
            this.d = true;
            this.e = var1;
            this.f = var2;
            this.g = var1;
            this.h = var2;
         }

      }
   }
}
