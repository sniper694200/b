import net.minecraft.server.MinecraftServer;

public class dq extends bi {
   public String c() {
      return "stop";
   }

   public String b(bn var1) {
      return "commands.stop.usage";
   }

   public void a(MinecraftServer var1, bn var2, String[] var3) throws ei {
      if (var1.d != null) {
         a(var2, this, "commands.stop.start", new Object[0]);
      }

      var1.x();
   }
}
