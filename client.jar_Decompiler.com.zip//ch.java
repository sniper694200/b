import com.google.common.collect.Lists;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public class ch extends bi {
   public String c() {
      return "fill";
   }

   public int a() {
      return 2;
   }

   public String b(bn var1) {
      return "commands.fill.usage";
   }

   public void a(MinecraftServer var1, bn var2, String[] var3) throws ei {
      if (var3.length < 7) {
         throw new ep("commands.fill.usage", new Object[0]);
      } else {
         var2.a(bp.a.b, 0);
         et var4 = a(var2, var3, 0, false);
         et var5 = a(var2, var3, 3, false);
         aou var6 = bi.b(var2, var3[6]);
         awr var7;
         if (var3.length >= 8) {
            var7 = a(var6, var3[7]);
         } else {
            var7 = var6.t();
         }

         et var8 = new et(Math.min(var4.p(), var5.p()), Math.min(var4.q(), var5.q()), Math.min(var4.r(), var5.r()));
         et var9 = new et(Math.max(var4.p(), var5.p()), Math.max(var4.q(), var5.q()), Math.max(var4.r(), var5.r()));
         int var10 = (var9.p() - var8.p() + 1) * (var9.q() - var8.q() + 1) * (var9.r() - var8.r() + 1);
         if (var10 > 32768) {
            throw new ei("commands.fill.tooManyBlocks", new Object[]{var10, 32768});
         } else if (var8.q() >= 0 && var9.q() < 256) {
            ams var11 = var2.e();

            for(int var12 = var8.r(); var12 <= var9.r(); var12 += 16) {
               for(int var13 = var8.p(); var13 <= var9.p(); var13 += 16) {
                  if (!var11.e(new et(var13, var9.q() - var8.q(), var12))) {
                     throw new ei("commands.fill.outOfWorld", new Object[0]);
                  }
               }
            }

            fy var22 = new fy();
            boolean var23 = false;
            if (var3.length >= 10 && var6.l()) {
               String var14 = a(var3, 9);

               try {
                  var22 = gp.a(var14);
                  var23 = true;
               } catch (go var21) {
                  throw new ei("commands.fill.tagError", new Object[]{var21.getMessage()});
               }
            }

            List<et> var24 = Lists.newArrayList();
            var10 = 0;

            for(int var15 = var8.r(); var15 <= var9.r(); ++var15) {
               for(int var16 = var8.q(); var16 <= var9.q(); ++var16) {
                  for(int var17 = var8.p(); var17 <= var9.p(); ++var17) {
                     et var18 = new et(var17, var16, var15);
                     if (var3.length >= 9) {
                        if (!"outline".equals(var3[8]) && !"hollow".equals(var3[8])) {
                           if ("destroy".equals(var3[8])) {
                              var11.b(var18, true);
                           } else if ("keep".equals(var3[8])) {
                              if (!var11.d(var18)) {
                                 continue;
                              }
                           } else if ("replace".equals(var3[8]) && !var6.l() && var3.length > 9) {
                              aou var19 = bi.b(var2, var3[9]);
                              if (var11.o(var18).u() != var19 || var3.length > 10 && !"-1".equals(var3[10]) && !"*".equals(var3[10]) && !bi.b(var19, var3[10]).apply(var11.o(var18))) {
                                 continue;
                              }
                           }
                        } else if (var17 != var8.p() && var17 != var9.p() && var16 != var8.q() && var16 != var9.q() && var15 != var8.r() && var15 != var9.r()) {
                           if ("hollow".equals(var3[8])) {
                              var11.a((et)var18, (awr)aov.a.t(), 2);
                              var24.add(var18);
                           }
                           continue;
                        }
                     }

                     avh var28 = var11.r(var18);
                     if (var28 != null && var28 instanceof tt) {
                        ((tt)var28).m();
                     }

                     if (var11.a((et)var18, (awr)var7, 2)) {
                        var24.add(var18);
                        ++var10;
                        if (var23) {
                           avh var20 = var11.r(var18);
                           if (var20 != null) {
                              var22.a("x", var18.p());
                              var22.a("y", var18.q());
                              var22.a("z", var18.r());
                              var20.a(var22);
                           }
                        }
                     }
                  }
               }
            }

            Iterator var25 = var24.iterator();

            while(var25.hasNext()) {
               et var26 = (et)var25.next();
               aou var27 = var11.o(var26).u();
               var11.a(var26, var27, false);
            }

            if (var10 <= 0) {
               throw new ei("commands.fill.failed", new Object[0]);
            } else {
               var2.a(bp.a.b, var10);
               a(var2, this, "commands.fill.success", new Object[]{var10});
            }
         } else {
            throw new ei("commands.fill.outOfWorld", new Object[0]);
         }
      }
   }

   public List<String> a(MinecraftServer var1, bn var2, String[] var3, @Nullable et var4) {
      if (var3.length > 0 && var3.length <= 3) {
         return a(var3, 0, var4);
      } else if (var3.length > 3 && var3.length <= 6) {
         return a(var3, 3, var4);
      } else if (var3.length == 7) {
         return a(var3, aou.h.c());
      } else if (var3.length == 9) {
         return a(var3, new String[]{"replace", "destroy", "keep", "hollow", "outline"});
      } else {
         return var3.length == 10 && "replace".equals(var3[8]) ? a(var3, aou.h.c()) : Collections.emptyList();
      }
   }
}
