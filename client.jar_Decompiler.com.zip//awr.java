import com.google.common.collect.ImmutableMap;
import java.util.Collection;

public interface awr extends awo, awq {
   Collection<axh<?>> s();

   <T extends Comparable<T>> T c(axh<T> var1);

   <T extends Comparable<T>, V extends T> awr a(axh<T> var1, V var2);

   <T extends Comparable<T>> awr a(axh<T> var1);

   ImmutableMap<axh<?>, Comparable<?>> t();

   aou u();
}
