import java.util.Random;

public class aqv extends aoo {
   public static final axe a;
   private final boolean b;
   private static boolean c;

   protected aqv(boolean var1) {
      super(bcx.e);
      this.w(this.A.b().a(a, fa.c));
      this.b = var1;
   }

   public ail a(awr var1, Random var2, int var3) {
      return ail.a(aov.al);
   }

   public void c(ams var1, et var2, awr var3) {
      this.e(var1, var2, var3);
   }

   private void e(ams var1, et var2, awr var3) {
      if (!var1.G) {
         awr var4 = var1.o(var2.c());
         awr var5 = var1.o(var2.d());
         awr var6 = var1.o(var2.e());
         awr var7 = var1.o(var2.f());
         fa var8 = (fa)var3.c(a);
         if (var8 == fa.c && var4.b() && !var5.b()) {
            var8 = fa.d;
         } else if (var8 == fa.d && var5.b() && !var4.b()) {
            var8 = fa.c;
         } else if (var8 == fa.e && var6.b() && !var7.b()) {
            var8 = fa.f;
         } else if (var8 == fa.f && var7.b() && !var6.b()) {
            var8 = fa.e;
         }

         var1.a((et)var2, (awr)var3.a(a, var8), 2);
      }
   }

   public void a(awr var1, ams var2, et var3, Random var4) {
      if (this.b) {
         fa var5 = (fa)var1.c(a);
         double var6 = (double)var3.p() + 0.5D;
         double var8 = (double)var3.q() + var4.nextDouble() * 6.0D / 16.0D;
         double var10 = (double)var3.r() + 0.5D;
         double var12 = 0.52D;
         double var14 = var4.nextDouble() * 0.6D - 0.3D;
         if (var4.nextDouble() < 0.1D) {
            var2.a((double)var3.p() + 0.5D, (double)var3.q(), (double)var3.r() + 0.5D, qd.bP, qe.e, 1.0F, 1.0F, false);
         }

         switch(var5) {
         case e:
            var2.a(fj.l, var6 - 0.52D, var8, var10 + var14, 0.0D, 0.0D, 0.0D);
            var2.a(fj.A, var6 - 0.52D, var8, var10 + var14, 0.0D, 0.0D, 0.0D);
            break;
         case f:
            var2.a(fj.l, var6 + 0.52D, var8, var10 + var14, 0.0D, 0.0D, 0.0D);
            var2.a(fj.A, var6 + 0.52D, var8, var10 + var14, 0.0D, 0.0D, 0.0D);
            break;
         case c:
            var2.a(fj.l, var6 + var14, var8, var10 - 0.52D, 0.0D, 0.0D, 0.0D);
            var2.a(fj.A, var6 + var14, var8, var10 - 0.52D, 0.0D, 0.0D, 0.0D);
            break;
         case d:
            var2.a(fj.l, var6 + var14, var8, var10 + 0.52D, 0.0D, 0.0D, 0.0D);
            var2.a(fj.A, var6 + var14, var8, var10 + 0.52D, 0.0D, 0.0D, 0.0D);
         }

      }
   }

   public boolean a(ams var1, et var2, awr var3, aeb var4, tz var5, fa var6, float var7, float var8, float var9) {
      if (var1.G) {
         return true;
      } else {
         avh var10 = var1.r(var2);
         if (var10 instanceof avs) {
            var4.a((tt)((avs)var10));
            var4.b(qq.Y);
         }

         return true;
      }
   }

   public static void a(boolean var0, ams var1, et var2) {
      awr var3 = var1.o(var2);
      avh var4 = var1.r(var2);
      c = true;
      if (var0) {
         var1.a((et)var2, (awr)aov.am.t().a(a, var3.c(a)), 3);
         var1.a((et)var2, (awr)aov.am.t().a(a, var3.c(a)), 3);
      } else {
         var1.a((et)var2, (awr)aov.al.t().a(a, var3.c(a)), 3);
         var1.a((et)var2, (awr)aov.al.t().a(a, var3.c(a)), 3);
      }

      c = false;
      if (var4 != null) {
         var4.A();
         var1.a(var2, var4);
      }

   }

   public avh a(ams var1, int var2) {
      return new avs();
   }

   public awr a(ams var1, et var2, fa var3, float var4, float var5, float var6, int var7, vn var8) {
      return this.t().a(a, var8.bt().d());
   }

   public void a(ams var1, et var2, awr var3, vn var4, ain var5) {
      var1.a((et)var2, (awr)var3.a(a, var4.bt().d()), 2);
      if (var5.t()) {
         avh var6 = var1.r(var2);
         if (var6 instanceof avs) {
            ((avs)var6).a(var5.r());
         }
      }

   }

   public void b(ams var1, et var2, awr var3) {
      if (!c) {
         avh var4 = var1.r(var2);
         if (var4 instanceof avs) {
            tw.a(var1, (et)var2, (avs)var4);
            var1.d(var2, this);
         }
      }

      super.b(var1, var2, var3);
   }

   public boolean v(awr var1) {
      return true;
   }

   public int c(awr var1, ams var2, et var3) {
      return afp.a(var2.r(var3));
   }

   public ain a(ams var1, et var2, awr var3) {
      return new ain(aov.al);
   }

   public ath a(awr var1) {
      return ath.d;
   }

   public awr a(int var1) {
      fa var2 = fa.a(var1);
      if (var2.k() == fa.a.b) {
         var2 = fa.c;
      }

      return this.t().a(a, var2);
   }

   public int e(awr var1) {
      return ((fa)var1.c(a)).a();
   }

   public awr a(awr var1, atk var2) {
      return var1.a(a, var2.a((fa)var1.c(a)));
   }

   public awr a(awr var1, arw var2) {
      return var1.a(var2.a((fa)var1.c(a)));
   }

   protected aws b() {
      return new aws(this, new axh[]{a});
   }

   static {
      a = ark.D;
   }
}
