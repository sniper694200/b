import java.util.Random;

public class chj implements nv {
   private final Random a = new Random();
   private final bhz b;
   private cgr c;
   private int d = 100;

   public chj(bhz var1) {
      this.b = var1;
   }

   public void e() {
      chj.a var1 = this.b.V();
      if (this.c != null) {
         if (!var1.a().a().equals(this.c.a())) {
            this.b.U().b(this.c);
            this.d = ri.a((Random)this.a, 0, var1.b() / 2);
         }

         if (!this.b.U().c(this.c)) {
            this.c = null;
            this.d = Math.min(ri.a(this.a, var1.b(), var1.c()), this.d);
         }
      }

      this.d = Math.min(this.d, var1.c());
      if (this.c == null && this.d-- <= 0) {
         this.a(var1);
      }

   }

   public void a(chj.a var1) {
      this.c = cgn.a(var1.a());
      this.b.U().a(this.c);
      this.d = Integer.MAX_VALUE;
   }

   public static enum a {
      a(qd.es, 20, 600),
      b(qd.er, 12000, 24000),
      c(qd.en, 1200, 3600),
      d(qd.eo, 0, 0),
      e(qd.et, 1200, 3600),
      f(qd.ep, 0, 0),
      g(qd.eq, 6000, 24000);

      private final qc h;
      private final int i;
      private final int j;

      private a(qc var3, int var4, int var5) {
         this.h = var3;
         this.i = var4;
         this.j = var5;
      }

      public qc a() {
         return this.h;
      }

      public int b() {
         return this.i;
      }

      public int c() {
         return this.j;
      }
   }
}
