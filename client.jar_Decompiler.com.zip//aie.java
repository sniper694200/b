import com.google.common.collect.Maps;
import java.util.Map;

public class aie extends aih {
   private final boolean b;

   public aie(boolean var1) {
      super(0, 0.0F, false);
      this.b = var1;
   }

   public int h(ain var1) {
      aie.a var2 = aie.a.a(var1);
      return this.b && var2.g() ? var2.e() : var2.c();
   }

   public float i(ain var1) {
      aie.a var2 = aie.a.a(var1);
      return this.b && var2.g() ? var2.f() : var2.d();
   }

   protected void a(ain var1, ams var2, aeb var3) {
      aie.a var4 = aie.a.a(var1);
      if (var4 == aie.a.d) {
         var3.c((uy)(new uy(uz.s, 1200, 3)));
         var3.c((uy)(new uy(uz.q, 300, 2)));
         var3.c((uy)(new uy(uz.i, 300, 1)));
      }

      super.a(var1, var2, var3);
   }

   public void a(ahn var1, fi<ain> var2) {
      if (this.a(var1)) {
         aie.a[] var3 = aie.a.values();
         int var4 = var3.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            aie.a var6 = var3[var5];
            if (!this.b || var6.g()) {
               var2.add(new ain(this, 1, var6.a()));
            }
         }
      }

   }

   public String a(ain var1) {
      aie.a var2 = aie.a.a(var1);
      return this.a() + "." + var2.b() + "." + (this.b && var2.g() ? "cooked" : "raw");
   }

   public static enum a {
      a(0, "cod", 2, 0.1F, 5, 0.6F),
      b(1, "salmon", 2, 0.1F, 6, 0.8F),
      c(2, "clownfish", 1, 0.1F),
      d(3, "pufferfish", 1, 0.1F);

      private static final Map<Integer, aie.a> e = Maps.newHashMap();
      private final int f;
      private final String g;
      private final int h;
      private final float i;
      private final int j;
      private final float k;
      private final boolean l;

      private a(int var3, String var4, int var5, float var6, int var7, float var8) {
         this.f = var3;
         this.g = var4;
         this.h = var5;
         this.i = var6;
         this.j = var7;
         this.k = var8;
         this.l = true;
      }

      private a(int var3, String var4, int var5, float var6) {
         this.f = var3;
         this.g = var4;
         this.h = var5;
         this.i = var6;
         this.j = 0;
         this.k = 0.0F;
         this.l = false;
      }

      public int a() {
         return this.f;
      }

      public String b() {
         return this.g;
      }

      public int c() {
         return this.h;
      }

      public float d() {
         return this.i;
      }

      public int e() {
         return this.j;
      }

      public float f() {
         return this.k;
      }

      public boolean g() {
         return this.l;
      }

      public static aie.a a(int var0) {
         aie.a var1 = (aie.a)e.get(var0);
         return var1 == null ? a : var1;
      }

      public static aie.a a(ain var0) {
         return var0.c() instanceof aie ? a(var0.j()) : a;
      }

      static {
         aie.a[] var0 = values();
         int var1 = var0.length;

         for(int var2 = 0; var2 < var1; ++var2) {
            aie.a var3 = var0[var2];
            e.put(var3.a(), var3);
         }

      }
   }
}
