public class ahf extends aih {
   public ahf(int var1) {
      super(var1, false);
      this.d(1);
   }

   public ain a(ain var1, ams var2, vn var3) {
      super.a(var1, var2, var3);
      return new ain(aip.C);
   }
}
