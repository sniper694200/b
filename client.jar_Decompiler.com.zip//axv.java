public class axv {
   private final int a;
   private int b;
   private int c;
   private final axn d;
   private axq e;
   private axq f;

   public axv(int var1, boolean var2) {
      this.a = var1;
      this.d = new axn();
      this.e = new axq();
      if (var2) {
         this.f = new axq();
      }

   }

   public awr a(int var1, int var2, int var3) {
      return this.d.a(var1, var2, var3);
   }

   public void a(int var1, int var2, int var3, awr var4) {
      awr var5 = this.a(var1, var2, var3);
      aou var6 = var5.u();
      aou var7 = var4.u();
      if (var6 != aov.a) {
         --this.b;
         if (var6.k()) {
            --this.c;
         }
      }

      if (var7 != aov.a) {
         ++this.b;
         if (var7.k()) {
            ++this.c;
         }
      }

      this.d.a(var1, var2, var3, var4);
   }

   public boolean a() {
      return this.b == 0;
   }

   public boolean b() {
      return this.c > 0;
   }

   public int d() {
      return this.a;
   }

   public void a(int var1, int var2, int var3, int var4) {
      this.f.a(var1, var2, var3, var4);
   }

   public int b(int var1, int var2, int var3) {
      return this.f.a(var1, var2, var3);
   }

   public void b(int var1, int var2, int var3, int var4) {
      this.e.a(var1, var2, var3, var4);
   }

   public int c(int var1, int var2, int var3) {
      return this.e.a(var1, var2, var3);
   }

   public void e() {
      this.b = 0;
      this.c = 0;

      for(int var1 = 0; var1 < 16; ++var1) {
         for(int var2 = 0; var2 < 16; ++var2) {
            for(int var3 = 0; var3 < 16; ++var3) {
               aou var4 = this.a(var1, var2, var3).u();
               if (var4 != aov.a) {
                  ++this.b;
                  if (var4.k()) {
                     ++this.c;
                  }
               }
            }
         }
      }

   }

   public axn g() {
      return this.d;
   }

   public axq h() {
      return this.e;
   }

   public axq i() {
      return this.f;
   }

   public void a(axq var1) {
      this.e = var1;
   }

   public void b(axq var1) {
      this.f = var1;
   }
}
