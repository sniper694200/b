public enum bly {
   a(0),
   b(1);

   private final int c;

   private bly(int var3) {
      this.c = var3;
   }

   public int a() {
      return this.c;
   }
}
