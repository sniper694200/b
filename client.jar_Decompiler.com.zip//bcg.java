import javax.annotation.Nullable;

public interface bcg {
   @Nullable
   bch.b a(ams var1, et var2, bch.b var3);
}
