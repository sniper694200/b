public class aii extends aih {
   public aii(int var1, float var2, boolean var3) {
      super(var1, var2, var3);
      this.a(true);
   }

   public boolean f_(ain var1) {
      return super.f_(var1) || var1.j() > 0;
   }

   public ajc g(ain var1) {
      return var1.j() == 0 ? ajc.c : ajc.d;
   }

   protected void a(ain var1, ams var2, aeb var3) {
      if (!var2.G) {
         if (var1.j() > 0) {
            var3.c((uy)(new uy(uz.j, 400, 1)));
            var3.c((uy)(new uy(uz.k, 6000, 0)));
            var3.c((uy)(new uy(uz.l, 6000, 0)));
            var3.c((uy)(new uy(uz.v, 2400, 3)));
         } else {
            var3.c((uy)(new uy(uz.j, 100, 1)));
            var3.c((uy)(new uy(uz.v, 2400, 0)));
         }
      }

   }

   public void a(ahn var1, fi<ain> var2) {
      if (this.a(var1)) {
         var2.add(new ain(this));
         var2.add(new ain(this, 1, 1));
      }

   }
}
