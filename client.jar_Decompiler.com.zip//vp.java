public enum vp {
   a(acu.class, 70, bcx.a, false, false),
   b(zt.class, 10, bcx.a, true, true),
   c(zq.class, 15, bcx.a, true, false),
   d(aaj.class, 5, bcx.h, true, false);

   private final Class<? extends vd> e;
   private final int f;
   private final bcx g;
   private final boolean h;
   private final boolean i;

   private vp(Class<? extends vd> var3, int var4, bcx var5, boolean var6, boolean var7) {
      this.e = var3;
      this.f = var4;
      this.g = var5;
      this.h = var6;
      this.i = var7;
   }

   public Class<? extends vd> a() {
      return this.e;
   }

   public int b() {
      return this.f;
   }

   public boolean d() {
      return this.h;
   }

   public boolean e() {
      return this.i;
   }
}
