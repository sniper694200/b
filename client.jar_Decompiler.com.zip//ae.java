import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ae implements p<ae.b> {
   private static final nd a = new nd("effects_changed");
   private final Map<nn, ae.a> b = Maps.newHashMap();

   public nd a() {
      return a;
   }

   public void a(nn var1, p.a<ae.b> var2) {
      ae.a var3 = (ae.a)this.b.get(var1);
      if (var3 == null) {
         var3 = new ae.a(var1);
         this.b.put(var1, var3);
      }

      var3.a(var2);
   }

   public void b(nn var1, p.a<ae.b> var2) {
      ae.a var3 = (ae.a)this.b.get(var1);
      if (var3 != null) {
         var3.b(var2);
         if (var3.a()) {
            this.b.remove(var1);
         }
      }

   }

   public void a(nn var1) {
      this.b.remove(var1);
   }

   public ae.b b(JsonObject var1, JsonDeserializationContext var2) {
      at var3 = at.a(var1.get("effects"));
      return new ae.b(var3);
   }

   public void a(oo var1) {
      ae.a var2 = (ae.a)this.b.get(var1.P());
      if (var2 != null) {
         var2.a(var1);
      }

   }

   // $FF: synthetic method
   public q a(JsonObject var1, JsonDeserializationContext var2) {
      return this.b(var1, var2);
   }

   static class a {
      private final nn a;
      private final Set<p.a<ae.b>> b = Sets.newHashSet();

      public a(nn var1) {
         this.a = var1;
      }

      public boolean a() {
         return this.b.isEmpty();
      }

      public void a(p.a<ae.b> var1) {
         this.b.add(var1);
      }

      public void b(p.a<ae.b> var1) {
         this.b.remove(var1);
      }

      public void a(oo var1) {
         List<p.a<ae.b>> var2 = null;
         Iterator var3 = this.b.iterator();

         p.a var4;
         while(var3.hasNext()) {
            var4 = (p.a)var3.next();
            if (((ae.b)var4.a()).a(var1)) {
               if (var2 == null) {
                  var2 = Lists.newArrayList();
               }

               var2.add(var4);
            }
         }

         if (var2 != null) {
            var3 = var2.iterator();

            while(var3.hasNext()) {
               var4 = (p.a)var3.next();
               var4.a(this.a);
            }
         }

      }
   }

   public static class b extends u {
      private final at a;

      public b(at var1) {
         super(ae.a);
         this.a = var1;
      }

      public boolean a(oo var1) {
         return this.a.a((vn)var1);
      }
   }
}
