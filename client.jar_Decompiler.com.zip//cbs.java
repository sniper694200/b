import com.mojang.authlib.GameProfile;
import java.util.UUID;
import org.apache.commons.lang3.StringUtils;

public class cbs implements cce<vn> {
   private final brq a;

   public cbs(brq var1) {
      this.a = var1;
   }

   public void a(vn var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8) {
      ain var9 = var1.b(vj.f);
      if (!var9.b()) {
         ail var10 = var9.c();
         bhz var11 = bhz.z();
         buq.G();
         if (var1.aU()) {
            buq.c(0.0F, 0.2F, 0.0F);
         }

         boolean var12 = var1 instanceof adw || var1 instanceof ads;
         float var13;
         if (var1.l_() && !(var1 instanceof adw)) {
            var13 = 2.0F;
            float var14 = 1.4F;
            buq.c(0.0F, 0.5F * var8, 0.0F);
            buq.b(0.7F, 0.7F, 0.7F);
            buq.c(0.0F, 16.0F * var8, 0.0F);
         }

         this.a.c(0.0625F);
         buq.c(1.0F, 1.0F, 1.0F, 1.0F);
         if (var10 == aip.ci) {
            var13 = 1.1875F;
            buq.b(1.1875F, -1.1875F, -1.1875F);
            if (var12) {
               buq.c(0.0F, 0.0625F, 0.0F);
            }

            GameProfile var17 = null;
            if (var9.o()) {
               fy var15 = var9.p();
               if (var15.b("SkullOwner", 10)) {
                  var17 = gj.a(var15.p("SkullOwner"));
               } else if (var15.b("SkullOwner", 8)) {
                  String var16 = var15.l("SkullOwner");
                  if (!StringUtils.isBlank(var16)) {
                     var17 = awb.b(new GameProfile((UUID)null, var16));
                     var15.a((String)"SkullOwner", (gn)gj.a(new fy(), var17));
                  }
               }
            }

            bxe.a.a(-0.5F, 0.0F, -0.5F, fa.b, 180.0F, var9.j(), var17, -1, var2);
         } else if (!(var10 instanceof agt) || ((agt)var10).E_() != vj.f) {
            var13 = 0.625F;
            buq.c(0.0F, -0.25F, 0.0F);
            buq.b(180.0F, 0.0F, 1.0F, 0.0F);
            buq.b(0.625F, -0.625F, -0.625F);
            if (var12) {
               buq.c(0.0F, 0.1875F, 0.0F);
            }

            var11.ae().a(var1, var9, bwa.b.f);
         }

         buq.H();
      }
   }

   public boolean a() {
      return false;
   }
}
