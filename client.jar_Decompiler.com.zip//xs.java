public class xs extends xc {
   ams a;
   vo b;
   vn c;
   int d;

   public xs(vo var1) {
      this.b = var1;
      this.a = var1.l;
      this.a(3);
   }

   public boolean a() {
      vn var1 = this.b.z();
      if (var1 == null) {
         return false;
      } else {
         this.c = var1;
         return true;
      }
   }

   public boolean b() {
      if (!this.c.aC()) {
         return false;
      } else if (this.b.h(this.c) > 225.0D) {
         return false;
      } else {
         return !this.b.x().o() || this.a();
      }
   }

   public void d() {
      this.c = null;
      this.b.x().p();
   }

   public void e() {
      this.b.t().a(this.c, 30.0F, 30.0F);
      double var1 = (double)(this.b.G * 2.0F * this.b.G * 2.0F);
      double var3 = this.b.d(this.c.p, this.c.bw().b, this.c.r);
      double var5 = 0.8D;
      if (var3 > var1 && var3 < 16.0D) {
         var5 = 1.33D;
      } else if (var3 < 225.0D) {
         var5 = 0.6D;
      }

      this.b.x().a((ve)this.c, var5);
      this.d = Math.max(this.d - 1, 0);
      if (!(var3 > var1)) {
         if (this.d <= 0) {
            this.d = 20;
            this.b.B(this.c);
         }
      }
   }
}
