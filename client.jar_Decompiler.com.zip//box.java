import com.mojang.authlib.properties.PropertyMap;
import java.io.File;
import java.net.Proxy;
import javax.annotation.Nullable;

public class box {
   public final box.e a;
   public final box.a b;
   public final box.b c;
   public final box.c d;
   public final box.d e;

   public box(box.e var1, box.a var2, box.b var3, box.c var4, box.d var5) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = var5;
   }

   public static class d {
      public final String a;
      public final int b;

      public d(String var1, int var2) {
         this.a = var1;
         this.b = var2;
      }
   }

   public static class b {
      public final File a;
      public final File b;
      public final File c;
      public final String d;

      public b(File var1, File var2, File var3, @Nullable String var4) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var4;
      }

      public cec a() {
         return (cec)(this.d == null ? new cef(this.c) : new cec(this.c, this.d));
      }
   }

   public static class a {
      public final int a;
      public final int b;
      public final boolean c;
      public final boolean d;

      public a(int var1, int var2, boolean var3, boolean var4) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var4;
      }
   }

   public static class e {
      public final big a;
      public final PropertyMap b;
      public final PropertyMap c;
      public final Proxy d;

      public e(big var1, PropertyMap var2, PropertyMap var3, Proxy var4) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var4;
      }
   }

   public static class c {
      public final boolean a;
      public final String b;
      public final String c;

      public c(boolean var1, String var2, String var3) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }
   }
}
