import java.util.Random;
import javax.annotation.Nullable;

public class atu extends aou {
   public static final axg a = axg.a("layers", 1, 8);
   protected static final bgz[] b = new bgz[]{new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.0D, 1.0D), new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.125D, 1.0D), new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.25D, 1.0D), new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.375D, 1.0D), new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.5D, 1.0D), new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.625D, 1.0D), new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.75D, 1.0D), new bgz(0.0D, 0.0D, 0.0D, 1.0D, 0.875D, 1.0D), new bgz(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D)};

   protected atu() {
      super(bcx.y);
      this.w(this.A.b().a(a, 1));
      this.a(true);
      this.a(ahn.c);
   }

   public bgz b(awr var1, amw var2, et var3) {
      return b[(Integer)var1.c(a)];
   }

   public boolean b(amw var1, et var2) {
      return (Integer)var1.o(var2).c(a) < 5;
   }

   public boolean k(awr var1) {
      return (Integer)var1.c(a) == 8;
   }

   public awp a(amw var1, awr var2, et var3, fa var4) {
      return var4 == fa.a ? awp.a : awp.i;
   }

   @Nullable
   public bgz a(awr var1, amw var2, et var3) {
      int var4 = (Integer)var1.c(a) - 1;
      float var5 = 0.125F;
      bgz var6 = var1.e(var2, var3);
      return new bgz(var6.a, var6.b, var6.c, var6.d, (double)((float)var4 * 0.125F), var6.f);
   }

   public boolean b(awr var1) {
      return false;
   }

   public boolean c(awr var1) {
      return false;
   }

   public boolean a(ams var1, et var2) {
      awr var3 = var1.o(var2.b());
      aou var4 = var3.u();
      if (var4 != aov.aI && var4 != aov.cB && var4 != aov.cv) {
         awp var5 = var3.d(var1, var2.b(), fa.b);
         return var5 == awp.a || var3.a() == bcx.j || var4 == this && (Integer)var3.c(a) == 8;
      } else {
         return false;
      }
   }

   public void a(awr var1, ams var2, et var3, aou var4, et var5) {
      this.e(var2, var3, var1);
   }

   private boolean e(ams var1, et var2, awr var3) {
      if (!this.a(var1, var2)) {
         this.b(var1, var2, var3, 0);
         var1.g(var2);
         return false;
      } else {
         return true;
      }
   }

   public void a(ams var1, aeb var2, et var3, awr var4, @Nullable avh var5, ain var6) {
      a(var1, var3, new ain(aip.aG, (Integer)var4.c(a) + 1, 0));
      var1.g(var3);
      var2.b(qq.a((aou)this));
   }

   public ail a(awr var1, Random var2, int var3) {
      return aip.aG;
   }

   public int a(Random var1) {
      return 0;
   }

   public void b(ams var1, et var2, awr var3, Random var4) {
      if (var1.b(amy.b, var2) > 11) {
         this.b(var1, var2, var1.o(var2), 0);
         var1.g(var2);
      }

   }

   public boolean a(awr var1, amw var2, et var3, fa var4) {
      if (var4 == fa.b) {
         return true;
      } else {
         awr var5 = var2.o(var3.a(var4));
         return var5.u() == this && (Integer)var5.c(a) >= (Integer)var1.c(a) ? false : super.a(var1, var2, var3, var4);
      }
   }

   public awr a(int var1) {
      return this.t().a(a, (var1 & 7) + 1);
   }

   public boolean a(amw var1, et var2) {
      return (Integer)var1.o(var2).c(a) == 1;
   }

   public int e(awr var1) {
      return (Integer)var1.c(a) - 1;
   }

   protected aws b() {
      return new aws(this, new axh[]{a});
   }
}
