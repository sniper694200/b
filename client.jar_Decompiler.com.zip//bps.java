public class bps extends bqd {
   private final brq a;
   private final brq b;
   private final brq[] c;
   private final brq[] d;

   public bps() {
      this.s = 64;
      this.t = 64;
      this.c = new brq[12];
      this.a = new brq(this);
      this.a.a(0, 0).a(-6.0F, 10.0F, -8.0F, 12, 12, 16);
      this.a.a(0, 28).a(-8.0F, 10.0F, -6.0F, 2, 12, 12);
      this.a.a(0, 28).a(6.0F, 10.0F, -6.0F, 2, 12, 12, true);
      this.a.a(16, 40).a(-6.0F, 8.0F, -6.0F, 12, 2, 12);
      this.a.a(16, 40).a(-6.0F, 22.0F, -6.0F, 12, 2, 12);

      for(int var1 = 0; var1 < this.c.length; ++var1) {
         this.c[var1] = new brq(this, 0, 0);
         this.c[var1].a(-1.0F, -4.5F, -1.0F, 2, 9, 2);
         this.a.a(this.c[var1]);
      }

      this.b = new brq(this, 8, 0);
      this.b.a(-1.0F, 15.0F, 0.0F, 2, 2, 1);
      this.a.a(this.b);
      this.d = new brq[3];
      this.d[0] = new brq(this, 40, 0);
      this.d[0].a(-2.0F, 14.0F, 7.0F, 4, 4, 8);
      this.d[1] = new brq(this, 0, 54);
      this.d[1].a(0.0F, 14.0F, 0.0F, 3, 3, 7);
      this.d[2] = new brq(this);
      this.d[2].a(41, 32).a(0.0F, 14.0F, 0.0F, 2, 2, 6);
      this.d[2].a(25, 19).a(1.0F, 10.5F, 3.0F, 1, 9, 9);
      this.a.a(this.d[0]);
      this.d[0].a(this.d[1]);
      this.d[1].a(this.d[2]);
   }

   public void a(ve var1, float var2, float var3, float var4, float var5, float var6, float var7) {
      this.a(var2, var3, var4, var5, var6, var7, var1);
      this.a.a(var7);
   }

   public void a(float var1, float var2, float var3, float var4, float var5, float var6, ve var7) {
      acy var8 = (acy)var7;
      float var9 = var3 - (float)var8.T;
      this.a.g = var4 * 0.017453292F;
      this.a.f = var5 * 0.017453292F;
      float[] var10 = new float[]{1.75F, 0.25F, 0.0F, 0.0F, 0.5F, 0.5F, 0.5F, 0.5F, 1.25F, 0.75F, 0.0F, 0.0F};
      float[] var11 = new float[]{0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 1.75F, 1.25F, 0.75F, 0.0F, 0.0F, 0.0F, 0.0F};
      float[] var12 = new float[]{0.0F, 0.0F, 0.25F, 1.75F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.75F, 1.25F};
      float[] var13 = new float[]{0.0F, 0.0F, 8.0F, -8.0F, -8.0F, 8.0F, 8.0F, -8.0F, 0.0F, 0.0F, 8.0F, -8.0F};
      float[] var14 = new float[]{-8.0F, -8.0F, -8.0F, -8.0F, 0.0F, 0.0F, 0.0F, 0.0F, 8.0F, 8.0F, 8.0F, 8.0F};
      float[] var15 = new float[]{8.0F, -8.0F, 0.0F, 0.0F, -8.0F, -8.0F, 8.0F, 8.0F, 8.0F, -8.0F, 0.0F, 0.0F};
      float var16 = (1.0F - var8.r(var9)) * 0.55F;

      for(int var17 = 0; var17 < 12; ++var17) {
         this.c[var17].f = 3.1415927F * var10[var17];
         this.c[var17].g = 3.1415927F * var11[var17];
         this.c[var17].h = 3.1415927F * var12[var17];
         this.c[var17].c = var13[var17] * (1.0F + ri.b(var3 * 1.5F + (float)var17) * 0.01F - var16);
         this.c[var17].d = 16.0F + var14[var17] * (1.0F + ri.b(var3 * 1.5F + (float)var17) * 0.01F - var16);
         this.c[var17].e = var15[var17] * (1.0F + ri.b(var3 * 1.5F + (float)var17) * 0.01F - var16);
      }

      this.b.e = -8.25F;
      ve var26 = bhz.z().aa();
      if (var8.dp()) {
         var26 = var8.dq();
      }

      if (var26 != null) {
         bhc var18 = ((ve)var26).f(0.0F);
         bhc var19 = var7.f(0.0F);
         double var20 = var18.c - var19.c;
         if (var20 > 0.0D) {
            this.b.d = 0.0F;
         } else {
            this.b.d = 1.0F;
         }

         bhc var22 = var7.e(0.0F);
         var22 = new bhc(var22.b, 0.0D, var22.d);
         bhc var23 = (new bhc(var19.b - var18.b, 0.0D, var19.d - var18.d)).a().b(1.5707964F);
         double var24 = var22.b(var23);
         this.b.c = ri.c((float)Math.abs(var24)) * 2.0F * (float)Math.signum(var24);
      }

      this.b.j = true;
      float var27 = var8.a(var9);
      this.d[0].g = ri.a(var27) * 3.1415927F * 0.05F;
      this.d[1].g = ri.a(var27) * 3.1415927F * 0.1F;
      this.d[1].c = -1.5F;
      this.d[1].d = 0.5F;
      this.d[1].e = 14.0F;
      this.d[2].g = ri.a(var27) * 3.1415927F * 0.15F;
      this.d[2].c = 0.5F;
      this.d[2].d = 0.5F;
      this.d[2].e = 6.0F;
   }
}
