import java.util.Iterator;
import javax.annotation.Nullable;

public class apg extends aoo {
   public static final axe a;
   protected static final bgz b;
   protected static final bgz c;
   protected static final bgz d;
   protected static final bgz e;
   protected static final bgz f;
   public final apg.a g;

   protected apg(apg.a var1) {
      super(bcx.d);
      this.w(this.A.b().a(a, fa.c));
      this.g = var1;
      this.a(var1 == apg.a.b ? ahn.d : ahn.c);
   }

   public boolean b(awr var1) {
      return false;
   }

   public boolean c(awr var1) {
      return false;
   }

   public boolean a_(awr var1) {
      return true;
   }

   public ath a(awr var1) {
      return ath.c;
   }

   public bgz b(awr var1, amw var2, et var3) {
      if (var2.o(var3.c()).u() == this) {
         return b;
      } else if (var2.o(var3.d()).u() == this) {
         return c;
      } else if (var2.o(var3.e()).u() == this) {
         return d;
      } else {
         return var2.o(var3.f()).u() == this ? e : f;
      }
   }

   public void c(ams var1, et var2, awr var3) {
      this.e(var1, var2, var3);
      Iterator var4 = fa.c.a.iterator();

      while(var4.hasNext()) {
         fa var5 = (fa)var4.next();
         et var6 = var2.a(var5);
         awr var7 = var1.o(var6);
         if (var7.u() == this) {
            this.e(var1, var6, var7);
         }
      }

   }

   public awr a(ams var1, et var2, fa var3, float var4, float var5, float var6, int var7, vn var8) {
      return this.t().a(a, var8.bt());
   }

   public void a(ams var1, et var2, awr var3, vn var4, ain var5) {
      fa var6 = fa.b(ri.c((double)(var4.v * 4.0F / 360.0F) + 0.5D) & 3).d();
      var3 = var3.a(a, var6);
      et var7 = var2.c();
      et var8 = var2.d();
      et var9 = var2.e();
      et var10 = var2.f();
      boolean var11 = this == var1.o(var7).u();
      boolean var12 = this == var1.o(var8).u();
      boolean var13 = this == var1.o(var9).u();
      boolean var14 = this == var1.o(var10).u();
      if (!var11 && !var12 && !var13 && !var14) {
         var1.a((et)var2, (awr)var3, 3);
      } else if (var6.k() == fa.a.a && (var11 || var12)) {
         if (var11) {
            var1.a((et)var7, (awr)var3, 3);
         } else {
            var1.a((et)var8, (awr)var3, 3);
         }

         var1.a((et)var2, (awr)var3, 3);
      } else if (var6.k() == fa.a.c && (var13 || var14)) {
         if (var13) {
            var1.a((et)var9, (awr)var3, 3);
         } else {
            var1.a((et)var10, (awr)var3, 3);
         }

         var1.a((et)var2, (awr)var3, 3);
      }

      if (var5.t()) {
         avh var15 = var1.r(var2);
         if (var15 instanceof avj) {
            ((avj)var15).a((String)var5.r());
         }
      }

   }

   public awr e(ams var1, et var2, awr var3) {
      if (var1.G) {
         return var3;
      } else {
         awr var4 = var1.o(var2.c());
         awr var5 = var1.o(var2.d());
         awr var6 = var1.o(var2.e());
         awr var7 = var1.o(var2.f());
         fa var8 = (fa)var3.c(a);
         if (var4.u() != this && var5.u() != this) {
            boolean var15 = var4.b();
            boolean var16 = var5.b();
            if (var6.u() == this || var7.u() == this) {
               et var17 = var6.u() == this ? var2.e() : var2.f();
               awr var18 = var1.o(var17.c());
               awr var13 = var1.o(var17.d());
               var8 = fa.d;
               fa var14;
               if (var6.u() == this) {
                  var14 = (fa)var6.c(a);
               } else {
                  var14 = (fa)var7.c(a);
               }

               if (var14 == fa.c) {
                  var8 = fa.c;
               }

               if ((var15 || var18.b()) && !var16 && !var13.b()) {
                  var8 = fa.d;
               }

               if ((var16 || var13.b()) && !var15 && !var18.b()) {
                  var8 = fa.c;
               }
            }
         } else {
            et var9 = var4.u() == this ? var2.c() : var2.d();
            awr var10 = var1.o(var9.e());
            awr var11 = var1.o(var9.f());
            var8 = fa.f;
            fa var12;
            if (var4.u() == this) {
               var12 = (fa)var4.c(a);
            } else {
               var12 = (fa)var5.c(a);
            }

            if (var12 == fa.e) {
               var8 = fa.e;
            }

            if ((var6.b() || var10.b()) && !var7.b() && !var11.b()) {
               var8 = fa.f;
            }

            if ((var7.b() || var11.b()) && !var6.b() && !var10.b()) {
               var8 = fa.e;
            }
         }

         var3 = var3.a(a, var8);
         var1.a((et)var2, (awr)var3, 3);
         return var3;
      }
   }

   public awr f(ams var1, et var2, awr var3) {
      fa var4 = null;
      Iterator var5 = fa.c.a.iterator();

      while(var5.hasNext()) {
         fa var6 = (fa)var5.next();
         awr var7 = var1.o(var2.a(var6));
         if (var7.u() == this) {
            return var3;
         }

         if (var7.b()) {
            if (var4 != null) {
               var4 = null;
               break;
            }

            var4 = var6;
         }
      }

      if (var4 != null) {
         return var3.a(a, var4.d());
      } else {
         fa var8 = (fa)var3.c(a);
         if (var1.o(var2.a(var8)).b()) {
            var8 = var8.d();
         }

         if (var1.o(var2.a(var8)).b()) {
            var8 = var8.e();
         }

         if (var1.o(var2.a(var8)).b()) {
            var8 = var8.d();
         }

         return var3.a(a, var8);
      }
   }

   public boolean a(ams var1, et var2) {
      int var3 = 0;
      et var4 = var2.e();
      et var5 = var2.f();
      et var6 = var2.c();
      et var7 = var2.d();
      if (var1.o(var4).u() == this) {
         if (this.d(var1, var4)) {
            return false;
         }

         ++var3;
      }

      if (var1.o(var5).u() == this) {
         if (this.d(var1, var5)) {
            return false;
         }

         ++var3;
      }

      if (var1.o(var6).u() == this) {
         if (this.d(var1, var6)) {
            return false;
         }

         ++var3;
      }

      if (var1.o(var7).u() == this) {
         if (this.d(var1, var7)) {
            return false;
         }

         ++var3;
      }

      return var3 <= 1;
   }

   private boolean d(ams var1, et var2) {
      if (var1.o(var2).u() != this) {
         return false;
      } else {
         Iterator var3 = fa.c.a.iterator();

         fa var4;
         do {
            if (!var3.hasNext()) {
               return false;
            }

            var4 = (fa)var3.next();
         } while(var1.o(var2.a(var4)).u() != this);

         return true;
      }
   }

   public void a(awr var1, ams var2, et var3, aou var4, et var5) {
      super.a(var1, var2, var3, var4, var5);
      avh var6 = var2.r(var3);
      if (var6 instanceof avj) {
         var6.B();
      }

   }

   public void b(ams var1, et var2, awr var3) {
      avh var4 = var1.r(var2);
      if (var4 instanceof tt) {
         tw.a(var1, var2, (tt)var4);
         var1.d(var2, this);
      }

      super.b(var1, var2, var3);
   }

   public boolean a(ams var1, et var2, awr var3, aeb var4, tz var5, fa var6, float var7, float var8, float var9) {
      if (var1.G) {
         return true;
      } else {
         uf var10 = this.c(var1, var2);
         if (var10 != null) {
            var4.a((tt)var10);
            if (this.g == apg.a.a) {
               var4.b(qq.aa);
            } else if (this.g == apg.a.b) {
               var4.b(qq.U);
            }
         }

         return true;
      }
   }

   @Nullable
   public uf c(ams var1, et var2) {
      return this.a(var1, var2, false);
   }

   @Nullable
   public uf a(ams var1, et var2, boolean var3) {
      avh var4 = var1.r(var2);
      if (!(var4 instanceof avj)) {
         return null;
      } else {
         uf var5 = (avj)var4;
         if (!var3 && this.e(var1, var2)) {
            return null;
         } else {
            Iterator var6 = fa.c.a.iterator();

            while(true) {
               while(true) {
                  fa var7;
                  avh var10;
                  do {
                     et var8;
                     aou var9;
                     do {
                        if (!var6.hasNext()) {
                           return (uf)var5;
                        }

                        var7 = (fa)var6.next();
                        var8 = var2.a(var7);
                        var9 = var1.o(var8).u();
                     } while(var9 != this);

                     if (this.e(var1, var8)) {
                        return null;
                     }

                     var10 = var1.r(var8);
                  } while(!(var10 instanceof avj));

                  if (var7 != fa.e && var7 != fa.c) {
                     var5 = new ts("container.chestDouble", (uf)var5, (avj)var10);
                  } else {
                     var5 = new ts("container.chestDouble", (avj)var10, (uf)var5);
                  }
               }
            }
         }
      }
   }

   public avh a(ams var1, int var2) {
      return new avj();
   }

   public boolean g(awr var1) {
      return this.g == apg.a.b;
   }

   public int b(awr var1, amw var2, et var3, fa var4) {
      if (!var1.m()) {
         return 0;
      } else {
         int var5 = 0;
         avh var6 = var2.r(var3);
         if (var6 instanceof avj) {
            var5 = ((avj)var6).l;
         }

         return ri.a(var5, 0, 15);
      }
   }

   public int c(awr var1, amw var2, et var3, fa var4) {
      return var4 == fa.b ? var1.a(var2, var3, var4) : 0;
   }

   private boolean e(ams var1, et var2) {
      return this.i(var1, var2) || this.j(var1, var2);
   }

   private boolean i(ams var1, et var2) {
      return var1.o(var2.a()).l();
   }

   private boolean j(ams var1, et var2) {
      Iterator var3 = var1.a(zz.class, new bgz((double)var2.p(), (double)(var2.q() + 1), (double)var2.r(), (double)(var2.p() + 1), (double)(var2.q() + 2), (double)(var2.r() + 1))).iterator();

      zz var5;
      do {
         if (!var3.hasNext()) {
            return false;
         }

         ve var4 = (ve)var3.next();
         var5 = (zz)var4;
      } while(!var5.dn());

      return true;
   }

   public boolean v(awr var1) {
      return true;
   }

   public int c(awr var1, ams var2, et var3) {
      return afp.b((tt)this.c(var2, var3));
   }

   public awr a(int var1) {
      fa var2 = fa.a(var1);
      if (var2.k() == fa.a.b) {
         var2 = fa.c;
      }

      return this.t().a(a, var2);
   }

   public int e(awr var1) {
      return ((fa)var1.c(a)).a();
   }

   public awr a(awr var1, atk var2) {
      return var1.a(a, var2.a((fa)var1.c(a)));
   }

   public awr a(awr var1, arw var2) {
      return var1.a(var2.a((fa)var1.c(a)));
   }

   protected aws b() {
      return new aws(this, new axh[]{a});
   }

   public awp a(amw var1, awr var2, et var3, fa var4) {
      return awp.i;
   }

   static {
      a = ark.D;
      b = new bgz(0.0625D, 0.0D, 0.0D, 0.9375D, 0.875D, 0.9375D);
      c = new bgz(0.0625D, 0.0D, 0.0625D, 0.9375D, 0.875D, 1.0D);
      d = new bgz(0.0D, 0.0D, 0.0625D, 0.9375D, 0.875D, 0.9375D);
      e = new bgz(0.0625D, 0.0D, 0.0625D, 1.0D, 0.875D, 0.9375D);
      f = new bgz(0.0625D, 0.0D, 0.0625D, 0.9375D, 0.875D, 0.9375D);
   }

   public static enum a {
      a,
      b;
   }
}
