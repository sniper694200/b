import javax.annotation.Nullable;

public class uz {
   public static final ux a;
   public static final ux b;
   public static final ux c;
   public static final ux d;
   public static final ux e;
   public static final ux f;
   public static final ux g;
   public static final ux h;
   public static final ux i;
   public static final ux j;
   public static final ux k;
   public static final ux l;
   public static final ux m;
   public static final ux n;
   public static final ux o;
   public static final ux p;
   public static final ux q;
   public static final ux r;
   public static final ux s;
   public static final ux t;
   public static final ux u;
   public static final ux v;
   public static final ux w;
   public static final ux x;
   public static final ux y;
   public static final ux z;
   public static final ux A;

   @Nullable
   private static ux a(String var0) {
      ux var1 = (ux)ux.b.c(new nd(var0));
      if (var1 == null) {
         throw new IllegalStateException("Invalid MobEffect requested: " + var0);
      } else {
         return var1;
      }
   }

   static {
      if (!ng.a()) {
         throw new RuntimeException("Accessed MobEffects before Bootstrap!");
      } else {
         a = a("speed");
         b = a("slowness");
         c = a("haste");
         d = a("mining_fatigue");
         e = a("strength");
         f = a("instant_health");
         g = a("instant_damage");
         h = a("jump_boost");
         i = a("nausea");
         j = a("regeneration");
         k = a("resistance");
         l = a("fire_resistance");
         m = a("water_breathing");
         n = a("invisibility");
         o = a("blindness");
         p = a("night_vision");
         q = a("hunger");
         r = a("weakness");
         s = a("poison");
         t = a("wither");
         u = a("health_boost");
         v = a("absorption");
         w = a("saturation");
         x = a("glowing");
         y = a("levitation");
         z = a("luck");
         A = a("unluck");
      }
   }
}
