public class cfj implements cfc {
   private final float[] a;
   private final float[] b;
   private final float[] c;

   public cfj(float[] var1, float[] var2, float[] var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }
}
