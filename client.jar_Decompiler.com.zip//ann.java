import java.util.Random;

public class ann extends anf {
   private final azs x;
   private final bas y;
   private final ann.a z;

   protected ann(ann.a var1, anf.a var2) {
      super(var2);
      this.x = new baj(aov.be.t().a(ary.a, ary.a.a), 9);
      this.y = new bas(false);
      if (var1 == ann.a.b) {
         this.s.z = 3;
      }

      this.u.add(new anf.c(aaq.class, 5, 4, 6));
      this.z = var1;
   }

   public aze a(Random var1) {
      return (aze)(var1.nextInt(3) > 0 ? this.y : super.a(var1));
   }

   public void a(ams var1, Random var2, et var3) {
      super.a(var1, var2, var3);
      int var4 = 3 + var2.nextInt(6);

      int var5;
      int var6;
      int var7;
      for(var5 = 0; var5 < var4; ++var5) {
         var6 = var2.nextInt(16);
         var7 = var2.nextInt(28) + 4;
         int var8 = var2.nextInt(16);
         et var9 = var3.a(var6, var7, var8);
         if (var1.o(var9).u() == aov.b) {
            var1.a((et)var9, (awr)aov.bP.t(), 2);
         }
      }

      for(var4 = 0; var4 < 7; ++var4) {
         var5 = var2.nextInt(16);
         var6 = var2.nextInt(64);
         var7 = var2.nextInt(16);
         this.x.b(var1, var2, var3.a(var5, var6, var7));
      }

   }

   public void a(ams var1, Random var2, ayu var3, int var4, int var5, double var6) {
      this.q = aov.c.t();
      this.r = aov.d.t();
      if ((var6 < -1.0D || var6 > 2.0D) && this.z == ann.a.c) {
         this.q = aov.n.t();
         this.r = aov.n.t();
      } else if (var6 > 1.0D && this.z != ann.a.b) {
         this.q = aov.b.t();
         this.r = aov.b.t();
      }

      this.b(var1, var2, var3, var4, var5, var6);
   }

   public static enum a {
      a,
      b,
      c;
   }
}
