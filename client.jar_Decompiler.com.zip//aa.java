import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class aa implements p<aa.b> {
   private static final nd a = new nd("cured_zombie_villager");
   private final Map<nn, aa.a> b = Maps.newHashMap();

   public nd a() {
      return a;
   }

   public void a(nn var1, p.a<aa.b> var2) {
      aa.a var3 = (aa.a)this.b.get(var1);
      if (var3 == null) {
         var3 = new aa.a(var1);
         this.b.put(var1, var3);
      }

      var3.a(var2);
   }

   public void b(nn var1, p.a<aa.b> var2) {
      aa.a var3 = (aa.a)this.b.get(var1);
      if (var3 != null) {
         var3.b(var2);
         if (var3.a()) {
            this.b.remove(var1);
         }
      }

   }

   public void a(nn var1) {
      this.b.remove(var1);
   }

   public aa.b b(JsonObject var1, JsonDeserializationContext var2) {
      aj var3 = aj.a(var1.get("zombie"));
      aj var4 = aj.a(var1.get("villager"));
      return new aa.b(var3, var4);
   }

   public void a(oo var1, adr var2, adw var3) {
      aa.a var4 = (aa.a)this.b.get(var1.P());
      if (var4 != null) {
         var4.a(var1, var2, var3);
      }

   }

   // $FF: synthetic method
   public q a(JsonObject var1, JsonDeserializationContext var2) {
      return this.b(var1, var2);
   }

   static class a {
      private final nn a;
      private final Set<p.a<aa.b>> b = Sets.newHashSet();

      public a(nn var1) {
         this.a = var1;
      }

      public boolean a() {
         return this.b.isEmpty();
      }

      public void a(p.a<aa.b> var1) {
         this.b.add(var1);
      }

      public void b(p.a<aa.b> var1) {
         this.b.remove(var1);
      }

      public void a(oo var1, adr var2, adw var3) {
         List<p.a<aa.b>> var4 = null;
         Iterator var5 = this.b.iterator();

         p.a var6;
         while(var5.hasNext()) {
            var6 = (p.a)var5.next();
            if (((aa.b)var6.a()).a(var1, var2, var3)) {
               if (var4 == null) {
                  var4 = Lists.newArrayList();
               }

               var4.add(var6);
            }
         }

         if (var4 != null) {
            var5 = var4.iterator();

            while(var5.hasNext()) {
               var6 = (p.a)var5.next();
               var6.a(this.a);
            }
         }

      }
   }

   public static class b extends u {
      private final aj a;
      private final aj b;

      public b(aj var1, aj var2) {
         super(aa.a);
         this.a = var1;
         this.b = var2;
      }

      public boolean a(oo var1, adr var2, adw var3) {
         if (!this.a.a(var1, var2)) {
            return false;
         } else {
            return this.b.a(var1, var3);
         }
      }
   }
}
