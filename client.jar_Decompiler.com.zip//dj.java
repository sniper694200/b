import net.minecraft.server.MinecraftServer;

public class dj extends bi {
   public String c() {
      return "setidletimeout";
   }

   public int a() {
      return 3;
   }

   public String b(bn var1) {
      return "commands.setidletimeout.usage";
   }

   public void a(MinecraftServer var1, bn var2, String[] var3) throws ei {
      if (var3.length != 1) {
         throw new ep("commands.setidletimeout.usage", new Object[0]);
      } else {
         int var4 = a(var3[0], 0);
         var1.d(var4);
         a(var2, this, "commands.setidletimeout.success", new Object[]{var4});
      }
   }
}
