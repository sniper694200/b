import java.util.Iterator;
import java.util.Random;

public class azh extends azs {
   private final aou a;
   private final int b;

   public azh(aou var1, int var2) {
      super(false);
      this.a = var1;
      this.b = var2;
   }

   public boolean b(ams var1, Random var2, et var3) {
      while(true) {
         label50: {
            if (var3.q() > 3) {
               if (var1.d(var3.b())) {
                  break label50;
               }

               aou var4 = var1.o(var3.b()).u();
               if (var4 != aov.c && var4 != aov.d && var4 != aov.b) {
                  break label50;
               }
            }

            if (var3.q() <= 3) {
               return false;
            }

            int var12 = this.b;

            for(int var5 = 0; var12 >= 0 && var5 < 3; ++var5) {
               int var6 = var12 + var2.nextInt(2);
               int var7 = var12 + var2.nextInt(2);
               int var8 = var12 + var2.nextInt(2);
               float var9 = (float)(var6 + var7 + var8) * 0.333F + 0.5F;
               Iterator var10 = et.a(var3.a(-var6, -var7, -var8), var3.a(var6, var7, var8)).iterator();

               while(var10.hasNext()) {
                  et var11 = (et)var10.next();
                  if (var11.n(var3) <= (double)(var9 * var9)) {
                     var1.a((et)var11, (awr)this.a.t(), 4);
                  }
               }

               var3 = var3.a(-(var12 + 1) + var2.nextInt(2 + var12 * 2), 0 - var2.nextInt(2), -(var12 + 1) + var2.nextInt(2 + var12 * 2));
            }

            return true;
         }

         var3 = var3.b();
      }
   }
}
