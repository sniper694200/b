public enum amq {
   a(-1, "", ""),
   b(0, "survival", "s"),
   c(1, "creative", "c"),
   d(2, "adventure", "a"),
   e(3, "spectator", "sp");

   int f;
   String g;
   String h;

   private amq(int var3, String var4, String var5) {
      this.f = var3;
      this.g = var4;
      this.h = var5;
   }

   public int a() {
      return this.f;
   }

   public String b() {
      return this.g;
   }

   public void a(adz var1) {
      if (this == c) {
         var1.c = true;
         var1.d = true;
         var1.a = true;
      } else if (this == e) {
         var1.c = true;
         var1.d = false;
         var1.a = true;
         var1.b = true;
      } else {
         var1.c = false;
         var1.d = false;
         var1.a = false;
         var1.b = false;
      }

      var1.e = !this.c();
   }

   public boolean c() {
      return this == d || this == e;
   }

   public boolean d() {
      return this == c;
   }

   public boolean e() {
      return this == b || this == d;
   }

   public static amq a(int var0) {
      return a(var0, b);
   }

   public static amq a(int var0, amq var1) {
      amq[] var2 = values();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         amq var5 = var2[var4];
         if (var5.f == var0) {
            return var5;
         }
      }

      return var1;
   }

   public static amq a(String var0) {
      return a(var0, b);
   }

   public static amq a(String var0, amq var1) {
      amq[] var2 = values();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         amq var5 = var2[var4];
         if (var5.g.equals(var0) || var5.h.equals(var0)) {
            return var5;
         }
      }

      return var1;
   }
}
