import com.google.common.collect.Lists;
import java.util.List;

public abstract class bul {
   private double c;
   private double d;
   private double e;
   protected List<bxp> a = Lists.newArrayListWithCapacity(17424);
   protected boolean b;

   public void a(double var1, double var3, double var5) {
      this.b = true;
      this.a.clear();
      this.c = var1;
      this.d = var3;
      this.e = var5;
   }

   public void a(bxp var1) {
      et var2 = var1.k();
      buq.c((float)((double)var2.p() - this.c), (float)((double)var2.q() - this.d), (float)((double)var2.r() - this.e));
   }

   public void a(bxp var1, amk var2) {
      this.a.add(var1);
   }

   public abstract void a(amk var1);
}
